create materialized view MV_WAREHOUSE_DEFINE
refresh force on demand
  as
    SELECT w.*,sysdate builddate FROM v_warehouse_define w

/

