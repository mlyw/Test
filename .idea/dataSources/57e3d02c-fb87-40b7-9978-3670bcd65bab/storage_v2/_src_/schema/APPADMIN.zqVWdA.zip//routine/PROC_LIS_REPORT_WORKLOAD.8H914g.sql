create PROCEDURE proc_lis_report_Workload
AS
  exception_info VARCHAR2(3000);
BEGIN
  DELETE FROM t_lis_report_core_Workload;
  /**先删业务量统计数据重新计算**/
  COMMIT;
  INSERT
  INTO t_lis_report_core_Workload
    (
      create_date,
      bussiness_date,
      item_code,
      item_desc,
      item_id,
      item_uom_code,
      item_uom_desc,
      item_category_code,
      item_category_name,
      warehouse_define_id,
      warehouse_define_code,
      warehouse_define_desc,
      ou_id,
      organization_code,
      organization_name,
      organization_id,
      handle_onhand_quantity,
      handle_onhand_account,
      order_id,
      order_code,
      order_type,
      orderlines,
      handle_type,
      employee_name,
      ou_employee_number,
      dept_name
    )
  /**增量写入每天的出入库交易数据**/
  SELECT sysdate create_date,
    bussinessdate,
    item_code,
    item_desc,
    item_id,
    uom_code,
    uom_desc,
    concatenated_segments,
    category_description,
    warehouse_id,
    warehouse_define_code,
    warehouse_define_name,
    ou_id,
    mis_io_code,
    mis_io_name,
    mis_io_id,
    handle_onhand_quantity,
    handle_onhand_account,
    order_id,
    order_code,
    order_type,
    lines,
    handle_type,
    employee_name,
    ou_employee_number,
    dept_name
  FROM v_lis_report_work_detail_info;
  COMMIT;
  ---删除业务量统计报表中的用户信息
  DELETE FROM t_lis_report_trans_user;
  ---动态写入业务量统计报表中的用户信息
  INSERT
  INTO t_lis_report_trans_user
    (
      employee_number,
      employee_name,
      dept_name
    )
  SELECT DISTINCT(d.ou_employee_number),
    d.employee_name,
    d.dept_name
  FROM t_lis_report_core_workload d;
  COMMIT;
  --插入日志
  INSERT
  INTO i_erp_logs VALUES
    (
      i_erp_logs_seq.nextval,
      0,
      0,
      sysdate,
      '每天增量工作量数据执行成功',
      'proc_lis_report_Workload'
    );
EXCEPTION
WHEN OTHERS THEN
  exception_info := 'ERR: An error occurred with info:'||TO_CHAR(SQLCODE)||' '||sqlerrm;
  INSERT
  INTO i_erp_logs VALUES
    (
      i_erp_logs_seq.nextval,
      0,0,
      sysdate,
      exception_info,
      'proc_lis_report_Workload'
    );
  COMMIT;
END proc_lis_report_Workload;
/

