create PROCEDURE "PROC_TASK" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
parent_task_id_seq number(15);
project_id_seq number(15);
exception_info varchar2(3000);
current_id number(19);
count_project_value number(19);
cursor csr_i_erp_task is
select task_id, task_number, task_name, description, wbs_level, task_manager_num, parent_task_id, parent_task_num, start_date, completion_date, service_type_code, service_type_flag, chargeable_flag, billable_flag, cost_flag, attribute1, attribute2, attribute3, attribute4, attribute5, attribute6, creation_date, last_update_date, erp_type, import_date, ou_id, project_id, project_code, seq_id, create_date from i_erp_tasks where create_date > start_time and create_date <= end_time order by task_id asc;
i_erp_task csr_i_erp_task%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_erp_tasks where create_date > start_time and create_date <= end_time;
  open csr_i_erp_task;
  fetch csr_i_erp_task into i_erp_task;
while (csr_i_erp_task%found) loop
  current_id := i_erp_task.seq_id;
  select count(*) into count_value from t_sys_erp_tasks where task_id = i_erp_task.task_id and erp_type = i_erp_task.erp_type;
  select count(*) into count_project_value from t_sys_erp_projects where project_id = i_erp_task.project_id and erp_type = i_erp_task.erp_type;
  if(count_project_value > 0) then
  select seq_id into project_id_seq from t_sys_erp_projects where project_id = i_erp_task.project_id and erp_type = i_erp_task.erp_type;
  elsif(count_project_value = 0) then
  project_id_seq := null;
  end if;
  if(i_erp_task.parent_task_id is null) then
  parent_task_id_seq := null;
  elsif(i_erp_task.parent_task_id is not null) then
  select seq_id into parent_task_id_seq from t_sys_erp_tasks where task_id = i_erp_task.parent_task_id and erp_type = i_erp_task.erp_type order by parent_task_id desc;
  end if;
  if(count_value = 1 and i_erp_task.completion_date is null) then
      update t_sys_erp_tasks t set t.last_updated_date = sysdate,
      t.task_code = i_erp_task.task_number,
      t.task_name = i_erp_task.task_name,
      t.task_manager_num = i_erp_task.task_manager_num,
      t.project_id = project_id_seq,
      t.parent_task_id = parent_task_id_seq,
      t.start_date = i_erp_task.start_date,
      t.description = i_erp_task.description,
      t.wbs_level = i_erp_task.wbs_level,
      t.ou_id = i_erp_task.ou_id,
      t.service_type_code = i_erp_task.service_type_code,
      t.service_type_flag = i_erp_task.service_type_flag,
      t.chargeable_flag = i_erp_task.chargeable_flag,
      t.billable_flag = i_erp_task.billable_flag,
      t.cost_flag = i_erp_task.cost_flag,
      t.attribute1 = i_erp_task.attribute1,
      t.attribute2 = i_erp_task.attribute2,
      t.attribute3 = i_erp_task.attribute3,
      t.attribute4 = i_erp_task.attribute4,
      t.attribute5 = i_erp_task.attribute5,
      t.attribute6 = i_erp_task.attribute6
      where t.task_id = i_erp_task.task_id and t.erp_type = i_erp_task.erp_type;
   elsif(count_value = 1 and i_erp_task.completion_date is not null) then
   update t_sys_erp_tasks t set t.last_updated_date = sysdate,
      t.status = 0
      where t.task_id = i_erp_task.task_id;
 elsif(count_value = 0 and i_erp_task.completion_date is null and i_erp_task.task_number != 'RCV') then
insert into t_sys_erp_tasks
  (seq_id, task_id, created_date,last_updated_date, status, version, erp_type, task_code, task_name, project_id, parent_task_id, start_date, completion_date, description, wbs_level, ou_id, service_type_code, service_type_flag, chargeable_flag, billable_flag, cost_flag, task_manager_num, attribute1, attribute2, attribute3, attribute4, attribute5, attribute6)
values
  (i_erp_task.seq_id, i_erp_task.task_id, sysdate, sysdate, 1, 0, i_erp_task.erp_type, i_erp_task.task_number, i_erp_task.task_name, project_id_seq, parent_task_id_seq, i_erp_task.start_date, i_erp_task.completion_date, i_erp_task.description, i_erp_task.wbs_level, i_erp_task.ou_id, i_erp_task.service_type_code, i_erp_task.service_type_flag, i_erp_task.chargeable_flag, i_erp_task.billable_flag, i_erp_task.cost_flag, i_erp_task.task_manager_num, i_erp_task.attribute1, i_erp_task.attribute2, i_erp_task.attribute3, i_erp_task.attribute4, i_erp_task.attribute5, i_erp_task.attribute6);
  elsif(count_value = 0 and i_erp_task.completion_date is null and i_erp_task.task_number = 'RCV') then
insert into t_sys_erp_tasks
  (seq_id, task_id, created_date,last_updated_date, status, version, erp_type, task_code, task_name, project_id, parent_task_id, start_date, completion_date, description, wbs_level, ou_id, service_type_code, service_type_flag, chargeable_flag, billable_flag, cost_flag, task_manager_num, attribute1, attribute2, attribute3, attribute4, attribute5, attribute6)
values
  (i_erp_task.seq_id, i_erp_task.task_id, sysdate, sysdate, 0, 0, i_erp_task.erp_type, i_erp_task.task_number, i_erp_task.task_name, project_id_seq, parent_task_id_seq, i_erp_task.start_date, i_erp_task.completion_date, i_erp_task.description, i_erp_task.wbs_level, i_erp_task.ou_id, i_erp_task.service_type_code, i_erp_task.service_type_flag, i_erp_task.chargeable_flag, i_erp_task.billable_flag, i_erp_task.cost_flag, i_erp_task.task_manager_num, i_erp_task.attribute1, i_erp_task.attribute2, i_erp_task.attribute3, i_erp_task.attribute4, i_erp_task.attribute5, i_erp_task.attribute6);
end if;
fetch csr_i_erp_task into i_erp_task;
count_success:=count_success+1;
end loop;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_erp_tasks');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm||';seq_id='||current_id;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_erp_tasks');
close csr_i_erp_task;
commit;
end;
/

