create procedure PROC_BUDGET(start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_budget is 
select budget_id, concatenated_segments, segment1, offset_flag, sell_flag, enabled_flag, start_date_active, end_date_active, last_update_date, attribute1, attribute2, attribute3, attribute4, attribute5, segment3_desc, seq_id, segment2, segment3, segment4, segment5, segment6, segment7, segment8, segment9, segment10, segment1_desc, segment2_desc, segment4_desc, segment5_desc, segment6_desc, segment7_desc, segment8_desc, segment9_desc, segment10_desc, create_date from i_erp_budget_info where create_date > start_time and create_date < end_time;
i_budget csr_i_budget%rowtype;
begin
  count_success := 0;
  select count(seq_id) into total_value from i_erp_budget_info where create_date > start_time and create_date < end_time;
  open csr_i_budget;
  fetch csr_i_budget into i_budget;
  while(csr_i_budget%found) loop
     select count(*) into count_value from t_sys_erp_budget t where t.budget_id = i_budget.budget_id;
     if(count_value = 1 and i_budget.enabled_flag = 'Y') then
     update t_sys_erp_budget
        set 
            concatenated_segments = i_budget.concatenated_segments,
            segment1 = i_budget.segment1,
            offset_flag = i_budget.offset_flag,
            sell_flag = i_budget.sell_flag,
            start_date_active = i_budget.start_date_active,
            end_date_active = i_budget.end_date_active,
            attribute1 = i_budget.attribute1,
            attribute2 = i_budget.attribute2,
            attribute3 = i_budget.attribute3,
            attribute4 = i_budget.attribute4,
            attribute5 = i_budget.attribute5,
            segment2 = i_budget.segment2,
            segment3 = i_budget.segment3,
            segment4 = i_budget.segment4,
            segment5 = i_budget.segment5,
            segment6 = i_budget.segment6,
            segment7 = i_budget.segment7,
            segment8 = i_budget.segment8,
            segment9 = i_budget.segment9,
            segment10 = i_budget.segment10,
            segment1_desc = i_budget.segment1_desc,
            segment2_desc = i_budget.segment2_desc,
            segment3_desc = i_budget.segment3_desc,
            segment4_desc = i_budget.segment4_desc,
            segment5_desc = i_budget.segment5_desc,
            segment6_desc = i_budget.segment6_desc,
            segment7_desc = i_budget.segment7_desc,
            segment8_desc = i_budget.segment8_desc,
            segment9_desc = i_budget.segment9_desc,
            segment10_desc = i_budget.segment10_desc,
            last_updated_date = i_budget.last_update_date
      where budget_id = i_budget.budget_id;     
     elsif(count_value = 1 and i_budget.enabled_flag = 'N') then
     update t_sys_erp_budget
        set status = 0
      where budget_id = i_budget.budget_id;
     elsif(count_value = 0 and i_budget.enabled_flag = 'Y') then
     insert into t_sys_erp_budget
     (budget_id, concatenated_segments, segment1, offset_flag, sell_flag, start_date_active, end_date_active, attribute1, attribute2, attribute3, attribute4, attribute5, segment2, segment3, segment4, segment5, segment6, segment7, segment8, segment9, segment10, segment1_desc, segment2_desc, segment3_desc, segment4_desc, segment5_desc, segment6_desc, segment7_desc, segment8_desc, segment9_desc, segment10_desc, seq_id, version, created_date, last_updated_date, status, erp_type)
      values
     (i_budget.budget_id, i_budget.concatenated_segments, i_budget.segment1, i_budget.offset_flag, i_budget.sell_flag, i_budget.start_date_active, i_budget.end_date_active, i_budget.attribute1, i_budget.attribute2, i_budget.attribute3, i_budget.attribute4, i_budget.attribute5, i_budget.segment2, i_budget.segment3, i_budget.segment4, i_budget.segment5, i_budget.segment6, i_budget.segment7, i_budget.segment8, i_budget.segment9, i_budget.segment10, i_budget.segment1_desc, i_budget.segment2_desc, i_budget.segment3_desc, i_budget.segment4_desc, i_budget.segment5_desc, i_budget.segment6_desc, i_budget.segment7_desc, i_budget.segment8_desc, i_budget.segment9_desc, i_budget.segment10_desc, SEQ_SYS_ERP_BUDGET.NEXTVAL, 0, sysdate, i_budget.last_update_date, 1, '2G');
     end if;
        fetch csr_i_budget into i_budget;
  end loop;
  close csr_i_budget; 
end;
/

