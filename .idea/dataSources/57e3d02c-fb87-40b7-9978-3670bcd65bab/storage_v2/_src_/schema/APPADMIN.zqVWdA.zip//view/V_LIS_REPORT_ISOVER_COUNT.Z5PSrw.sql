create view V_LIS_REPORT_ISOVER_COUNT as
  SELECT
    /**呆滞物资占比报表原始数据视图*/
    o.mis_ou_id ou_id,
    o.mis_io_id organization_id,
    o.warehouse_define_id,
    (o.mis_io_code  || ' ' || o.mis_io_name) orginfo,
    (o.warehouse_define_code || ' ' || o.warehouse_define_name) warehouseinfo,
    o.concatenated_segments item_category_code,
    o.category_description item_category_name,
    o.item_id,
    o.item_code,
    o.item_desc,
    o.uom_code item_uom_code,
    o.uom_desc item_uom_desc,
    NVL(o.item_quantity,0) item_quantity,
    NVL(o.item_account,0) item_account,
    NVL(overall.over_item_account,0) over_item_account,
    NVL(to9.over_7to9_account,0) over_7to9_account ,
    NVL(to10.over_10to12_account,0) over_10to12_account,
    NVL(to13.over_13to18_account,0) over_13to18_account,
    NVL(to24.over_19to24_account,0) over_19to24_account,
    NVL(to25.over_25more_account,0) over_25more_account
  FROM v_lis_report_qty_item_now o
  LEFT JOIN v_lis_report_qty_isover overall
  ON o.mis_ou_id               =overall.ou_id
  AND o.mis_io_id              =overall.organization_id
  AND o.warehouse_define_id    =overall.warehouse_define_id
  AND o.item_id                =overall.item_id
  AND o.item_code              =overall.item_code
  AND o.item_desc              =overall.item_desc
  AND o.uom_code               =overall.item_uom_code
  AND o.uom_desc               =overall.item_uom_desc
  LEFT JOIN v_lis_report_qty_isover_7to9 to9
  ON o.mis_ou_id               =to9.ou_id
  AND o.mis_io_id              =to9.organization_id
  AND o.warehouse_define_id    =to9.warehouse_define_id
  AND o.item_id                =to9.item_id
  AND o.item_code              =to9.item_code
  AND o.item_desc              =to9.item_desc
  AND o.uom_code               =to9.item_uom_code
  AND o.uom_desc               =to9.item_uom_desc
  LEFT JOIN v_lis_report_qty_isover_10to12 to10
  ON o.mis_ou_id               =to10.ou_id
  AND o.mis_io_id              =to10.organization_id
  AND o.warehouse_define_id    =to10.warehouse_define_id
  AND o.item_id                =to10.item_id
  AND o.item_code              =to10.item_code
  AND o.item_desc              =to10.item_desc
  AND o.uom_code               =to10.item_uom_code
  AND o.uom_desc               =to10.item_uom_desc
  LEFT JOIN v_lis_report_qty_isover_13to18 to13
  ON o.mis_ou_id               =to13.ou_id
  AND o.mis_io_id              =to13.organization_id
  AND o.warehouse_define_id    =to13.warehouse_define_id
  AND o.item_id                =to13.item_id
  AND o.item_code              =to13.item_code
  AND o.item_desc              =to13.item_desc
  AND o.uom_code               =to13.item_uom_code
  AND o.uom_desc               =to13.item_uom_desc
  LEFT JOIN v_lis_report_qty_isover_19to24 to24
  ON o.mis_ou_id               =to24.ou_id
  AND o.mis_io_id              =to24.organization_id
  AND o.warehouse_define_id    =to24.warehouse_define_id
  AND o.item_id                =to24.item_id
  AND o.item_code              =to24.item_code
  AND o.item_desc              =to24.item_desc
  AND o.uom_code               =to24.item_uom_code
  AND o.uom_desc               =to24.item_uom_desc
  LEFT JOIN v_lis_report_qty_isover_25more to25
  ON o.mis_ou_id               =to25.ou_id
  AND o.mis_io_id              =to25.organization_id
  AND o.warehouse_define_id    =to25.warehouse_define_id
  AND o.item_id                =to25.item_id
  AND o.item_code              =to25.item_code
  AND o.item_desc              =to25.item_desc
  AND o.uom_code               =to25.item_uom_code
  AND o.uom_desc               =to25.item_uom_desc
/

