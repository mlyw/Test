create trigger TRIGGER_WAREHOUSE_INFO_AREA
  before insert or update
  on T_WAREHOUSE_DEFINE
  for each row
  declare
    v_org_count   number;---符合库存组织要求的数量
    v_old_count   number;---旧数量
    v_area_id     number;---仓库占用面积id
    exception_info varchar2(3000 BYTE);--异常信息
begin
    v_old_count:= 0;
    v_org_count:=0;
    select count(o.ORGANIZATION_ID) into v_org_count from v_sys_erp_organizations o where o.ORGANIZATION_ID=:new.mis_io_id and o.IS_STRAIGHT=0;
    if(:new.category_id != 209 and v_org_count!=0 and :new.parent_warehouse_id is not null and :new.mis_subinventoey_id is not null ) then
      select count(id) into v_old_count from t_warehouse_define_area where warehouse_code=:new.warehouse_define_code;
      if (v_old_count > 0) then
        update t_warehouse_define_area
        set status = :new.status,string_value1 = 'trigger_warehouse_info_area触发器自动同步更新,version=' || (version+1),version =  version+1
        where warehouse_code = :new.warehouse_define_code;
      else
        select s_warehouse_define.nextval into v_area_id from dual;
        insert into t_warehouse_define_area
        (id,status,string_value1,version,occupy_area, areainfo, order_status, warehouse_id, warehouse_code)
        values
        (v_area_id,1,'trigger_warehouse_info_area触发器自动同步新增',1,150,200,1,:new.id,:new.warehouse_define_code);
      end if;
    end if;
  ---插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,1,1,sysdate,'同步成功;' ||:new.warehouse_define_code ,'trigger_warehouse_info_area:t_warehouse_define->t_warehouse_define_area');
exception when others then
  exception_info := 'trigger_warehouse_info_area:'||:new.warehouse_define_code||' An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,1,1,sysdate,exception_info,'trigger_warehouse_info_area:t_warehouse_define->t_warehouse_define_area');
end TRIGGER_WAREHOUSE_INFO_AREA;
/

