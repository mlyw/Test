create PROCEDURE proc_lis_report_trans_vendor(
    executedate DATE)
AS
  exception_info VARCHAR2(3000);
  v_date date;
  pre_count number(15);---执行前条数
  aft_count number(15);---执行后条数
BEGIN
  if (executedate is null) then 
    v_date:=to_date(to_char(sysdate,'yyyy-mm-dd'),'yyyy-MM-dd');
   else
     v_date:=executedate;
  end if;
  select count(*) into pre_count from t_lis_report_core_trans_vendor;
  INSERT INTO t_lis_report_core_trans_vendor
  /**增量写入每天的出入库交易数据**/
  SELECT v_date create_date,
    (v_date-1) bussiness_date,
    '' string_value1,
    1 status,
    1 version,
    tmp.item_code,
    tmp.item_desc,
    tmp.item_id,
    tmp.uom_code,
    tmp.uom_desc,
    tmp.concatenated_segments,
    tmp.category_description,
    tmp.warehouse_id,
    w.warehouse_define_code,
    w.warehouse_define_name,
    w.mis_ou_id,
    w.mis_ou_name,
    w.mis_io_code,
    w.mis_io_name,
    w.mis_io_id,
    SUM(NVL(tmp.current_receive_quantity,0)) current_receive_quantity,
    SUM(NVL(tmp.current_receive_account,0)) current_receive_account,
    SUM(NVL(tmp.current_out_quantity,0)) current_out_quantity,
    SUM(NVL(tmp.current_out_account,0)) current_out_account,
    tmp.order_id,
    tmp.order_code,
    tmp.order_type,
    tmp.vendor_name,
    tmp.vendor_id
  FROM
    (SELECT item_id,
      warehouse_receive_id warehouse_id,
      vendor_id,
      vendor_name,
      item_code,
      item_desc,
      uom_code,
      uom_desc,
      concatenated_segments,
      category_description,
      order_id,
      order_code,
      order_type,
      SUM(current_receive_quantity) current_receive_quantity,
      SUM(current_receive_account) current_receive_account,
      0 current_out_quantity,
      0 current_out_account
    FROM V_LIS_REPORT_vendor_into
    WHERE vendor_id                     IS NOT NULL
    AND TO_CHAR(import_date,'yyyy-MM-dd')=TO_CHAR((v_date-1),'yyyy-MM-dd')
    GROUP BY item_id,
      warehouse_receive_id,
      vendor_id,
      vendor_name,
      item_code,
      item_desc,
      uom_code,
      uom_desc,
      concatenated_segments,
      category_description,
      order_id,
      order_code,
      order_type
    UNION ALL
    SELECT item_id,
      warehouse_out_id warehouse_id,
      vendor_id,
      vendor_name,
      item_code,
      item_desc,
      uom_code,
      uom_desc,
      concatenated_segments,
      category_description,
      order_id,
      order_code,
      order_type,
      0 current_receive_quantity,
      0 current_receive_account,
      SUM(current_out_quantity) current_out_quantity,
      SUM(current_out_account) current_out_account
    FROM V_LIS_REPORT_vendor_out
    WHERE vendor_id                     IS NOT NULL
    AND TO_CHAR(import_date,'yyyy-MM-dd')=TO_CHAR((v_date-1),'yyyy-MM-dd')
    GROUP BY item_id,
      warehouse_out_id,
      vendor_id,
      vendor_name,
      item_code,
      item_desc,
      uom_code,
      uom_desc,
      concatenated_segments,
      category_description,
      order_id,
      order_code,
      order_type
    ) tmp,
    mv_warehouse_define w
  WHERE tmp.warehouse_id=w.id
  GROUP BY tmp.item_id,
    w.mis_ou_id,
    w.mis_io_id,
    tmp.warehouse_id,
    tmp.item_code,
    tmp.item_desc,
    tmp.uom_code,
    tmp.uom_desc,
    tmp.concatenated_segments,
    tmp.category_description,
    w.warehouse_define_code,
    w.warehouse_define_name,
    w.mis_ou_name,
    w.mis_io_code,
    w.mis_io_name,
    tmp.order_id,
    tmp.order_code,
    tmp.order_type,
    tmp.vendor_name,
    tmp.vendor_id;
  COMMIT;
  select count(*) into aft_count from t_lis_report_core_trans_vendor; 
  --插入日志
  INSERT
  INTO i_erp_logs VALUES
    (
      i_erp_logs_seq.nextval,
      pre_count,
      aft_count,
      sysdate,
      '每天增量供应商交易数据执行成功',
      'proc_lis_report_trans_vendor'
    );
EXCEPTION
WHEN OTHERS THEN
  exception_info := 'ERR: An error occurred with info:'||TO_CHAR(SQLCODE)||' '||sqlerrm;
  INSERT
  INTO i_erp_logs VALUES
    (
      i_erp_logs_seq.nextval,
      pre_count,0,
      sysdate,
      exception_info,
      'proc_lis_report_trans_vendor'
    );
  COMMIT;
END proc_lis_report_trans_vendor;
/

