create view V_WAREHOUSE_DEFINE_BY_PURCHASE as
  SELECT
  /**业务量统计专用子库视图*/
    w."ID",
    w."CREATED_DATE",
    w."CREATED_USER",
    w."DATE_VALUE1",
    w."LAST_UPDATED_DATE",
    w."LAST_UPDATED_USER",
    w."NUMBER_VALUE1",
    w."STATUS",
    w."STRING_VALUE1",
    w."VERSION",
    w."MIS_IO_CODE",
    w."MIS_IO_ID",
    w."MIS_IO_NAME",
    w."MIS_LOCATION_DESC",
    w."MIS_LOCATION_ID",
    w."MIS_OU_ID",
    w."MIS_OU_NAME",
    w."MIS_SUBINVENTOEY_TYPE",
    w."MIS_SUBINVENTORY_DESC",
    w."MIS_SUBINVENTORY_NAME",
    w."MIS_LOCATION_CODE",
    w."VOI_VMI_FLAG",
    w."WAREHOUSE_ADDRESS",
    w."WAREHOUSE_CAPITAL_TYPE",
    w."WAREHOUSE_DEFINE_CODE",
    w."WAREHOUSE_DEFINE_NAME",
    w."WAREHOUSE_FULL_CODE",
    w."WAREHOUSE_FULL_NAME",
    w."WAREHOUSE_LEVEL",
    w."WAREHOUSE_NOTES",
    w."CATEGORY_ID",
    w."PARENT_WAREHOUSE_ID",
    w."MIS_SUBINVENTOEY_ID",
    w."IS_STORAGE",
    w."IS_NEW",
    w."OTHERS",
    w."DEPT_ID",
    w."VENDOR_ID",
    w."LONGITUDE",
    w."LATITUDE",
    w."VALID_STATUS",
    w."APPROVE_STATUS",
    w."REVERSE_STATUS",
    w."APPROVE_HEADER_ID"
  FROM t_warehouse_category c,
    t_warehouse_define w,
    t_sys_erp_organizations s
  WHERE c.code               ='01'
  AND w.category_id          =c.id
  AND w.status               =1
  AND c.status               =1
  AND w.parent_warehouse_id IS NOT NULL
  AND w.mis_io_id            =s.ORGANIZATION_ID
  AND s.organization_code   IN ('BJP','BJE','BJC','BJO','HJE','10E','BJR','BJF','10F','HJF')
/

