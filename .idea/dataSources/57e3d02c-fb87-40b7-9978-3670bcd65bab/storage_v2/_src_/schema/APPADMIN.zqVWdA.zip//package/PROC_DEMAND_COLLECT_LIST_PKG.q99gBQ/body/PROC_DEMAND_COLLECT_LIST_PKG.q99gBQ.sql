create package body proc_demand_collect_list_pkg is
  procedure proc_demand_collect_list(erpTypeVO in varchar2,pageno in number,pagesize in number,taskcode in varchar2,taskfounder in varchar2,supplymode in varchar2,materialcode in varchar2,materialdesc in varchar2,flag in varchar2,
       temp_list out cur_proc_demand_collect_list,total out number)

   AS
  begin
    /* 每次执行存储过程时,删除表中所有的数据 */
    delete from temp_demand_collect_list;

    --(1)向需求汇总查询临时表插入物料组信息的数据(预计使用量,突发值,最大库容量,现有量,库存可用量,已采购未到货数量)   wjr
    insert into temp_demand_collect_list
      (sys_name,
       common_name,
       common_desc,
       common_unit,
       high_val,
       low_val,
       onhand_qty,
       common_id,
       item_type_code,
       next_one_month_qty,
       next_two_month_qty,
       next_tri_month_qty,
       reserve_qty,
       unreceivable_qty,
       next_one_month_expqty,
       next_two_month_expqty,
       next_tri_month_expqty,
       collect_line_id)
      select sysinfo.sys_name,
             itemgroup.item_group_name,
             itemgroup.item_group_code,
             itemgroup.item_group_unit,
             itemval.highval,
             itemval.lowval,
             itemval.onhandqty,
             dee.item_id,
             dee.item_type_code,
             dee.next_one_month_qty,
             dee.next_two_month_qty,
             dee.next_tri_month_qty,
             itemval.reserveQty,
             itemval.unrecevableQty,
             expectdemand.next_one_Month_expQty,
             expectdemand.next_two_Month_expQty,
             expectdemand.next_two_Month_expQty,
             dee.collect_line_id
        from (select de.item_id,
                     de.item_type_code,
                     de.collect_line_id,
                     sum(decode(de.collect_month,
                                to_char(add_months(trunc(sysdate), 1),
                                        'yyyy-mm'),
                                de.collect_ALL_qty,
                                null)) next_one_Month_qty,
                     sum(decode(de.collect_month,
                                to_char(add_months(trunc(sysdate), 2),
                                        'yyyy-mm'),
                                de.collect_ALL_qty,
                                null)) next_two_month_qty,
                     sum(decode(de.collect_month,
                                to_char(add_months(trunc(sysdate), 3),
                                        'yyyy-mm'),
                                de.collect_ALL_qty,
                                null)) next_tri_month_qty
                from (select deptde.collect_line_id,
                             deptde.item_type_code,
                             deptde.item_id,
                             deptde.collect_month,
                             sum(deptde.collect_qty) collect_ALL_qty
                        from T_LIS_DEPART_DEMAND deptde
                       group by deptde.collect_month,
                                deptde.item_id,
                                deptde.item_type_code,
                                deptde.collect_line_id) de
               group by de.item_id, de.item_type_code, de.collect_line_id) dee
        left join t_lis_sys_info sysinfo
          on dee.item_type_code = sysinfo.sys_code
        left join t_lis_itemgroup_head itemgroup
          on itemgroup.id = dee.item_id
        left join (select m.item_group_headid,
                          MAX(ssms.Threshold_Value_High) HighVal,
                          MAX(ssms.Threshold_Value_Low) LowVal,
                          sum(onqty.onqt) onhandqty,
                          sum(onqty.resQty) reserveQty,
                          sum(basespm.rece) unrecevableQty
                     from (select t.item_id, t.item_group_headid
                             from t_lis_itemgroup_line t
                            where t.item_group_headid in
                                  (select t.item_id
                                     from t_lis_depart_demand t
                                    where t.item_type_code = 'item_group'
                                    group by t.item_id)) m
                    left join T_Safety_Stock_Material_Setup ssms on ssms.Item_Group_Id=m.item_group_headid --根据物料id 查出最大库存量和安全库存 在根据物料组求和 wjr
                     left join (select Wq.Item_Id,sum(nvl(round(Wq.Onhand_Quantity/Igl.Convert_Ratio,5),0)) onqt,sum(nvl(round(r.rq/Igl.Convert_Ratio,5),0)) resQty
                                from T_Wh_Current_Onhand_Quantity wq
                                  join T_Lis_Itemgroup_Line igl on Igl.Item_Id=Wq.Item_Id and Igl.Status = 1 --统计包含在物料组中的物料即可
                                  left join (
                                    select Info.Onhand_Id, sum(nvl(Info.Reserve_Quantity,0)) rq from T_Sys_Item_Resereve_Info info 
                                    where Info.Status = 1 and Info.Reserve_End_Day > sysdate
                                    group by Info.Onhand_Id
                                  ) r on R.Onhand_Id=wq.id
                                where Wq.Onhand_Quantity > 0 and Wq.Status = 1  and Wq.Erp_Type=erpTypeVO
                                and exists (
                                    SELECT 1
                                    FROM T_Warehouse_Define wd JOIN T_WAREHOUSE_CATEGORY twc ON wd.CATEGORY_ID = twc.id AND Twc.Code ='01' AND Twc.Status =1
                                    WHERE Wd.Warehouse_Define_Code NOT IN(SELECT * FROM t_lis_un_wa) AND Wd.Status =1 AND wq.warehouse_define_id = wd.id
                                    START WITH Wd.Parent_Warehouse_Id IN
                                    (SELECT wd.id FROM T_Warehouse_Define wd
                                    WHERE Wd.Warehouse_Define_Code in
                                    (SELECT Org.Organization_Code FROM T_Lis_Item_Type lit JOIN T_Sys_Erp_Organizations org
                                    ON Org.Organization_Id=Lit.Organazation_Id
                                    AND Org.Status  = 1  ) )
                                    CONNECT BY PRIOR wd.id=Wd.Parent_Warehouse_Id
                                    )
                                group by Wq.Item_Id
                     /*select onq.item_id,
                                      sum(onq.onhand_quantity) onqt,
                                      sum(onq.reserve_quantity) resQty --取得所有物料的现有量和冻结量  在根据物料id 分组求和   wjr
                                 from (select res.reserve_quantity, t.*
                                         from T_WH_CURRENT_ONHAND_QUANTITY t
                                         left join t_sys_item_resereve_info res
                                           on res.onhand_id = t.id
                                        where t.erp_type = '2G') onq
                                where onq.warehouse_define_id in
                                      (select t.id
                                         from t_warehouse_define t
                                         left join t_warehouse_category ware_cate
                                           on t.category_id = ware_cate.id
                                        where t.status = 1
                                          and ware_cate.code = '01'
                                          and ware_cate.status = 1)
                                  and onq.erp_type = '2G'
                                group by onq.item_id*/) onqty
                       on onqty.item_id = m.item_id
                     left join (select base.item_id,
                                      sum(round(base.quantity_receivable/Igl.Convert_Ratio,5)) rece --取得所有的物料的未到货数量 求和  wjr
                                 from t_base_spm_pur_order_lines base
                                  join T_Lis_Itemgroup_Line igl on Igl.Item_Id=base.item_id and Igl.Status = 1
                                --where base.erp_type = erpTypeVO
                                group by base.item_id) basespm
                       on basespm.item_id = m.item_id
                    group by m.item_group_headid) itemval
          on itemval.item_group_headid = dee.item_id
        left join ( --已当前月份为基础,取得下三个月份的突发值 和 item_id(item_id,product_id,item_group_id)  wjr
                   select exde.item_id,
                           sum(decode(exde.expectdate,
                                      to_char(add_months(trunc(sysdate), 1),
                                              'yyyy-mm'),
                                      exde.exdemand,
                                      null)) next_one_Month_expQty,
                           sum(decode(exde.expectdate,
                                      to_char(add_months(trunc(sysdate), 2),
                                              'yyyy-mm'),
                                      exde.exdemand,
                                      null)) next_two_Month_expQty,
                           sum(decode(exde.expectdate,
                                      to_char(add_months(trunc(sysdate), 3),
                                              'yyyy-mm'),
                                      exde.exdemand,
                                      null)) next_tri_Month_expQty
                     from (select expectde.item_id,
                                   expectde.expectdate,
                                   sum(expectde.expect_demand) exdemand
                              from (select line.item_type_code,
                                           line.item_id,
                                           line.expect_demand,
                                           to_char(line.expect_date, 'yyyy-mm') expectdate
                                      from t_lis_sudden_demand_head head
                                      left join t_lis_sudden_demand_line line
                                        on head.id = line.sudden_head_id
                                     where head.head_status = 3
                                       and line.item_type_code = 'item_group'
                                       and head.erp_type = erpTypeVO) expectde
                             group by expectde.item_id, expectde.expectdate) exde
                    group by exde.item_id) expectdemand
          on expectdemand.item_id = dee.item_id
       where sysinfo.category = 'item_category'
         and dee.item_type_code = 'item_group';
    commit;

    -- (2)向需求汇总临时表中  插入物料的信息((预计使用量,突发值,最大库容量,现有量,库存可用量,已采购未到货数量)) wjr
    insert into temp_demand_collect_list
      (sys_name,
       common_name,
       common_desc,
       common_unit,
       high_val,
       low_val,
       onhand_qty,
       common_id,
       item_type_code,
       next_one_month_qty,
       next_two_month_qty,
       next_tri_month_qty,
       reserve_qty,
       unreceivable_qty,
       next_one_month_expqty,
       next_two_month_expqty,
       next_tri_month_expqty,
       collect_line_id)
      select sysinfo.sys_name,
             item.item_name,
             item.item_code,
             item.uom_desc,
             ssms.Threshold_Value_High high_val,
             ssms.Threshold_Value_Low low_val,
             onqty.onqt,
             dee.item_id,
             dee.item_type_code,
             dee.next_one_month_qty,
             dee.next_two_month_qty,
             dee.next_tri_month_qty,
             onqty.reserveQty,
             receive.rece,
             expectdemand.next_one_Month_expQty,
             expectdemand.next_two_Month_expQty,
             expectdemand.next_tri_Month_expQty,
             dee.collect_line_id
        from (select de.item_id,
                     de.item_type_code,
                     de.collect_line_id,
                     sum(decode(de.collect_month,
                                to_char(add_months(trunc(sysdate), 1),
                                        'yyyy-mm'),
                                de.collect_ALL_qty,
                                null)) next_one_Month_qty,
                     sum(decode(de.collect_month,
                                to_char(add_months(trunc(sysdate), 2),
                                        'yyyy-mm'),
                                de.collect_ALL_qty,
                                null)) next_two_month_qty,
                     sum(decode(de.collect_month,
                                to_char(add_months(trunc(sysdate), 3),
                                        'yyyy-mm'),
                                de.collect_ALL_qty,
                                null)) next_tri_month_qty
                from (select t.collect_line_id,
                             t.item_type_code,
                             t.item_id,
                             t.collect_month,
                             sum(t.collect_qty) collect_ALL_qty
                        from T_LIS_DEPART_DEMAND t
                       group by t.collect_month,
                                t.item_id,
                                t.item_type_code,
                                t.collect_line_id) de
               group by de.item_id, de.item_type_code, de.collect_line_id) dee
        left join t_lis_sys_info sysinfo
          on dee.item_type_code = sysinfo.sys_code
        left join t_sys_erp_items item
          on item.seq_id = dee.item_id
        left join T_Safety_Stock_Material_Setup ssms on ssms.item_id = dee.item_id --根据物料id 查出最大库存量和安全库存
        left join (select onq.item_id,
                          sum(onq.onhand_quantity) onqt,
                          sum(onq.reserve_quantity) reserveQty --根据物料求所有的现有的量和冻结数量
                     from (select res.reserve_quantity, t.*
                             from T_WH_CURRENT_ONHAND_QUANTITY t
                             left join t_sys_item_resereve_info res
                               on res.onhand_id = t.id
                            where t.erp_type = erpTypeVO) onq
                    where onq.warehouse_define_id in
                          (select t.id
                             from t_warehouse_define t
                             left join t_warehouse_category ware_cate
                               on t.category_id = ware_cate.id
                            where t.status = 1
                              and ware_cate.code = '01'
                              and ware_cate.status = 1)
                      and onq.erp_type = erpTypeVO
                    group by onq.item_id) onqty
          on onqty.item_id = dee.item_id
        left join (select base.item_id, sum(base.quantity_receivable) rece --取得物料的未到货数量
                     from t_base_spm_pur_order_lines base
                   -- where base.erp_type = erpTypeVO
                    group by base.item_id) receive
          on receive.item_id = dee.item_id
        left join ( --取得已当前月份为基础  下三个月份的突发需求值
                   select exde.item_id,
                           sum(decode(exde.expectdate,
                                      to_char(add_months(trunc(sysdate), 1),
                                              'yyyy-mm'),
                                      exde.exdemand,
                                      null)) next_one_Month_expQty,
                           sum(decode(exde.expectdate,
                                      to_char(add_months(trunc(sysdate), 2),
                                              'yyyy-mm'),
                                      exde.exdemand,
                                      null)) next_two_Month_expQty,
                           sum(decode(exde.expectdate,
                                      to_char(add_months(trunc(sysdate), 3),
                                              'yyyy-mm'),
                                      exde.exdemand,
                                      null)) next_tri_Month_expQty
                     from (select expectde.item_id,
                                   expectde.expectdate,
                                   sum(expectde.expect_demand) exdemand
                              from (select line.item_type_code,
                                           line.item_id,
                                           line.expect_demand,
                                           to_char(line.expect_date, 'yyyy-mm') expectdate
                                      from t_lis_sudden_demand_head head
                                      left join t_lis_sudden_demand_line line
                                        on head.id = line.sudden_head_id
                                     where head.head_status = 3
                                       and line.item_type_code = 'item_code'
                                       and head.erp_type = erpTypeVO) expectde
                             group by expectde.item_id, expectde.expectdate) exde
                    group by exde.item_id) expectdemand
          on expectdemand.item_id = dee.item_id
       where sysinfo.category = 'item_category'
         and dee.item_type_code = 'item_code';
    commit;

    -- (3)向需求汇总临时表中  插入产品的信息((预计使用量,突发值,最大库容量,现有量,库存可用量,已采购未到货数量)) wjr
      insert into temp_demand_collect_list
      (sys_name,
       common_name,
       common_desc,
       common_unit,
       high_val,
       low_val,
       onhand_qty,
       common_id,
       item_type_code,
       next_one_month_qty,
       next_two_month_qty,
       next_tri_month_qty,
       reserve_qty,
       unreceivable_qty,
       next_one_month_expqty,
       next_two_month_expqty,
       next_tri_month_expqty,
       collect_line_id)
      select sysinfo.sys_name,
             product.product_name,
             product.product_code,
             product.uom_desc,
             stock.high_val,
             stock.low_val,
             onqty.onqt,
             dee.item_id,
             dee.item_type_code,
             dee.next_one_month_qty,
             dee.next_two_month_qty,
             dee.next_tri_month_qty,
             onqty.reserveQty,
             receivable.rece,
             expectdemand.next_one_Month_expQty,
             expectdemand.next_two_Month_expQty,
             expectdemand.next_tri_Month_expQty,
             dee.collect_line_id
        from (select de.item_id,
                     de.item_type_code,
                     de.collect_line_id,
                     sum(decode(de.collect_month,
                                to_char(add_months(trunc(sysdate), 1),
                                        'yyyy-mm'),
                                de.collect_ALL_qty,
                                null)) next_one_Month_qty,
                     sum(decode(de.collect_month,
                                to_char(add_months(trunc(sysdate), 2),
                                        'yyyy-mm'),
                                de.collect_ALL_qty,
                                null)) next_two_month_qty,
                     sum(decode(de.collect_month,
                                to_char(add_months(trunc(sysdate), 3),
                                        'yyyy-mm'),
                                de.collect_ALL_qty,
                                null)) next_tri_month_qty
                from (select t.collect_line_id,
                             t.item_type_code,
                             t.item_id,
                             t.collect_month,
                             sum(t.collect_qty) collect_ALL_qty
                        from T_LIS_DEPART_DEMAND t
                       group by t.collect_month,
                                t.item_id,
                                t.item_type_code,
                                t.collect_line_id) de
               group by de.item_id, de.item_type_code, de.collect_line_id) dee
        left join t_lis_sys_info sysinfo
          on dee.item_type_code = sysinfo.sys_code
        left join t_sys_spm_products product
          on product.Seq_Id = dee.item_id
        left join t_safety_stock_alarm_notice stock
          on stock.product_id = dee.item_id --根据产品id去查询最大库存量和安全库存
        left join (select onq.product_id,
                          sum(onq.onhand_quantity) onqt,
                          sum(onq.reserve_quantity) reserveQty --取得产品的库存的可以量和冻结数量
                     from (select res.reserve_quantity, t.*
                             from T_WH_CURRENT_ONHAND_QUANTITY t
                             left join t_sys_item_resereve_info res
                               on res.onhand_id = t.id
                            where t.erp_type = '2G') onq
                    where onq.warehouse_define_id in
                          (select t.id
                             from t_warehouse_define t
                             left join t_warehouse_category ware_cate
                               on t.category_id = ware_cate.id
                            where t.status = 1
                              and ware_cate.code = '01'
                              and ware_cate.status = 1)
                      and onq.erp_type = '2G'
                    group by onq.product_id) onqty
          on onqty.product_id = dee.item_id
        left join (select base.product_id,
                          sum(base.quantity_receivable) rece --取得产品的未到货数量
                     from t_base_spm_pur_order_lines base
                   -- where base.erp_type = '2G'
                    group by base.product_id) receivable
          on receivable.product_id = dee.item_id
        left join ( --取得产品下三个月的突发需求值
                   select exde.item_id,
                           sum(decode(exde.expectdate,
                                      to_char(add_months(trunc(sysdate), 1),
                                              'yyyy-mm'),
                                      exde.exdemand,
                                      null)) next_one_Month_expQty,
                           sum(decode(exde.expectdate,
                                      to_char(add_months(trunc(sysdate), 2),
                                              'yyyy-mm'),
                                      exde.exdemand,
                                      null)) next_two_Month_expQty,
                           sum(decode(exde.expectdate,
                                      to_char(add_months(trunc(sysdate), 3),
                                              'yyyy-mm'),
                                      exde.exdemand,
                                      null)) next_tri_Month_expQty
                     from (select expectde.item_id,
                                   expectde.expectdate,
                                   sum(expectde.expect_demand) exdemand
                              from (select line.item_type_code,
                                           line.item_id,
                                           line.expect_demand,
                                           to_char(line.expect_date, 'yyyy-mm') expectdate
                                      from t_lis_sudden_demand_head head
                                      left join t_lis_sudden_demand_line line
                                        on head.id = line.sudden_head_id
                                     where head.head_status = 3
                                       and line.item_type_code = 'prod_code'
                                       and head.erp_type = '2G') expectde
                             group by expectde.item_id, expectde.expectdate) exde
                    group by exde.item_id) expectdemand
          on expectdemand.item_id = dee.item_id
       where sysinfo.category = 'item_category'
         and dee.item_type_code = 'prod_code';
    commit;


    if flag='N' then
    open temp_list for  select l.sys_name sysName,
                               l.common_name commonName,
                               l.common_desc commonDesc,
                               l.common_unit commonUnit,
                               MAX(l.high_val) high_Val,
                               MAX(l.low_val) low_Val,
                               MAX(l.onhand_qty) onhand_Qty,
                               l.common_id commonId,
                               sum(l.next_one_month_qty) next_one_month_qty,
                               sum(l.next_two_month_qty) next_two_month_qty,
                               sum(l.next_tri_month_qty) next_tri_month_qty,
                               MAX(l.reserve_qty) reserve_qty,
                               MAX(l.unreceivable_qty) unreceivable_qty,
                               sum(l.next_one_month_expqty) next_one_month_expqty,
                               sum(l.next_two_month_expqty) next_two_month_expqty,
                               sum(l.next_tri_month_expqty) next_tri_month_expqty
                          FROM temp_demand_collect_list l
                          left join (select line.id,
                                            t.created_user,
                                            u.employee_name,
                                            t.if_add,
                                            t.collect_head_code,
                                            t.status
                                       FROM t_lis_demand_collect_head t
                                       left join t_lis_demand_collect_line line
                                         on t.id = line.collect_headid
                                       left join t_lis_user u
                                         on u.employee_number = t.created_user
                                      where t.erp_type = erpTypeVO) d
                            on d.id = l.collect_line_id
                         where d.status = 1
                         group by l.sys_name,
                                  l.common_name,
                                  l.common_desc,
                                  l.common_unit,
                                  l.common_id;
    else 
      open temp_list for SELECT B.*
       FROM (select A.*, ROWNUM RN
               FROM (select l.sys_name sysName,
                            l.common_name commonName,
                            l.common_desc commonDesc,
                            l.common_unit commonUnit,
                            MAX(l.high_val) high_val,
                            MAX(l.low_val) low_val,
                            MAX(l.onhand_qty) onhand_qty,
                            l.common_id commonId,
                            sum(l.next_one_month_qty) next_one_month_qty,
                            sum(l.next_two_month_qty) next_two_month_qty,
                            sum(l.next_tri_month_qty) next_tri_month_qty,
                            MAX(l.reserve_qty) reserve_qty,
                            MAX(l.unreceivable_qty) unreceivable_qty,
                            sum(l.next_one_month_expqty) next_one_month_expqty,
                            sum(l.next_two_month_expqty) next_two_month_expqty,
                            sum(l.next_tri_month_expqty) next_tri_month_expqty
                       FROM temp_demand_collect_list l
                       left join (select line.id,
                                        head.created_user,
                                        u.employee_name,
                                        head.if_add,
                                        head.collect_head_code,
                                        head.status
                                   FROM t_lis_demand_collect_head head
                                   left join t_lis_demand_collect_line line
                                     on head.id = line.collect_headid
                                   left join t_lis_user u
                                     on u.employee_number = head.created_user
                                  where head.erp_type = erpTypeVO) d
                         on d.id = l.collect_line_id
                      where d.status = 1
                        and d.collect_head_code like  '%'|| nvl(taskcode, '')||'%'
                        and d.employee_name like '%'|| nvl(taskfounder, '')||'%'
                        and d.if_add like '%'|| nvl(supplymode, '')||'%'
                        and l.common_desc like '%'|| nvl(materialcode, '')||'%'
                        and l.common_name like '%'|| nvl(materialdesc, '')||'%'
                      group by l.sys_name,
                               l.common_name,
                               l.common_desc,
                               l.common_unit,
                               l.common_id) A) B
      WHERE RN between ((pageno - 1) * pagesize) + 1 and pageno * pagesize;
      end if;

      select count(B.common_id)
        into total
        from (select A.*
                from (select l.sys_name,
                             l.common_name,
                             l.common_desc,
                             l.common_unit,
                             MAX(l.high_val) high_val,
                             MAX(l.low_val) low_val,
                             MAX(l.onhand_qty) onhand_qty,
                             l.common_id,
                             sum(l.next_one_month_qty) next_one_month_qty,
                             sum(l.next_two_month_qty) next_two_month_qty,
                             sum(l.next_tri_month_qty) next_tri_month_qty,
                             MAX(l.reserve_qty) reserve_qty,
                             MAX(l.unreceivable_qty) unreceivable_qty,
                             sum(l.next_one_month_expqty) next_one_month_expqty,
                             sum(l.next_two_month_expqty) next_two_month_expqty,
                             sum(l.next_tri_month_expqty) next_tri_month_expqty
                        FROM temp_demand_collect_list l
                        left join (select line.id,
                                         head.created_user,
                                         u.employee_name,
                                         head.if_add,
                                         head.collect_head_code,
                                         head.status
                                    FROM t_lis_demand_collect_head head
                                    left join t_lis_demand_collect_line line
                                      on head.id = line.collect_headid
                                    left join t_lis_user u
                                      on u.employee_number =
                                         head.created_user
                                   where head.erp_type = erpTypeVO) d
                          on d.id = l.collect_line_id
                       where d.status = 1
                         and d.collect_head_code like '%' || nvl(taskcode, '') || '%'
                         and d.employee_name like '%' || nvl(taskfounder, '') || '%'
                         and d.if_add like '%' || nvl(supplymode, '') || '%'
                         and l.common_desc like '%' || nvl(materialcode, '') || '%'
                         and l.common_name like '%' || nvl(materialdesc, '') || '%'
                       group by l.sys_name,
                                l.common_name,
                                l.common_desc,
                                l.common_unit,
                                l.common_id) A

              )B;

              commit;

  end proc_demand_collect_list;

end proc_demand_collect_list_pkg;
/

