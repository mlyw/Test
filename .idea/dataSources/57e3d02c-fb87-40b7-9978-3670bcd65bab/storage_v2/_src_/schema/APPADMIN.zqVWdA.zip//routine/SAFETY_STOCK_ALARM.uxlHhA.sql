create procedure safety_stock_alarm
as
  var_createdate date;
  var_insert_sql varchar2(5000);
  var_low_flag varchar2(10);
  var_high_flag varchar2(10);
  var_has_used varchar2(5);
  --v_item_count number;
  --v_category_count number;
  --v_project_count number;
begin
  var_low_flag := 'tooLow';
  var_high_flag := 'tooHigh';
  var_has_used := 'N';
  select to_date(to_char(sysdate,'yyyy-mm-dd')||' 00:00:00','yyyy-mm-dd hh24:mi:ss') into var_createdate from dual;
  --添加物料告警
  var_insert_sql:='insert into t_safety_stock_alarm_notice
                            (id,
                             item_category_code,
                             item_category_desc,
                             item_id,
                             item_code,
                             item_desc,
                             erp_type,
                             uom_desc,
                             high_val,
                             low_val,
                             quantity_count,
                             over_count,
                             material_type,
                             flag_type,
                             creation_date,
                             version,
                             status,
                             has_used)
                   select s_safety_stock_alarm_notice_id.nextval,
                          material.item_category_code,
                          material.item_category_desc,
                          material.item_id,
                          material.item_code,
                          material.item_desc,
                          material.erp_type,
                          material.uom_desc,
                          material.threshold_value_high,
                          material.threshold_value_low,
                          quanum.quantity,
                          (case when quanum.quantity < low_val then quanum.quantity-threshold_value_low else quanum.quantity-threshold_value_high end),
                          material.material_type,
                          (case when quanum.quantity < low_val then '''||var_low_flag||''' else '''||var_high_flag||''' end),
                          '''||var_createdate||''',
                          0,
                          1,
                          '''||var_has_used||'''
                   from t_safety_stock_material_setup material,
                          (select sum(onhand_quantity) quantity, item_id thisid
                           from t_wh_current_onhand_quantity quan
                           where onhand_quantity > 0 and status = 1
                           and exists (
                           SELECT 1
                          FROM T_Warehouse_Define wd JOIN T_WAREHOUSE_CATEGORY twc ON wd.CATEGORY_ID = twc.id AND Twc.Code =''01'' AND Twc.Status =1
                          WHERE Wd.Warehouse_Define_Code NOT IN(SELECT * FROM t_lis_un_wa) AND Wd.Status =1 AND quan.warehouse_define_id = wd.id
                          START WITH Wd.Parent_Warehouse_Id IN
                          (SELECT wd.id FROM T_Warehouse_Define wd
                            WHERE Wd.Warehouse_Define_Code in
                              (SELECT Org.Organization_Code FROM T_Lis_Item_Type lit JOIN T_Sys_Erp_Organizations org
                                ON Org.Organization_Id=Lit.Organazation_Id
                               AND Org.Status  = 1  ) )
                          CONNECT BY PRIOR wd.id=Wd.Parent_Warehouse_Id
                           )
                           group by item_id) quanum
                   where status = 1
                         and material_type = '||1||'
                         and (quanum.quantity < low_val or quanum.quantity > high_val)
                         and quanum.thisid = material.item_id
                         and (material.item_scope is null or material.item_scope = 0)
                         ';
   --insert into test123(a) values(var_insert_sql);
   --commit;
   execute immediate var_insert_sql;
   commit;
   safety_stock_alarm_detail(var_createdate,1);
   --添加产品告警
   var_insert_sql:='insert into t_safety_stock_alarm_notice
                            (id,
                             product_id,
                             product_code,
                             product_desc,
                             erp_type,
                             uom_desc,
                             high_val,
                             low_val,
                             quantity_count,
                             over_count,
                             material_type,
                             flag_type,
                             creation_date,
                             version,
                             status,
                             has_used)
                   select s_safety_stock_alarm_notice_id.nextval,
                          material.product_id,
                          material.product_code,
                          material.product_desc,
                          material.erp_type,
                          material.uom_desc,
                          material.threshold_value_high,
                          material.threshold_value_low,
                          quanum.quantity,
                          (case when quanum.quantity < low_val then quanum.quantity-threshold_value_low else quanum.quantity-threshold_value_high end),
                          material.material_type,
                          (case when quanum.quantity < low_val then '''||var_low_flag||''' else '''||var_high_flag||''' end),
                          '''||var_createdate||''',
                          0,
                          1,
                          '''||var_has_used||'''
                   from t_safety_stock_material_setup material,
                          (select sum(onhand_quantity) quantity, product_id thisid
                           from t_wh_current_onhand_quantity quan
                           where onhand_quantity > 0 and status = 1
                           and exists (
                            SELECT 1
                            FROM T_Warehouse_Define wd JOIN T_WAREHOUSE_CATEGORY twc ON wd.CATEGORY_ID = twc.id AND Twc.Code =''01'' AND Twc.Status =1
                            WHERE Wd.Warehouse_Define_Code NOT IN(SELECT * FROM t_lis_un_wa) AND Wd.Status =1 AND quan.warehouse_define_id = wd.id
                            START WITH Wd.Parent_Warehouse_Id IN
                            (SELECT wd.id FROM T_Warehouse_Define wd
                              WHERE Wd.Warehouse_Define_Code in
                                (SELECT Org.Organization_Code FROM T_Lis_Item_Type lit JOIN T_Sys_Erp_Organizations org
                                  ON Org.Organization_Id=Lit.Organazation_Id
                                 AND Org.Status  = 1  ) )
                            CONNECT BY PRIOR wd.id=Wd.Parent_Warehouse_Id
                           )
                           group by product_id) quanum
                   where status = 1
                         and material_type = '||2||'
                         and (quanum.quantity < low_val or quanum.quantity > high_val)
                         and quanum.thisid = material.product_id';
   --insert into test123(a) values(var_insert_sql);
   --commit;
   execute immediate var_insert_sql;
   commit;
   safety_stock_alarm_detail(var_createdate,2);

   --添加物料类型告警
   --现去掉物料类型
   /*var_insert_sql:='insert into t_safety_stock_alarm_notice
                            (id,
                             item_category_code,
                             item_category_desc,
                             uom_desc,
                             high_val,
                             low_val,
                             quantity_count,
                             over_count,
                             material_type,
                             flag_type,
                             creation_date,
                             version,
                             status,
                             has_used)
                   select s_safety_stock_alarm_notice_id.nextval,
                          material.item_category_code,
                          material.item_category_desc,
                          material.uom_desc,
                          material.threshold_value_high,
                          material.threshold_value_low,
                          quanum.quantity,
                          (case when quanum.quantity < low_val then quanum.quantity-threshold_value_low else quanum.quantity-threshold_value_high end),
                          material.material_type,
                          (case when quanum.quantity < low_val then '''||var_low_flag||''' else '''||var_high_flag||''' end),
                          '''||var_createdate||''',
                          0,
                          1,
                          '''||var_has_used||'''
                   from t_safety_stock_material_setup material,
                          (select sum(onhand_quantity) quantity, item_category_code thiscode
                           from t_wh_current_onhand_quantity
                           where onhand_quantity > 0 and status = 1
                           group by item_category_code) quanum
                   where status = 1
                         and material_type = '||0||'
                         and (quanum.quantity < low_val or quanum.quantity > high_val)
                         and quanum.thiscode = material.item_category_code';
   insert into test123(a) values(var_insert_sql);
   commit;
   execute immediate var_insert_sql;
   commit;
   safety_stock_alarm_detail(var_createdate,0);*/

  --添加物料组告警
  var_insert_sql:='insert into t_safety_stock_alarm_notice
                            (id,
                             item_category_code,
                             item_category_desc,
                             item_id,
                             item_code,
                             item_desc,
                             erp_type,
                             uom_desc,
                             high_val,
                             low_val,
                             quantity_count,
                             over_count,
                             material_type,
                             flag_type,
                             creation_date,
                             version,
                             status,
                             has_used,
                             Organizationid,
                             Item_Scope,
                             Item_Group_Id)
                   select s_safety_stock_alarm_notice_id.nextval,
                          material.item_category_code,
                          material.item_category_desc,
                          material.item_id,
                          material.item_code,
                          material.item_desc,
                          material.erp_type,
                          material.uom_desc,
                          material.threshold_value_high,
                          material.threshold_value_low,
                          quanum.quantity,
                          (case when quanum.quantity < low_val then quanum.quantity-threshold_value_low else quanum.quantity-threshold_value_high end),
                          material.material_type,
                          (case when quanum.quantity < low_val then '''||var_low_flag||''' else '''||var_high_flag||''' end),
                          '''||var_createdate||''',
                          0,
                          1,
                          '''||var_has_used||''',
                          Material.Organizationid,
                          Material.Item_Scope,
                          Material.Item_Group_Id
                   from t_safety_stock_material_setup material,
                          (select H.id,sum(round(t.Quantity/L.Convert_Ratio,5)) quantity
                            from T_Lis_Itemgroup_Head h
                              left join T_Lis_Itemgroup_Line l on L.Item_Group_Headid=H.Id 
                              join (select sum(onhand_quantity) quantity, item_id thisid
                                        from t_wh_current_onhand_quantity quan
                                        where onhand_quantity > 0 and status = 1
                                        and exists (
                                        SELECT 1
                                        FROM T_Warehouse_Define wd JOIN T_WAREHOUSE_CATEGORY twc ON wd.CATEGORY_ID = twc.id AND Twc.Code =''01'' AND Twc.Status =1
                                        WHERE Wd.Warehouse_Define_Code NOT IN(SELECT * FROM t_lis_un_wa) AND Wd.Status =1 AND quan.warehouse_define_id = wd.id
                                        START WITH Wd.Parent_Warehouse_Id IN
                                        (SELECT wd.id FROM T_Warehouse_Define wd
                                          WHERE Wd.Warehouse_Define_Code in
                                            (SELECT Org.Organization_Code FROM T_Lis_Item_Type lit JOIN T_Sys_Erp_Organizations org
                                              ON Org.Organization_Id=Lit.Organazation_Id
                                             AND Org.Status  = 1  ) )
                                        CONNECT BY PRIOR wd.id=Wd.Parent_Warehouse_Id
                                        )
                                        group by item_id) t on t.thisid=L.Item_Id
                            where  H.Status =1 and H.if_lock=0
                            group by h.id) quanum
                   where status = 1
                     
                         and (quanum.quantity < low_val or quanum.quantity > high_val)
                         and quanum.id = material.item_group_id
                         and material.item_scope = 1
                         ';
   --insert into test123(a) values(var_insert_sql);
   --commit;
   execute immediate var_insert_sql;
   commit;
   safety_stock_alarm_detail(var_createdate,3);

   --修改告警信息主表中的数据
   update t_safety_stock_alarm_notice n
   set (has_used, quan_count, need_count) =
       (select 'y', case when quantity.quantity_count>0 then quantity.quantity_count else 0 end,
       case when useneed.need_count>0 then useneed.need_count else 0 end
          from t_safety_stock_alarm_notice notice,
               (select sum(quantity_count) quantity_count, notice_id
                  from t_safety_stock_quantity
                 group by notice_id) quantity,
               (select sum(need_count) need_count, notice_id
                  from t_safety_stock_use_need
                 group by notice_id) useneed
         where quantity.notice_id(+) = notice.id
           and useneed.notice_id(+) = notice.id
           and notice.id = n.id)
         where has_used = 'R'
           and creation_date = var_createdate;
  commit;
end safety_stock_alarm;
/

