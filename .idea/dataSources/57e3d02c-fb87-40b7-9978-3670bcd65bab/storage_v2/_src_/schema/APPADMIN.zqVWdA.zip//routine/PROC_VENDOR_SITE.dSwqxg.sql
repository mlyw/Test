create PROCEDURE "PROC_VENDOR_SITE" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_vendor_site is
select vendor_site_id, vendor_site_name, ou_id, ou_name, creation_date, inactive_date, last_update_date, address_line1, address_line2, address_line3, address_line4, country, province, city, zip, erp_type, vendor_id, vendor_number, seq_id from i_erp_vendor_site_info where create_date > start_time and create_date < end_time order by erp_type desc;
i_vendor_site csr_i_vendor_site%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_erp_vendor_site_info where create_date > start_time and create_date < end_time;
  open csr_i_vendor_site;
  fetch csr_i_vendor_site into i_vendor_site;
while (csr_i_vendor_site%found) loop
  select count(*) into count_value from T_SYS_ERP_VENDOR_SITE_INFO where VENDOR_SITE_ID = i_vendor_site.vendor_site_id and erp_type = i_vendor_site.erp_type;
  if(count_value = 1 and i_vendor_site.inactive_date is null) then
      update T_SYS_ERP_VENDOR_SITE_INFO t set t.last_updated_date = sysdate,
      t.vendor_site_name = i_vendor_site.vendor_site_name,
      t.erp_type = i_vendor_site.erp_type,
      t.ou_id = i_vendor_site.ou_id,
      t.address_line1 = i_vendor_site.address_line1,
      t.address_line2 = i_vendor_site.address_line2,
      t.address_line3 = i_vendor_site.address_line3,
      t.address_line4 = i_vendor_site.address_line4,
      t.country = i_vendor_site.country,
      t.province = i_vendor_site.province,
      t.city = i_vendor_site.city,
      t.zip = i_vendor_site.zip,
      t.vendor_id = i_vendor_site.vendor_id
      where t.vendor_site_id = i_vendor_site.vendor_site_id;
   elsif(count_value = 1 and i_vendor_site.inactive_date is not null) then
   update T_SYS_ERP_VENDOR_SITE_INFO t set t.last_updated_date = sysdate,
      t.vendor_site_name = i_vendor_site.vendor_site_name,
      t.erp_type = i_vendor_site.erp_type,
      t.ou_id = i_vendor_site.ou_id,
      t.address_line1 = i_vendor_site.address_line1,
      t.address_line2 = i_vendor_site.address_line2,
      t.address_line3 = i_vendor_site.address_line3,
      t.address_line4 = i_vendor_site.address_line4,
      t.country = i_vendor_site.country,
      t.province = i_vendor_site.province,
      t.city = i_vendor_site.city,
      t.zip = i_vendor_site.zip,
      t.vendor_id = i_vendor_site.vendor_id,
      t.status = 0
      where t.vendor_site_id = i_vendor_site.vendor_site_id;
 elsif(count_value = 0 and i_vendor_site.inactive_date is null) then
insert into t_sys_erp_vendor_site_info
  (seq_id, vendor_site_id, vendor_site_name, ou_id, inactive_date, address_line1, address_line2, address_line3, address_line4, country, province, city, zip, erp_type, vendor_id, created_date, last_updated_date, status)
values
  (i_vendor_site.seq_id ,i_vendor_site.vendor_site_id, i_vendor_site.vendor_site_name, i_vendor_site.ou_id, i_vendor_site.inactive_date, i_vendor_site.address_line1, i_vendor_site.address_line2, i_vendor_site.address_line3, i_vendor_site.address_line4, i_vendor_site.country, i_vendor_site.province, i_vendor_site.city, i_vendor_site.zip, i_vendor_site.erp_type, i_vendor_site.vendor_id, sysdate, sysdate, 1);
end if;
fetch csr_i_vendor_site into i_vendor_site;
count_success:=count_success+1;
end loop;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','T_SYS_ERP_VENDOR_SITE_INFO');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_ERP_VENDOR_SITE_INFO');
close csr_i_vendor_site;
commit;
end;
/

