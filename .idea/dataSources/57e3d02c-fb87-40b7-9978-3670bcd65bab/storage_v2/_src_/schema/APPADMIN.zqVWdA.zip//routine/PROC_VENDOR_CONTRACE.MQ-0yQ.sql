create PROCEDURE proc_VENDOR_CONTRACE (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_vendors_contrace is
select vendor_id, vendor_site_id, contract_name, area_code, phone, fax_area_code, fax, email_address, erp_type from i_erp_vendor_contrace_info
 where create_date > start_time and create_date < end_time order by erp_type desc;
i_vendors_contrace csr_i_vendors_contrace%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_Erp_Vendor_Contrace_Info where create_date > start_time and create_date < end_time;
  open csr_i_vendors_contrace;
  fetch csr_i_vendors_contrace into i_vendors_contrace;
while (csr_i_vendors_contrace%found) loop
  select count(*) into count_value from t_sys_erp_vendor_contrace where VENDOR_ID = i_vendors_contrace.vendor_id and vendor_site_id = i_vendors_contrace.vendor_site_id;
  if(count_value = 1) then
      update t_sys_erp_vendor_contrace t set t.last_updated_date = sysdate,
      t.erp_type = i_vendors_contrace.erp_type,
      t.vendor_site_id = i_vendors_contrace.vendor_site_id,
      t.contract_name = i_vendors_contrace.contract_name,
      t.area_code = i_vendors_contrace.area_code,
      t.phone = i_vendors_contrace.phone,
      t.fax_area_code = i_vendors_contrace.fax_area_code,
      t.fax = i_vendors_contrace.fax,
      t.email_address = i_vendors_contrace.email_address
      where t.vendor_id = i_vendors_contrace.vendor_id;
      fetch csr_i_vendors_contrace into i_vendors_contrace;
 else
insert into t_sys_erp_vendor_contrace
  (vendor_id, vendor_site_id, contract_name, area_code, phone, fax_area_code, fax, email_address, erp_type, created_date, last_updated_date, status)
values
  (i_vendors_contrace.vendor_id, i_vendors_contrace.vendor_site_id, i_vendors_contrace.contract_name, i_vendors_contrace.area_code, i_vendors_contrace.phone, i_vendors_contrace.fax_area_code, i_vendors_contrace.fax, i_vendors_contrace.email_address, i_vendors_contrace.erp_type, sysdate, sysdate, 1);

fetch csr_i_vendors_contrace into i_vendors_contrace;
count_success:=count_success+1;
end if;
end loop;
close csr_i_vendors_contrace;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_erp_vendor_contrace');
exception when others then
  --count_num := count_success;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_erp_vendor_contrace');
close csr_i_vendors_contrace;
commit;
end;
/

