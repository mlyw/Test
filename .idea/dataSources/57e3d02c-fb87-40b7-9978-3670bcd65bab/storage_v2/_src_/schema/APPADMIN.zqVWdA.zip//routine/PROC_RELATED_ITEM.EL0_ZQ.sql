create PROCEDURE proc_related_item(start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_related_item is
select item_id, item_code, item_name, related_item_id, related_item_code, related_item_name, erp_type, last_update_date, import_date, organization_id, seq_id, create_date from i_erp_related_item
where create_date > start_time and create_date < end_time order by erp_type desc;
i_related_item csr_i_related_item%rowtype;
begin
  count_success := 0;
select count(*) into total_value from i_erp_related_item where create_date > start_time and create_date < end_time;
  open csr_i_related_item;
  fetch csr_i_related_item into i_related_item;
  while (csr_i_related_item%found) loop
    select count(*) into count_value from t_sys_erp_related_item where item_id = i_related_item.item_id and RELATED_ITEM_ID = i_related_item.related_item_id;
if(count_value = 0) then
insert into t_sys_erp_related_item
  (item_id, item_code, item_name, related_item_id, related_item_code, related_item_name, erp_type, organization_id, id)
values
  (i_related_item.item_id,i_related_item.item_code,i_related_item.item_name,i_related_item.related_item_id,i_related_item.related_item_code,i_related_item.item_name,i_related_item.erp_type,i_related_item.organization_id,i_related_item.seq_id);
 end if;
fetch csr_i_related_item into i_related_item;
count_success:=count_success + 1;
end loop;
close csr_i_related_item;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_erp_related_item');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_erp_related_item');
commit;
end;
/

