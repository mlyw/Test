create view V_LIS_REPORT_ITEM_OVER_ACCOUNT as
  SELECT
    /**以ou/库存/子库/物料分类/物料为维度的呆滞物资及当前库存物资金额（为仓库运营表和物料统计表的呆滞占比提供数据）*/
    overper.ou_id,
    overper.organization_id,
    overper.warehouse_define_id,
    overper.item_category_code,
    overper.item_category_name,
    overper.item_id,
    overper.item_code,
    overper.item_desc,
    overper.item_uom_code,
    overper.item_uom_desc,
    SUM(overper.over_7to9_account) over_7to9_account,
    SUM(overper.over_10to12_account) over_10to12_account,
    SUM(overper.over_13to18_account) over_13to18_account,
    SUM(overper.over_19to24_account) over_19to24_account,
    SUM(overper.over_25more_account) over_25more_account,
    SUM(overper.item_account) item_account
  FROM
    (
    ----当前物资金额
    SELECT rqi.mis_ou_id ou_id,
      rqi.mis_io_id organization_id,
      rqi.warehouse_define_id,
      rqi.concatenated_segments item_category_code,
      rqi.category_description item_category_name,
      rqi.item_id,
      rqi.item_code,
      rqi.item_desc,
      rqi.uom_code item_uom_code,
      rqi.uom_desc item_uom_desc,
      0 over_7to9_account,
      0 over_10to12_account,
      0 over_13to18_account,
      0 over_19to24_account,
      0 over_25more_account,
      SUM(rqi.item_account) item_account
    FROM v_lis_report_qty_item_now rqi
    GROUP BY rqi.mis_ou_id,
      rqi.mis_io_id,
      rqi.warehouse_define_id,
      rqi.concatenated_segments,
      rqi.category_description,
      rqi.item_id,
      rqi.item_code,
      rqi.item_desc,
      rqi.uom_code,
      rqi.uom_desc
    UNION ALL
    ----呆滞物资金额
    SELECT ric.ou_id,
      ric.organization_id,
      ric.warehouse_define_id,
      ric.item_category_code,
      ric.item_category_name,
      ric.item_id,
      ric.item_code,
      ric.item_desc,
      ric.item_uom_code,
      ric.item_uom_desc,
      SUM(ric.over_7to9_account) over_7to9_account,
      SUM(ric.over_10to12_account) over_10to12_account,
      SUM(ric.over_13to18_account) over_13to18_account,
      SUM(ric.over_19to24_account) over_19to24_account,
      SUM(ric.over_25more_account) over_25more_account,
      0 item_account
    FROM V_LIS_REPORT_isover_count ric
    GROUP BY ric.ou_id,
      ric.organization_id,
      ric.warehouse_define_id,
      ric.item_category_code,
      ric.item_category_name,
      ric.item_id,
      ric.item_code,
      ric.item_desc,
      ric.item_uom_code,
      ric.item_uom_desc
    ) overper
  GROUP BY overper.ou_id,
    overper.organization_id,
    overper.warehouse_define_id,
    overper.item_category_code,
    overper.item_category_name,
    overper.item_id,
    overper.item_code,
    overper.item_desc,
    overper.item_uom_code,
    overper.item_uom_desc
/

