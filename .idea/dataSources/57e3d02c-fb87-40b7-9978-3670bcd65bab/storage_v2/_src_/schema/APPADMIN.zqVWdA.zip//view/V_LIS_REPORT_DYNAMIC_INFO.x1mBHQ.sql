create view V_LIS_REPORT_DYNAMIC_INFO as
  SELECT
    /**库存无动态情况主表统计视图*/
    n.mis_ou_id,
    n.mis_io_id,
    n.warehouse_define_id,
    (n.mis_io_code
    ||' '
    ||n.mis_io_name) orginfo,
    (n.warehouse_define_code
    ||' '
    ||n.warehouse_define_name) warehouseinfo,
    n.concatenated_segments,
    n.category_description,
    n.item_code,
    n.item_name,
    MIN(n.beforedate) beforedate,
    MAX(n.afterdate) afterdate,
    MAX(n.outdate) outdate,
    MAX(n.dynamistimes) dynamistimes,
    SUM(n.accotunt) accotunt
  FROM MV_LIS_REPORT_DYNAMIC n
  GROUP BY n.mis_ou_id,
    n.mis_io_id,
    n.mis_io_code,
    n.mis_io_name,
    n.warehouse_define_id,
    n.warehouse_define_code,
    n.warehouse_define_name,
    n.category_description,
    n.concatenated_segments,
    n.item_code,
    n.item_name
/

