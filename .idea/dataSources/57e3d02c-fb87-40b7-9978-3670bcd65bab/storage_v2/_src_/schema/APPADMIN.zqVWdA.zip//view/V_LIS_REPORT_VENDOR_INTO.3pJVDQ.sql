create view V_LIS_REPORT_VENDOR_INTO as
  SELECT tmp.item_code,
    tmp.item_desc,
    tmp.item_id,
    tmp.uom_code,
    tmp.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.warehouse_receive_id,
    tmp.product_unit_price,
    tmp.current_receive_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.current_receive_quantity,0) current_receive_account,
    tmp.accounting_confirm_date import_date,
    tmp.id order_id,
    tmp.receipt_order_code order_code,
    tmp.order_type,
    o.vendor_id,
    o.vendor_name
  FROM
    (SELECT rl.item_id,
      rl.item_code,
      rl.item_desc,
      rl.uom_code,
      rl.uom_desc,
      NVL(rl.product_unit_price,0) product_unit_price,
      NVL(rl.current_receive_quantity,0) current_receive_quantity,
      rl.warehouse_receive_id,
      rl.accounting_confirm_date,
      rh.id,
      rh.receipt_order_code,
      '接收入库' order_type,
      rh.po_id
    FROM t_receiptorder_headerinfo rh,
      t_receiptorder_lineinfo rl
    WHERE rl.status                                     =1
    AND rl.status                                       =1
    AND rh.order_status                                 =5
    AND rl.receipt_order_line_sid                       =2
    AND rl.receipt_order_id                             =rh.id
    AND TO_CHAR(rl.accounting_confirm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_base_spm_pur_order_headers o
  ON tmp.po_id=o.spm_po_header_id
  UNION ALL
  ----rm销售数据
  SELECT i.item_code,
    i.item_name item_desc,
    rs.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    d.id warehouse_receive_id,
    0 product_unit_price,
    ABS(NVL(rs.quantity,0)) current_receive_quantity,
    0*NVL(ABS(NVL(rs.quantity,0)),0) current_receive_account,
    rs.transcation_date import_date,
    rs.seq_id order_id,
    rs.origin_filename order_code,
    '有价卡销售回退' order_type,
    tmp.vendor_id,
    tmp.vendor_name
  FROM t_lis_rm_sales rs
  LEFT JOIN t_warehouse_define d
  ON rs.subinventory_code=d.warehouse_define_code
  LEFT JOIN t_sys_erp_items i
  ON rs.item_id=i.seq_id
  LEFT JOIN
    (SELECT rmtmp.rm_sales_id,
      rmtmp.vendor_id,
      v.vendor_name
    FROM
      (SELECT n.rm_sales_id,
        MAX(q.vendor_id) vendor_id
      FROM t_lis_rm_warehouse_relation n,
        t_wh_current_onhand_quantity q
      WHERE n.warehouse_current_onhandqty_id=q.id
      AND q.vendor_id                      IS NOT NULL
      GROUP BY n.rm_sales_id
      ) rmtmp,
      t_sys_erp_vendors v
    WHERE rmtmp.vendor_id=v.seq_id
    ) tmp
  ON rs.seq_id                                 =tmp.rm_sales_id
  WHERE NVL(rs.quantity,0)                     <0
  AND TO_CHAR(rs.transcation_date,'yyyy-MM-dd')>'2016-12-31'
  AND NVL(rs.flag,'')                          ='Y'
  UNION ALL
  ----SIM卡销售月结 由于没有记录供应商/现有量/接收批次号 无法按照供应商统计数据
  ----工程退库/工程杂收
  SELECT tmp.item_code,
    tmp.item_name item_desc,
    tmp.itemid item_id,
    i.uom_code,
    tmp.unit uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.warehousebacktoid warehouse_receive_id,
    tmp.prouintprice product_unit_price,
    tmp.acpt_cfm_quty current_receive_quantity,
    NVL(tmp.prouintprice,0)*NVL(tmp.acpt_cfm_quty,0) current_receive_account,
    tmp.acc_cfm_date import_date,
    tmp.id order_id,
    tmp.back_order_code order_code,
    tmp.order_type order_type,
    tmp.vendor_id,
    tmp.vendor_name
  FROM
    (SELECT bl.item_code,
      bl.item_name,
      bl.itemid,
      bl.unit,
      bl.warehousebacktoid,
      bl.acpt_cfm_quty,
      bl.prouintprice,
      bl.acc_cfm_date,
      bh.id,
      bh.back_order_code,
      CASE
        WHEN bh.backtypeid=5
        THEN '杂收'
        ELSE '退库'
      END AS order_type,
      q.vendor_id,
      v.vendor_name
    FROM t_bck_hd bh,
      t_bck_ln bl,
      t_out_notmk m,
      t_wh_current_onhand_quantity q,
      t_sys_erp_vendors v
    WHERE bh.status                          =1
    AND bl.status                            =1
    AND q.status                             =1
    AND m.status                             =1
    AND bh.orderstatus                       =60
    AND bh.backtypeid                       IN (1,5)
    AND bl.backorderid                       =bh.id
    AND bl.invitemassignlineid               =m.id
    AND m.warehouse_onhand_id                =q.id
    AND v.seq_id                             =q.vendor_id
    AND bl.invitemassignlineid              IS NOT NULL
    AND m.warehouse_onhand_id               IS NOT NULL
    AND TO_CHAR(bl.acc_cfm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.itemid=i.seq_id
  UNION ALL
  ---综合调增/综合退库
  SELECT tmp.item_code,
    tmp.item_name item_desc,
    tmp.itemid item_id,
    i.uom_code,
    tmp.unit uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.warehousebacktoid warehouse_receive_id,
    tmp.prouintprice product_unit_price,
    tmp.backquantity current_receive_quantity,
    NVL(tmp.prouintprice,0)*NVL(tmp.backquantity,0) current_receive_account,
    tmp.acc_cfm_date import_date,
    tmp.id order_id,
    tmp.back_order_code order_code,
    tmp.order_type order_type,
    tmp.vendor_id,
    tmp.vendor_name
  FROM
    (SELECT bl.item_code,
      bl.item_name,
      bl.itemid,
      bl.unit,
      bl.warehousebacktoid,
      bl.backquantity,
      bl.prouintprice,
      bl.acc_cfm_date,
      bh.id,
      bh.back_order_code,
      CASE
        WHEN bh.backtypeid=86
        THEN '杂收'
        ELSE '退库'
      END AS order_type,
      q.vendor_id,
      v.vendor_name
    FROM t_bck_hd bh,
      t_bck_ln bl,
      t_out_notmk m,
      t_wh_current_onhand_quantity q,
      t_sys_erp_vendors v
    WHERE bh.status                          =1
    AND bl.status                            =1
    AND q.status                             =1
    AND m.status                             =1
    AND bh.orderstatus                       =60
    AND bh.backtypeid                       IN (84,86)
    AND bl.backorderid                       =bh.id
    AND bl.invitemassignlineid               =m.id
    AND m.warehouse_onhand_id                =q.id
    AND v.seq_id                             =q.vendor_id
    AND bl.invitemassignlineid              IS NOT NULL
    AND m.warehouse_onhand_id               IS NOT NULL
    AND TO_CHAR(bl.acc_cfm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.itemid=i.seq_id
  UNION ALL
  ---调拨-调入方
  ----工程物资调拨
  SELECT tmp.item_code,
    tmp.item_desc,
    tmp.item_id,
    tmp.uom_code,
    tmp.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.wh_id_trf_into warehouse_receive_id,
    tmp.product_unit_price,
    tmp.change_quty current_receive_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.change_quty,0) current_receive_account,
    tmp.account_date import_date,
    tmp.id order_id,
    tmp.wh_chg_ord_code order_code,
    tmp.order_type order_type,
    tmp.vendor_id,
    tmp.vendor_name
  FROM
    (SELECT hl.item_code,
      hl.item_id,
      hl.uom_desc,
      hl.item_desc,
      hl.uom_code,
      hl.wh_id_trf_into,
      NVL(hl.product_unit_price,0) product_unit_price,
      hl.change_quty,
      hd.account_date,
      hd.id,
      hd.wh_chg_ord_code,
      '调拨' order_type,
      q.vendor_id,
      v.vendor_name
    FROM t_chg_hd_ln hd,
      t_chg_ln hl,
      t_wh_current_onhand_quantity q,
      t_sys_erp_vendors v
    WHERE hd.status                          =1
    AND hl.status                            =1
    AND hd.order_status                     IN (5,50)
    AND hl.chghdln_id                        =hd.id
    AND hl.onhand_id                         =q.id
    AND q.vendor_id                          =v.seq_id
    AND q.vendor_id                         IS NOT NULL
    AND hl.onhand_id                        IS NOT NULL
    AND TO_CHAR(hd.account_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  UNION ALL
  ---报废卡退库 由于没有记录供应商/现有量/接收批次号 无法按照供应商统计数据
  -----cnp出库时从C001出到具体的营业厅 具体营业厅的数据当做营业厅的入库数据
  SELECT tmp.item_code,
    i.item_name item_desc,
    tmp.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    d.id warehouse_receive_id,
    tmp.product_unit_price,
    tmp.Acpt_Cfm_Quty current_receive_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.Acpt_Cfm_Quty,0) current_receive_account,
    tmp.acc_cfm_date import_date,
    tmp.id order_id,
    tmp.out_ord_code order_code,
    tmp.order_type,
    tmp.vendor_id,
    tmp.vendor_name
  FROM
    (SELECT m.item_id,
      m.item_code,
      l.to_subinventory_code,
      m.product_unit_price,
      m.Acpt_Cfm_Quty,
      m.acc_cfm_date,
      h.id,
      h.out_ord_code,
      '大库调入' order_type,
      m.warehouse_onhand_id,
      m.vendor_id,
      v.vendor_name
    FROM t_out_hd h,
      t_out_ln l,
      t_out_notmk m,
      t_sys_erp_vendors v
    WHERE h.status                          =1
    AND l.status                            =1
    AND m.status                            =1
    AND h.ord_status                        =6
    AND l.ord_ln_status                     =7
    AND m.asgn_ln_status                    =1
    AND m.outlninfo_id                      =l.id
    AND l.outhdinfo_id                      =h.id
    AND m.vendor_id                         =v.seq_id
    AND l.to_subinventory_code             IS NOT NULL
    AND TO_CHAR(m.acc_cfm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.to_subinventory_code=d.warehouse_define_code
/

