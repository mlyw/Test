create PROCEDURE proc_organization (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_organization is
select organization_id, organization_code, organization_name, material_type, erp_type, enable_date, disable_date, last_update_date, ou_id, ou_name from i_erp_organization where create_date > start_time and create_date < end_time;
i_organization csr_i_organization%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_Erp_Organization where create_date > start_time and create_date < end_time;
  open csr_i_organization;
  fetch csr_i_organization into i_organization;
while (csr_i_organization%found) loop
  select count(*) into count_value from t_Sys_Erp_Organizations where ORGANIZATION_ID = i_organization.organization_id;
  if(count_value = 1 and i_organization.disable_date is null) then
      update t_Sys_Erp_Organizations t set t.last_updated_date = sysdate,
      t.material_type = i_organization.material_type,
      t.erp_type = i_organization.erp_type,
      t.organization_code = i_organization.organization_code,
      t.organization_name = i_organization.organization_name,
      t.ou_id = i_organization.ou_id,
      t.enable_date = i_organization.enable_date
      where t.organization_id = i_organization.organization_id;
   elsif(count_value = 1 and i_organization.disable_date is not null) then
   update t_Sys_Erp_Organizations t set t.last_updated_date = sysdate,
      t.material_type = i_organization.material_type,
      t.erp_type = i_organization.erp_type,
      t.organization_code = i_organization.organization_code,
      t.organization_name = i_organization.organization_name,
      t.ou_id = i_organization.ou_id,
      t.enable_date = i_organization.enable_date,
      t.status = 0
      where t.organization_id = i_organization.organization_id;
 elsif(count_value = 0 and i_organization.disable_date is null) then
   insert into t_sys_erp_organizations
     (organization_id, created_date, last_updated_date, status, erp_type, material_type, organization_code, organization_name, ou_id, disable_date, enable_date)
   values
     (i_organization.organization_id, sysdate, sysdate, 1, i_organization.erp_type, i_organization.material_type, i_organization.organization_code, i_organization.organization_name, i_organization.ou_id, i_organization.disable_date, i_organization.enable_date);
end if;
fetch csr_i_organization into i_organization;
count_success:=count_success+1;
end loop;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_erp_organizations');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_erp_organizations');
close csr_i_organization;
commit;
end;
/

