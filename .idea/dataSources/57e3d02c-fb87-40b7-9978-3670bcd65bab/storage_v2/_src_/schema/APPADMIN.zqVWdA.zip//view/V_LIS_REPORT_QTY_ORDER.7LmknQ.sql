create view V_LIS_REPORT_QTY_ORDER as
  SELECT
  /**以ou/库存/物料分类/物料为维度的年度集采金额视图*/
    TO_CHAR(spo.po_approval_date,'yyyyMM') bussiness_date,
    spo.po_ou_id,
    spo.pol_organization_id,
    i.concatenated_segments,
    i.category_description,
    spo.item_id,
    spo.po_item_code,
    spo.po_item_desc,
    spo.po_uom_desc,
    spo.po_uom_code,
    SUM(NVL(spo.pol_quantity_ordered_account,0)) collectaccount
  FROM V_SPM_PUR_ORDER_INFO spo,
    t_sys_erp_items i
  WHERE spo.item_id        =i.seq_id
  AND i.inventory_item_flag='Y'
  GROUP BY TO_CHAR(spo.po_approval_date,'yyyyMM'),
    spo.po_ou_id,
    spo.pol_organization_id,
    i.concatenated_segments,
    i.category_description,
    spo.item_id,
    spo.po_item_code,
    spo.po_item_desc,
    spo.po_uom_code,
    spo.po_uom_desc
/

