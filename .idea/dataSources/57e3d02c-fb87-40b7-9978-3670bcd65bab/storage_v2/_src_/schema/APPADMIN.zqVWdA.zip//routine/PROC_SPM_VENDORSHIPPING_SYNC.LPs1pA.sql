create PROCEDURE proc_spm_vendorshipping_sync (start_time timestamp, end_time timestamp) as
  total_value number(15);
  count_value number(2);
  count_success number(15);
  exception_info varchar2(3000);
cursor csr_i_spm_vendorShipping is
  select seq_id,
    vendor_shipping_header_id,
    vendor_shipping_line_id,
    spm_po_header_id,
    spm_po_number,
    spm_po_line_id,
    spm_po_distribution_id,
    mis_po_header_id,
    mis_po_number,
    mis_po_line_id,
    mis_po_distribution_id,
    product_id,
    product_code,
    product_name,
    item_id,
    item_code,
    item_desc,
    uom_code,
    uom_desc,
    quantity_shipped,
    arrival_time,
    create_time,
    uniqe_identifier_flag,
    import_date,
    long_attribute,
    string_attribute,
    datetime_attribute,
    double_attribute
  from i_spm_vendorshipping
  where create_time >= start_time and create_time <= end_time;
i_vendorshipping csr_i_spm_vendorShipping%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_spm_vendorshipping where create_time >= start_time and create_time <= end_time;
  open csr_i_spm_vendorShipping;
  fetch csr_i_spm_vendorShipping into i_vendorshipping;
  while (csr_i_spm_vendorShipping%found) loop
    select count(*) into count_value from t_sys_spm_vendorshipping where vendor_shipping_header_id = i_vendorshipping.vendor_shipping_header_id;
    if (count_value = 1) then
      update t_sys_spm_vendorshipping
        set last_updated_date = sysdate,
        vendor_shipping_header_id = i_vendorshipping.vendor_shipping_header_id,
        vendor_shipping_line_id = i_vendorshipping.vendor_shipping_line_id,
        spm_po_header_id = i_vendorshipping.spm_po_header_id ,
        spm_po_number = i_vendorshipping.spm_po_number ,
        spm_po_line_id = i_vendorshipping.spm_po_line_id ,
        spm_po_distribution_id = i_vendorshipping.spm_po_distribution_id ,
        mis_po_header_id = i_vendorshipping.mis_po_header_id ,
        mis_po_number = i_vendorshipping.mis_po_number ,
        mis_po_line_id = i_vendorshipping.mis_po_line_id ,
        mis_po_distribution_id = i_vendorshipping.mis_po_distribution_id ,
        product_id = i_vendorshipping.product_id ,
        product_code = i_vendorshipping.product_code ,
        product_name = i_vendorshipping.product_name ,
        item_id = i_vendorshipping.item_id ,
        item_desc = i_vendorshipping.item_desc ,
        uom_code = i_vendorshipping.uom_code ,
        uom_desc = i_vendorshipping.uom_desc ,
        quantity_shipped = i_vendorshipping.quantity_shipped ,
        arrival_time = i_vendorshipping.arrival_time ,
        create_time = i_vendorshipping.create_time ,
        uniqe_identifier_flag = i_vendorshipping.uniqe_identifier_flag ,
        import_date = i_vendorshipping.import_date ,
        long_attribute = i_vendorshipping.long_attribute ,
        string_attribute = i_vendorshipping.string_attribute ,
        datetime_attribute = i_vendorshipping.datetime_attribute ,
        double_attribute = i_vendorshipping.double_attribute
      where vendor_shipping_header_id = i_vendorshipping.vendor_shipping_header_id;
    else
      insert into t_sys_spm_vendorshipping (seq_id,
                vendor_shipping_header_id,
                vendor_shipping_line_id,
                spm_po_header_id,
                spm_po_number,
                spm_po_line_id,
                spm_po_distribution_id,
                mis_po_header_id,
                mis_po_number,
                mis_po_line_id,
                mis_po_distribution_id,
                product_id,
                product_code,
                product_name,
                item_id,
                item_code,
                item_desc,
                uom_code,
                uom_desc,
                quantity_shipped,
                arrival_time,
                create_time,
                uniqe_identifier_flag,
                import_date,
                long_attribute,
                string_attribute,
                datetime_attribute,
                double_attribute,
                created_date,
                last_updated_date,
                status,
                version) values(seq_spm_vendorshipping.nextval,
                                i_vendorshipping.vendor_shipping_header_id,
                                i_vendorshipping.vendor_shipping_line_id,
                                i_vendorshipping.spm_po_header_id,
                                i_vendorshipping.spm_po_number,
                                i_vendorshipping.spm_po_line_id,
                                i_vendorshipping.spm_po_distribution_id,
                                i_vendorshipping.mis_po_header_id,
                                i_vendorshipping.mis_po_number,
                                i_vendorshipping.mis_po_line_id,
                                i_vendorshipping.mis_po_distribution_id,
                                i_vendorshipping.product_id,
                                i_vendorshipping.product_code,
                                i_vendorshipping.product_name,
                                i_vendorshipping.item_id,
                                i_vendorshipping.item_code,
                                i_vendorshipping.item_desc,
                                i_vendorshipping.uom_code,
                                i_vendorshipping.uom_desc,
                                i_vendorshipping.quantity_shipped,
                                i_vendorshipping.arrival_time,
                                i_vendorshipping.create_time,
                                i_vendorshipping.uniqe_identifier_flag,
                                i_vendorshipping.import_date,
                                i_vendorshipping.long_attribute,
                                i_vendorshipping.string_attribute,
                                i_vendorshipping.datetime_attribute,
                                i_vendorshipping.double_attribute,
                                sysdate,
                                sysdate,1,0
                                );
    end if;
  fetch csr_i_spm_vendorShipping into i_vendorshipping;
  count_success:=count_success+1;
  end loop;
  close csr_i_spm_vendorShipping ;
  --插入日志
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_spm_vendorshipping');
  exception when others then
      exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
    insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_spm_vendorshipping');
  commit;
END;
/

