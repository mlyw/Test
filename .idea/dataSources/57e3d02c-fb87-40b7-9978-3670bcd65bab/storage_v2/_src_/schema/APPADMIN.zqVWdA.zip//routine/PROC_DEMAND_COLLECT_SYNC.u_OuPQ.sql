create PROCEDURE PROC_DEMAND_COLLECT_SYNC AS
lineId number(19);
itemId number(19);
deptId number(19);
dcount number(19);
demandId number(19);
num number(19);
rcsor sys_refcursor;
cursor csr_demand_collect is
      select distinct l.collect_line_id,l.collect_depart_id,sei.seq_id
 
     FROM t_lis_depart_demand l
     left join t_lis_depart_head h on h.id = l.collect_depart_id and h.status = 1
     left join t_lis_sys_info si on si.sys_code = l.item_type_code and si.status = 1
     left join t_sys_erp_items sei on sei.seq_id=l.item_id and sei.status = 1
     left join t_sys_spm_products ssp on ssp.seq_id=l.item_id and ssp.status = 1
     left join t_lis_itemgroup_head igh on igh.id=l.item_id and igh.status = 1
     left join t_sys_erp_ou ou on ou.erp_type=h.erp_type and ou.status = 1
     inner join t_lis_ouuser ouuser on ouuser.employee_number=h.demand_person_number and ouuser.ou_id = ou.ou_id and ouuser.status = 1
 --    inner join t_lis_demand_collect_issue li on li.collect_line_id = l.collect_line_id and li.issue_scope_id = h.issue_scope_id
     where l.status =1 and h.collect_status in (1,3) and h.collect_headid = 241 and l.project_id is null and h.issue_scope_id = 226
     and l.collect_line_id in (select l.id from T_LIS_DEMAND_COLLECT_line l where l.collect_headid = 201)
     ;
csr_demand csr_demand_collect%rowtype;
BEGIN
   open csr_demand_collect;
     fetch csr_demand_collect into csr_demand;
     loop
            exit when csr_demand_collect%notfound;
          select count(*) into dcount from t_lis_depart_demand d 
              where  d.status = 1 and d.project_id is null and d.collect_depart_id = csr_demand.collect_depart_id
              and d.item_type_code = 'item_code'
              and d.item_id = csr_demand.seq_id;
           
        /*  if(dcount <= 3) then 
            open rcsor for
                    select ddd.r,ddd.id from (
                    select rownum r, dd.id from (select d.* from t_lis_depart_demand d 
                    where d.status = 0 and d.project_id is null
                    and d.collect_depart_id = csr_demand.collect_depart_id
                    and d.item_type_code = 'item_code' 
                    and d.item_id = csr_demand.seq_id
                    order by d.id) dd 
                    ) ddd 
                    where ddd.r <= 3;
            --修改年份
              num := 4;
              loop
                 fetch rcsor into demandId;
                 exit when rcsor%notfound;
                 update t_lis_depart_demand d set d.status=1, d.collect_month = '2016-0' || num, d.string_value1 = '2016/5/10updateFor00000013' where d.id=demandId;
                 num := num + 1;
                end loop;
          end if;*/
          if(dcount > 3) then 
                    open rcsor for
                    select ddd.id from (
                    select rownum r, dd.id from (select d.* from t_lis_depart_demand d 
                    where d.status = 1 and d.project_id is null
                    and d.collect_depart_id = csr_demand.collect_depart_id
                    and d.item_type_code = 'item_code' 
                    and d.item_id = csr_demand.seq_id
                    order by d.id) dd 
                    ) ddd 
                    where ddd.r <= 3;
                /*    
                    loop 
                     fetch rcsor into demandId;
                     exit when rcsor%notfound;
                          update t_lis_depart_demand d set d.status=0, d.string_value1 = '2016/5/10update'where d.id=demandId;
                          
                    end loop;*/
                --失效
                loop
                 fetch rcsor into demandId;
                 exit when rcsor%notfound;
                 update t_lis_depart_demand d set d.status=0, d.string_value1 = '2016/5/10updateFor00000013' where d.id=demandId;
                end loop;
         
                    
          end if;
          
        fetch csr_demand_collect into csr_demand;
        end loop;
     close csr_demand_collect;
     commit;
END PROC_DEMAND_COLLECT_SYNC;
/

