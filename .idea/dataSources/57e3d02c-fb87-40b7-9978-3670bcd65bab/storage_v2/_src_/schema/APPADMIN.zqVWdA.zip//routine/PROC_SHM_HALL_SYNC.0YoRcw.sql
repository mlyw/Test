create PROCEDURE PROC_SHM_HALL_SYNC (startTimestamp timestamp,endTimestamp timestamp) AS
total_value number(15);
count_success number(15);
count_value number(15);
exception_info varchar2(3000);
dept_id number(19);
if_dist_val number(1);
cursor csr_i_shm_hall is
select hall_code,hall_mis_code,hall_name,hall_dept_code,hall_dept_name,hall_type,hall_address,hall_status,hall_area_type,expired_date,hall_contacts,hall_contacts_phone
from i_sys_shm_hall where create_time >= startTimestamp and create_time <= endTimestamp order by seq_id;
i_shm_hall csr_i_shm_hall%rowtype;
begin
  count_success := 0;
  select count(seq_id) into total_value from i_sys_shm_hall where create_time >= startTimestamp and create_time <= endTimestamp;
  open csr_i_shm_hall;
  fetch csr_i_shm_hall into i_shm_hall;
while(csr_i_shm_hall%found) loop
  if(i_shm_hall.hall_type = '1') then
      if_dist_val:= 1;
  elsif(i_shm_hall.hall_type = '0') then
      if_dist_val:= 0;
  end if;
  if(i_shm_hall.hall_dept_name is null) then
     dept_id := null;
  else
    select id into dept_id from t_lis_dept where dept_name = i_shm_hall.hall_dept_name;
  end if;
  select count(seq_id) into count_value from t_sys_shm_hall where hall_mis_code = i_shm_hall.hall_mis_code and hall_status = i_shm_hall.hall_status;
  if(count_value = 1) then
     update t_sys_shm_hall
        set last_updated_date = sysdate,
            hall_code = i_shm_hall.hall_code,
            hall_mis_code = i_shm_hall.hall_mis_code,
            hall_name = i_shm_hall.hall_name,
            hall_dept_id = dept_id,
            hall_dept_code = i_shm_hall.hall_dept_code,
            hall_dept_name = i_shm_hall.hall_dept_name,
            hall_type = i_shm_hall.hall_type,
            hall_address = i_shm_hall.hall_address,
            hall_status = i_shm_hall.hall_status,
            hall_area_type = i_shm_hall.hall_area_type,
            expired_date = i_shm_hall.expired_date,
            hall_contacts = i_shm_hall.hall_contacts,
            --if_distribution =if_dist_val,
            hall_contacts_phone = i_shm_hall.hall_contacts_phone
        where  hall_mis_code = i_shm_hall.hall_mis_code and hall_status = i_shm_hall.hall_status;
  else
      insert into t_sys_shm_hall
           (seq_id,hall_code,hall_mis_code,hall_name,hall_dept_id,hall_dept_code,hall_dept_name,hall_type,hall_address,hall_status,hall_area_type,expired_date,hall_contacts,if_distribution,version,status,created_date,last_updated_date,hall_contacts_phone)
      values
           (seq_sys_shm_hall.nextval,i_shm_hall.hall_code,i_shm_hall.hall_mis_code, i_shm_hall.hall_name,dept_id,i_shm_hall.hall_dept_code,i_shm_hall.hall_dept_name, i_shm_hall.hall_type,i_shm_hall.hall_address,i_shm_hall.hall_status,i_shm_hall.hall_area_type,i_shm_hall.expired_date,i_shm_hall.hall_contacts, if_dist_val,0,1,sysdate,sysdate,i_shm_hall.hall_contacts_phone);
  end if;
  fetch csr_i_shm_hall into i_shm_hall;
  count_success := count_success+1;
end loop;
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','t_sys_shm_hall');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_shm_hall');
close csr_i_shm_hall;
commit;
end;
/

