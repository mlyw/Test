create PROCEDURE PROC_DELIVERY_NOTICE(itime varchar2) AS 
  total_value number(15);
  count_value number(2);
  count_success number(15);
  exception_info varchar2(3000);
  notice_status number(19);
  cursor csr_i_spm_vendorShipping is
  select distinct t.SEQ_ID,
          t.VENDOR_SHIPPING_HEADER_ID,
          t.SPM_PO_HEADER_ID, 
          t.SPM_PO_NUMBER,
          t.MIS_PO_HEADER_ID,
          t.MIS_PO_NUMBER,
          t.VENDOR_SHIPPING_TITLE,
          t.VENDOR_SHIPPING_DESC,
          t.VENDOR_SHIPPING_DATE
  from i_spm_vendorshipping t
  where t.time=itime;
  i_vendorshipping csr_i_spm_vendorShipping%rowtype;
BEGIN
  count_success := 0;
  select count(distinct VENDOR_SHIPPING_HEADER_ID) into total_value from i_spm_vendorshipping where time=itime;
  open csr_i_spm_vendorShipping;
  fetch csr_i_spm_vendorShipping into i_vendorshipping;
  while (csr_i_spm_vendorShipping%found) loop
    count_value := 0;
    select count(id) into count_value from t_lis_delivery_notice_header h where H.Vendor_Shipping_Header_Id=i_vendorshipping.VENDOR_SHIPPING_HEADER_ID;
    if(count_value = 0) then
      insert into t_lis_delivery_notice_header(ID,
                DELIVERY_ORDER_CODE,
                BASE_HEAD_ID,
                QUOTA_TYPE,
                QUOTA_STATUS,
                BATCH_STATUS,
                STATUS,
                VERSION,
                CREATED_USER,
                CREATED_DATE,
                LAST_UPDATED_USER,
                LAST_UPDATED_DATE,
                VENDOR_SHIPPING_TITLE,
                VENDOR_SHIPPING_DESC,
                VENDOR_SHIPPING_DATE,
                VENDOR_SHIPPING_HEADER_ID,
                SPM_PO_HEADER_ID,
                SPM_PO_NUMBER,
                MIS_PO_HEADER_ID,
                MIS_PO_NUMBER,
                notice_status)
      values(seq_lis_delivery_notice_head.nextval,
             to_char(sysdate,'yyyymmddHHMMSS')||'-'||i_vendorshipping.MIS_PO_NUMBER,
             i_vendorshipping.SPM_PO_HEADER_ID,
             'batch_type',-2,0,1,1,'12345678',sysdate,'12345678',sysdate,
             i_vendorshipping.VENDOR_SHIPPING_TITLE,
             i_vendorshipping.VENDOR_SHIPPING_DESC,
             i_vendorshipping.VENDOR_SHIPPING_DATE,
             i_vendorshipping.VENDOR_SHIPPING_HEADER_ID,
             i_vendorshipping.SPM_PO_HEADER_ID,
             i_vendorshipping.SPM_PO_NUMBER,
             i_vendorshipping.MIS_PO_HEADER_ID,
             i_vendorshipping.MIS_PO_NUMBER,
             1);
    else 
      select h.notice_status into notice_status from t_lis_delivery_notice_header h where h.VENDOR_SHIPPING_HEADER_ID=i_vendorshipping.VENDOR_SHIPPING_HEADER_ID;
      if( 1 = notice_status) then
        update t_lis_delivery_notice_header h 
        set h.BASE_HEAD_ID= i_vendorshipping.SPM_PO_HEADER_ID,
            h.VERSION=h.VERSION+1,
            h.LAST_UPDATED_DATE=sysdate,
            h.SPM_PO_HEADER_ID=i_vendorshipping.SPM_PO_HEADER_ID,
            h.SPM_PO_NUMBER=i_vendorshipping.SPM_PO_NUMBER,
            h.MIS_PO_HEADER_ID=i_vendorshipping.MIS_PO_HEADER_ID,
            h.MIS_PO_NUMBER=i_vendorshipping.MIS_PO_NUMBER
        where h.VENDOR_SHIPPING_HEADER_ID=i_vendorshipping.VENDOR_SHIPPING_HEADER_ID and h.notice_status=1;
      end if;
    end if;
    fetch csr_i_spm_vendorShipping into i_vendorshipping;
    count_success:=count_success+1;
  end loop;
  close csr_i_spm_vendorShipping ;
  --插入日志
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_lis_delivery_notice_header');
  exception when others then
      exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
    insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_lis_delivery_notice_header');
  commit;
END PROC_DELIVERY_NOTICE;
/

