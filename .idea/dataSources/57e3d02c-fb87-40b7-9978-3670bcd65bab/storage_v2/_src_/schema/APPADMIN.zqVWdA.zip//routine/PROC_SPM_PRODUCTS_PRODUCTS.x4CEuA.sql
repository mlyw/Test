create PROCEDURE "PROC_SPM_PRODUCTS_PRODUCTS" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
product_seq_id number(19);
cursor csr_i_products_products is 
--组合产品关联关系
  select product_id,child_product_id,child_product_code,child_product_name,product_count,created_date,last_update_date from i_spm_products_product 
  where import_date between start_time and end_time order by created_date;
  i_products_products csr_i_products_products%rowtype;
  begin
    count_success := 0;
    select count(seq_id) into total_value from i_spm_products_product where import_date > start_time and import_date < end_time ;
    open csr_i_products_products;
    fetch csr_i_products_products into i_products_products;
    while (csr_i_products_products%found) loop
      select seq_id into product_seq_id from t_sys_spm_products where product_id = i_products_products.product_id;
      select count(seq_id) into count_value from t_sys_spm_products_products s where s.product_id = product_seq_id and s.child_product_id = i_products_products.child_product_id and s.child_product_code = i_products_products.child_product_code and s.status = 1;
      if(count_value >= 1) then 
            update t_sys_spm_products_products
            set product_id = product_seq_id,
                child_product_id = i_products_products.child_product_id,
                child_product_code = i_products_products.child_product_code,
                child_product_name = i_products_products.child_product_name,
                
                product_count = i_products_products.product_count,
                status = 1,
                last_updated_date = sysdate
            where child_product_id =  i_products_products.child_product_id and product_id = product_seq_id;
                     
      else 
        insert into t_sys_spm_products_products (seq_id,product_id,child_product_id,child_product_code,child_product_name,product_count,version,status,created_date,last_updated_date)
         values (SEQ_LIS_SPM_PRODUCTS_PRODUCTS.nextval,product_seq_id,i_products_products.child_product_id,i_products_products.child_product_code,i_products_products.child_product_name,
         i_products_products.product_count,1,1,i_products_products.created_date,i_products_products.last_update_date);

      end if;
      fetch csr_i_products_products into i_products_products;
      count_success:=count_success+1;
      end loop;
      close csr_i_products_products;
      commit;
      --插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value, count_success, sysdate,'同步成功','t_sys_spm_products_products');
exception when others then
  --count_num := count_success;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_spm_products_products');
close csr_i_products_products;
commit;
end;
/

