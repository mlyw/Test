create package dynamic_checking_pkg is
   type cur_dynamic_checking is ref cursor;
   procedure proc_dynamic_checking(ouEmployeeNumber in varchar2,ouId in long,flag in varchar2,pagenum in number,pagesize in number,warehouse_id in varchar2,dynamic_checking out cur_dynamic_checking,total out number);
end dynamic_checking_pkg;
/

