create PACKAGE body PROC_RMSALES_ONHAND_PKG IS
  PROCEDURE "PROC_RMSALES_DEDUCTION_ONHAND"(fileName         IN VARCHAR2,
                                            rmsalesId        IN NUMBER,
                                            itemCode         IN VARCHAR2,
                                            erpOrderBatch    IN VARCHAR2,
                                            quantity         IN NUMBER,
                                            subinventoryCode IN VARCHAR2,
                                            orgCode          IN VARCHAR2,
                                            temp_list        OUT cursor_rmsales_list) AS
    quantity_vo          NUMBER(19, 5); -- 用来接收传值和赋值计算应用 wjr
    currentOnHandQty     NUMBER(19, 5); --当前循环实时现有量
    updateCount          NUMBER(10);
    countValue           NUMBER(10);
    whCurrentOnhandQtyId NUMBER(19);
    subWarehouseId       NUMBER(19);
    total_Qty            NUMBER(19, 5);
    reverse_count        NUMBER(19); --冻结条数
    reverse_qty          NUMBER(19, 5); --冻结现有量数量
    CURSOR lis_wh_onhand_qty IS --定义LIS WH_CURRENT_ONHAND_QTY的游标 wjr
      SELECT wh.id, wh.version, wh.onhand_quantity,wh.cost_unit_price
        FROM T_WH_CURRENT_ONHAND_QUANTITY wh
       INNER JOIN t_Warehouse_Define wd
          ON wh.warehouse_define_id = wd.id
       WHERE wh.item_code = itemCode
         AND wh.mis_pic_code = erpOrderBatch
         AND wh.onhand_quantity > 0
         AND wh.status = 1
         AND EXISTS
       (SELECT 1
                FROM T_SYS_ERP_SUBINVENTORY sub
               INNER JOIN T_SYS_ERP_ORGANIZATIONS org
                  ON org.organization_id = sub.organizations_id
               WHERE sub.status = 1
                 AND sub.SUBINVENTORY_CODE = subinventoryCode
                 AND org.organization_code = orgCode
                 AND sub.SUBINVENTORY_ID = wd.MIS_SUBINVENTOEY_ID)
       ORDER BY wh.created_date;
    whonhand_qty lis_wh_onhand_qty%rowtype; -- 将游标的每一条数据赋值给whonhand_qty
  BEGIN
    quantity_vo := quantity; -- 赋值
  
    if quantity_vo >= 0 then
      --当RM SALES 的数量大于0 就执行保存操作   
      select count(wd.id)
        into countValue
        from t_sys_erp_subinventory sub
       INNER JOIN t_warehouse_define wd
          on sub.subinventory_id = wd.mis_subinventoey_id
       where sub.subinventory_code = subinventoryCode
         and sub.status = 1
         and wd.status = 1
         and sub.organizations_id in
             (select org.organization_id
                from T_SYS_ERP_ORGANIZATIONS org
               where org.status = 1
                 and org.organization_code = orgCode);
      if 1 = countValue then
        select wd.id
          into subWarehouseId
          from t_sys_erp_subinventory sub
         INNER JOIN t_warehouse_define wd
            on sub.subinventory_id = wd.mis_subinventoey_id
         where sub.subinventory_code = subinventoryCode
           and sub.status = 1
           and wd.status = 1
           and sub.organizations_id in
               (select org.organization_id
                  from T_SYS_ERP_ORGANIZATIONS org
                 where org.status = 1
                   and org.organization_code = orgCode);
        select S_WH_CURRENT_ONHAND_QUANTITY.NEXTVAL
          into whCurrentOnhandQtyId
          from dual;
        insert into T_WH_CURRENT_ONHAND_QUANTITY
          (id,
           item_code,
           item_desc,
           item_id,
           mis_pic_code,
           onhand_quantity,
           STRING_VALUE1,
           uom_code,
           uom_desc,
           Warehouse_Define_Id,
           ERP_TYPE,
           status,
           version,
           Created_Date,
           CREATED_USER,
           LAST_UPDATED_DATE,
           LAST_UPDATED_USER)
          select whCurrentOnhandQtyId,
                 rmitem.*,
                 1,
                 1,
                 sysdate,
                 '12345678',
                 sysdate,
                 '12345678'
            from (select rm.item_code,
                         item.item_name,
                         rm.item_id,
                         rm.erp_order_batch,
                         rm.quantity,
                         rm.origin_filename || ' ' || rm.operation_type,
                         item.uom_code,
                         item.uom_desc,
                         subWarehouseId,
                         ouorg.erp_type
                    from t_lis_rm_sales rm
                    left join t_sys_erp_items item
                      on rm.item_id = item.seq_id
                    left join (select ou.erp_type, ORG.ORGANIZATION_CODE
                                from T_SYS_ERP_OU ou
                               inner join T_SYS_ERP_ORGANIZATIONS org
                                  on org.ou_id = OU.OU_ID) ouorg
                      on rm.organization_code = ouorg.organization_code
                   where rm.seq_id = rmsalesId) rmitem;
      
        insert into t_lis_rm_warehouse_relation
          (seq_id,
           rm_sales_id,
           warehouse_current_onhandqty_id,
           status,
           version,
           created_date,
           last_updated_date,
           filename,
           pre_sub_quantity,
           QUANTITY)
        values
          (SEQ_LIS_RM_WAREHOUSE.NEXTVAL,
           rmsalesId,
           whCurrentOnhandQtyId,
           1,
           0,
           sysdate,
           sysdate,
           fileName,
           0,
           quantity_vo);
        update t_lis_rm_sales rm
           set rm.flag              = 'Y',
               rm.version           = nvl(rm.version, 0) + 1,
               rm.last_updated_date = sysdate
         where rm.seq_id = rmsalesId; --更新rm sales此条数据为标记成功  
        commit;
      end if;
    else
      total_qty := 0;
      select SUM(nvl(QTY.ONHAND_QUANTITY, 0))
        into total_qty
        from T_WH_CURRENT_ONHAND_QUANTITY QTY
       where QTY.STATUS = 1
         and QTY.ONHAND_QUANTITY > 0
         and QTY.ITEM_CODE = itemCode
         and QTY.MIS_PIC_CODE = erpOrderBatch
         and exists
       (select 1
                from T_WAREHOUSE_DEFINE      WD,
                     T_SYS_ERP_SUBINVENTORY  INV,
                     T_SYS_ERP_ORGANIZATIONS ORG
               where WD.STATUS = 1
                 and INV.STATUS = 1
                 and INV.SUBINVENTORY_ID = WD.MIS_SUBINVENTOEY_ID
                 and ORG.ORGANIZATION_ID = INV.ORGANIZATIONS_ID
                 and INV.SUBINVENTORY_CODE = subinventoryCode
                 and ORG.ORGANIZATION_CODE = orgCode
                 and WD.id = QTY.WAREHOUSE_DEFINE_ID);
      if total_qty + quantity >= 0 then
        for whonhand_qty in lis_wh_onhand_qty loop
          updateCount := 0;
          --LIS现有量 currentOnHandQty
          select wh.onhand_quantity
            into currentOnHandQty
            from T_WH_CURRENT_ONHAND_QUANTITY wh
           where wh.id = whonhand_qty.id;
          reverse_qty := 0;
          --冻结
          select count(*)
            into reverse_count
            from t_sys_item_resereve_info info
           where info.status = 1
             and info.onhand_id = whonhand_qty.id
             and (info.reserve_end_day - info.reserve_start_day) < 31;
          if (reverse_count > 0) then
            select sum(info.reserve_quantity)
              into reverse_qty
              from t_sys_item_resereve_info info
             where info.status = 1
               and info.onhand_id = whonhand_qty.id;
          end if;
          --如果本条现有量减去冻结<=0，则循环下一个现有量,否则 扣减
          if (currentOnHandQty - reverse_qty <= 0) then
            update t_lis_rm_sales rm
               set rm.flag              = '',
                   rm.string_value1     = '存在冻结数据.现有量ID' || whonhand_qty.id,
                   rm.cost_unit_price   = whonhand_qty.cost_unit_price,--成本单价 lmt
                   rm.last_updated_date = sysdate
             where rm.seq_id = rmsalesId; --更新rm sales此条数据为标记成功
            commit;
          else
            --扣减
            if (currentOnHandQty - reverse_qty + quantity_vo = 0) then
              -- (1) 判断如果等于0 ,结束此循环 ,更新三张表的关系
              update T_WH_CURRENT_ONHAND_QUANTITY wh
                 set wh.onhand_quantity   = currentOnHandQty + quantity_vo,
                     wh.version           = nvl(wh.version, 0) + 1,
                     wh.last_updated_date = sysdate --更新LIS 物料现有量
               where wh.id = whonhand_qty.id
                 and wh.version = whonhand_qty.version;
              updateCount := sql%rowcount; -- 更新了现有量条数
              if (updateCount > 0) then
                update t_lis_rm_sales rm
                   set rm.flag              = 'Y',
                       rm.version           = nvl(rm.version, 0) + 1,
                       rm.cost_unit_price   = whonhand_qty.cost_unit_price,--成本单价 lmt                       
                       rm.last_updated_date = sysdate --更新rm sales此条数据为标记成功
                 where rm.seq_id = rmsalesId;
                insert into t_lis_rm_warehouse_relation
                  (seq_id,
                   rm_sales_id,
                   warehouse_current_onhandqty_id,
                   status,
                   version,
                   created_date,
                   last_updated_date,
                   filename,
                   pre_sub_quantity,
                   QUANTITY)
                values
                  (SEQ_LIS_RM_WAREHOUSE.NEXTVAL,
                   rmsalesId,
                   whonhand_qty.id,
                   1,
                   0,
                   sysdate,
                   sysdate,
                   fileName,
                   currentOnHandQty,
                   quantity_vo);
                commit;
                exit;
              end if;
            elsif (currentOnHandQty - reverse_qty + quantity_vo > 0) then
              -- (2) 判断如果等于>0 ,结束此循环 ,更新三张表的关系
              update T_WH_CURRENT_ONHAND_QUANTITY wh
                 set wh.onhand_quantity   = currentOnHandQty + quantity_vo,
                     wh.version           = nvl(wh.version, 0) + 1,
                     wh.last_updated_date = sysdate --更新LIS 物料现有量
               where wh.id = whonhand_qty.id
                 and wh.version = whonhand_qty.version;
              updateCount := sql%rowcount;
              if (updateCount > 0) then
                update t_lis_rm_sales rm
                   set rm.flag              = 'Y',
                       rm.version           = nvl(rm.version, 0) + 1,
                       rm.cost_unit_price   = whonhand_qty.cost_unit_price,--成本单价 lmt                       
                       rm.last_updated_date = sysdate --更新rm sales此条数据为标记成功
                 where rm.seq_id = rmsalesId;
                insert into t_lis_rm_warehouse_relation
                  (seq_id,
                   rm_sales_id,
                   warehouse_current_onhandqty_id,
                   status,
                   version,
                   created_date,
                   last_updated_date,
                   filename,
                   pre_sub_quantity,
                   QUANTITY)
                values
                  (SEQ_LIS_RM_WAREHOUSE.NEXTVAL,
                   rmsalesId,
                   whonhand_qty.id,
                   1,
                   0,
                   sysdate,
                   sysdate,
                   fileName,
                   currentOnHandQty,
                   quantity_vo);
                commit;
                exit;
              end if;
            elsif (currentOnHandQty - reverse_qty + quantity_vo < 0) then
              -- (3) 判断如果等于 < 0 ,继续循环 ,更新三张表的关系
              update T_WH_CURRENT_ONHAND_QUANTITY wh
                 set wh.onhand_quantity   = 0 + reverse_qty,
                     wh.version           = nvl(wh.version, 0) + 1,
                     wh.last_updated_date = sysdate --更新LIS 物料现有量
               where wh.id = whonhand_qty.id
                 and wh.version = whonhand_qty.version;
              updateCount := sql%rowcount;
              if (updateCount > 0) then
                insert into t_lis_rm_warehouse_relation
                  (seq_id,
                   rm_sales_id,
                   warehouse_current_onhandqty_id,
                   status,
                   version,
                   created_date,
                   last_updated_date,
                   filename,
                   pre_sub_quantity,
                   QUANTITY)
                values
                  (SEQ_LIS_RM_WAREHOUSE.NEXTVAL,
                   rmsalesId,
                   whonhand_qty.id,
                   1,
                   0,
                   sysdate,
                   sysdate,
                   fileName,
                   currentOnHandQty,
                   quantity_vo);
                update t_lis_rm_sales rm
                   set rm.flag              = 'Y',
                       rm.version           = nvl(rm.version, 0) + 1,
                       rm.cost_unit_price   = whonhand_qty.cost_unit_price,--成本单价 lmt                       
                       rm.last_updated_date = sysdate
                 where rm.seq_id = rmsalesId; --更新rm sales此条数据为标记成功
                quantity_vo := currentOnHandQty - reverse_qty + quantity_vo;
                commit;
              end if;
            end if;
          end if;
        end loop;
      else
        update t_lis_rm_sales rm
           set rm.flag              = '',
               rm.string_value1     = '扣减失败,现有量不足',
               rm.last_updated_date = sysdate
         where rm.seq_id = rmsalesId; --更新rm sales此条数据为标记成功
        commit;
      end if;
    end if;
    open temp_list for
      select *
        from t_lis_rm_sales rm
       where rm.seq_id = rmsalesId
         and rm.flag = 'Y';
  END PROC_RMSALES_DEDUCTION_ONHAND;
end PROC_RMSALES_ONHAND_PKG;
/

