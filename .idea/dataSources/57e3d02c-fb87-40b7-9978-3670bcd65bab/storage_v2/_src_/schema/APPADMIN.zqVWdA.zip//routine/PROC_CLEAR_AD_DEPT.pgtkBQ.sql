create procedure "PROC_CLEAR_AD_DEPT"(end_time timestamp) is
total_value number(15);
exception_info varchar2(3000);
begin 
  select count(seq_id) into total_value from t_ad_dept where import_date<sysdate-7;
  delete from t_ad_user where import_date <sysdate-7;
  commit;
 --插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value, total_value, sysdate,'清除成功','CLR_T_AD_USER');
  exception when others then
   rollback;  
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,exception_info,'CLR_T_AD_USER');
commit;
end;
/

