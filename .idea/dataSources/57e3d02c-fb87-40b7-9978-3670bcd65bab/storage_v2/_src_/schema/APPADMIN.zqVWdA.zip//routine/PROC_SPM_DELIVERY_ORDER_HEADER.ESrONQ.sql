create procedure PROC_SPM_DELIVERY_ORDER_HEADER(startDate timestamp, endDate timestamp)
AS
    total_value number(19);
    count_success number(19);
    exception_info varchar2(3000);
    version_value NUMBER(10);
    count_value NUMBER(19);
    
    CURSOR csr_order_head IS
      SELECT 
        delivery_order_id,
        delivery_order_number,
        delivery_order_desc,
        delivery_order_createdate,
        delivery_order_createuser,
        vendor_id, vendor_name,
        vendor_contact,
        vendor_contact_tel,
        delivery_site,
        delivery_recipient,
        delivery_recipient_tel,
        agree_status,
        import_date,
        remark1, remark2
      FROM I_SPM_DELIVERY_ORDER_HEADER WHERE IMPORT_DATE BETWEEN startDate AND endDate;
    i_order_header csr_order_head%ROWTYPE;

begin
    total_value := 0;
    count_success := 0;
    
    SELECT COUNT(seq_id) INTO total_value FROM I_SPM_DELIVERY_ORDER_HEADER WHERE IMPORT_DATE BETWEEN startDate AND endDate;
    
    OPEN csr_order_head;

    LOOP
      FETCH csr_order_head INTO i_order_header;
      EXIT WHEN(csr_order_head%NOTFOUND);
        count_value := 0;
      
        -- judging update or insert
        SELECT COUNT(seq_id) INTO count_value FROM T_SPM_DELIVERY_ORDER_HEADER 
            WHERE DELIVERY_ORDER_ID = i_order_header.delivery_order_id 
              AND DELIVERY_ORDER_NUMBER = i_order_header.delivery_order_number AND status = 1;
        
        -- set version
        IF (count_value >= 1) THEN
            SELECT version INTO version_value FROM T_SPM_DELIVERY_ORDER_HEADER 
              WHERE DELIVERY_ORDER_ID = i_order_header.delivery_order_id 
                AND DELIVERY_ORDER_NUMBER = i_order_header.delivery_order_number AND status = 1;
            version_value := version_value + 1;
        ELSE
            version_value := 0;
        END IF;
        
        -- executing insert or update
        IF (count_value >= 1) THEN
          UPDATE T_SPM_DELIVERY_ORDER_HEADER
            SET
              DELIVERY_ORDER_ID = i_order_header.delivery_order_id,
              DELIVERY_ORDER_NUMBER = i_order_header.delivery_order_number,
              DELIVERY_ORDER_DESC = i_order_header.delivery_order_desc,
              DELIVERY_ORDER_CREATEDATE = i_order_header.delivery_order_createdate,
              DELIVERY_ORDER_CREATEUSER = i_order_header.delivery_order_createuser,
              VENDOR_ID = i_order_header.vendor_id,
              VENDOR_NAME = i_order_header.vendor_name,
              VENDOR_CONTACT = i_order_header.vendor_contact,
              VENDOR_CONTACT_TEL = i_order_header.vendor_contact_tel,
              IMPORT_DATE = i_order_header.import_date,
              DELIVERY_SITE = i_order_header.delivery_site,
              DELIVERY_RECIPIENT = i_order_header.delivery_recipient,
              DELIVERY_RECIPIENT_TEL = i_order_header.delivery_recipient_tel,
              AGREE_STATUS = i_order_header.agree_status,
              "VERSION" = version_value,
              LAST_UPDATED_DATE = systimestamp,
              REMARK1 = i_order_header.remark1,
              REMARK2 = i_order_header.remark2
            WHERE status = 1
              AND DELIVERY_ORDER_ID = i_order_header.delivery_order_id 
              AND DELIVERY_ORDER_NUMBER = i_order_header.delivery_order_number;
        ELSE
          INSERT INTO T_SPM_DELIVERY_ORDER_HEADER(
              DELIVERY_ORDER_ID,
              DELIVERY_ORDER_NUMBER,
              DELIVERY_ORDER_DESC,
              DELIVERY_ORDER_CREATEDATE,
              DELIVERY_ORDER_CREATEUSER,
              VENDOR_ID,
              VENDOR_NAME,
              VENDOR_CONTACT,
              VENDOR_CONTACT_TEL,
              IMPORT_DATE,
              DELIVERY_SITE,            
              DELIVERY_RECIPIENT,
              DELIVERY_RECIPIENT_TEL,
              AGREE_STATUS,
              SEQ_ID,
              "VERSION", 
              STATUS,
              CREATED_DATE,
              LAST_UPDATED_DATE,
              REMARK1,
              REMARK2
          ) VALUES(
              i_order_header.delivery_order_id,
              i_order_header.delivery_order_number,
              i_order_header.delivery_order_desc,
              i_order_header.delivery_order_createdate,
              i_order_header.delivery_order_createuser,
              i_order_header.vendor_id,
              i_order_header.vendor_name,
              i_order_header.vendor_contact,
              i_order_header.vendor_contact_tel,
              i_order_header.import_date,
              i_order_header.delivery_site,
              i_order_header.delivery_recipient,
              i_order_header.delivery_recipient_tel,
              i_order_header.agree_status,
              T_SIMPLE_DETECTION_SEQ.NEXTVAL,
              version_value,
              1,
              systimestamp,
              systimestamp,
              i_order_header.remark1,
              i_order_header.remark2
          );
        END IF;
        
        count_success := count_success + 1;
    END LOOP;

    -- log
    INSERT INTO i_erp_logs VALUES(i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','T_SPM_DELIVERY_ORDER_HEADER');
    EXCEPTION WHEN OTHERS THEN 
        exception_info := 'ERR: An error occurred with info:' || to_char(sqlcode) || ' ' || sqlerrm;
        INSERT INTO i_erp_logs 
          VALUES(i_erp_logs_seq.nextval, total_value,count_success, sysdate, exception_info, 'T_SPM_DELIVERY_ORDER_HEADER');
    
    CLOSE csr_order_head;
    COMMIT;
end PROC_SPM_DELIVERY_ORDER_HEADER;
/

