create procedure proc_spm_product_sync(startTimestamp timestamp,endTimestamp timestamp) as
total_value number(15);
count_success number(15);
count_value number(15);
exception_info varchar2(3000);
cursor csr_i_product is
select product_id,product_code,product_name,product_category_id,product_category_code,product_category_name,uom_code,uom_desc,isno_accessories,case validity_flag when 'Y' then 1 when 'N' then 0 end as validity_flag,case uniqe_identifier_flag when 'Y' then 1 when 'N' then 0 end as uniqe_identifier_flag from i_spm_products 
where created_time between  startTimestamp and endTimestamp order by seq_id desc;
i_product csr_i_product%rowtype;
begin
  count_success := 0;
  select count(seq_id) into total_value from i_spm_products where created_time between startTimestamp and endTimestamp;
  open csr_i_product;
  fetch csr_i_product into i_product;
while(csr_i_product%found) loop
  select count(seq_id) into count_value from t_sys_spm_products where product_id = i_product.product_id;
  if(count_value = 1) then
     update t_sys_spm_products
        set last_updated_date = sysdate,
            product_id = i_product.product_id,
            product_code = i_product.product_code,
            product_name = i_product.product_name,
            product_category_id = i_product.product_category_id,
            product_category_code = i_product.product_category_code,
            product_category_name = i_product.product_category_name,
            uom_code = i_product.uom_code,
            uom_desc = i_product.uom_desc,
            validity_flag = i_product.validity_flag,
            uniqe_identifier_flag = i_product.uniqe_identifier_flag,
            isno_accessories = i_product.isno_accessories
        where product_id = i_product.product_id;
  else 
        insert into t_sys_spm_products
           (seq_id,product_id,product_code,product_name,product_category_id, 
            product_category_code,product_category_name,uom_code,uom_desc,validity_flag, uniqe_identifier_flag, RECEIVE_PIC_FLAG,isno_accessories,CREATED_DATE, last_updated_date,status,version)
        values   
           (SEQ_SPM_PRODUCTS.Nextval,i_product.product_id,i_product.product_code,i_product.product_name,i_product.product_category_id, 
           i_product.product_category_code,i_product.product_category_name,i_product.uom_code,i_product.uom_desc,i_product.validity_flag,i_product.uniqe_identifier_flag, 1,i_product.isno_accessories, sysdate, sysdate, 1, 1);
  end if;
fetch csr_i_product into i_product;
count_success := count_success+1;
end loop;
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','t_sys_spm_products');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_spm_products');
close csr_i_product;
commit;
end;
/

