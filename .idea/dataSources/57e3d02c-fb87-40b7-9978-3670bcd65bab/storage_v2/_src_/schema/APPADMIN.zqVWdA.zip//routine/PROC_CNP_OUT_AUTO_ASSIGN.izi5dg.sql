create procedure proc_cnp_out_auto_assign(headerId        in number,
                                                     flag            out number,
                                                     resultInfo      out varchar2,
                                                     ouEmployeeNumbe in varchar2,
                                                     ouId            in number,
                                                     erpType         in varchar2) as

  cursor c_out_line_info is
  
    select line.id,
           line.item_id,
           line.apply_quty - nvl(line.tol_asgn_quty, 0),
           line.item_code,
           (select h.project_code from t_out_hd h where h.id = headerId),
           line.mis_pic_code
      from t_out_ln line
     where line.outhdinfo_id = headerId
       and (line.ord_ln_status is null or line.ord_ln_status = 2 or
           line.ord_ln_status = 8);
  c_quota_detail_info sys_refcursor;

  type r_onhand_info is record(
    onhand_id                 number,
    onhand_quantity           number(19, 5),
    quota_quantity            number(19, 5),
    warehouse_id              number,
    onhand_item_id            number,
    onhand_item_code          varchar2(30),
    mis_pic_code              varchar2(50),
    rec_pic_code              varchar2(50),
    vendor_id                 number,
    locator_id                number,
    locator_code              varchar2(50),
    product_unit_price        number(19, 5),
    product_unit_price_ex_tax number(19, 5),
    quota_locking_id          number);

  type r_c_onhand_info is ref cursor return r_onhand_info;

  c_onhand_info r_c_onhand_info;

  lineid         number;
  itemid         number;
  itemCode       varchar2(30);
  assign_line_id number;
  quantity       number(19, 5);
  project_code   varchar2(30);
  misPicNO       varchar2(30);
  temp_quantity  number(19, 5);
  limit_quantity number(19, 5);
  recordCount    number;

  quota_type         varchar2(20);
  quota_control_type number;
  quota_head_id      number;
  quota_line_id      number;
  quota_detail_id    number;

  employeeNumbe varchar2(20);

  v_onhand_info r_onhand_info;

  v_total_onhand_quantity number(19, 5);

  v_record_count number;

  E_EXECUTING_EXCEPTION exception;
begin
  select count(t.business_id)
    into v_record_count
    from t_lis_auto_assign_temp t
   where t.business_id = headerid;
  if v_record_count > 0 then
    raise E_EXECUTING_EXCEPTION;
  end if;
  insert into t_lis_auto_assign_temp values (headerid);
  commit;
  resultInfo    := '<p>自动分配分配成功:</p>';
  flag          := 1;
  employeeNumbe := substr(ouEmployeeNumbe,
                          instr(ouEmployeeNumbe, '_', 1, 1) + 1,
                          length(ouEmployeeNumbe) -
                          instr(ouEmployeeNumbe, '_', 1, 1));
  open c_out_line_info;
  loop
    fetch c_out_line_info
      into lineid, itemid, quantity, itemCode, project_code, misPicNO;
    exit when c_out_line_info%notfound;
    --因为在申请出库已经判断过所申请的物料是否配额控制 所以只需要查询配额冻结记录里面有没有该记录就行了
    select count(rq.id)
      into recordCount
      from t_lis_recipient_quota_reserve rq
     where rq.status = 1
       and rq.business_order_line_id = lineId;
    temp_quantity := quantity;
    if recordCount > 0 then
      --如果该物料做了配额管理 还要查询控制方式
      open c_quota_detail_info for
        select distinct rd.header_id, rd.line_id, rd.id
          from t_lis_recipient_quota_detail rd
         where rd.id in
               (select rq.quota_detail_id
                  from t_lis_recipient_quota_reserve rq
                 where rq.status = 1
                   and rq.business_order_line_id = lineId);
      loop
        fetch c_quota_detail_info
          into quota_head_id, quota_line_id, quota_detail_id;
        exit when c_quota_detail_info%notfound;
        select rh.quota_type, rl.quota_control_type
          into quota_type, quota_control_type
          from t_lis_recipient_quota_header rh
          join t_lis_recipient_quota_line rl
            on rh.id = rl.header_id
         where rh.status = 1
           and rl.status = 1
           and rh.id = quota_head_id
           and rl.id = quota_line_id;
        if quota_type = 'batch_type' then
          --如果配额类型是批次 要查询配额的现有量
        
          --现有量必须大于或等于申请数量 不再部分分配
          select sum(a.onhand_quantity - nvl(f.RESERVE_QUANTITY, 0))
            into v_total_onhand_quantity
            from t_wh_current_onhand_quantity a
            join t_warehouse_access_user d
              on a.warehouse_define_id = d.warehouse_define_id
             and d.employ_number = employeeNumbe
            left join T_SYS_ERP_LOCATORS l
              on a.LOCATOR_ID = l.LOCATOR_ID
             and l.ERP_TYPE = erpType
            left join T_SYS_SPM_PRODUCTS b
              on a.product_id = b.seq_id
            left join (select qll.quota_quantity - nvl(mk.asgn_quty, 0) ql_quota_quantity,
                              qll.onhand_id,
                              qll.id
                         from t_lis_recipient_quota_locking qll
                         left join t_out_notmk mk
                           on qll.id = mk.quota_locking_id
                        where qll.detail_id = quota_detail_id) ql
              on ql.onhand_id = a.id
            left join (select e.onhand_id,
                              sum(nvl(e.RESERVE_QUANTITY, 0)) as RESERVE_QUANTITY
                         from T_SYS_ITEM_RESEREVE_INFO e
                        where sysdate < e.reserve_end_day
                          and e.status = 1
                        group by e.onhand_id) f
              on a.id = f.onhand_id
            left join T_WAREHOUSE_DEFINE w
              on a.warehouse_define_id = w.id
             and w.is_storage like 'Y'
             and w.MIS_OU_ID = ouId
           where a.onhand_quantity - nvl(f.RESERVE_QUANTITY, 0) > 0
             and a.item_id = itemid
             and a.mis_pic_code = misPicNO --添加mis批次号
             and a.id in (select tql.onhand_id
                            from t_lis_recipient_quota_locking tql
                           where tql.detail_id = quota_detail_id)
             and a.ERP_TYPE = erpType
             and a.status = 1
             and (l.LOCATOR_CODE like '%' || project_code || '%' or
                 l.locator_code not like '%|%' or l.locator_code is null)
             and w.CATEGORY_ID =
                 (select twc.id
                    from T_WAREHOUSE_CATEGORY twc
                   where twc.CODE like '01')
                --过滤部分子库存
             and w.id not in
                 (select wd.id
                    from T_WAREHOUSE_DEFINE wd
                   INNER JOIN t_sys_erp_subinventory sub
                      ON wd.mis_subinventoey_id = sub.subinventory_id
                   INNER JOIN t_sys_erp_organizations org
                      on sub.ORGANIZATIONS_ID = org.ORGANIZATION_ID
                   where sub.status = 1
                     and org.status = 1
                     and org.ORGANIZATION_ID = 86
                     and sub.SUBINVENTORY_CODE in ('C990', 'C990-1', 'C999'))
           order by a.created_date;
          if v_total_onhand_quantity >= quantity then
            open c_onhand_info for
              select a.id,
                     a.onhand_quantity - nvl(f.RESERVE_QUANTITY, 0),
                     ql.ql_quota_quantity,
                     a.warehouse_define_id,
                     a.item_id,
                     a.item_code,
                     a.mis_pic_code,
                     a.receipt_pic_code,
                     a.vendor_id,
                     a.locator_id,
                     a.locator_code,
                     a.cost_unit_price product_unit_price, --成本单价，update by lmt20180615
                     a.product_unit_price_ex_tax,
                     ql.id
                from t_wh_current_onhand_quantity a
                join t_warehouse_access_user d
                  on a.warehouse_define_id = d.warehouse_define_id
                 and d.employ_number = employeeNumbe
                left join T_SYS_ERP_LOCATORS l
                  on a.LOCATOR_ID = l.LOCATOR_ID
                 and l.ERP_TYPE = erpType
                left join T_SYS_SPM_PRODUCTS b
                  on a.product_id = b.seq_id
                left join (select qll.quota_quantity - nvl(mk.asgn_quty, 0) ql_quota_quantity,
                                  qll.onhand_id,
                                  qll.id
                             from t_lis_recipient_quota_locking qll
                             left join t_out_notmk mk
                               on qll.id = mk.quota_locking_id
                            where qll.detail_id = quota_detail_id) ql
                  on ql.onhand_id = a.id
                left join (select e.onhand_id,
                                  sum(nvl(e.RESERVE_QUANTITY, 0)) as RESERVE_QUANTITY
                             from T_SYS_ITEM_RESEREVE_INFO e
                            where sysdate < e.reserve_end_day
                              and e.status = 1
                            group by e.onhand_id) f
                  on a.id = f.onhand_id
                left join T_WAREHOUSE_DEFINE w
                  on a.warehouse_define_id = w.id
                 and w.is_storage like 'Y'
                 and w.MIS_OU_ID = ouId
               where a.onhand_quantity - nvl(f.RESERVE_QUANTITY, 0) > 0
                 and a.item_id = itemid
                 and a.mis_pic_code = misPicNO --添加mis批次号
                 and a.id in
                     (select tql.onhand_id
                        from t_lis_recipient_quota_locking tql
                       where tql.detail_id = quota_detail_id)
                 and a.ERP_TYPE = erpType
                 and a.status = 1
                 and (l.LOCATOR_CODE like '%' || project_code || '%' or
                     l.locator_code not like '%|%' or
                     l.locator_code is null)
                 and w.CATEGORY_ID =
                     (select twc.id
                        from T_WAREHOUSE_CATEGORY twc
                       where twc.CODE like '01')
                    --过滤部分子库存
                 and w.id not in
                     (select wd.id
                        from T_WAREHOUSE_DEFINE wd
                       INNER JOIN t_sys_erp_subinventory sub
                          ON wd.mis_subinventoey_id = sub.subinventory_id
                       INNER JOIN t_sys_erp_organizations org
                          on sub.ORGANIZATIONS_ID = org.ORGANIZATION_ID
                       where sub.status = 1
                         and org.status = 1
                         and org.ORGANIZATION_ID = 86
                         and sub.SUBINVENTORY_CODE in
                             ('C990', 'C990-1', 'C999'))
               order by a.created_date;
            loop
              fetch c_onhand_info
                into v_onhand_info;
              exit when quantity = 0;
              exit when c_onhand_info%notfound;
              limit_quantity := least(v_onhand_info.onhand_quantity,
                                      v_onhand_info.quota_quantity);
              assign_line_id := LIS_ORDER_SEQ.Nextval;
              if limit_quantity >= quantity then
                insert into t_out_notmk
                  (id,
                   created_date,
                   created_user,
                   last_updated_date,
                   last_updated_user,
                   status,
                   version,
                   asgn_ln_status,
                   asgn_quty,
                   asgn_time,
                   item_code,
                   item_id,
                   mis_pic_code,
                   ord_ln_id,
                   outlninfo_id,
                   out_ord_id,
                   rcp_pic_code,
                   warehouseid,
                   reserve_days,
                   if_reserve,
                   warehouse_onhand_id,
                   vendor_id,
                   source_warehouse_id,
                   locator_id,
                   locator_code,
                   product_unit_price,
                   product_unit_price_ex_tax,
                   quota_locking_id)
                values
                  (assign_line_id,
                   systimestamp,
                   ouEmployeeNumbe,
                   systimestamp,
                   ouEmployeeNumbe,
                   1,
                   0,
                   4,
                   quantity,
                   systimestamp,
                   v_onhand_info.onhand_item_code,
                   v_onhand_info.onhand_item_id,
                   v_onhand_info.mis_pic_code,
                   lineid,
                   lineid,
                   headerId,
                   v_onhand_info.rec_pic_code,
                   v_onhand_info.warehouse_id,
                   3,
                   1,
                   v_onhand_info.onhand_id,
                   v_onhand_info.vendor_id,
                   v_onhand_info.warehouse_id,
                   v_onhand_info.locator_id,
                   v_onhand_info.locator_code,
                   v_onhand_info.product_unit_price,
                   v_onhand_info.product_unit_price_ex_tax,
                   v_onhand_info.quota_locking_id);
                insert into t_sys_item_resereve_info
                  (reserveid,
                   status,
                   version,
                   reserve_end_day,
                   material_onhand_id,
                   order_line_id,
                   reserve_quantity,
                   reserve_start_day,
                   order_type,
                   onhand_id)
                values
                  (S_OUT_RESERVE_INF.Nextval,
                   1,
                   0,
                   sysdate + 30,
                   v_onhand_info.onhand_id,
                   assign_line_id,
                   quantity,
                   sysdate,
                   'CK',
                   v_onhand_info.onhand_id);
                quantity := 0;
              
              elsif limit_quantity < quantity then
                insert into t_out_notmk
                  (id,
                   created_date,
                   created_user,
                   last_updated_date,
                   last_updated_user,
                   status,
                   version,
                   asgn_ln_status,
                   asgn_quty,
                   asgn_time,
                   item_code,
                   item_id,
                   mis_pic_code,
                   ord_ln_id,
                   outlninfo_id,
                   out_ord_id,
                   rcp_pic_code,
                   warehouseid,
                   reserve_days,
                   if_reserve,
                   warehouse_onhand_id,
                   vendor_id,
                   source_warehouse_id,
                   locator_id,
                   locator_code,
                   product_unit_price,
                   product_unit_price_ex_tax,
                   quota_locking_id)
                values
                  (assign_line_id,
                   systimestamp,
                   ouEmployeeNumbe,
                   systimestamp,
                   ouEmployeeNumbe,
                   1,
                   0,
                   4,
                   limit_quantity,
                   systimestamp,
                   v_onhand_info.onhand_item_code,
                   v_onhand_info.onhand_item_id,
                   v_onhand_info.mis_pic_code,
                   lineid,
                   lineid,
                   headerId,
                   v_onhand_info.rec_pic_code,
                   v_onhand_info.warehouse_id,
                   3,
                   1,
                   v_onhand_info.onhand_id,
                   v_onhand_info.vendor_id,
                   v_onhand_info.warehouse_id,
                   v_onhand_info.locator_id,
                   v_onhand_info.locator_code,
                   v_onhand_info.product_unit_price,
                   v_onhand_info.product_unit_price_ex_tax,
                   v_onhand_info.quota_locking_id);
                insert into t_sys_item_resereve_info
                  (reserveid,
                   status,
                   version,
                   reserve_end_day,
                   material_onhand_id,
                   order_line_id,
                   reserve_quantity,
                   reserve_start_day,
                   order_type,
                   onhand_id)
                values
                  (S_OUT_RESERVE_INF.Nextval,
                   1,
                   0,
                   sysdate + 30,
                   v_onhand_info.onhand_id,
                   assign_line_id,
                   limit_quantity,
                   sysdate,
                   'CK',
                   v_onhand_info.onhand_id);
                quantity := quantity - limit_quantity;
              
              end if;
            end loop;
            close c_onhand_info;
          end if;
        end if;
        if quota_type = 'total_type' then
        
          select sum(a.onhand_quantity - nvl(f.RESERVE_QUANTITY, 0))
            into v_total_onhand_quantity
            from t_wh_current_onhand_quantity a
            join t_warehouse_access_user d
              on a.warehouse_define_id = d.warehouse_define_id
             and d.employ_number = employeeNumbe
            left join T_SYS_ERP_LOCATORS l
              on a.LOCATOR_ID = l.LOCATOR_ID
             and l.ERP_TYPE = erpType
            left join T_SYS_SPM_PRODUCTS b
              on a.product_id = b.seq_id
            left join (select qll.quota_quantity - nvl(mk.asgn_quty, 0) ql_quota_quantity,
                              qll.onhand_id,
                              qll.id
                         from t_lis_recipient_quota_locking qll
                         left join t_out_notmk mk
                           on qll.id = mk.quota_locking_id
                        where qll.detail_id = quota_detail_id) ql
              on ql.onhand_id = a.id
            left join (select e.onhand_id,
                              sum(nvl(e.RESERVE_QUANTITY, 0)) as RESERVE_QUANTITY
                         from T_SYS_ITEM_RESEREVE_INFO e
                        where sysdate < e.reserve_end_day
                          and e.status = 1
                        group by e.onhand_id) f
              on a.id = f.onhand_id
            left join T_WAREHOUSE_DEFINE w
              on a.warehouse_define_id = w.id
             and w.is_storage like 'Y'
             and w.MIS_OU_ID = ouId
           where a.onhand_quantity - nvl(f.RESERVE_QUANTITY, 0) > 0
             and a.item_id = itemid
             and a.mis_pic_code = misPicNO --添加mis批次号
             and a.id not in
                 (select distinct tql.onhand_id
                    from t_lis_recipient_quota_locking tql)
             and a.ERP_TYPE = erpType
             and a.status = 1
             and (l.LOCATOR_CODE like '%' || project_code || '%' or
                 l.locator_code not like '%|%' or l.locator_code is null)
             and w.CATEGORY_ID =
                 (select twc.id
                    from T_WAREHOUSE_CATEGORY twc
                   where twc.CODE like '01')
                --过滤部分子库存
             and w.id not in
                 (select wd.id
                    from T_WAREHOUSE_DEFINE wd
                   INNER JOIN t_sys_erp_subinventory sub
                      ON wd.mis_subinventoey_id = sub.subinventory_id
                   INNER JOIN t_sys_erp_organizations org
                      on sub.ORGANIZATIONS_ID = org.ORGANIZATION_ID
                   where sub.status = 1
                     and org.status = 1
                     and org.ORGANIZATION_ID = 86
                     and sub.SUBINVENTORY_CODE in ('C990', 'C990-1', 'C999'))
           order by a.created_date;
          if v_total_onhand_quantity >= quantity then
            open c_onhand_info for
              select a.id,
                     a.onhand_quantity - nvl(f.RESERVE_QUANTITY, 0),
                     ql.ql_quota_quantity,
                     a.warehouse_define_id,
                     a.item_id,
                     a.item_code,
                     a.mis_pic_code,
                     a.receipt_pic_code,
                     a.vendor_id,
                     a.locator_id,
                     a.locator_code,
                     a.cost_unit_price product_unit_price, --成本单价，update by lmt20180615                     
                     a.product_unit_price_ex_tax,
                     ql.id
                from t_wh_current_onhand_quantity a
                join t_warehouse_access_user d
                  on a.warehouse_define_id = d.warehouse_define_id
                 and d.employ_number = employeeNumbe
                left join T_SYS_ERP_LOCATORS l
                  on a.LOCATOR_ID = l.LOCATOR_ID
                 and l.ERP_TYPE = erpType
                left join T_SYS_SPM_PRODUCTS b
                  on a.product_id = b.seq_id
                left join (select qll.quota_quantity - nvl(mk.asgn_quty, 0) ql_quota_quantity,
                                  qll.onhand_id,
                                  qll.id
                             from t_lis_recipient_quota_locking qll
                             left join t_out_notmk mk
                               on qll.id = mk.quota_locking_id
                            where qll.detail_id = quota_detail_id) ql
                  on ql.onhand_id = a.id
                left join (select e.onhand_id,
                                  sum(nvl(e.RESERVE_QUANTITY, 0)) as RESERVE_QUANTITY
                             from T_SYS_ITEM_RESEREVE_INFO e
                            where sysdate < e.reserve_end_day
                              and e.status = 1
                            group by e.onhand_id) f
                  on a.id = f.onhand_id
                left join T_WAREHOUSE_DEFINE w
                  on a.warehouse_define_id = w.id
                 and w.is_storage like 'Y'
                 and w.MIS_OU_ID = ouId
               where a.onhand_quantity - nvl(f.RESERVE_QUANTITY, 0) > 0
                 and a.item_id = itemid
                 and a.mis_pic_code = misPicNO --添加mis批次号
                 and a.id not in
                     (select distinct tql.onhand_id
                        from t_lis_recipient_quota_locking tql)
                 and a.ERP_TYPE = erpType
                 and a.status = 1
                 and (l.LOCATOR_CODE like '%' || project_code || '%' or
                     l.locator_code not like '%|%' or
                     l.locator_code is null)
                 and w.CATEGORY_ID =
                     (select twc.id
                        from T_WAREHOUSE_CATEGORY twc
                       where twc.CODE like '01')
                    --过滤部分子库存
                 and w.id not in
                     (select wd.id
                        from T_WAREHOUSE_DEFINE wd
                       INNER JOIN t_sys_erp_subinventory sub
                          ON wd.mis_subinventoey_id = sub.subinventory_id
                       INNER JOIN t_sys_erp_organizations org
                          on sub.ORGANIZATIONS_ID = org.ORGANIZATION_ID
                       where sub.status = 1
                         and org.status = 1
                         and org.ORGANIZATION_ID = 86
                         and sub.SUBINVENTORY_CODE in
                             ('C990', 'C990-1', 'C999'))
               order by a.created_date;
            loop
              fetch c_onhand_info
                into v_onhand_info;
              exit when quantity = 0;
              exit when c_onhand_info%notfound;
              assign_line_id := LIS_ORDER_SEQ.Nextval;
              if v_onhand_info.quota_quantity >= quantity then
                insert into t_out_notmk
                  (id,
                   created_date,
                   created_user,
                   last_updated_date,
                   last_updated_user,
                   status,
                   version,
                   asgn_ln_status,
                   asgn_quty,
                   asgn_time,
                   item_code,
                   item_id,
                   mis_pic_code,
                   ord_ln_id,
                   outlninfo_id,
                   out_ord_id,
                   rcp_pic_code,
                   warehouseid,
                   reserve_days,
                   if_reserve,
                   warehouse_onhand_id,
                   vendor_id,
                   source_warehouse_id,
                   locator_id,
                   locator_code,
                   product_unit_price,
                   product_unit_price_ex_tax,
                   quota_locking_id)
                values
                  (assign_line_id,
                   systimestamp,
                   ouEmployeeNumbe,
                   systimestamp,
                   ouEmployeeNumbe,
                   1,
                   0,
                   4,
                   quantity,
                   systimestamp,
                   v_onhand_info.onhand_item_code,
                   v_onhand_info.onhand_item_id,
                   v_onhand_info.mis_pic_code,
                   lineid,
                   lineid,
                   headerId,
                   v_onhand_info.rec_pic_code,
                   v_onhand_info.warehouse_id,
                   3,
                   1,
                   v_onhand_info.onhand_id,
                   v_onhand_info.vendor_id,
                   v_onhand_info.warehouse_id,
                   v_onhand_info.locator_id,
                   v_onhand_info.locator_code,
                   v_onhand_info.product_unit_price,
                   v_onhand_info.product_unit_price_ex_tax,
                   v_onhand_info.quota_locking_id);
                insert into t_sys_item_resereve_info
                  (reserveid,
                   status,
                   version,
                   reserve_end_day,
                   material_onhand_id,
                   order_line_id,
                   reserve_quantity,
                   reserve_start_day,
                   order_type,
                   onhand_id)
                values
                  (S_OUT_RESERVE_INF.Nextval,
                   1,
                   0,
                   sysdate + 30,
                   v_onhand_info.onhand_id,
                   assign_line_id,
                   quantity,
                   sysdate,
                   'CK',
                   v_onhand_info.onhand_id);
                quantity := 0;
              elsif v_onhand_info.quota_quantity < quantity then
                insert into t_out_notmk
                  (id,
                   created_date,
                   created_user,
                   last_updated_date,
                   last_updated_user,
                   status,
                   version,
                   asgn_ln_status,
                   asgn_quty,
                   asgn_time,
                   item_code,
                   item_id,
                   mis_pic_code,
                   ord_ln_id,
                   outlninfo_id,
                   out_ord_id,
                   rcp_pic_code,
                   warehouseid,
                   reserve_days,
                   if_reserve,
                   warehouse_onhand_id,
                   vendor_id,
                   source_warehouse_id,
                   locator_id,
                   locator_code,
                   product_unit_price,
                   product_unit_price_ex_tax,
                   quota_locking_id)
                values
                  (assign_line_id,
                   systimestamp,
                   ouEmployeeNumbe,
                   systimestamp,
                   ouEmployeeNumbe,
                   1,
                   0,
                   4,
                   v_onhand_info.quota_quantity,
                   systimestamp,
                   v_onhand_info.onhand_item_code,
                   v_onhand_info.onhand_item_id,
                   v_onhand_info.mis_pic_code,
                   lineid,
                   lineid,
                   headerId,
                   v_onhand_info.rec_pic_code,
                   v_onhand_info.warehouse_id,
                   3,
                   1,
                   v_onhand_info.onhand_id,
                   v_onhand_info.vendor_id,
                   v_onhand_info.warehouse_id,
                   v_onhand_info.locator_id,
                   v_onhand_info.locator_code,
                   v_onhand_info.product_unit_price,
                   v_onhand_info.product_unit_price_ex_tax,
                   v_onhand_info.quota_locking_id);
                insert into t_sys_item_resereve_info
                  (reserveid,
                   status,
                   version,
                   reserve_end_day,
                   material_onhand_id,
                   order_line_id,
                   reserve_quantity,
                   reserve_start_day,
                   order_type,
                   onhand_id)
                values
                  (S_OUT_RESERVE_INF.Nextval,
                   1,
                   0,
                   sysdate + 30,
                   v_onhand_info.onhand_id,
                   assign_line_id,
                   v_onhand_info.quota_quantity,
                   sysdate,
                   'CK',
                   v_onhand_info.onhand_id);
                quantity := quantity - v_onhand_info.quota_quantity;
              
              end if;
            end loop;
            close c_onhand_info;
          end if;
        end if;
      
      end loop;
      close c_quota_detail_info;
    end if;
    if recordCount = 0 then
      select sum(a.onhand_quantity - nvl(f.RESERVE_QUANTITY, 0))
        into v_total_onhand_quantity
        from t_wh_current_onhand_quantity a
        join t_warehouse_access_user d
          on a.warehouse_define_id = d.warehouse_define_id
         and d.employ_number = employeeNumbe
        left join T_SYS_ERP_LOCATORS l
          on a.LOCATOR_ID = l.LOCATOR_ID
         and l.ERP_TYPE = erpType
        left join T_SYS_SPM_PRODUCTS b
          on a.product_id = b.seq_id
        left join (select qll.quota_quantity - nvl(mk.asgn_quty, 0) ql_quota_quantity,
                          qll.onhand_id,
                          qll.id
                     from t_lis_recipient_quota_locking qll
                     left join t_out_notmk mk
                       on qll.id = mk.quota_locking_id) ql
          on ql.onhand_id = a.id
        left join (select e.onhand_id,
                          sum(nvl(e.RESERVE_QUANTITY, 0)) as RESERVE_QUANTITY
                     from T_SYS_ITEM_RESEREVE_INFO e
                    where sysdate < e.reserve_end_day
                      and e.status = 1
                    group by e.onhand_id) f
          on a.id = f.onhand_id
        left join T_WAREHOUSE_DEFINE w
          on a.warehouse_define_id = w.id
         and w.is_storage like 'Y'
         and w.MIS_OU_ID = ouId
       where a.onhand_quantity - nvl(f.RESERVE_QUANTITY, 0) > 0
         and a.item_id = itemid
         and a.mis_pic_code = misPicNO --添加mis批次号
         and a.id not in
             (select distinct tql.onhand_id
                from t_lis_recipient_quota_locking tql)
         and a.ERP_TYPE = erpType
         and a.status = 1
         and w.CATEGORY_ID = (select twc.id
                                from T_WAREHOUSE_CATEGORY twc
                               where twc.CODE like '01')
         and (l.LOCATOR_CODE like '%' || project_code || '%' or
             l.locator_code not like '%|%' or l.locator_code is null)
            --过滤部分子库存
         and w.id not in
             (select wd.id
                from T_WAREHOUSE_DEFINE wd
               INNER JOIN t_sys_erp_subinventory sub
                  ON wd.mis_subinventoey_id = sub.subinventory_id
               INNER JOIN t_sys_erp_organizations org
                  on sub.ORGANIZATIONS_ID = org.ORGANIZATION_ID
               where sub.status = 1
                 and org.status = 1
                 and org.ORGANIZATION_ID = 86
                 and sub.SUBINVENTORY_CODE in ('C990', 'C990-1', 'C999'))
       order by a.created_date;
    
      if v_total_onhand_quantity >= quantity then
        open c_onhand_info for
          select a.id,
                 a.onhand_quantity - nvl(f.RESERVE_QUANTITY, 0),
                 ql.ql_quota_quantity,
                 a.warehouse_define_id,
                 a.item_id,
                 a.item_code,
                 a.mis_pic_code,
                 a.receipt_pic_code,
                 a.vendor_id,
                 a.locator_id,
                 a.locator_code,
                 a.cost_unit_price product_unit_price, --成本单价，update by lmt20180615
                 a.product_unit_price_ex_tax,
                 ql.id
            from t_wh_current_onhand_quantity a
            join t_warehouse_access_user d
              on a.warehouse_define_id = d.warehouse_define_id
             and d.employ_number = employeeNumbe
            left join T_SYS_ERP_LOCATORS l
              on a.LOCATOR_ID = l.LOCATOR_ID
             and l.ERP_TYPE = erpType
            left join T_SYS_SPM_PRODUCTS b
              on a.product_id = b.seq_id
            left join (select qll.quota_quantity - nvl(mk.asgn_quty, 0) ql_quota_quantity,
                              qll.onhand_id,
                              qll.id
                         from t_lis_recipient_quota_locking qll
                         left join t_out_notmk mk
                           on qll.id = mk.quota_locking_id) ql
              on ql.onhand_id = a.id
            left join (select e.onhand_id,
                              sum(nvl(e.RESERVE_QUANTITY, 0)) as RESERVE_QUANTITY
                         from T_SYS_ITEM_RESEREVE_INFO e
                        where sysdate < e.reserve_end_day
                          and e.status = 1
                        group by e.onhand_id) f
              on a.id = f.onhand_id
            left join T_WAREHOUSE_DEFINE w
              on a.warehouse_define_id = w.id
             and w.is_storage like 'Y'
             and w.MIS_OU_ID = ouId
           where a.onhand_quantity - nvl(f.RESERVE_QUANTITY, 0) > 0
             and a.item_id = itemid
             and a.mis_pic_code = misPicNO --添加mis批次号
             and a.id not in
                 (select distinct tql.onhand_id
                    from t_lis_recipient_quota_locking tql)
             and a.ERP_TYPE = erpType
             and a.status = 1
             and w.CATEGORY_ID =
                 (select twc.id
                    from T_WAREHOUSE_CATEGORY twc
                   where twc.CODE like '01')
             and (l.LOCATOR_CODE like '%' || project_code || '%' or
                 l.locator_code not like '%|%' or l.locator_code is null)
                --过滤部分子库存
             and w.id not in
                 (select wd.id
                    from T_WAREHOUSE_DEFINE wd
                   INNER JOIN t_sys_erp_subinventory sub
                      ON wd.mis_subinventoey_id = sub.subinventory_id
                   INNER JOIN t_sys_erp_organizations org
                      on sub.ORGANIZATIONS_ID = org.ORGANIZATION_ID
                   where sub.status = 1
                     and org.status = 1
                     and org.ORGANIZATION_ID = 86
                     and sub.SUBINVENTORY_CODE in ('C990', 'C990-1', 'C999'))
           order by a.created_date;
        loop
          fetch c_onhand_info
            into v_onhand_info;
          exit when quantity = 0;
          exit when c_onhand_info%notfound;
          dbms_output.put_line(v_onhand_info.onhand_id || '===' ||
                               v_onhand_info.onhand_item_code);
          assign_line_id := LIS_ORDER_SEQ.Nextval;
          if v_onhand_info.onhand_quantity >= quantity then
            insert into t_out_notmk
              (id,
               created_date,
               created_user,
               last_updated_date,
               last_updated_user,
               status,
               version,
               asgn_ln_status,
               asgn_quty,
               asgn_time,
               item_code,
               item_id,
               mis_pic_code,
               ord_ln_id,
               outlninfo_id,
               out_ord_id,
               rcp_pic_code,
               warehouseid,
               reserve_days,
               if_reserve,
               warehouse_onhand_id,
               vendor_id,
               source_warehouse_id,
               locator_id,
               locator_code,
               product_unit_price,
               product_unit_price_ex_tax,
               quota_locking_id)
            values
              (assign_line_id,
               systimestamp,
               ouEmployeeNumbe,
               systimestamp,
               ouEmployeeNumbe,
               1,
               0,
               4,
               quantity,
               systimestamp,
               v_onhand_info.onhand_item_code,
               v_onhand_info.onhand_item_id,
               v_onhand_info.mis_pic_code,
               lineid,
               lineid,
               headerId,
               v_onhand_info.rec_pic_code,
               v_onhand_info.warehouse_id,
               3,
               1,
               v_onhand_info.onhand_id,
               v_onhand_info.vendor_id,
               v_onhand_info.warehouse_id,
               v_onhand_info.locator_id,
               v_onhand_info.locator_code,
               v_onhand_info.product_unit_price,
               v_onhand_info.product_unit_price_ex_tax,
               v_onhand_info.quota_locking_id);
            insert into t_sys_item_resereve_info
              (reserveid,
               status,
               version,
               reserve_end_day,
               material_onhand_id,
               order_line_id,
               reserve_quantity,
               reserve_start_day,
               order_type,
               onhand_id)
            values
              (S_OUT_RESERVE_INF.Nextval,
               1,
               0,
               sysdate + 30,
               v_onhand_info.onhand_id,
               assign_line_id,
               quantity,
               sysdate,
               'CK',
               v_onhand_info.onhand_id);
            quantity := 0;
          elsif v_onhand_info.onhand_quantity < quantity then
            insert into t_out_notmk
              (id,
               created_date,
               created_user,
               last_updated_date,
               last_updated_user,
               status,
               version,
               asgn_ln_status,
               asgn_quty,
               asgn_time,
               item_code,
               item_id,
               mis_pic_code,
               ord_ln_id,
               outlninfo_id,
               out_ord_id,
               rcp_pic_code,
               warehouseid,
               reserve_days,
               if_reserve,
               warehouse_onhand_id,
               vendor_id,
               source_warehouse_id,
               locator_id,
               locator_code,
               product_unit_price,
               product_unit_price_ex_tax,
               quota_locking_id)
            values
              (assign_line_id,
               systimestamp,
               ouEmployeeNumbe,
               systimestamp,
               ouEmployeeNumbe,
               1,
               0,
               4,
               v_onhand_info.onhand_quantity,
               systimestamp,
               v_onhand_info.onhand_item_code,
               v_onhand_info.onhand_item_id,
               v_onhand_info.mis_pic_code,
               lineid,
               lineid,
               headerId,
               v_onhand_info.rec_pic_code,
               v_onhand_info.warehouse_id,
               3,
               1,
               v_onhand_info.onhand_id,
               v_onhand_info.vendor_id,
               v_onhand_info.warehouse_id,
               v_onhand_info.locator_id,
               v_onhand_info.locator_code,
               v_onhand_info.product_unit_price,
               v_onhand_info.product_unit_price_ex_tax,
               v_onhand_info.quota_locking_id);
            insert into t_sys_item_resereve_info
              (reserveid,
               status,
               version,
               reserve_end_day,
               material_onhand_id,
               order_line_id,
               reserve_quantity,
               reserve_start_day,
               order_type,
               onhand_id)
            values
              (S_OUT_RESERVE_INF.Nextval,
               1,
               0,
               sysdate + 30,
               v_onhand_info.onhand_id,
               assign_line_id,
               v_onhand_info.onhand_quantity,
               sysdate,
               'CK',
               v_onhand_info.onhand_id);
            quantity := quantity - v_onhand_info.onhand_quantity;
          
          end if;
        end loop;
        close c_onhand_info;
      end if;
    end if;
    if quantity = 0 then
      resultInfo := resultInfo || '<p>物料:' || itemCode || '申请数量:' ||
                    temp_quantity || '全部分配</p>';
      update t_out_ln ln
         set ln.last_updated_date = sysdate,
             ln.last_updated_user = ouEmployeeNumbe,
             ln.asgn_quty         = temp_quantity,
             ln.tol_asgn_quty     = nvl(ln.tol_asgn_quty, 0) + temp_quantity,
             ord_ln_status        = 1
       where ln.id = lineid;
      update t_out_hd h set h.ord_status = 5 where h.id = headerId;
    elsif quantity = temp_quantity then
      --当现有量不足，先删除临时表的id，2017年11月21日09:05:19 yangwl 目前先这么改
      delete from t_lis_auto_assign_temp t where T.Business_Id = headerId;
      commit;
      resultInfo := resultInfo || '<p>物料:' || itemCode || '申请数量:' ||
                    temp_quantity || '没有可分配的现有量或没有足够的现有量</p>';
      /* else
      resultInfo :=resultInfo|| '<p>物料:'||itemCode||'申请数量:'||temp_quantity||'部分分配</p>';
      update t_out_ln ln set ln.last_updated_date=sysdate,ln.last_updated_user=ouEmployeeNumbe,ln.asgn_quty=temp_quantity-quantity,ln.tol_asgn_quty=temp_quantity-quantity+nvl(ln.tol_asgn_quty,0),ord_ln_status=2 where ln.id=lineid;
      */
    end if;
  end loop;
  close c_out_line_info;
exception
  when E_EXECUTING_EXCEPTION then
    flag       := -1;
    resultInfo := '该出库申请正在进行自动分配,请重试!';
  
  when others then
    rollback;
    flag       := -1;
    resultInfo := 'executing procedure proc_out_auto_assign error';
end;
/

