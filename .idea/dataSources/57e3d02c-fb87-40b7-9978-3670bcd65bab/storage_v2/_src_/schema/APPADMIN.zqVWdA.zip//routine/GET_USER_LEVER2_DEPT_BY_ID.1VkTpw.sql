create function get_user_lever2_dept_by_id(v_deptId number)
return number is deptId number(16);
begin

    select id into deptId from (select id,dept_code,dept_name,parent_id  from t_lis_dept where status=1
    start with id=v_deptId
    connect by prior parent_id=id) paretDept
    where parent_id  =(select tld_p1.id  from t_lis_dept tld_p1 where tld_p1.dept_name='中国移动通信集团北京有限公司');
    return deptId;
end;
/

