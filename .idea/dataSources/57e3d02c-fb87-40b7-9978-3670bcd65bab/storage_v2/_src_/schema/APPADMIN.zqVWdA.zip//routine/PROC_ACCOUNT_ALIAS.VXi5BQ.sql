create PROCEDURE "PROC_ACCOUNT_ALIAS" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_alias is
select disposition_id, description, cc_id, distribution_account, distribution_desc, organization_id, last_update_date, erp_type, SEQ_ID, DISABLE_DATE from i_erp_account_alias where create_date > start_time and create_date < end_time order by erp_type desc;
i_alias csr_i_alias%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from I_ERP_ACCOUNT_ALIAS where create_date > start_time and create_date < end_time;
  open csr_i_alias;
  fetch csr_i_alias into i_alias;
while (csr_i_alias%found) loop
  select count(*) into count_value from T_SYS_ERP_ACCOUNT_ALIAS where ACCOUNT_ALIAS_ID = i_alias.disposition_id and ERP_TYPE = i_alias.erp_type;
  if(count_value = 1 and i_alias.disable_date is null) then
      update T_SYS_ERP_ACCOUNT_ALIAS t set t.last_updated_date = sysdate,
      t.account_alias_name = i_alias.description,
      t.erp_type = i_alias.erp_type,
      t.cc_id = i_alias.cc_id,
      t.distribution_account = i_alias.distribution_account,
      t.distribution_desc = i_alias.distribution_desc,
      t.organization_id = i_alias.organization_id
      where t.ACCOUNT_ALIAS_ID = i_alias.disposition_id;
   elsif(count_value = 1 and i_alias.disable_date is not null) then
   update T_SYS_ERP_ACCOUNT_ALIAS t set t.last_updated_date = sysdate,
      t.account_alias_name = i_alias.description,
      t.erp_type = i_alias.erp_type,
      t.cc_id = i_alias.cc_id,
      t.distribution_account = i_alias.distribution_account,
      t.distribution_desc = i_alias.distribution_desc,
      t.organization_id = i_alias.organization_id,
      t.disable_date = i_alias.disable_date,
      t.status = 0
      where t.ACCOUNT_ALIAS_ID = i_alias.disposition_id;
 elsif(count_value = 0 and i_alias.disable_date is null) then
   insert into t_sys_erp_account_alias
       (seq_id, account_alias_id, created_date, last_updated_date, status, account_alias_name, erp_type, cc_id, distribution_account, distribution_desc, organization_id)
     values
       (i_alias.seq_id, i_alias.disposition_id, sysdate, sysdate, '1', i_alias.description , i_alias.erp_type, i_alias.cc_id, i_alias.distribution_account, i_alias.distribution_desc, i_alias.organization_id);
end if;
fetch csr_i_alias into i_alias;
count_success:=count_success+1;
end loop;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','T_SYS_ERP_ACCOUNT_ALIAS');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_ERP_ACCOUNT_ALIAS');
close csr_i_alias;
commit;
end;
/

