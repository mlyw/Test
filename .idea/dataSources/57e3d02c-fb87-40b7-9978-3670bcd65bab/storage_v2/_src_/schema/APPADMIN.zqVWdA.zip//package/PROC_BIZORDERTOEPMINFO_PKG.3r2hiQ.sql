create PACKAGE PROC_BIZORDERTOEPMINFO_PKG is

   type cursor_list is ref cursor; -- cursor
   
   --查询信息
   PROCEDURE PROC_BIZORDERTOEMPINFO(startdate varchar2,enddate varchar2,ordercode in varchar2,temp_list out cursor_list);

end PROC_BIZORDERTOEPMINFO_PKG;
/

