create PROCEDURE proc_station_line (start_time timestamp,end_time timestamp) as

  total_value number(15);
  count_value number(2);
  count_success number(15);
  exception_info varchar2(3000);
  header_seq_id_value number(19); 
  header_project_code varchar2(200);
  sub_project_id number(19);
  version_value number(19); 
  status_value number(2);
  
cursor csr_i_station_line is
 select seq_id,project_code,req_code,project_no,station_no,station_name,delete_flag,string_attr,long_attr,datetime_attr,double_attr,import_date, sub_project_no from I_EPM_STATION_LINE where import_date between start_time and end_time;
  i_station_line csr_i_station_line%rowtype;

begin 
  count_success := 0;
  count_value := 0;
  total_value:= 0;
  header_seq_id_value:= 0;
  header_project_code:='';
  sub_project_id :=0;
  status_value:=1;
  select count(seq_id) into total_value from I_EPM_STATION_LINE where import_date between start_time and  end_time; 
  open csr_i_station_line;
  fetch csr_i_station_line into i_station_line;
  while (csr_i_station_line%found) loop
--------------------------------------子项目存在----------------------------------------------------------------------------------
    if(i_station_line.sub_project_no is not null) then 
      select count(seq_id) into count_value from T_SYS_EPM_STATION_LINE 
            where sub_project_no  = i_station_line.sub_project_no 
                  and req_code = i_station_line.req_code 
                  and project_no = i_station_line.project_no
                  and subproject_seq_id is not null;
      if(count_value = 0 ) then
          select seq_id into sub_project_id from T_SYS_EPM_STATION_SUBPROJECT  
                where sub_project_no = i_station_line.sub_project_no 
                      and status=1
                      and sub_project_status='1';
      end if;
      if(i_station_line.delete_flag is not null) then
           if(i_station_line.delete_flag ='delete') then
              status_value := 0;
          elsif(i_station_line.delete_flag !='delete' ) then
              status_value := 1;
          end if;
       else status_value := 1;
      end if;
      --数据添加
      if(count_value = 1) then
        update T_SYS_EPM_STATION_LINE set
         station_no        = i_station_line.station_no,
         station_name      = i_station_line.station_name,
         delete_flag       = i_station_line.delete_flag,
         string_attr       = i_station_line.string_attr,
         long_attr         = i_station_line.long_attr,
         datetime_attr     = i_station_line.datetime_attr,
         double_attr       = i_station_line.double_attr,
         last_updated_date = sysdate,
         version = version + 1,
         status = status_value
        where sub_project_no  = i_station_line.sub_project_no 
              and req_code = i_station_line.req_code 
              and project_no = i_station_line.project_no
              and subproject_seq_id is not null;
      else
        insert into T_SYS_EPM_STATION_LINE(seq_id,header_seq_id,project_code,req_code,project_no,station_no,station_name,delete_flag,string_attr,long_attr,datetime_attr,double_attr,created_user,created_date,last_updated_user,last_updated_date,version,status,sub_project_no,subproject_seq_id)
        values
        (
          SEQ_EPM_STATION.nextval,
          null,null,
          i_station_line.req_code,
          i_station_line.project_no,
          i_station_line.station_no,
          i_station_line.station_name,
          i_station_line.delete_flag,
          i_station_line.string_attr,
          i_station_line.long_attr,
          i_station_line.datetime_attr,
          i_station_line.double_attr,
          '',sysdate,'',sysdate,1,
          status_value,
          i_station_line.sub_project_no,
          sub_project_id
        );
      end if;
       /*
        如果子项目是从项目下或其他子项目下调拨过来了，标记之前的需要号
        注意:  工程号可以挂在不同项目下， 这里需要查询子项目对应的项目，然后在标记
       */      
      select h.project_code into header_project_code 
      from T_SYS_EPM_STATION_SUBPROJECT sub join t_sys_epm_station_header h on sub.header_seq_id=h.seq_id 
      where sub.sub_project_no = i_station_line.sub_project_no and sub.status=1 and sub.sub_project_status='1';
      update T_SYS_EPM_STATION_LINE l set l.if_allocate = 1,l.delete_flag='delete',l.status = 0
      where l.project_code=header_project_code
            and l.req_code = i_station_line.req_code 
            and l.project_no = i_station_line.project_no
            and status=1
            and l.header_seq_id is not null
            and l.subproject_seq_id is null
            ;
--------------------------------------子项目编号为空, 则挂在项目下-----------------------------------------------------------
    else
      select count(seq_id) into count_value from T_SYS_EPM_STATION_LINE 
            where project_code  = i_station_line.project_code 
                  and req_code = i_station_line.req_code 
                  and project_no = i_station_line.project_no
                  and header_seq_id is not null;
      if(count_value = 0 ) then
            select seq_id into header_seq_id_value from T_SYS_EPM_STATION_HEADER  where project_code = i_station_line.project_code;
      end if;
      
      if(i_station_line.delete_flag is not null) then
           if(i_station_line.delete_flag ='delete') then
              status_value := 0;
          elsif(i_station_line.delete_flag !='delete' ) then
              status_value := 1;
          end if;
       else status_value := 1;
      end if;
      
      if(count_value = 1) then
          update T_SYS_EPM_STATION_LINE set
             station_no        = i_station_line.station_no,
             station_name      = i_station_line.station_name,
             delete_flag       = i_station_line.delete_flag,
             string_attr       = i_station_line.string_attr,
             long_attr         = i_station_line.long_attr,
             datetime_attr     = i_station_line.datetime_attr,
             double_attr       = i_station_line.double_attr,
             last_updated_date = sysdate,
             version = version + 1,
             status = status_value,
             sub_project_no=null,
             subproject_seq_id=null
           where project_code = i_station_line.project_code  
                  and req_code = i_station_line.req_code 
                  and project_no = i_station_line.project_no
                  and header_seq_id is not null;
      else
        insert into T_SYS_EPM_STATION_LINE(seq_id,header_seq_id,project_code,req_code,project_no,station_no,station_name,delete_flag,string_attr,long_attr,datetime_attr,double_attr,created_user,created_date,last_updated_user, last_updated_date, version,status,sub_project_no,subproject_seq_id )
        values
        (
          SEQ_EPM_STATION.nextval,
          header_seq_id_value,
          i_station_line.project_code,
          i_station_line.req_code,
          i_station_line.project_no,
          i_station_line.station_no,
          i_station_line.station_name,
          i_station_line.delete_flag,
          i_station_line.string_attr,
          i_station_line.long_attr,
          i_station_line.datetime_attr,
          i_station_line.double_attr,
          '',sysdate,'',sysdate,1,status_value,null,null
        );
        
      end if;
    end if;
  fetch csr_i_station_line into i_station_line;
    count_success:=count_success+1;
  end loop;
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','T_SYS_EPM_STATION_LINE');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_EPM_STATION_LINE');
close csr_i_station_line;
commit;
end;
/

