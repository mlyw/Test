create view V_CARD_QUANTITY_DIFFERENCES as
  select t1.物料一子库一MIS批次号,
       t1.物料编码,
       t1.子库存,
       t1.mis批次号,
       t1.累计库存余额,
       t2.库存现有量,
       t1.累计库存余额 - t2.库存现有量 差异
  from (select t.物料编码 || '~' || t.子库存 || '~' || t.mis批次号 物料一子库一MIS批次号,
               t.物料编码,
               t.子库存,
               t.mis批次号,
               sum(t.交易数量) 累计库存余额
          from v_card_process_transactions t
         where t.子库存 is not null
         group by t.物料编码,
                  t.子库存,
                  t.mis批次号,
                  t.物料编码 || '~' || t.子库存 || '~' || t.mis批次号) t1,
       (select tq.item_code || '~' || twd.mis_subinventory_name || '~' ||
               tq.mis_pic_code 物料一子库一MIS批次号,
               sum(nvl(tq.onhand_quantity, 0)) 库存现有量
          from t_wh_current_onhand_quantity tq, t_warehouse_define twd
         where tq.warehouse_define_id = twd.id
           and twd.mis_subinventory_name like 'C%'
           and tq.status = 1
           -- and twd.status = 1
         group by tq.item_code || '~' || twd.mis_subinventory_name || '~' ||
                  tq.mis_pic_code) t2
 where t1.物料一子库一MIS批次号 = t2.物料一子库一MIS批次号(+)
/

