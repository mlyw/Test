create view V_LIS_REPORT_DYNAMIC as
  SELECT
  /**无动态库存统计依赖的视图*/
    tmp1.item_code,
    tmp1.item_name,
    tmp1.item_id,
    tmp1.uom_code,
    tmp1.uom_desc,
    tmp1.concatenated_segments,
    tmp1.category_description,
    tmp1.warehouse_define_id,
    tmp1.warehouse_define_code,
    tmp1.warehouse_define_name,
    tmp1.mis_ou_id,
    tmp1.mis_ou_name,
    tmp1.mis_io_code,
    tmp1.mis_io_name,
    tmp1.mis_io_id,
    tmp1.receipt_pic_code,
    tmp1.accotunt,
    tmp1.afterdate,
    tmp1.beforedate,
    tmp2.outdate,
    CASE
      WHEN tmp2.outdate IS NOT NULL
      THEN to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd') - to_date(tmp2.outdate,'yyyy-MM-dd')
      ELSE to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd') - to_date(tmp1.beforedate,'yyyy-MM-dd')
    END dynamistimes
  FROM
    (SELECT tmp.item_code,
      tmp.item_desc item_name,
      tmp.item_id,
      tmp.uom_code,
      tmp.uom_desc,
      i.concatenated_segments,
      i.category_description,
      tmp.warehouse_define_id,
      tmp.receipt_pic_code,
      tmp.accotunt,
      tmp.warehouse_define_code,
      tmp.warehouse_define_name,
      tmp.mis_ou_id,
      tmp.mis_ou_name,
      tmp.mis_io_code,
      tmp.mis_io_name,
      tmp.mis_io_id,
      tmp.afterdate,
      tmp.beforedate
    FROM
      (SELECT q.item_id,
        q.item_code,
        q.item_desc,
        q.uom_code,
        q.uom_desc,
        q.warehouse_define_id,
        q.receipt_pic_code,
        w.warehouse_define_code,
        w.warehouse_define_name,
        w.mis_ou_id,
        w.mis_ou_name,
        w.mis_io_code,
        w.mis_io_name,
        w.mis_io_id,
        SUM(NVL(q.cost_unit_price,0)*NVL(q.onhand_quantity,0)) accotunt,
        TO_CHAR(MAX(q.created_date),'yyyy-MM-dd') afterdate,
        TO_CHAR(MIN(q.created_date),'yyyy-MM-dd') beforedate
      FROM t_wh_current_onhand_quantity q,
        mv_warehouse_define w
      WHERE q.warehouse_define_id=w.id
      AND w.status               =1
      AND q.status               =1
      AND q.created_date        IS NOT NULL
      AND q.onhand_quantity      >0
      AND q.receipt_pic_code    IS NOT NULL
      GROUP BY q.item_id,
        q.item_desc,
        q.item_code,
        q.uom_desc,
        q.uom_code,
        q.receipt_pic_code,
        q.warehouse_define_id,
        w.warehouse_define_code,
        w.warehouse_define_name,
        w.mis_ou_id,
        w.mis_ou_name,
        w.mis_io_code,
        w.mis_io_name,
        w.mis_io_id
      ) tmp
    LEFT JOIN t_sys_erp_items i
    ON tmp.item_id=i.seq_id
    ) tmp1
  LEFT JOIN
    (SELECT n.item_id,
      n.item_desc,
      n.item_code,
      n.uom_code,
      n.uom_desc,
      n.concatenated_segments,
      n.category_description,
      n.warehouse_out_id,
      n.receipt_pic_code,
      TO_CHAR(MAX(n.import_date),'yyyy-MM-dd') outdate
    FROM V_LIS_REPORT_DYNAMIC_OUT n
    WHERE n.receipt_pic_code IS NOT NULL
    GROUP BY n.item_id,
      n.item_desc,
      n.item_code,
      n.uom_code,
      n.uom_desc,
      n.concatenated_segments,
      n.category_description,
      n.warehouse_out_id,
      n.receipt_pic_code
    ) tmp2
  ON tmp1.item_code             =tmp2.item_code
  AND tmp1.item_name            =tmp2.item_desc
  AND tmp1.item_id              =tmp2.item_id
  AND tmp1.uom_code             =tmp2.uom_code
  AND tmp1.uom_desc             =tmp2.uom_desc
  AND tmp1.concatenated_segments=tmp2.concatenated_segments
  AND tmp1.category_description =tmp2.category_description
  AND tmp1.warehouse_define_id  =tmp2.warehouse_out_id
  AND tmp1.receipt_pic_code     = tmp2.receipt_pic_code
/

