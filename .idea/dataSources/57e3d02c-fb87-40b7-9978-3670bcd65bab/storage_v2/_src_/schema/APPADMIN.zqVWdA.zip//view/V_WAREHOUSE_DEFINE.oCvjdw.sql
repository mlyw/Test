create view V_WAREHOUSE_DEFINE as
  SELECT
    /**有效子库信息视图（不包含暂存点子库信息）*/
    w."ID",
    w."CREATED_DATE",
    w."CREATED_USER",
    w."DATE_VALUE1",
    w."LAST_UPDATED_DATE",
    w."LAST_UPDATED_USER",
    w."NUMBER_VALUE1",
    w."STATUS",
    w."STRING_VALUE1",
    w."VERSION",
    w."MIS_IO_CODE",
    w."MIS_IO_ID",
    w."MIS_IO_NAME",
    w."MIS_LOCATION_DESC",
    w."MIS_LOCATION_ID",
    w."MIS_OU_ID",
    w."MIS_OU_NAME",
    w."MIS_SUBINVENTOEY_TYPE",
    w."MIS_SUBINVENTORY_DESC",
    w."MIS_SUBINVENTORY_NAME",
    w."MIS_LOCATION_CODE",
    w."VOI_VMI_FLAG",
    w."WAREHOUSE_ADDRESS",
    w."WAREHOUSE_CAPITAL_TYPE",
    w."WAREHOUSE_DEFINE_CODE",
    w."WAREHOUSE_DEFINE_NAME",
    w."WAREHOUSE_FULL_CODE",
    w."WAREHOUSE_FULL_NAME",
    w."WAREHOUSE_LEVEL",
    w."WAREHOUSE_NOTES",
    w."CATEGORY_ID",
    w."PARENT_WAREHOUSE_ID",
    w."MIS_SUBINVENTOEY_ID",
    w."IS_STORAGE",
    w."IS_NEW",
    w."OTHERS",
    w."DEPT_ID",
    w."VENDOR_ID",
    w."LONGITUDE",
    w."LATITUDE",
    w."VALID_STATUS",
    w."APPROVE_STATUS",
    w."REVERSE_STATUS",
    w."APPROVE_HEADER_ID",
    a.areainfo,
    a.occupy_area
  FROM t_warehouse_define w,
    t_warehouse_category c,
    v_sys_erp_organizations o,
    t_warehouse_define_area a
  WHERE w.category_id        =c.id
  AND c.code NOT            IN ('03','02')
  AND w.status               =1
  AND w.parent_warehouse_id IS NOT NULL
  AND w.mis_subinventoey_id IS NOT NULL
  AND o.is_straight          =0
  AND w.mis_io_id            =o.organization_id
  AND a.status               =1
  AND a.order_status         =1
  AND w.id                   =a.warehouse_id
  /**有效子库信息营业厅视图（不包含暂存点子库信息）*/
  UNION ALL
  SELECT w."ID",
    w."CREATED_DATE",
    w."CREATED_USER",
    w."DATE_VALUE1",
    w."LAST_UPDATED_DATE",
    w."LAST_UPDATED_USER",
    w."NUMBER_VALUE1",
    w."STATUS",
    w."STRING_VALUE1",
    w."VERSION",
    w."MIS_IO_CODE",
    w."MIS_IO_ID",
    w."MIS_IO_NAME",
    w."MIS_LOCATION_DESC",
    w."MIS_LOCATION_ID",
    w."MIS_OU_ID",
    w."MIS_OU_NAME",
    w."MIS_SUBINVENTOEY_TYPE",
    w."MIS_SUBINVENTORY_DESC",
    w."MIS_SUBINVENTORY_NAME",
    w."MIS_LOCATION_CODE",
    w."VOI_VMI_FLAG",
    w."WAREHOUSE_ADDRESS",
    w."WAREHOUSE_CAPITAL_TYPE",
    w."WAREHOUSE_DEFINE_CODE",
    w."WAREHOUSE_DEFINE_NAME",
    w."WAREHOUSE_FULL_CODE",
    w."WAREHOUSE_FULL_NAME",
    w."WAREHOUSE_LEVEL",
    w."WAREHOUSE_NOTES",
    w."CATEGORY_ID",
    w."PARENT_WAREHOUSE_ID",
    w."MIS_SUBINVENTOEY_ID",
    w."IS_STORAGE",
    w."IS_NEW",
    w."OTHERS",
    w."DEPT_ID",
    w."VENDOR_ID",
    w."LONGITUDE",
    w."LATITUDE",
    w."VALID_STATUS",
    w."APPROVE_STATUS",
    w."REVERSE_STATUS",
    w."APPROVE_HEADER_ID",
    a.areainfo,
    a.occupy_area
  FROM t_warehouse_define w,
    t_warehouse_category c,
    t_sys_shm_hall h,
    v_sys_erp_organizations o,
    t_warehouse_define_area a
  WHERE w.category_id        =c.id
  AND c.code                 = '02'
  AND w.status               =1
  AND h.status               =1
  AND h.hall_type           IN (1,0)
 AND h.hall_mis_code        =w.warehouse_define_code
  AND w.parent_warehouse_id IS NOT NULL
  AND w.mis_subinventoey_id IS NOT NULL
  AND o.is_straight          =0
  AND w.mis_io_id            =o.organization_id
  AND a.status               =1
  AND a.order_status         =1
  AND w.id                   =a.warehouse_id
/

