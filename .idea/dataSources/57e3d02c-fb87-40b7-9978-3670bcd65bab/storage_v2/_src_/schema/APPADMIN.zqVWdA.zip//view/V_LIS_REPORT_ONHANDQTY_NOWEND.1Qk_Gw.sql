create view V_LIS_REPORT_ONHANDQTY_NOWEND as
  SELECT
    /**以当前日期为准动态计算库存现有量期末值*/
    TO_CHAR(sysdate,'yyyyMM') bussinessdate,
    q.item_code,
    q.item_desc,
    q.item_id,
    q.uom_code item_uom_code,
    q.uom_desc item_uom_desc,
    i.concatenated_segments item_category_code,
    i.category_description item_category_name,
    q.warehouse_define_id,
    w.mis_ou_id ou_id,
    q.erp_type,
    w.mis_io_id organization_id,
    SUM(NVL(q.onhand_quantity,0)) onhand_quantity,
    SUM(NVL(q.onhand_quantity,0)*NVL(q.cost_unit_price,0)) onhand_quantity_account,
    2 data_type,
    NULL mis_onhand_quantity_account
  FROM t_wh_current_onhand_quantity q,
    mv_warehouse_define w,
    t_sys_erp_items i
  WHERE q.status              =1
  AND w.status                =1
  AND i.status                =1
  AND q.warehouse_define_id   =w.id
  AND q.item_id               =i.seq_id
  AND NVL(q.onhand_quantity,0)>0
  GROUP BY w.mis_ou_id,
    w.mis_io_id,
    q.warehouse_define_id,
    i.concatenated_segments,
    i.category_description,
    q.item_id,
    q.item_code,
    q.item_desc,
    q.uom_code,
    q.uom_desc,
    q.erp_type
/

