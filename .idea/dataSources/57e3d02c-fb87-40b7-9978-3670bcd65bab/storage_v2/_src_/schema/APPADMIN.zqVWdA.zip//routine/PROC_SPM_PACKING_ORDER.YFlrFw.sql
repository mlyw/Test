create PROCEDURE PROC_SPM_PACKING_ORDER(startDate TIMESTAMP, endDate TIMESTAMP) 
AS
    total_value NUMBER(19);
    count_success NUMBER(19);
    exception_info VARCHAR2(3000);
    version_value NUMBER(10);
    count_value NUMBER(19);
    item_validate_res NUMBER(10);
    status_value NUMBER(3);
    line_id_value NUMBER(19); -- 送货单行SEQ_ID
    
    invalid_line_id EXCEPTION;
    
    CURSOR crs_pack IS 
      SELECT 
        BOX_NUMBER, BOX_QUANTITY, DELIVERY_ORDER_ID, DELIVERY_ORDER_LINE_ID, ITEM_ID, ITEM_CODE, ITEM_DESC, PRODUCT_ID,
        PRODUCT_CODE, PRODUCT_DESC, UOM_CODE, UOM_DESC, IMPORT_DATE, REMARK1, REMARK2, REMARK3, REMARK4, REMARK5
      FROM I_SPM_PACKING_ORDER
        WHERE IMPORT_DATE BETWEEN startDate AND endDate;
    i_pack crs_pack%ROWTYPE;
    
BEGIN
    total_value := 0;
    count_success := 0;
    
    SELECT COUNT(seq_id) INTO total_value FROM I_SPM_PACKING_ORDER WHERE IMPORT_DATE BETWEEN startDate AND endDate;
    
    OPEN crs_pack;
    
    LOOP 
      FETCH crs_pack INTO i_pack;
      EXIT WHEN (crs_pack%NOTFOUND);
        
        count_value := 0;
        item_validate_res := 0;
        status_value := 0;
        line_id_value := 0;
        
        -- query spm delivery order line seq_id
        SELECT seq_id INTO line_id_value FROM t_spm_delivery_order_line
          WHERE DELIVERY_HEADER_ID = i_pack.delivery_order_id AND DELIVERY_LINE_ID = i_pack.delivery_order_line_id;
        
        IF (line_id_value <= 0) THEN
            RAISE invalid_line_id;
        END IF;
        
        -- judging update or insert (箱号、送货单头、送货单行一致，执行修改)
        SELECT COUNT(seq_id) INTO count_value FROM T_SPM_PACKING_ORDER 
          WHERE 
            BOX_NUMBER = i_pack.box_number AND DELIVERY_ORDER_ID = i_pack.delivery_order_id AND DELIVERY_ORDER_LINE_ID = i_pack.delivery_order_line_id;
        
        -- set version
        IF (count_value > 0) THEN
          SELECT version INTO version_value FROM T_SPM_PACKING_ORDER
            WHERE 
              BOX_NUMBER = i_pack.box_number AND DELIVERY_ORDER_ID = i_pack.delivery_order_id AND DELIVERY_ORDER_LINE_ID = i_pack.delivery_order_line_id;
            version_value := version_value + 1; 
        ELSE
            version_value := 0;
        END IF;
        
        -- item validate
        SELECT COUNT(seq_id) INTO item_validate_res FROM t_sys_erp_items 
          WHERE status = 1 AND item_id = i_pack.item_id AND item_code = i_pack.item_code;
        
        IF (item_validate_res >= 1) THEN
            status_value := 1;
        ELSE
            status_value := 0;
        END IF;
        
        -- executing update or insert
        IF (count_value > 0) THEN
          UPDATE T_SPM_PACKING_ORDER
            SET
              BOX_QUANTITY = i_pack.box_quantity,
              ITEM_ID = i_pack.item_id,
              ITEM_CODE = i_pack.item_code,
              ITEM_DESC = i_pack.item_desc,
              PRODUCT_ID = i_pack.product_id,
              PRODUCT_CODE = i_pack.product_code,
              PRODUCT_DESC = i_pack.product_desc,
              UOM_CODE = i_pack.uom_code,
              UOM_DESC = i_pack.uom_desc,
              "VERSION" = version_value, 
              STATUS = status_value,
              LAST_UPDATED_DATE = systimestamp,
              REMARK1 = i_pack.remark1,
              REMARK2 = i_pack.remark2,
              REMARK3 = i_pack.remark3,
              REMARK4 = i_pack.remark4,
              REMARK5 = i_pack.remark5,
              IMPORT_DATE = i_pack.import_date
            WHERE 
              BOX_NUMBER = i_pack.box_number AND DELIVERY_ORDER_ID = i_pack.delivery_order_id AND DELIVERY_ORDER_LINE_ID = i_pack.delivery_order_line_id;
        ELSE
          INSERT INTO T_SPM_PACKING_ORDER(
              BOX_NUMBER,
              BOX_QUANTITY,
              DELIVERY_ORDER_ID,
              DELIVERY_ORDER_LINE_ID,
              ITEM_ID,
              ITEM_CODE,
              ITEM_DESC,
              PRODUCT_ID,
              PRODUCT_CODE,
              PRODUCT_DESC,
              UOM_CODE,
              UOM_DESC,
              DELIVER_ORDER_LINE_SEQID,
              SEQ_ID,
              "VERSION", 
              STATUS,
              CREATED_DATE,
              LAST_UPDATED_DATE,
              REMARK1,
              REMARK2,
              REMARK3,
              REMARK4,
              REMARK5,
              import_date
          ) VALUES(
              i_pack.box_number,
              i_pack.box_quantity,
              i_pack.delivery_order_id,
              i_pack.delivery_order_line_id,
              i_pack.item_id,
              i_pack.item_code,
              i_pack.item_desc,
              i_pack.product_id,
              i_pack.product_code,
              i_pack.product_desc,
              i_pack.uom_code,
              i_pack.uom_desc,
              line_id_value,
              T_SIMPLE_DETECTION_SEQ.NEXTVAL,
              version_value,
              status_value,
              systimestamp,
              systimestamp,
              i_pack.remark1,
              i_pack.remark2,
              i_pack.remark3,
              i_pack.remark4,
              i_pack.remark5,
              i_pack.import_date
          );  
        END IF;
        
        count_success := count_success + 1;
    END LOOP;
    
    -- log
    INSERT INTO i_erp_logs VALUES(i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','T_SPM_PACKING_ORDER');
    EXCEPTION WHEN invalid_line_id THEN
        exception_info := 'ERR: An error occurred with info: 没有找到对应的行seq_id-箱号：' || i_pack.box_number || ' 送货单头:' || i_pack.delivery_order_id || '送货单行：' || i_pack.delivery_order_line_id;
        INSERT INTO i_erp_logs 
            VALUES(i_erp_logs_seq.nextval, total_value,count_success, sysdate, exception_info, 'T_SPM_PACKING_ORDER');
        
        CLOSE crs_pack;
        COMMIT;
      WHEN OTHERS THEN 
        exception_info := 'ERR: An error occurred with info:' || to_char(sqlcode) || ' ' || sqlerrm;
          INSERT INTO i_erp_logs 
            VALUES(i_erp_logs_seq.nextval, total_value,count_success, sysdate, exception_info, 'T_SPM_PACKING_ORDER');
        
        CLOSE crs_pack;
        COMMIT;
END PROC_SPM_PACKING_ORDER;
/

