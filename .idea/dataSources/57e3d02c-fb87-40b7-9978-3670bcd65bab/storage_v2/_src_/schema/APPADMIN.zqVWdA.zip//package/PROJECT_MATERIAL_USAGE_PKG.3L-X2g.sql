create package project_material_usage_pkg is
   type cur_project_material is ref cursor;
   procedure proc_project_material_usage(projectCode in varchar2, projectName in varchar2,
             itemCode in varchar2, itemName varchar2, spmPoCode in varchar2, createdName in varchar2,
             createdDept in varchar2, beginDate in varchar2, endDate in varchar2, transactionType in varchar2,
             pagenum in number, pagesize in number, ouId in long, ouCode in varchar2,
             total out number, project_material out cur_project_material);
end project_material_usage_pkg;
/

