create view V_T_SYS_ERP_OU as
  SELECT
/**报表ou查询框统一视图*/
ou_id,
    erp_type,
    ou_code
    || ' '
    || ou_name ouinfo
  FROM t_sys_erp_ou
  WHERE status=1
/

