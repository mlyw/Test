create PROCEDURE "PROC_SUBINVENTORY" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_subinventory is
select subinventory_code, subinventory_name, asset_inventory, locator_flag, enable_date, disable_date, last_update_date, erp_type, import_date, ou_id, organization_id, organization_name, seq_id, Attribute9, Attribute10, Attribute11 from i_erp_subinventory
 where create_date > start_time and create_date < end_time order by erp_type desc;
i_subinventory csr_i_subinventory%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_erp_subinventory where create_date > start_time and create_date < end_time;
  open csr_i_subinventory;
  fetch csr_i_subinventory into i_subinventory;
while (csr_i_subinventory%found) loop
  select count(*) into count_value from t_Sys_Erp_Subinventory where SUBINVENTORY_CODE = i_subinventory.subinventory_code and erp_type = i_subinventory.erp_type and ORGANIZATIONS_ID = i_subinventory.organization_id;
  if(count_value = 1 and i_subinventory.DISABLE_DATE is null) then
      update t_Sys_Erp_Subinventory t set t.last_updated_date = sysdate,
      t.subinventory_name = i_subinventory.subinventory_name,
      t.erp_type = i_subinventory.erp_type,
      t.organizations_id = i_subinventory.organization_id,
      t.ou_id = i_subinventory.ou_id,
      t.enable_date = i_subinventory.enable_date,
      t.asset_inventory = i_subinventory.asset_inventory,
      t.locator_flag = i_subinventory.locator_flag, 
      t.Attribute9 = i_subinventory.Attribute9,
      t.Attribute10 = i_subinventory.Attribute10,
      t.Attribute11 = i_subinventory.Attribute11 
      where t.subinventory_code = i_subinventory.subinventory_code;
   elsif(count_value = 1 and i_subinventory.disable_date is not null) then
   update t_Sys_Erp_Subinventory t set t.last_updated_date = sysdate,
      t.subinventory_name = i_subinventory.subinventory_name,
      t.erp_type = i_subinventory.erp_type,
      t.organizations_id = i_subinventory.organization_id,
      t.ou_id = i_subinventory.ou_id,
      t.enable_date = i_subinventory.enable_date,
      t.asset_inventory = i_subinventory.asset_inventory,
      t.locator_flag = i_subinventory.locator_flag,
      t.disable_date = i_subinventory.disable_date,
      t.Attribute9 = i_subinventory.Attribute9,
      t.Attribute10 = i_subinventory.Attribute10,
      t.Attribute11 = i_subinventory.Attribute11,
      t.status = 0
      where t.subinventory_code = i_subinventory.subinventory_code;
 elsif(count_value = 0 and i_subinventory.disable_date is null) then
  insert into t_sys_erp_subinventory
    (seq_id, subinventory_id, created_date, last_updated_date, status, erp_type, subinventory_code, subinventory_name, organizations_id, ou_id, enable_date, disable_date, asset_inventory, locator_flag,Attribute9,Attribute10,Attribute11)
  values
    (i_subinventory.seq_id, i_subinventory.seq_id, sysdate, sysdate, 1, i_subinventory.erp_type, i_subinventory.subinventory_code, i_subinventory.subinventory_name, i_subinventory.organization_id, i_subinventory.ou_id, i_subinventory.enable_date, i_subinventory.disable_date, i_subinventory.asset_inventory, i_subinventory.locator_flag,i_subinventory.Attribute9,i_subinventory.Attribute10,i_subinventory.Attribute11);
end if;
fetch csr_i_subinventory into i_subinventory;
count_success:=count_success+1;
end loop;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_erp_subinventory');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_erp_subinventory');
close csr_i_subinventory;
commit;
end;
/

