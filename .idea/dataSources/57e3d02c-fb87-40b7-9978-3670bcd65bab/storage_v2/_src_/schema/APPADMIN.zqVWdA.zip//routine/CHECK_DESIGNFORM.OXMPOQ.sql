create FUNCTION "CHECK_DESIGNFORM"(v_item_id    varchar2,
                                              v_project_no varchar2,
                                              v_item_type  varchar2 --物料类型：1 物料 2物料组
                                              ) return float as
  v_headerid      number(19);
  v_lineid        number(19);
  v_hasTempOrder  number(19); --是否存在临时货单
  v_temp_headerid number(19); --临时货单头ID
  v_temp_lineid   number(19); --临时货单行ID
  v_qty           number(19); --正式货单数量
  v_temp_qty      number(19); --临时货单数量
  v_isExists      number(19); --正式货单是否存在该物料
  v_isTempExists  number(19); --临时货单是否存在该物料
BEGIN
  --判断是否有临时货单
  select count(1)
    into v_hasTempOrder
    from T_SYS_EPM_DESIGNINGFORM_HEADER h
   where h.project_no = v_project_no
     and h.status = 1
     and h.is_temporder = 1;

  --取正式货单头数据
  select h.seq_id
    into v_headerid
    from t_sys_epm_designingform_header h
   where h.project_no = v_project_no
     and h.status = 1
     and (h.is_temporder is null or h.is_temporder = 0);

  --1.无临时货单，返回正式货单头ID
  if v_hasTempOrder = 0 then
    return v_headerid;
  else
    --2.判断正式货单是否存在该物料
    if v_item_type = 1 then
      --物料
      select count(seq_id)
        into v_isExists
        from T_SYS_EPM_DESIGNINGFORM_LINE zl
       where zl.status = 1
         and zl.item_id = v_item_id
         and zl.MATERIAL_TYPE = 1
         and zl.header_seq_id = v_headerid;
    elsif v_item_type = 2 then
      --物料组
      select count(seq_id)
        into v_isExists
        from T_SYS_EPM_DESIGNINGFORM_LINE zl
       where zl.status = 1
         and zl.item_group_id = v_item_id
         and zl.MATERIAL_TYPE = 1
         and zl.header_seq_id = v_headerid;
    end if;

    --3.正式货单不存在该物料，返回正式货单头ID
    if v_isExists = 0 then
      return v_headerid;
    else
      --4.取临时货单头数据
      select h.seq_id
        into v_temp_headerid
        from t_sys_epm_designingform_header h
       where h.project_no = v_project_no
         and h.status = 1
         and h.is_temporder = 1;
      --5.判断临时货单是否存在该物料
      if v_item_type = 1 then
        --物料
        select count(seq_id)
          into v_isTempExists
          from T_SYS_EPM_DESIGNINGFORM_LINE zl
         where zl.status = 1
           and zl.item_id = v_item_id
           and zl.MATERIAL_TYPE = 1
           and zl.header_seq_id = v_temp_headerid;
      elsif v_item_type = 2 then
        --物料组
        select count(seq_id)
          into v_isTempExists
          from T_SYS_EPM_DESIGNINGFORM_LINE zl
         where zl.status = 1
           and zl.item_group_id = v_item_id
           and zl.MATERIAL_TYPE = 1
           and zl.header_seq_id = v_temp_headerid;
      end if;

      --6.临时货单不存在该物料，返回临时货单头ID
      if v_isTempExists = 0 then
        return v_temp_headerid;
      else
        --2.取正式货单行数据
        if v_item_type = 1 then
          --物料
          select zl.seq_id, zl.dmd_quantity
            into v_lineid, v_qty
            from T_SYS_EPM_DESIGNINGFORM_LINE zl
           where zl.status = 1
             and zl.item_id = v_item_id
             and zl.MATERIAL_TYPE = 1
             and zl.header_seq_id = v_headerid;
        elsif v_item_type = 2 then
          --物料组
          select zl.seq_id, zl.dmd_quantity
            into v_lineid, v_qty
            from T_SYS_EPM_DESIGNINGFORM_LINE zl
           where zl.status = 1
             and zl.item_group_id = v_item_id
             and zl.MATERIAL_TYPE = 1
             and zl.header_seq_id = v_headerid;
        end if;

        --4.取临时货单行数据
        if v_item_type = 1 then
          --物料
          select zl.seq_id, zl.dmd_quantity
            into v_temp_lineid, v_temp_qty
            from T_SYS_EPM_DESIGNINGFORM_LINE zl
           where zl.status = 1
             and zl.item_id = v_item_id
             and zl.MATERIAL_TYPE = 1
             and zl.header_seq_id = v_temp_headerid;
        elsif v_item_type = 2 then
          --物料组
          select zl.seq_id, zl.dmd_quantity
            into v_temp_lineid, v_temp_qty
            from T_SYS_EPM_DESIGNINGFORM_LINE zl
           where zl.status = 1
             and zl.item_group_id = v_item_id
             and zl.MATERIAL_TYPE = 1
             and zl.header_seq_id = v_temp_headerid;
        end if;
        if v_temp_qty < v_qty then
          return v_temp_headerid;
        else
          return v_headerid;
        end if;
      end if;
    end if;
  end if;
END;
/

