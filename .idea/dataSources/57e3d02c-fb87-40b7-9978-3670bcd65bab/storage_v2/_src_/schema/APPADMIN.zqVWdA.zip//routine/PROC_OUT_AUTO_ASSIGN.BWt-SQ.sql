create procedure proc_out_auto_assign(headerId in number,
                                                  flag out number,
                                                  resultInfo out varchar2,
                                                  ouEmployeeNumbe in varchar2,
                                                  ouId in number,
                                                  erpType in varchar2) as

--物料包
itemPackageId number;
lineid number;
itemid number;
itemCode varchar2(30);
assign_line_id number;
quantity number(19,5);
project_code varchar2(30);
temp_quantity number(19,5);
limit_quantity number(19,5);
recordCount number;
item_scope number;
quota_type varchar2(20);
quota_control_type number;
quota_head_id number;
quota_line_id number;
quota_detail_id number;
employeeNumbe varchar2(20);
v_total_onhand_quantity number(19,5);
v_record_count number;
E_EXECUTING_EXCEPTION exception;
E_ITEM_GROUP_EXCEPTION exception;
itemGroupId number(19);
itemGroupCode varchar2(50);
convertRatio number(19,5);
msg varchar2(200);
Asn number(19,5);
temp_qty number(19,5);
--待分配的行
cursor c_out_line_info is
select line.id,
       line.item_id,
       line.apply_quty-nvl(line.tol_asgn_quty,0),
       line.item_code,
       (select h.project_code from t_out_hd h where h.id=headerId),
       nvl(item_Package_Header_Id,0),
       line.item_scope
from t_out_ln line 
where line.outhdinfo_id=headerId and (line.ord_ln_status is null or line.ord_ln_status=2 or line.ord_ln_status=8);
c_quota_detail_info sys_refcursor;
c_item_scope_info sys_refcursor;
type r_onhand_info is record
(
 onhand_id number,
 onhand_quantity number(19,5),
 quota_quantity number(19,5),
 warehouse_id number,
 onhand_item_id number,
 onhand_item_code varchar2(30),
 mis_pic_code varchar2(50),
 rec_pic_code varchar2(50),
 vendor_id number,
 locator_id number,
 locator_code varchar2(50),
 product_unit_price number(19,5),
 product_unit_price_ex_tax number(19,5),
 quota_locking_id number
);
type r_c_onhand_info is ref cursor return r_onhand_info;
c_onhand_info  r_c_onhand_info;
v_onhand_info r_onhand_info;
begin
  select count(*) into v_record_count from t_lis_auto_assign_temp t where t.business_id=headerId;                      
  if v_record_count > 0 then 
    raise E_EXECUTING_EXCEPTION;
  end if ;
  resultInfo :='<p>自动分配分配成功:</p>';
  flag :=1;
  employeeNumbe := substr(ouEmployeeNumbe,instr(ouEmployeeNumbe,'_',1,1)+1,length(ouEmployeeNumbe)-instr(ouEmployeeNumbe,'_',1,1));
  open c_out_line_info;
  loop
  fetch c_out_line_info into lineid,itemid,quantity,itemCode,project_code,itemPackageId,item_scope;
  exit when c_out_line_info%notfound;
    v_total_onhand_quantity := 0;--现有量
    --普通物料
    if(item_scope is null or 0 = item_scope) then 
      --因为在申请出库已经判断过所申请的物料是否配额控制 所以只需要查询配额冻结记录里面有没有该记录就行了
      select count(rq.id) into recordCount 
        from t_lis_recipient_quota_reserve  rq 
        where rq.status=1 and rq.business_order_line_id=lineId;
      temp_quantity :=quantity; 
      if recordCount > 0 then
        --如果该物料做了配额管理 还要查询控制方式
        open c_quota_detail_info for
        select distinct rd.header_id,rd.line_id,rd.id 
          from t_lis_recipient_quota_detail rd 
          where rd.id in(select rq.quota_detail_id from t_lis_recipient_quota_reserve  rq where rq.status=1 and rq.business_order_line_id=lineId);
        loop
        fetch c_quota_detail_info into quota_head_id,quota_line_id,quota_detail_id;
        exit when c_quota_detail_info%notfound;
        select rh.quota_type,rl.quota_control_type into quota_type,quota_control_type 
          from t_lis_recipient_quota_header rh join t_lis_recipient_quota_line rl on rh.id = rl.header_id 
          where rh.status=1 and rl.status=1  and rh.id=quota_head_id and rl.id=quota_line_id;
        if quota_type='batch_type' then
         --如果配额类型是批次 要查询配额的现有量
         --现有量必须大于或等于申请数量 不再部分分配
          SELECT SUM(a.onhand_quantity-NVL(f.RESERVE_QUANTITY,0)) INTO v_total_onhand_quantity
        FROM t_wh_current_onhand_quantity a
        JOIN
          (SELECT DISTINCT ac.employ_number,
            ac.warehouse_define_id
          FROM t_warehouse_access_user ac
          ) d ON a.warehouse_define_id = d.warehouse_define_id AND d.employ_number      =employeeNumbe
          --限制现有量属于BJE下
        JOIN
          (SELECT its.seq_id
          FROM t_sys_erp_items its
          JOIN t_sys_erp_organizations org
          ON org.organization_id   =its.organization_id
          AND org.organization_code='BJE'
          AND its.status= 1
          ) itss ON itss.seq_id =a.item_id
        LEFT JOIN T_SYS_ERP_LOCATORS l ON a.LOCATOR_ID=l.LOCATOR_ID AND l.ERP_TYPE =erpType
        LEFT JOIN T_SYS_SPM_PRODUCTS b ON a.product_id=b.seq_id
        LEFT JOIN
          (SELECT qll.quota_quantity-NVL(mk.asgn_quty,0) ql_quota_quantity,qll.onhand_id,qll.id
          FROM t_lis_recipient_quota_locking qll
          LEFT JOIN t_out_notmk mk ON qll.id =mk.quota_locking_id
          WHERE qll.detail_id =quota_detail_id) ql ON ql.onhand_id=a.id
        LEFT JOIN
          (SELECT e.onhand_id,
            SUM(NVL(e.RESERVE_QUANTITY,0)) AS RESERVE_QUANTITY
          FROM T_SYS_ITEM_RESEREVE_INFO e
          WHERE sysdate < e.reserve_end_day
          AND e.status  = 1
          GROUP BY e.onhand_id
          ) f ON a.id=f.onhand_id
        LEFT JOIN T_WAREHOUSE_DEFINE w ON a.warehouse_define_id=w.id AND w.is_storage LIKE 'Y' AND w.MIS_OU_ID =ouId AND w.mis_io_code = 'BJE'
        WHERE a.onhand_quantity-NVL(f.RESERVE_QUANTITY,0)>0 AND a.item_id = itemid
        AND a.id                                        IN
          (SELECT tql.onhand_id
          FROM t_lis_recipient_quota_locking tql
          WHERE tql.detail_id=quota_detail_id
          ) AND a.ERP_TYPE=erpType AND a.status  =1
        AND ( l.LOCATOR_CODE LIKE '%' ||project_code ||'%' OR l.locator_code NOT LIKE '%|%' OR l.locator_code IS NULL )
        AND w.CATEGORY_ID  = (SELECT twc.id FROM T_WAREHOUSE_CATEGORY twc WHERE twc.CODE LIKE '01') AND a.item_package_id IS NULL --非物料包
        ORDER BY a.created_date;
          if v_total_onhand_quantity>= quantity then 
        open c_onhand_info for  
        SELECT a.id,a.onhand_quantity-NVL(f.RESERVE_QUANTITY,0),ql.ql_quota_quantity,a.warehouse_define_id,a.item_id,a.item_code,
               a.mis_pic_code,a.receipt_pic_code,a.vendor_id,a.locator_id,a.locator_code,a.product_unit_price,a.product_unit_price_ex_tax,ql.id
        FROM t_wh_current_onhand_quantity a
        JOIN
          (SELECT DISTINCT ac.employ_number,
            ac.warehouse_define_id
          FROM t_warehouse_access_user ac
          ) d ON a.warehouse_define_id = d.warehouse_define_id
        AND d.employ_number      =employeeNumbe
        --限制现有量属于BJE下
        JOIN
          (SELECT its.seq_id
          FROM t_sys_erp_items its
          JOIN t_sys_erp_organizations org
          ON org.organization_id   =its.organization_id
          AND org.organization_code='BJE'
          AND its.status           = 1
          ) itss ON itss.seq_id    =a.item_id
        LEFT JOIN T_SYS_ERP_LOCATORS l ON a.LOCATOR_ID=l.LOCATOR_ID AND l.ERP_TYPE =erpType
        LEFT JOIN T_SYS_SPM_PRODUCTS b ON a.product_id=b.seq_id
        LEFT JOIN
          (SELECT qll.quota_quantity-NVL(mk.asgn_quty,0) ql_quota_quantity,qll.onhand_id,qll.id
          FROM t_lis_recipient_quota_locking qll
          LEFT JOIN t_out_notmk mk ON qll.id  =mk.quota_locking_id
          WHERE qll.detail_id =quota_detail_id
          ) ql ON ql.onhand_id=a.id
        LEFT JOIN
          (SELECT e.onhand_id,
            SUM(NVL(e.RESERVE_QUANTITY,0)) AS RESERVE_QUANTITY
          FROM T_SYS_ITEM_RESEREVE_INFO e
          WHERE sysdate < e.reserve_end_day
          AND e.status  = 1
          GROUP BY e.onhand_id
          ) f ON a.id=f.onhand_id
        LEFT JOIN T_WAREHOUSE_DEFINE w ON a.warehouse_define_id=w.id AND w.is_storage LIKE 'Y' AND w.MIS_OU_ID =ouId AND w.mis_io_code = 'BJE'
        WHERE a.onhand_quantity-NVL(f.RESERVE_QUANTITY,0)>0 AND a.item_id= itemid
        AND a.id  IN
          (SELECT tql.onhand_id
          FROM t_lis_recipient_quota_locking tql
          WHERE tql.detail_id=quota_detail_id
          ) AND a.ERP_TYPE=erpType AND a.status  =1 AND ( l.LOCATOR_CODE LIKE '%' ||project_code ||'%' OR l.locator_code NOT LIKE '%|%' OR l.locator_code IS NULL )
        AND w.CATEGORY_ID  =
          (SELECT twc.id FROM T_WAREHOUSE_CATEGORY twc WHERE twc.CODE LIKE '01'
          ) AND a.item_package_id IS NULL --非物料包
        ORDER BY a.created_date;
             
             
             
             loop
               fetch c_onhand_info into v_onhand_info;
               exit when quantity=0;
               exit when c_onhand_info%notfound;
               limit_quantity :=least(v_onhand_info.onhand_quantity,v_onhand_info.quota_quantity);
                assign_line_id :=LIS_ORDER_SEQ.Nextval;
               if limit_quantity >= quantity then
                 insert into t_out_notmk(id,created_date,created_user,last_updated_date,last_updated_user,
                 status,version,asgn_ln_status,asgn_quty,asgn_time,item_code,item_id,mis_pic_code,ord_ln_id,outlninfo_id,
                 out_ord_id,rcp_pic_code,warehouseid,reserve_days,if_reserve,warehouse_onhand_id,vendor_id,
                 source_warehouse_id,locator_id,locator_code,product_unit_price,product_unit_price_ex_tax,
                 quota_locking_id)
                 values(assign_line_id,systimestamp,ouEmployeeNumbe,systimestamp,ouEmployeeNumbe,
                 1,0,4,quantity,systimestamp,v_onhand_info.onhand_item_code,v_onhand_info.onhand_item_id,
                 v_onhand_info.mis_pic_code,lineid,lineid,headerId,v_onhand_info.rec_pic_code,v_onhand_info.warehouse_id,
                 3,1,v_onhand_info.onhand_id,v_onhand_info.vendor_id,v_onhand_info.warehouse_id,v_onhand_info.locator_id
                 ,v_onhand_info.locator_code,v_onhand_info.product_unit_price,v_onhand_info.product_unit_price_ex_tax,
                v_onhand_info.quota_locking_id);
                insert into t_sys_item_resereve_info(reserveid,status,version,reserve_end_day,material_onhand_id,
                       order_line_id,reserve_quantity,reserve_start_day,order_type,onhand_id)
                 values(S_OUT_RESERVE_INF.Nextval,1,0,sysdate+3,v_onhand_info.onhand_id,assign_line_id,
                 quantity,sysdate,'CK',v_onhand_info.onhand_id);
                 quantity :=0;
                 
                    elsif limit_quantity<quantity then
                    insert into t_out_notmk(id,created_date,created_user,last_updated_date,last_updated_user,
                 status,version,asgn_ln_status,asgn_quty,asgn_time,item_code,item_id,mis_pic_code,ord_ln_id,outlninfo_id,
                 out_ord_id,rcp_pic_code,warehouseid,reserve_days,if_reserve,warehouse_onhand_id,vendor_id,
                 source_warehouse_id,locator_id,locator_code,product_unit_price,product_unit_price_ex_tax,
                 quota_locking_id)
                 values(assign_line_id,systimestamp,ouEmployeeNumbe,systimestamp,ouEmployeeNumbe,
                 1,0,4,limit_quantity,systimestamp,v_onhand_info.onhand_item_code,v_onhand_info.onhand_item_id,
                 v_onhand_info.mis_pic_code,lineid,lineid,headerId,v_onhand_info.rec_pic_code,v_onhand_info.warehouse_id,
                 3,1,v_onhand_info.onhand_id,v_onhand_info.vendor_id,v_onhand_info.warehouse_id,v_onhand_info.locator_id
                 ,v_onhand_info.locator_code,v_onhand_info.product_unit_price,v_onhand_info.product_unit_price_ex_tax,
                v_onhand_info.quota_locking_id);
                insert into t_sys_item_resereve_info(reserveid,status,version,reserve_end_day,material_onhand_id,
                       order_line_id,reserve_quantity,reserve_start_day,order_type,onhand_id)
                 values(S_OUT_RESERVE_INF.Nextval,1,0,sysdate+3,v_onhand_info.onhand_id,assign_line_id,
                 limit_quantity,sysdate,'CK',v_onhand_info.onhand_id);
                 quantity := quantity - limit_quantity;
                 
                end if;
               end loop;
               close  c_onhand_info;
               end if ;
        end if;
        if quota_type='total_type' then          
        SELECT SUM(a.onhand_quantity-NVL(f.RESERVE_QUANTITY,0))
        INTO v_total_onhand_quantity
        FROM t_wh_current_onhand_quantity a
        JOIN
          (SELECT DISTINCT ac.employ_number,
            ac.warehouse_define_id
          FROM t_warehouse_access_user ac
          ) d ON a.warehouse_define_id = d.warehouse_define_id AND d.employ_number      =employeeNumbe
        --限制现有量属于BJE下
        JOIN
          (SELECT its.seq_id
          FROM t_sys_erp_items its JOIN t_sys_erp_organizations org ON org.organization_id   =its.organization_id
          AND org.organization_code='BJE' AND its.status = 1 ) itss ON itss.seq_id    =a.item_id
        LEFT JOIN T_SYS_ERP_LOCATORS l ON a.LOCATOR_ID=l.LOCATOR_ID AND l.ERP_TYPE =erpType
        LEFT JOIN T_SYS_SPM_PRODUCTS b ON a.product_id=b.seq_id
        LEFT JOIN
          (SELECT qll.quota_quantity-NVL(mk.asgn_quty,0) ql_quota_quantity,qll.onhand_id,qll.id
          FROM t_lis_recipient_quota_locking qll
          LEFT JOIN t_out_notmk mk ON qll.id =mk.quota_locking_id
          WHERE qll.detail_id =quota_detail_id
          ) ql ON ql.onhand_id=a.id
        LEFT JOIN
          (SELECT e.onhand_id, SUM(NVL(e.RESERVE_QUANTITY,0)) AS RESERVE_QUANTITY
          FROM T_SYS_ITEM_RESEREVE_INFO e
          WHERE sysdate < e.reserve_end_day AND e.status  = 1
          GROUP BY e.onhand_id
          ) f ON a.id=f.onhand_id
        LEFT JOIN T_WAREHOUSE_DEFINE w ON a.warehouse_define_id=w.id AND w.is_storage LIKE 'Y' AND w.MIS_OU_ID  =ouId AND w.mis_io_code  = 'BJE'
        WHERE a.onhand_quantity-NVL(f.RESERVE_QUANTITY,0)>0
        AND a.item_id    = itemid
        AND a.id NOT IN
          (SELECT DISTINCT tql.onhand_id FROM t_lis_recipient_quota_locking tql
          ) AND a.ERP_TYPE=erpType AND a.status  =1 AND ( l.LOCATOR_CODE LIKE '%' ||project_code ||'%' OR l.locator_code NOT LIKE '%|%' OR l.locator_code IS NULL )
        AND w.CATEGORY_ID  = (SELECT twc.id FROM T_WAREHOUSE_CATEGORY twc WHERE twc.CODE LIKE '01')
        AND a.item_package_id IS NULL --非物料包
        ORDER BY a.created_date;
        if v_total_onhand_quantity>= quantity then 
          open c_onhand_info for  select a.id,a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0),
                ql.ql_quota_quantity,a.warehouse_define_id,a.item_id,a.item_code,a.mis_pic_code,
                a.receipt_pic_code,a.vendor_id,a.locator_id,a.locator_code,a.product_unit_price,
                a.product_unit_price_ex_tax,ql.id
            from t_wh_current_onhand_quantity a join  (select distinct ac.employ_number,ac.warehouse_define_id from t_warehouse_access_user ac) d on
            a.warehouse_define_id = d.warehouse_define_id and  d.employ_number =employeeNumbe
            --限制现有量属于BJE下
            join (select its.seq_id from t_sys_erp_items its join t_sys_erp_organizations org on org.organization_id=its.organization_id and org.organization_code='BJE' and its.status = 1) itss on itss.seq_id=a.item_id
            left join T_SYS_ERP_LOCATORS l on a.LOCATOR_ID=l.LOCATOR_ID and  l.ERP_TYPE=erpType
            left join T_SYS_SPM_PRODUCTS b on a.product_id=b.seq_id
            left join (select qll.quota_quantity-nvl(mk.asgn_quty,0) ql_quota_quantity,qll.onhand_id,qll.id from
             t_lis_recipient_quota_locking  qll left join t_out_notmk mk on qll.id=mk.quota_locking_id
            where qll.detail_id=quota_detail_id ) ql on ql.onhand_id=a.id
            left join (select e.onhand_id,sum(nvl(e.RESERVE_QUANTITY,0)) as RESERVE_QUANTITY
            from T_SYS_ITEM_RESEREVE_INFO e where sysdate < e.reserve_end_day and e.status = 1
            group by e.onhand_id) f on a.id=f.onhand_id
            left join T_WAREHOUSE_DEFINE w on a.warehouse_define_id=w.id and w.is_storage like 'Y' and w.MIS_OU_ID =ouId and w.mis_io_code = 'BJE'
            where a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0)>0
               and a.item_id= itemid
               and a.id not in (select distinct tql.onhand_id from t_lis_recipient_quota_locking tql)
               and a.ERP_TYPE=erpType  and a.status=1
               and ( l.LOCATOR_CODE like '%'||project_code||'%' or l.locator_code not like '%|%' or l.locator_code is null )
               and w.CATEGORY_ID=(select twc.id from T_WAREHOUSE_CATEGORY twc where twc.CODE like '01')
                and a.item_package_id is null --非物料包
               order by a.created_date;
          loop
                 fetch c_onhand_info into v_onhand_info;
                 exit when quantity=0;
                 exit when c_onhand_info%notfound;
                  assign_line_id :=LIS_ORDER_SEQ.Nextval;
                 if v_onhand_info.quota_quantity >= quantity then
                   insert into t_out_notmk(id,created_date,created_user,last_updated_date,last_updated_user,
                   status,version,asgn_ln_status,asgn_quty,asgn_time,item_code,item_id,mis_pic_code,ord_ln_id,outlninfo_id,
                   out_ord_id,rcp_pic_code,warehouseid,reserve_days,if_reserve,warehouse_onhand_id,vendor_id,
                   source_warehouse_id,locator_id,locator_code,product_unit_price,product_unit_price_ex_tax,
                   quota_locking_id)
                   values(assign_line_id,systimestamp,ouEmployeeNumbe,systimestamp,ouEmployeeNumbe,
                   1,0,4,quantity,systimestamp,v_onhand_info.onhand_item_code,v_onhand_info.onhand_item_id,
                   v_onhand_info.mis_pic_code,lineid,lineid,headerId,v_onhand_info.rec_pic_code,v_onhand_info.warehouse_id,
                   3,1,v_onhand_info.onhand_id,v_onhand_info.vendor_id,v_onhand_info.warehouse_id,v_onhand_info.locator_id
                   ,v_onhand_info.locator_code,v_onhand_info.product_unit_price,v_onhand_info.product_unit_price_ex_tax,
                  v_onhand_info.quota_locking_id);
                  insert into t_sys_item_resereve_info(reserveid,status,version,reserve_end_day,material_onhand_id,
                         order_line_id,reserve_quantity,reserve_start_day,order_type,onhand_id)
                   values(S_OUT_RESERVE_INF.Nextval,1,0,sysdate+3,v_onhand_info.onhand_id,assign_line_id,
                   quantity,sysdate,'CK',v_onhand_info.onhand_id);
                   quantity :=0;
                    elsif v_onhand_info.quota_quantity<quantity then
                      insert into t_out_notmk(id,created_date,created_user,last_updated_date,last_updated_user,
                   status,version,asgn_ln_status,asgn_quty,asgn_time,item_code,item_id,mis_pic_code,ord_ln_id,outlninfo_id,
                   out_ord_id,rcp_pic_code,warehouseid,reserve_days,if_reserve,warehouse_onhand_id,vendor_id,
                   source_warehouse_id,locator_id,locator_code,product_unit_price,product_unit_price_ex_tax,
                   quota_locking_id)
                   values(assign_line_id,systimestamp,ouEmployeeNumbe,systimestamp,ouEmployeeNumbe,
                   1,0,4,v_onhand_info.quota_quantity,systimestamp,v_onhand_info.onhand_item_code,v_onhand_info.onhand_item_id,
                   v_onhand_info.mis_pic_code,lineid,lineid,headerId,v_onhand_info.rec_pic_code,v_onhand_info.warehouse_id,
                   3,1,v_onhand_info.onhand_id,v_onhand_info.vendor_id,v_onhand_info.warehouse_id,v_onhand_info.locator_id
                   ,v_onhand_info.locator_code,v_onhand_info.product_unit_price,v_onhand_info.product_unit_price_ex_tax,
                  v_onhand_info.quota_locking_id);
                  insert into t_sys_item_resereve_info(reserveid,status,version,reserve_end_day,material_onhand_id,
                         order_line_id,reserve_quantity,reserve_start_day,order_type,onhand_id)
                   values(S_OUT_RESERVE_INF.Nextval,1,0,sysdate+3,v_onhand_info.onhand_id,assign_line_id,
                   v_onhand_info.quota_quantity,sysdate,'CK',v_onhand_info.onhand_id);
                   quantity := quantity - v_onhand_info.quota_quantity;
                  
                  end if;
                 end loop;
          close  c_onhand_info;
        end if;
        end if;
        end loop;
        close c_quota_detail_info;
      end if;
      if recordCount=0 then
        --判断是否存在于物料包
        if(0 != itemPackageId) then
          select sum(a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0)) into v_total_onhand_quantity
          from t_wh_current_onhand_quantity a join  (select distinct ac.employ_number,ac.warehouse_define_id from t_warehouse_access_user ac) d on
          a.warehouse_define_id = d.warehouse_define_id and  d.employ_number =employeeNumbe
          --限制现有量属于BJE下
          join (select its.seq_id from t_sys_erp_items its join t_sys_erp_organizations org on org.organization_id=its.organization_id and org.organization_code='BJE' and its.status = 1) itss on itss.seq_id=a.item_id
          left join T_SYS_ERP_LOCATORS l on a.LOCATOR_ID=l.LOCATOR_ID and  l.ERP_TYPE=erpType
          left join T_SYS_SPM_PRODUCTS b on a.product_id=b.seq_id
          left join (select qll.quota_quantity-nvl(mk.asgn_quty,0) ql_quota_quantity,qll.onhand_id,qll.id from
          t_lis_recipient_quota_locking  qll left join t_out_notmk mk on qll.id=mk.quota_locking_id
          ) ql on ql.onhand_id=a.id
          left join (select e.onhand_id,sum(nvl(e.RESERVE_QUANTITY,0)) as RESERVE_QUANTITY
          from T_SYS_ITEM_RESEREVE_INFO e where sysdate < e.reserve_end_day and e.status = 1
          group by e.onhand_id) f on a.id=f.onhand_id
          left join T_WAREHOUSE_DEFINE w on a.warehouse_define_id=w.id and w.is_storage like 'Y' and w.MIS_OU_ID =ouId and w.mis_io_code = 'BJE'
          where a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0)>0
          and a.item_id= itemid
          and a.id not in (select distinct tql.onhand_id from t_lis_recipient_quota_locking tql)
          and a.ERP_TYPE=erpType  and a.status=1
          and w.CATEGORY_ID=(select twc.id from T_WAREHOUSE_CATEGORY twc where twc.CODE like '01')
          and ( l.LOCATOR_CODE like '%'||project_code||'%' or l.locator_code not like '%|%' or l.locator_code is null )
          and a.item_package_id = itemPackageId  --物料包
          order by a.created_date;
        end if;
        if(itemPackageId=0) then
          select sum(a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0)) into v_total_onhand_quantity
          from t_wh_current_onhand_quantity a join  (select distinct ac.employ_number,ac.warehouse_define_id from t_warehouse_access_user ac) d on
          a.warehouse_define_id = d.warehouse_define_id and  d.employ_number =employeeNumbe
          --限制现有量属于BJE下
          join (select its.seq_id from t_sys_erp_items its join t_sys_erp_organizations org on org.organization_id=its.organization_id and org.organization_code='BJE' and its.status = 1) itss on itss.seq_id=a.item_id
          left join T_SYS_ERP_LOCATORS l on a.LOCATOR_ID=l.LOCATOR_ID and  l.ERP_TYPE=erpType
          left join T_SYS_SPM_PRODUCTS b on a.product_id=b.seq_id
          left join (select qll.quota_quantity-nvl(mk.asgn_quty,0) ql_quota_quantity,qll.onhand_id,qll.id from
          t_lis_recipient_quota_locking  qll left join t_out_notmk mk on qll.id=mk.quota_locking_id
          ) ql on ql.onhand_id=a.id
          left join (select e.onhand_id,sum(nvl(e.RESERVE_QUANTITY,0)) as RESERVE_QUANTITY
          from T_SYS_ITEM_RESEREVE_INFO e where sysdate < e.reserve_end_day and e.status = 1
          group by e.onhand_id) f on a.id=f.onhand_id
          left join T_WAREHOUSE_DEFINE w on a.warehouse_define_id=w.id and w.is_storage like 'Y' and w.MIS_OU_ID =ouId and w.mis_io_code = 'BJE'
          where a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0)>0
          and a.item_id= itemid
          and a.id not in (select distinct tql.onhand_id from t_lis_recipient_quota_locking tql)
          and a.ERP_TYPE=erpType  and a.status=1
          and w.CATEGORY_ID=(select twc.id from T_WAREHOUSE_CATEGORY twc where twc.CODE like '01')
          and ( l.LOCATOR_CODE like '%'||project_code||'%' or l.locator_code not like '%|%' or l.locator_code is null )
          and a.item_package_id is null --非物料包
          order by a.created_date;  
        end if;
        if v_total_onhand_quantity>=quantity then 
          --判断是否存在于物料包
          if(0 != itemPackageId) then
            open c_onhand_info for  select a.id ,a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0) ,
            ql.ql_quota_quantity,a.warehouse_define_id,a.item_id,a.item_code,a.mis_pic_code,
            a.receipt_pic_code,a.vendor_id,a.locator_id,a.locator_code,a.product_unit_price,
            a.product_unit_price_ex_tax,ql.id
            from t_wh_current_onhand_quantity a join  (select distinct ac.employ_number,ac.warehouse_define_id from t_warehouse_access_user ac) d on
            a.warehouse_define_id = d.warehouse_define_id and  d.employ_number =employeeNumbe
            --限制现有量属于BJE下
            join (select its.seq_id from t_sys_erp_items its join t_sys_erp_organizations org on org.organization_id=its.organization_id and org.organization_code='BJE' and its.status = 1) itss on itss.seq_id=a.item_id
            left join T_SYS_ERP_LOCATORS l on a.LOCATOR_ID=l.LOCATOR_ID and  l.ERP_TYPE=erpType
            left join T_SYS_SPM_PRODUCTS b on a.product_id=b.seq_id
            left join (select qll.quota_quantity-nvl(mk.asgn_quty,0) ql_quota_quantity,qll.onhand_id,qll.id from
            t_lis_recipient_quota_locking  qll left join t_out_notmk mk on qll.id=mk.quota_locking_id
            ) ql on ql.onhand_id=a.id
            left join (select e.onhand_id,sum(nvl(e.RESERVE_QUANTITY,0)) as RESERVE_QUANTITY
            from T_SYS_ITEM_RESEREVE_INFO e where sysdate < e.reserve_end_day and e.status = 1
            group by e.onhand_id) f on a.id=f.onhand_id
            left join T_WAREHOUSE_DEFINE w on a.warehouse_define_id=w.id and w.is_storage like 'Y' and w.MIS_OU_ID =ouId and w.mis_io_code = 'BJE'
            where a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0)>0
            and a.item_id= itemid
            and a.id not in (select distinct tql.onhand_id from t_lis_recipient_quota_locking tql)
            and a.ERP_TYPE=erpType  and a.status=1
            and w.CATEGORY_ID=(select twc.id from T_WAREHOUSE_CATEGORY twc where twc.CODE like '01')
            and ( l.LOCATOR_CODE like '%'||project_code||'%' or l.locator_code not like '%|%' or l.locator_code is null )
            and a.item_package_id = itemPackageId
            --(select h.id from t_item_package_head h where h.status = 1 and h.product_id = itemPackageId)  --物料包
            order by a.created_date;
          end if;
          if(itemPackageId=0) then
            open c_onhand_info for  select a.id ,a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0) ,
            ql.ql_quota_quantity,a.warehouse_define_id,a.item_id,a.item_code,a.mis_pic_code,
            a.receipt_pic_code,a.vendor_id,a.locator_id,a.locator_code,a.product_unit_price,
            a.product_unit_price_ex_tax,ql.id
            from t_wh_current_onhand_quantity a join  (select distinct ac.employ_number,ac.warehouse_define_id from t_warehouse_access_user ac) d on
            a.warehouse_define_id = d.warehouse_define_id and  d.employ_number =employeeNumbe
            --限制现有量属于BJE下
            join (select its.seq_id from t_sys_erp_items its join t_sys_erp_organizations org on org.organization_id=its.organization_id and org.organization_code='BJE' and its.status = 1) itss on itss.seq_id=a.item_id
            left join T_SYS_ERP_LOCATORS l on a.LOCATOR_ID=l.LOCATOR_ID and  l.ERP_TYPE=erpType
            left join T_SYS_SPM_PRODUCTS b on a.product_id=b.seq_id
            left join (select qll.quota_quantity-nvl(mk.asgn_quty,0) ql_quota_quantity,qll.onhand_id,qll.id from
            t_lis_recipient_quota_locking  qll left join t_out_notmk mk on qll.id=mk.quota_locking_id
            ) ql on ql.onhand_id=a.id
            left join (select e.onhand_id,sum(nvl(e.RESERVE_QUANTITY,0)) as RESERVE_QUANTITY
            from T_SYS_ITEM_RESEREVE_INFO e where sysdate < e.reserve_end_day and e.status = 1
            group by e.onhand_id) f on a.id=f.onhand_id
            left join T_WAREHOUSE_DEFINE w on a.warehouse_define_id=w.id and w.is_storage like 'Y' and w.MIS_OU_ID =ouId and w.mis_io_code = 'BJE'
            where a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0)>0
            and a.item_id= itemid
            and a.id not in (select distinct tql.onhand_id from t_lis_recipient_quota_locking tql)
            and a.ERP_TYPE=erpType  and a.status=1
            and w.CATEGORY_ID=(select twc.id from T_WAREHOUSE_CATEGORY twc where twc.CODE like '01')
            and ( l.LOCATOR_CODE like '%'||project_code||'%' or l.locator_code not like '%|%' or l.locator_code is null )
            and a.item_package_id is null --非物料包
            order by a.created_date;
          end if;
          loop
          fetch c_onhand_info into v_onhand_info;
          exit when quantity=0;
          exit when c_onhand_info%notfound;
          dbms_output.put_line(v_onhand_info.onhand_id||'==='||v_onhand_info.onhand_item_code);
          assign_line_id :=LIS_ORDER_SEQ.Nextval;
          if v_onhand_info.onhand_quantity >= quantity then
            insert into t_out_notmk(id,created_date,created_user,last_updated_date,last_updated_user,
            status,version,asgn_ln_status,asgn_quty,asgn_time,item_code,item_id,mis_pic_code,ord_ln_id,outlninfo_id,
            out_ord_id,rcp_pic_code,warehouseid,reserve_days,if_reserve,warehouse_onhand_id,vendor_id,
            source_warehouse_id,locator_id,locator_code,product_unit_price,product_unit_price_ex_tax,
            quota_locking_id)
            values(assign_line_id,systimestamp,ouEmployeeNumbe,systimestamp,ouEmployeeNumbe,
            1,0,4,quantity,systimestamp,v_onhand_info.onhand_item_code,v_onhand_info.onhand_item_id,
            v_onhand_info.mis_pic_code,lineid,lineid,headerId,v_onhand_info.rec_pic_code,v_onhand_info.warehouse_id,
            3,1,v_onhand_info.onhand_id,v_onhand_info.vendor_id,v_onhand_info.warehouse_id,v_onhand_info.locator_id
            ,v_onhand_info.locator_code,v_onhand_info.product_unit_price,v_onhand_info.product_unit_price_ex_tax,
            v_onhand_info.quota_locking_id);
            insert into t_sys_item_resereve_info(reserveid,status,version,reserve_end_day,material_onhand_id,
            order_line_id,reserve_quantity,reserve_start_day,order_type,onhand_id)
            values(S_OUT_RESERVE_INF.Nextval,1,0,sysdate+3,v_onhand_info.onhand_id,assign_line_id,
            quantity,sysdate,'CK',v_onhand_info.onhand_id);
            quantity :=0;
            elsif v_onhand_info.onhand_quantity<quantity then
            insert into t_out_notmk(id,created_date,created_user,last_updated_date,last_updated_user,
            status,version,asgn_ln_status,asgn_quty,asgn_time,item_code,item_id,mis_pic_code,ord_ln_id,outlninfo_id,
            out_ord_id,rcp_pic_code,warehouseid,reserve_days,if_reserve,warehouse_onhand_id,vendor_id,
            source_warehouse_id,locator_id,locator_code,product_unit_price,product_unit_price_ex_tax,
            quota_locking_id)
            values(assign_line_id,systimestamp,ouEmployeeNumbe,systimestamp,ouEmployeeNumbe,
            1,0,4,v_onhand_info.onhand_quantity,systimestamp,v_onhand_info.onhand_item_code,v_onhand_info.onhand_item_id,
            v_onhand_info.mis_pic_code,lineid,lineid,headerId,v_onhand_info.rec_pic_code,v_onhand_info.warehouse_id,
            3,1,v_onhand_info.onhand_id,v_onhand_info.vendor_id,v_onhand_info.warehouse_id,v_onhand_info.locator_id
            ,v_onhand_info.locator_code,v_onhand_info.product_unit_price,v_onhand_info.product_unit_price_ex_tax,
            v_onhand_info.quota_locking_id);
            insert into t_sys_item_resereve_info(reserveid,status,version,reserve_end_day,material_onhand_id,
            order_line_id,reserve_quantity,reserve_start_day,order_type,onhand_id)
            values(S_OUT_RESERVE_INF.Nextval,1,0,sysdate+3,v_onhand_info.onhand_id,assign_line_id,
            v_onhand_info.onhand_quantity,sysdate,'CK',v_onhand_info.onhand_id);
            quantity := quantity - v_onhand_info.onhand_quantity;
          end if;
          end loop;
          close  c_onhand_info;
        end if;
      end if;
    end if;
    if(1 = item_scope) then 
      --物料组
      temp_quantity := quantity;
      --组内物料
      open c_item_scope_info for 
      select distinct l.ITEM_ID,l.item_code, l.CONVERT_RATIO
        from T_LIS_ITEMGROUP_HEAD h left join T_LIS_ITEMGROUP_LINE l on h.id=l.ITEM_GROUP_HEADID and l.status=1
        where h.status=1 and h.id=itemid
        order by l.CONVERT_RATIO;
      itemGroupId := 0;
      itemGroupCode := '';
      convertRatio := 0;
      Asn := 0;
      temp_qty:=0;
      loop
        fetch c_item_scope_info into itemGroupId,itemGroupCode,convertRatio;
        exit when quantity=0;
        exit when c_item_scope_info%notfound;
        if(convertRatio is null or convertRatio < 0) then 
          msg := '物料组:' || itemCode || '中含有无效的配比.';
          raise E_ITEM_GROUP_EXCEPTION;
        end if;
        --本次循环组内物料需要分配的数量
        
        temp_qty:=quantity*convertRatio;
        --现有量
        select sum(a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0)) into v_total_onhand_quantity
        from t_wh_current_onhand_quantity a join  (select distinct ac.employ_number,ac.warehouse_define_id from t_warehouse_access_user ac) d on
        a.warehouse_define_id = d.warehouse_define_id and  d.employ_number =employeeNumbe
        join (select its.seq_id from t_sys_erp_items its join t_sys_erp_organizations org on org.organization_id=its.organization_id and org.organization_code='BJE' and its.status = 1) itss on itss.seq_id=a.item_id
        left join T_SYS_ERP_LOCATORS l on a.LOCATOR_ID=l.LOCATOR_ID and  l.ERP_TYPE=erpType
        left join T_SYS_SPM_PRODUCTS b on a.product_id=b.seq_id
        left join (select qll.quota_quantity-nvl(mk.asgn_quty,0) ql_quota_quantity,qll.onhand_id,qll.id from
        t_lis_recipient_quota_locking  qll left join t_out_notmk mk on qll.id=mk.quota_locking_id
        ) ql on ql.onhand_id=a.id
        left join (select e.onhand_id,sum(nvl(e.RESERVE_QUANTITY,0)) as RESERVE_QUANTITY
        from T_SYS_ITEM_RESEREVE_INFO e where sysdate < e.reserve_end_day and e.status = 1
        group by e.onhand_id) f on a.id=f.onhand_id
        left join T_WAREHOUSE_DEFINE w on a.warehouse_define_id=w.id and w.is_storage like 'Y' and w.MIS_OU_ID =ouId and w.mis_io_code = 'BJE'
        where a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0)>0
        and a.item_id= itemGroupId
        and a.id not in (select distinct tql.onhand_id from t_lis_recipient_quota_locking tql)
        and a.ERP_TYPE=erpType  and a.status=1
        and w.CATEGORY_ID=(select twc.id from T_WAREHOUSE_CATEGORY twc where twc.CODE like '01')
        and ( l.LOCATOR_CODE like '%'||project_code||'%' or l.locator_code not like '%|%' or l.locator_code is null )
        and a.item_package_id is null --非物料包
        order by a.created_date;
        --如果现有量大于组内物料*配比的数量，本次可完全分配
        if(v_total_onhand_quantity > 0) then
          open c_onhand_info for  select a.id ,a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0) ,
          ql.ql_quota_quantity,a.warehouse_define_id,a.item_id,a.item_code,a.mis_pic_code,
          a.receipt_pic_code,a.vendor_id,a.locator_id,a.locator_code,a.product_unit_price,
          a.product_unit_price_ex_tax,ql.id
          from t_wh_current_onhand_quantity a join  (select distinct ac.employ_number,ac.warehouse_define_id from t_warehouse_access_user ac) d on
          a.warehouse_define_id = d.warehouse_define_id and  d.employ_number =employeeNumbe
          join (select its.seq_id from t_sys_erp_items its join t_sys_erp_organizations org on org.organization_id=its.organization_id and org.organization_code='BJE' and its.status = 1) itss on itss.seq_id=a.item_id
          left join T_SYS_ERP_LOCATORS l on a.LOCATOR_ID=l.LOCATOR_ID and  l.ERP_TYPE=erpType
          left join T_SYS_SPM_PRODUCTS b on a.product_id=b.seq_id
          left join (select qll.quota_quantity-nvl(mk.asgn_quty,0) ql_quota_quantity,qll.onhand_id,qll.id from
          t_lis_recipient_quota_locking  qll left join t_out_notmk mk on qll.id=mk.quota_locking_id
          ) ql on ql.onhand_id=a.id
          left join (select e.onhand_id,sum(nvl(e.RESERVE_QUANTITY,0)) as RESERVE_QUANTITY
          from T_SYS_ITEM_RESEREVE_INFO e where sysdate < e.reserve_end_day and e.status = 1
          group by e.onhand_id) f on a.id=f.onhand_id
          left join T_WAREHOUSE_DEFINE w on a.warehouse_define_id=w.id and w.is_storage like 'Y' and w.MIS_OU_ID =ouId and w.mis_io_code = 'BJE'
          where a.onhand_quantity-nvl(f.RESERVE_QUANTITY,0)>0
          and a.item_id= itemGroupId
          and a.id not in (select distinct tql.onhand_id from t_lis_recipient_quota_locking tql)
          and a.ERP_TYPE=erpType  and a.status=1
          and w.CATEGORY_ID=(select twc.id from T_WAREHOUSE_CATEGORY twc where twc.CODE like '01')
          and ( l.LOCATOR_CODE like '%'||project_code||'%' or l.locator_code not like '%|%' or l.locator_code is null )
          and a.item_package_id is null --非物料包
          order by a.created_date;
          if(v_total_onhand_quantity >= temp_qty) then
            Asn := floor(temp_qty/convertRatio) * convertRatio;
            quantity  := quantity - floor(temp_qty/convertRatio);
          elsif(v_total_onhand_quantity < temp_qty) then
            Asn := floor(v_total_onhand_quantity/convertRatio) * convertRatio;
            quantity  := quantity - floor(v_total_onhand_quantity/convertRatio);
          end if;
          --插入分配行
          if(Asn > 0) then
            loop
              fetch c_onhand_info into v_onhand_info;
              exit when Asn=0;
              exit when c_onhand_info%notfound;
              assign_line_id :=LIS_ORDER_SEQ.Nextval;
              if v_onhand_info.onhand_quantity >= Asn then
                insert into t_out_notmk(id,created_date,created_user,last_updated_date,last_updated_user,
                status,version,asgn_ln_status,asgn_quty,asgn_time,item_code,item_id,mis_pic_code,ord_ln_id,outlninfo_id,
                out_ord_id,rcp_pic_code,warehouseid,reserve_days,if_reserve,warehouse_onhand_id,vendor_id,
                source_warehouse_id,locator_id,locator_code,product_unit_price,product_unit_price_ex_tax,
                quota_locking_id)
                values(assign_line_id,systimestamp,ouEmployeeNumbe,systimestamp,ouEmployeeNumbe,
                1,0,4,Asn,systimestamp,v_onhand_info.onhand_item_code,v_onhand_info.onhand_item_id,
                v_onhand_info.mis_pic_code,lineid,lineid,headerId,v_onhand_info.rec_pic_code,v_onhand_info.warehouse_id,
                3,1,v_onhand_info.onhand_id,v_onhand_info.vendor_id,v_onhand_info.warehouse_id,v_onhand_info.locator_id
                ,v_onhand_info.locator_code,v_onhand_info.product_unit_price,v_onhand_info.product_unit_price_ex_tax,
                v_onhand_info.quota_locking_id);
                insert into t_sys_item_resereve_info(reserveid,status,version,reserve_end_day,material_onhand_id,
                order_line_id,reserve_quantity,reserve_start_day,order_type,onhand_id)
                values(S_OUT_RESERVE_INF.Nextval,1,0,sysdate+3,v_onhand_info.onhand_id,assign_line_id,
                Asn,sysdate,'CK',v_onhand_info.onhand_id);
                Asn :=0;
              elsif(v_onhand_info.onhand_quantity < Asn) then 
                insert into t_out_notmk(id,created_date,created_user,last_updated_date,last_updated_user,
                status,version,asgn_ln_status,asgn_quty,asgn_time,item_code,item_id,mis_pic_code,ord_ln_id,outlninfo_id,
                out_ord_id,rcp_pic_code,warehouseid,reserve_days,if_reserve,warehouse_onhand_id,vendor_id,
                source_warehouse_id,locator_id,locator_code,product_unit_price,product_unit_price_ex_tax,
                quota_locking_id)
                values(assign_line_id,systimestamp,ouEmployeeNumbe,systimestamp,ouEmployeeNumbe,
                1,0,4,v_onhand_info.onhand_quantity,systimestamp,v_onhand_info.onhand_item_code,v_onhand_info.onhand_item_id,
                v_onhand_info.mis_pic_code,lineid,lineid,headerId,v_onhand_info.rec_pic_code,v_onhand_info.warehouse_id,
                3,1,v_onhand_info.onhand_id,v_onhand_info.vendor_id,v_onhand_info.warehouse_id,v_onhand_info.locator_id
                ,v_onhand_info.locator_code,v_onhand_info.product_unit_price,v_onhand_info.product_unit_price_ex_tax,
                v_onhand_info.quota_locking_id);
                insert into t_sys_item_resereve_info(reserveid,status,version,reserve_end_day,material_onhand_id,
                order_line_id,reserve_quantity,reserve_start_day,order_type,onhand_id)
                values(S_OUT_RESERVE_INF.Nextval,1,0,sysdate+3,v_onhand_info.onhand_id,assign_line_id,
                v_onhand_info.onhand_quantity,sysdate,'CK',v_onhand_info.onhand_id);
                Asn := Asn - v_onhand_info.onhand_quantity;
              end if;
            end loop;
            close c_onhand_info;
          end if;
        end if;
      end loop;
      close c_item_scope_info;
    end if;
    if quantity=0 then
     --如果不存在物料包,则记录,物料包内的行是否取消在后续java代码控制
      if(itemPackageId=0) then
        if(item_scope is null or 0 = item_scope) then 
          resultInfo :=resultInfo|| '<p>物料:'||itemCode||'申请数量:'||temp_quantity||'全部分配</p>';
        elsif(1 = item_scope) then 
          resultInfo :=resultInfo|| '<p>物料组:'||itemCode||'申请数量:'||temp_quantity||'全部分配</p>';
        end if;
      end if;
      update t_out_ln ln set ln.last_updated_date=sysdate,ln.last_updated_user=ouEmployeeNumbe,ln.asgn_quty=temp_quantity,ln.tol_asgn_quty=nvl(ln.tol_asgn_quty,0)+temp_quantity,ord_ln_status=1 where ln.id=lineid;
    elsif quantity <= temp_quantity then
      --如果不存在物料包,则记录,物料包内的行是否取消在后续java代码控制
      if(itemPackageId=0) then
        if(item_scope is null or 0 = item_scope) then 
          resultInfo :=resultInfo|| '<p>物料:'||itemCode||'申请数量:'||temp_quantity||'没有可分配的现有量或没有足够的现有量</p>';
        elsif(1 = item_scope) then 
          msg := msg || '<p>物料组:'||itemCode||'申请数量:'||temp_quantity||'没有可分配的现有量或没有足够的现有量</p>';
          raise E_ITEM_GROUP_EXCEPTION;
        end if;
      end if;       
    end if ; 
  end loop;
  close c_out_line_info;
exception
  when E_EXECUTING_EXCEPTION  then
    flag := -1;
    resultInfo :='该出库申请正在进行自动分配,请重试!';
  when E_ITEM_GROUP_EXCEPTION  then
    rollback;
    flag := -1;
    resultInfo := msg;
  when others then
    rollback;
    flag := -1;
    resultInfo :='executing procedure proc_out_auto_assign error';
end;
/

