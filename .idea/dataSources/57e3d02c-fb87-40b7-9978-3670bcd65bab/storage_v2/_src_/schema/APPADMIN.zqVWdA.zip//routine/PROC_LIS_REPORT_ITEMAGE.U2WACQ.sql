create PROCEDURE proc_lis_report_itemage
AS
  exception_info VARCHAR2(3000);
BEGIN
  DELETE FROM t_lis_report_core_ageinfo;
  /**先删除库龄信息后重新计算**/
  COMMIT;
  INSERT
  INTO t_lis_report_core_ageinfo
    (
      create_date,
      bussiness_date,
      string_value1,
      status,
      version,
      item_code,
      item_desc,
      item_id,
      item_uom_code,
      item_uom_desc,
      item_category_code,
      item_category_name,
      warehouse_define_id,
      warehouse_define_code,
      warehouse_define_desc,
      ou_id,
      ou_name,
      organization_code,
      organization_name,
      organization_id,
      receipt_pic_code,
      item_receive_date,
      product_unit_price,
      item_count,
      item_account,
      isover,
      item_age,
      age_7to9,
      age_10to12,
      age_13to18,
      age_19to24,
      age_25more,
      mis_pic_code,
      vendor_id,
      locator_code,
      locator_id,
      project_id,
      project_name,
      project_number,
      vendor_name
    )
  SELECT create_date,
    bussiness_date,
    string_value1,
    status,
    version,
    item_code,
    item_name,
    item_id,
    uom_code,
    uom_desc,
    concatenated_segments,
    category_description,
    warehouse_define_id,
    warehouse_define_code,
    warehouse_define_name,
    mis_ou_id,
    mis_ou_name,
    mis_io_code,
    mis_io_name,
    mis_io_id,
    receipt_pic_code,
    to_date(initdate,'yyyy-MM-dd') receivedate,
    NVL(product_unit_price,0) product_unit_price,
    onhand_quantity,
    onhand_account,
    isover,
    itemage,
    age_7to9,
    age_10to12,
    age_13to18,
    age_19to24,
    age_25more,
    mis_pic_code,
    vendor_id,
    locator_code,
    locator_id,
    project_id,
    project_name,
    project_number,
    vendor_name
  FROM v_lis_report_ageinfo;
  COMMIT;
  --插入日志
  INSERT
  INTO i_erp_logs VALUES
    (
      i_erp_logs_seq.nextval,
      0,
      0,
      sysdate,
      '每天定时计算库龄信息成功',
      'proc_lis_report_itemage'
    );
EXCEPTION
WHEN OTHERS THEN
  exception_info := 'ERR: An error occurred with info:'||TO_CHAR(SQLCODE)||' '||sqlerrm;
  INSERT
  INTO i_erp_logs VALUES
    (
      i_erp_logs_seq.nextval,
      0,0,
      sysdate,
      exception_info,
      'proc_lis_report_itemage'
    );
  COMMIT;
END proc_lis_report_itemage;
/

