create view V_LIS_REPORT_VENDOR_ISOVER as
  SELECT
    /**以供应商物料及单位为维度的呆滞物资的库存金额及呆滞金额视图*/
    rca.ou_id,
    rca.organization_id,
    rca.warehouse_define_id,
    (rca.organization_code
    || ' '
    || rca.organization_name) orginfo,
    (rca.warehouse_define_code
    || ' '
    || rca.warehouse_define_desc) warehouseinfo,
    rca.vendor_id,
    rca.item_category_code,
    rca.item_category_name,
    rca.item_id,
    rca.item_code,
    rca.item_desc,
    rca.item_uom_code,
    rca.item_uom_desc,
    SUM(rio.item_quantity) item_quantity,
    SUM(NVL(rio.item_account,0)) item_account,
    SUM(NVL(rca.item_account,0)) over_item_account
  FROM t_lis_report_core_ageinfo rca
  LEFT JOIN v_lis_report_qty_vendor_now rio
  ON rca.ou_id               =rio.mis_ou_id
  AND rca.organization_id    =rio.mis_io_id
  AND rca.warehouse_define_id=rio.warehouse_define_id
  AND rca.item_id            =rio.item_id
  AND rca.item_code          =rio.item_code
  AND rca.item_desc          =rio.item_desc
  AND rca.item_uom_code      =rio.uom_code
  AND rca.item_uom_desc      =rio.uom_desc
  AND rca.vendor_id          =rio.vednor_id
  AND rca.vendor_name        =rio.vendor_name
  WHERE rca.isover           =1
  AND rca.vendor_id         IS NOT NULL
  GROUP BY rca.ou_id,
    rca.organization_id,
    rca.organization_code,
    rca.organization_name,
    rca.warehouse_define_id,
    rca.vendor_id,
    rca.warehouse_define_code,
    rca.warehouse_define_desc,
    rca.item_category_code,
    rca.item_category_name,
    rca.item_id,
    rca.item_code,
    rca.item_desc,
    rca.item_uom_code,
    rca.item_uom_desc
/

