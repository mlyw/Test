create procedure proc_product_testing_task(startTimestamp timestamp,endTimestamp timestamp) as
count_success number(19);
total_value number(19);    -- 将产品任务检测信息导入到LIS业务表  wjr
count_value number(19);
exception_info varchar2(3000);
cursor csr_i_prod_testing_task is
select product_testing_task_id,product_testing_task_desc,product_testing_task_line_id,product_testing_quantity,uom_code,uom_desc,spm_po_header_id,spm_po_number,spm_po_line_id,spm_po_distribution_id,mis_po_header_id,mis_po_number,mis_po_line_id,mis_po_distribution_id,product_testing_result_line_id,testing_result_flag,testing_task_import_date,testing_result_import_date,long_attribute,string_attribute,datetime_attribute,double_attribute from i_spm_product_testing_task
where create_time >= startTimestamp and create_time <= endTimestamp order by seq_id desc;
i_prod_testing_task csr_i_prod_testing_task%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_spm_product_testing_task where create_time >= startTimestamp and create_time <= endTimestamp;
  open csr_i_prod_testing_task;
  fetch csr_i_prod_testing_task into i_prod_testing_task;
  while(csr_i_prod_testing_task%found) loop
      -- 如果spm_po_line_id is null product_testing_result_line_id is not null
      if(i_prod_testing_task.spm_po_line_id is null and i_prod_testing_task.product_testing_result_line_id is not null) then
          select count(*) into count_value from t_sys_spm_product_testing_task where product_testing_task_id = i_prod_testing_task.product_testing_task_id and product_testing_task_line_id = i_prod_testing_task.product_testing_task_line_id
          and product_testing_result_line_id =  i_prod_testing_task.product_testing_result_line_id and spm_po_line_id is null;
          if(count_value = 1) then
          update t_sys_spm_product_testing_task
            set last_updated_date = sysdate,
                product_testing_task_id = i_prod_testing_task.product_testing_task_id,
                product_testing_task_desc = i_prod_testing_task.product_testing_task_desc,
                product_testing_task_line_id = i_prod_testing_task.product_testing_task_line_id,
                product_testing_quantity = i_prod_testing_task.product_testing_quantity,
                uom_code = i_prod_testing_task.uom_code,
                uom_desc = i_prod_testing_task.uom_desc,
                spm_po_header_id = i_prod_testing_task.spm_po_header_id,
                spm_po_number = i_prod_testing_task.spm_po_number,
                spm_po_line_id = i_prod_testing_task.spm_po_line_id,
                spm_po_distribution_id = i_prod_testing_task.spm_po_distribution_id,
                mis_po_header_id = i_prod_testing_task.mis_po_header_id,
                mis_po_number = i_prod_testing_task.mis_po_number,
                mis_po_line_id = i_prod_testing_task.mis_po_line_id,
                mis_po_distribution_id = i_prod_testing_task.mis_po_distribution_id,
                product_testing_result_line_id = i_prod_testing_task.product_testing_result_line_id,
                testing_result_flag = i_prod_testing_task.testing_result_flag,
                testing_task_import_date = i_prod_testing_task.testing_task_import_date,
                testing_result_import_date = i_prod_testing_task.testing_result_import_date
            where product_testing_task_id = i_prod_testing_task.product_testing_task_id and product_testing_task_line_id = i_prod_testing_task.product_testing_task_line_id
            and product_testing_result_line_id =  i_prod_testing_task.product_testing_result_line_id and spm_po_line_id is null;
          else
            insert into t_sys_spm_product_testing_task
              (seq_id,product_testing_task_id,product_testing_task_desc,product_testing_task_line_id,product_testing_quantity,uom_code,uom_desc,spm_po_header_id,spm_po_number,spm_po_line_id,spm_po_distribution_id,mis_po_header_id,mis_po_number,mis_po_line_id,mis_po_distribution_id,product_testing_result_line_id,testing_result_flag,testing_task_import_date,testing_result_import_date,created_date,last_updated_date,status,version)
            values
              (SEQ_SPM_PRODUCT_TESTING_TASK.Nextval,i_prod_testing_task.product_testing_task_id,i_prod_testing_task.product_testing_task_desc,i_prod_testing_task.product_testing_task_line_id,i_prod_testing_task.product_testing_quantity,i_prod_testing_task.uom_code,i_prod_testing_task.uom_desc,i_prod_testing_task.spm_po_header_id,i_prod_testing_task.spm_po_number,i_prod_testing_task.spm_po_line_id,i_prod_testing_task.spm_po_distribution_id,i_prod_testing_task.mis_po_header_id,i_prod_testing_task.mis_po_number,i_prod_testing_task.mis_po_line_id,i_prod_testing_task.mis_po_distribution_id,i_prod_testing_task.product_testing_result_line_id,i_prod_testing_task.testing_result_flag,i_prod_testing_task.testing_task_import_date,i_prod_testing_task.testing_result_import_date,sysdate,sysdate,1,0);
          end if;
      elsif(i_prod_testing_task.spm_po_line_id is null and i_prod_testing_task.product_testing_result_line_id is null) then
          select count(*) into count_value from t_sys_spm_product_testing_task where product_testing_task_id = i_prod_testing_task.product_testing_task_id and product_testing_task_line_id = i_prod_testing_task.product_testing_task_line_id and
          product_testing_result_line_id is null and spm_po_line_id is null;
          if(count_value = 1) then
          update t_sys_spm_product_testing_task
            set last_updated_date = sysdate,
                product_testing_task_id = i_prod_testing_task.product_testing_task_id,
                product_testing_task_desc = i_prod_testing_task.product_testing_task_desc,
                product_testing_task_line_id = i_prod_testing_task.product_testing_task_line_id,
                product_testing_quantity = i_prod_testing_task.product_testing_quantity,
                uom_code = i_prod_testing_task.uom_code,
                uom_desc = i_prod_testing_task.uom_desc,
                spm_po_header_id = i_prod_testing_task.spm_po_header_id,
                spm_po_number = i_prod_testing_task.spm_po_number,
                spm_po_line_id = i_prod_testing_task.spm_po_line_id,
                spm_po_distribution_id = i_prod_testing_task.spm_po_distribution_id,
                mis_po_header_id = i_prod_testing_task.mis_po_header_id,
                mis_po_number = i_prod_testing_task.mis_po_number,
                mis_po_line_id = i_prod_testing_task.mis_po_line_id,
                mis_po_distribution_id = i_prod_testing_task.mis_po_distribution_id,
                product_testing_result_line_id = i_prod_testing_task.product_testing_result_line_id,
                testing_result_flag = i_prod_testing_task.testing_result_flag,
                testing_task_import_date = i_prod_testing_task.testing_task_import_date,
                testing_result_import_date = i_prod_testing_task.testing_result_import_date
            where product_testing_task_id = i_prod_testing_task.product_testing_task_id
            and product_testing_task_line_id = i_prod_testing_task.product_testing_task_line_id and product_testing_result_line_id is null and spm_po_line_id is null;
          else
            insert into t_sys_spm_product_testing_task
              (seq_id,product_testing_task_id,product_testing_task_desc,product_testing_task_line_id,product_testing_quantity,uom_code,uom_desc,spm_po_header_id,spm_po_number,spm_po_line_id,spm_po_distribution_id,mis_po_header_id,mis_po_number,mis_po_line_id,mis_po_distribution_id,product_testing_result_line_id,testing_result_flag,testing_task_import_date,testing_result_import_date,created_date,last_updated_date,status,version)
            values
              (SEQ_SPM_PRODUCT_TESTING_TASK.Nextval,i_prod_testing_task.product_testing_task_id,i_prod_testing_task.product_testing_task_desc,i_prod_testing_task.product_testing_task_line_id,i_prod_testing_task.product_testing_quantity,i_prod_testing_task.uom_code,i_prod_testing_task.uom_desc,i_prod_testing_task.spm_po_header_id,i_prod_testing_task.spm_po_number,i_prod_testing_task.spm_po_line_id,i_prod_testing_task.spm_po_distribution_id,i_prod_testing_task.mis_po_header_id,i_prod_testing_task.mis_po_number,i_prod_testing_task.mis_po_line_id,i_prod_testing_task.mis_po_distribution_id,i_prod_testing_task.product_testing_result_line_id,i_prod_testing_task.testing_result_flag,i_prod_testing_task.testing_task_import_date,i_prod_testing_task.testing_result_import_date,sysdate,sysdate,1,0);
          end if;
      elsif(i_prod_testing_task.spm_po_line_id is not null and i_prod_testing_task.product_testing_result_line_id is null) then
          select count(*) into count_value from t_sys_spm_product_testing_task
          where product_testing_task_id = i_prod_testing_task.product_testing_task_id and spm_po_line_id = i_prod_testing_task.spm_po_line_id
          and product_testing_task_line_id = i_prod_testing_task.product_testing_task_line_id and product_testing_result_line_id is null;
          if(count_value = 1) then
             update t_sys_spm_product_testing_task
                set last_updated_date = sysdate,
                    product_testing_task_id = i_prod_testing_task.product_testing_task_id,
                    product_testing_task_desc = i_prod_testing_task.product_testing_task_desc,
                    product_testing_task_line_id = i_prod_testing_task.product_testing_task_line_id,
                    product_testing_quantity = i_prod_testing_task.product_testing_quantity,
                    uom_code = i_prod_testing_task.uom_code,
                    uom_desc = i_prod_testing_task.uom_desc,
                    spm_po_header_id = i_prod_testing_task.spm_po_header_id,
                    spm_po_number = i_prod_testing_task.spm_po_number,
                    spm_po_line_id = i_prod_testing_task.spm_po_line_id,
                    spm_po_distribution_id = i_prod_testing_task.spm_po_distribution_id,
                    mis_po_header_id = i_prod_testing_task.mis_po_header_id,
                    mis_po_number = i_prod_testing_task.mis_po_number,
                    mis_po_line_id = i_prod_testing_task.mis_po_line_id,
                    mis_po_distribution_id = i_prod_testing_task.mis_po_distribution_id,
                    product_testing_result_line_id = i_prod_testing_task.product_testing_result_line_id,
                    testing_result_flag = i_prod_testing_task.testing_result_flag,
                    testing_task_import_date = i_prod_testing_task.testing_task_import_date,
                    testing_result_import_date = i_prod_testing_task.testing_result_import_date
                where product_testing_task_id = i_prod_testing_task.product_testing_task_id and spm_po_line_id = i_prod_testing_task.spm_po_line_id
                and product_testing_task_line_id = i_prod_testing_task.product_testing_task_line_id and product_testing_result_line_id is null;
           else
              insert into t_sys_spm_product_testing_task
                  (seq_id,product_testing_task_id,product_testing_task_desc,product_testing_task_line_id,product_testing_quantity,uom_code,uom_desc,spm_po_header_id,spm_po_number,spm_po_line_id,spm_po_distribution_id,mis_po_header_id,mis_po_number,mis_po_line_id,mis_po_distribution_id,product_testing_result_line_id,testing_result_flag,testing_task_import_date,testing_result_import_date,created_date,last_updated_date,status,version)
              values
                  (SEQ_SPM_PRODUCT_TESTING_TASK.Nextval,i_prod_testing_task.product_testing_task_id,i_prod_testing_task.product_testing_task_desc,i_prod_testing_task.product_testing_task_line_id,i_prod_testing_task.product_testing_quantity,i_prod_testing_task.uom_code,i_prod_testing_task.uom_desc,i_prod_testing_task.spm_po_header_id,i_prod_testing_task.spm_po_number,i_prod_testing_task.spm_po_line_id,i_prod_testing_task.spm_po_distribution_id,i_prod_testing_task.mis_po_header_id,i_prod_testing_task.mis_po_number,i_prod_testing_task.mis_po_line_id,i_prod_testing_task.mis_po_distribution_id,i_prod_testing_task.product_testing_result_line_id,i_prod_testing_task.testing_result_flag,i_prod_testing_task.testing_task_import_date,i_prod_testing_task.testing_result_import_date,sysdate,sysdate,1,0);
           end if;
      else
          select count(*) into count_value from t_sys_spm_product_testing_task
          where product_testing_task_id = i_prod_testing_task.product_testing_task_id and spm_po_line_id = i_prod_testing_task.spm_po_line_id and product_testing_task_line_id = i_prod_testing_task.product_testing_task_line_id and product_testing_result_line_id =  i_prod_testing_task.product_testing_result_line_id;
          if(count_value = 1) then
             update t_sys_spm_product_testing_task
                set last_updated_date = sysdate,
                    product_testing_task_id = i_prod_testing_task.product_testing_task_id,
                    product_testing_task_desc = i_prod_testing_task.product_testing_task_desc,
                    product_testing_task_line_id = i_prod_testing_task.product_testing_task_line_id,
                    product_testing_quantity = i_prod_testing_task.product_testing_quantity,
                    uom_code = i_prod_testing_task.uom_code,
                    uom_desc = i_prod_testing_task.uom_desc,
                    spm_po_header_id = i_prod_testing_task.spm_po_header_id,
                    spm_po_number = i_prod_testing_task.spm_po_number,
                    spm_po_line_id = i_prod_testing_task.spm_po_line_id,
                    spm_po_distribution_id = i_prod_testing_task.spm_po_distribution_id,
                    mis_po_header_id = i_prod_testing_task.mis_po_header_id,
                    mis_po_number = i_prod_testing_task.mis_po_number,
                    mis_po_line_id = i_prod_testing_task.mis_po_line_id,
                    mis_po_distribution_id = i_prod_testing_task.mis_po_distribution_id,
                    product_testing_result_line_id = i_prod_testing_task.product_testing_result_line_id,
                    testing_result_flag = i_prod_testing_task.testing_result_flag,
                    testing_task_import_date = i_prod_testing_task.testing_task_import_date,
                    testing_result_import_date = i_prod_testing_task.testing_result_import_date
                where product_testing_task_id = i_prod_testing_task.product_testing_task_id and spm_po_line_id = i_prod_testing_task.spm_po_line_id and product_testing_task_line_id = i_prod_testing_task.product_testing_task_line_id and product_testing_result_line_id =  i_prod_testing_task.product_testing_result_line_id;
           else
              insert into t_sys_spm_product_testing_task
                  (seq_id,product_testing_task_id,product_testing_task_desc,product_testing_task_line_id,product_testing_quantity,uom_code,uom_desc,spm_po_header_id,spm_po_number,spm_po_line_id,spm_po_distribution_id,mis_po_header_id,mis_po_number,mis_po_line_id,mis_po_distribution_id,product_testing_result_line_id,testing_result_flag,testing_task_import_date,testing_result_import_date,created_date,last_updated_date,status,version)
              values
                  (SEQ_SPM_PRODUCT_TESTING_TASK.Nextval,i_prod_testing_task.product_testing_task_id,i_prod_testing_task.product_testing_task_desc,i_prod_testing_task.product_testing_task_line_id,i_prod_testing_task.product_testing_quantity,i_prod_testing_task.uom_code,i_prod_testing_task.uom_desc,i_prod_testing_task.spm_po_header_id,i_prod_testing_task.spm_po_number,i_prod_testing_task.spm_po_line_id,i_prod_testing_task.spm_po_distribution_id,i_prod_testing_task.mis_po_header_id,i_prod_testing_task.mis_po_number,i_prod_testing_task.mis_po_line_id,i_prod_testing_task.mis_po_distribution_id,i_prod_testing_task.product_testing_result_line_id,i_prod_testing_task.testing_result_flag,i_prod_testing_task.testing_task_import_date,i_prod_testing_task.testing_result_import_date,sysdate,sysdate,1,0);
           end if;
      end if;
   fetch csr_i_prod_testing_task into i_prod_testing_task;
   count_success := count_success+1;
   end loop;
   insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','t_sys_spm_product_testing_task');
   exception when others then
    exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
   insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_spm_product_testing_task');
  close csr_i_prod_testing_task;
COMMIT;
end;
/

