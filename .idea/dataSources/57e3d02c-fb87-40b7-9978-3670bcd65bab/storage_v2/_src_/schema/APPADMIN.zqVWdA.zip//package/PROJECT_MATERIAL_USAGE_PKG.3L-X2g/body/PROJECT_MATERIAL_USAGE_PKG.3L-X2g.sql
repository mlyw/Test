create package body project_material_usage_pkg is
 procedure proc_project_material_usage(projectCode in varchar2, projectName in varchar2,
             itemCode in varchar2, itemName varchar2, spmPoCode in varchar2, createdName in varchar2,
             createdDept in varchar2, beginDate in varchar2, endDate in varchar2, transactionType in varchar2,
             pagenum in number, pagesize in number, ouId in long, ouCode in varchar2,
             total out number, project_material out cur_project_material)
as
begin
  delete from temp_project_material_usage;
--直发
      insert into temp_project_material_usage(project_material_usage_id,
             project_code, project_name, task_code, task_name, receipt_place, receipt_user,
             authorize_card, epm_task_code, epm_task_name, item_code, item_name,
             uom_code, trf_out_cfm_quty, created_user, created_dept, created_dept_id, operator,
             transaction_type, spm_po_code, order_desc, created_date, acc_cfm_imptomis_date)
          select
            t_project_material_usage.nextval,
            p.project_code as project_code,
            p.project_name as project_name,
            t.task_code as task_code,
            t.task_name as task_name,
            d.warehouse_define_code||' '||d.warehouse_define_name as receiptPlace,
            '' as receiptUser,
            '' as authorizeCard,--授权卡号（暂无）
            l.epm_task_code as epm_task_code,
            l.epm_task_name as epm_task_name,
            l.item_code as item_code,
            l.item_desc as item_desc,
            l.uom_desc as uom_desc,
            l.current_receive_quantity as current_receive_quantity,
            u.employee_name as created_user,
            dept.dept_name as created_dept,
            dept.id as dept_id,
            (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=l.accounting_confirm_by_uid) as operator,
            case h.is_straight when 1 then '直发' end as is_straight,
            h.receipt_order_code as receipt_order_code,
            baseh.mis_po_number || '/' || baseh.spm_po_number || ' ' || baseh.spm_po_desc as spm_po_desc,
            l.receipt_confirm_date as created_date,
            l.accounting_confrim_import_date as acc_cfm_imptomis_date
        from t_receiptorder_lineinfo l
           left join t_receiptorder_headerinfo h on l.receipt_order_id=h.id
           left join t_sys_erp_projects p on p.seq_id = l.project_id
           left join t_sys_erp_tasks t on t.task_id = l.task_id
           left join t_warehouse_define d on d.id = l.address_id
           left join t_lis_ouuser ou on ou.ou_employee_number=l.receipt_order_line_uid
           left join t_lis_user u on ou.employee_number=u.employee_number
           left join t_lis_dept dept on dept.id = h.apply_dept_id
           left join t_base_spm_pur_order_headers baseh on baseh.spm_po_header_id = h.po_id
        where l.receipt_order_line_sid=2
               and l.status=1 and h.status=1
               and h.is_straight = 1
               and h.ou_id = ouId
               and p.project_code like '%'||nvl(projectCode,'')||'%'
               and p.project_name like '%'||nvl(projectName,'')||'%'
               and l.item_code like '%'||nvl(itemCode,'')||'%'
               and l.item_desc like '%'||nvl(itemName,'')||'%'
               and h.receipt_order_code like '%'||nvl(spmPoCode,'')||'%'
               and u.employee_name like '%'||nvl(createdName,'')||'%'
               and dept.dept_name like '%'||nvl(createdDept,'')||'%'
               and '直发' like '%'||nvl(transactionType,'')||'%'
               and l.receipt_confirm_date between to_date(beginDate,'yyyy-mm-dd') and to_date(endDate,'yyyy-mm-dd');
              -- and (
              --     (nvl(projectCode,'') <> '' and p.project_code = projectCode)
                --   or
              --     1=1
               --)
               --条件

--出库

      insert into temp_project_material_usage(project_material_usage_id,
             project_code, project_name, task_code, task_name, receipt_place, receipt_user,
             authorize_card, epm_task_code, epm_task_name, item_code, item_name,
             uom_code, trf_out_cfm_quty, created_user, created_dept, created_dept_id, operator,
             transaction_type, spm_po_code, order_desc, created_date, acc_cfm_imptomis_date)

          select
            t_project_material_usage.nextval,
            H.Project_code as project_code,
            H.Project_name as project_name,
            ln.task_code as task_code,
            ln.task_name as task_name,
            d.warehouse_define_code||' '||d.warehouse_define_name as receiptPlace,
            h.construction_company||'/'||h.take_goods_user_name as receiptUser,
            h.authorization_card as authorize_card,--授权卡号（暂无）
            ln.epmtask_code as epm_task_code,
            ln.epmtask_name as epm_task_name,
            Item.Item_code as item_code ,
            Item.Item_name as item_name ,
            Item.Uom_Desc as uom_desc ,
            Info.Trf_out_cfm_quty as trf_out_cfm_quty ,
            u.employee_name as created_user,
            dept.dept_name as created_dept,
            dept.id as dept_id,
            (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=Info.ACC_CFM_BYUSER_ID) as operator,
            '出库' as transaction_type,
            H.Out_ord_code as out_ord_code ,
            H.Ord_Desc as order_desc,
            H.Created_Date as created_date,
            Info.Acc_cfm_imptomis_date as acc_cfm_imptomis_date
          From T_out_notmk Info
            left join T_sys_erp_items Item On Item.Seq_id = Info.Item_id
            left join T_wh_current_onhand_quantity Onhand On Info.Warehouse_onhand_id=Onhand.Id
            left join T_out_hd H On H.Id=Info.Out_ord_id
            left join t_out_ln ln on ln.id = info.ord_ln_id
            left join t_warehouse_define d on d.id = ln.rcpt_place_id

            left join t_lis_ouuser ou on ou.ou_employee_number=H.Created_User
            left join t_lis_user u on ou.employee_number=u.employee_number
            left join t_lis_dept dept on dept.id = h.cre_dept_id
         Where H.Status=1 and (Info.Asgn_ln_status=1 Or Info.Asgn_ln_status=5 ) And Info.Status=1
               and ln.status=1
               and H.Out_ord_code like ouCode||'%'
               and H.project_code like '%'||nvl(projectCode,'')||'%'
               and H.project_name like '%'||nvl(projectName,'')||'%'
               and Item.item_code like '%'||nvl(itemCode,'')||'%'
               and Item.Item_Name like '%'||nvl(itemName,'')||'%'
               and h.Out_ord_code like '%'||nvl(spmPoCode,'')||'%'
               and u.employee_name like '%'||nvl(createdName,'')||'%'
               and dept.dept_name like '%'||nvl(createdDept,'')||'%'
               and '出库' like '%'||nvl(transactionType,'')||'%'
               and h.Created_Date between to_date(beginDate,'yyyy-mm-dd') and to_date(endDate,'yyyy-mm-dd');


--退库

      insert into temp_project_material_usage(project_material_usage_id,
             project_code, project_name, task_code, task_name, receipt_place, receipt_user,
             authorize_card, epm_task_code, epm_task_name, item_code, item_name,
             uom_code, trf_out_cfm_quty, created_user, created_dept, created_dept_id, operator,
             transaction_type, spm_po_code, order_desc, created_date, acc_cfm_imptomis_date)

           select
                t_project_material_usage.nextval,
                hd.project_code as project_code,
                hd.project_name as project_name,
                bckln.task_code as task_code,
                bckln.task_name as task_name,
                d.warehouse_define_code||' '||d.warehouse_define_name as receiptPlace,
                '' as receiptUser,
                '' as authorizeCard,--授权卡号（暂无）
                '' as epm_task_code,
                '' as epm_task_name,
                bckln.item_code as item_code,
                bckln.item_name as item_name,
                bckln.unit as uom_desc,
                bckln.acpt_cfm_quty as trf_out_cfm_quty,
                u.employee_name as created_user,
                dept.dept_name as created_dept,
                dept.id as dept_id,
                (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=bckln.acccfm_by_userid) as operator,
                '退库' as transaction_type,
                hd.back_order_code as order_code,
                hd.back_order_desc as order_desc,
                hd.created_date as created_date,
                hd.sendmis_date as acc_cfm_imptomis_date
              from T_BCK_LN bckln
                 join T_BCK_HD hd on bckln.bckHdInfo_id = hd.id
                 and (hd.orderstatus = 50 or hd.orderstatus = 60)
                 and (bckln.line_status_id = 40 or bckln.line_status_id = 50 or bckln.line_status_id = 60)
                 and hd.status=1 and bckln.status=1
                 left join t_warehouse_define d on d.id = bckln.warehousebacktoid
                 left join t_lis_ouuser ou on ou.ou_employee_number=hd.created_user
                 left join t_lis_user u on ou.employee_number=u.employee_number
                 left join t_lis_dept dept on dept.id = hd.creationdeptid
              where
                 hd.back_order_code like ouCode||'%'
                 and hd.project_code like '%'||nvl(projectCode,'')||'%'
                 and hd.project_name like '%'||nvl(projectName,'')||'%'
                 and bckln.item_code like '%'||nvl(itemCode,'')||'%'
                 and bckln.Item_Name like '%'||nvl(itemName,'')||'%'
                 and hd.back_order_code like '%'||nvl(spmPoCode,'')||'%'
                 and u.employee_name like '%'||nvl(createdName,'')||'%'
                 and dept.dept_name like '%'||nvl(createdDept,'')||'%'
                 and '退库' like '%'||nvl(transactionType,'')||'%'
                 and hd.created_date between to_date(beginDate,'yyyy-mm-dd') and to_date(endDate,'yyyy-mm-dd');


     open project_material for
     SELECT B.* FROM ( SELECT A.*, ROWNUM RN
        FROM(select * from temp_project_material_usage u
               where
                 u.project_code like '%'||nvl(projectCode,'')||'%'
                 and u.project_name like '%'||nvl(projectName,'')||'%'
                 and u.item_code like '%'||nvl(itemCode,'')||'%'
                 and u.item_name like '%'||nvl(itemName,'')||'%'
                 and u.spm_po_code like '%'||nvl(spmPoCode,'')||'%'
                 and u.created_user like '%'||nvl(createdName,'')||'%'
                 and u.created_dept like '%'||nvl(createdDept,'')||'%'
                 and u.transaction_type like '%'||nvl(transactionType,'')||'%'
                 and u.created_date between to_date(beginDate,'yyyy-mm-dd') and to_date(endDate,'yyyy-mm-dd')
            )A
        )B
     WHERE RN between ((pagenum-1)*pagesize)+1 and pagenum*pagesize
     order by B.project_material_usage_id desc;
     select count(*) into total from temp_project_material_usage u
          where
                 u.project_code like '%'||nvl(projectCode,'')||'%'
                 and u.project_name like '%'||nvl(projectName,'')||'%'
                 and u.item_code like '%'||nvl(itemCode,'')||'%'
                 and u.item_name like '%'||nvl(itemName,'')||'%'
                 and u.spm_po_code like '%'||nvl(spmPoCode,'')||'%'
                 and u.created_user like '%'||nvl(createdName,'')||'%'
                 and u.created_dept like '%'||nvl(createdDept,'')||'%'
                 and u.transaction_type like '%'||nvl(transactionType,'')||'%'
                 and u.created_date between to_date(beginDate,'yyyy-mm-dd') and to_date(endDate,'yyyy-mm-dd');
    commit;
end;
end;
/

