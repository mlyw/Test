create FUNCTION "AVAILABLE_QUANTITY" (v_item_id number)
return number
as
v_available_quantity number(19,5);
BEGIN
  select sum(round(nvl(wh.onhand_quantity,0)-(nvl(f.RESERVE_QUANTITY,0) + nvl(asgn.asgn_quty,0)),5)) into v_available_quantity
      from t_wh_current_onhand_quantity wh 
      left join(select e.onhand_id,sum(nvl(e.RESERVE_QUANTITY,0)) as RESERVE_QUANTITY  from T_SYS_ITEM_RESEREVE_INFO e
      where sysdate < e.reserve_end_day and e.status = 1  group by e.onhand_id) f on wh.id=f.onhand_id
      left join (select asgninfo.warehouse_Onhand_Id,nvl(sum(asgninfo.asgn_quty),0) as asgn_quty  from T_OUT_NOTMK asgninfo
      where asgninfo.asgn_ln_status=3 group by asgninfo.warehouse_Onhand_Id having min(asgninfo.IF_RESERVE)=0 ) asgn on wh.id=asgn.warehouse_Onhand_Id
    where wh.status = 1 and wh.item_id=v_item_id;
  
  RETURN v_available_quantity;
END;
/

