create view V_LIS_REPORT_QTY_OPERATE_CORE as
  SELECT
    /**以ou/库存/子库/物料分类/物料为维度的出入库交易数据以及当前的库存数据*/
    NVL(rct.bussiness_date,sysdate) bussiness_date ,
    NVL(rct.ou_id,rqi.mis_ou_id) mis_ou_id,
    NVL(rct.organization_id,rqi.mis_io_id) mis_io_id,
    (NVL(rct.organization_code,rqi.mis_io_code)
    || ' '
    || NVL(rct.organization_name,rqi.mis_io_name)) onginfo,
    NVL(rct.warehouse_define_id,rqi.warehouse_define_id) warehouse_define_id,
    (NVL(rct.warehouse_define_code,rqi.warehouse_define_code)
    || ' '
    || NVL(rct.warehouse_define_desc,rqi.warehouse_define_name)) warehouseinfo,
    NVL(rct.item_category_code,rqi.concatenated_segments) item_category_code,
    NVL(rct.item_category_name,rqi.category_description) item_category_name,
    NVL(rct.item_id,rqi.item_id) item_id,
    NVL(rct.item_code,rqi.item_code) item_code,
    NVL(rct.item_desc,rqi.item_desc) item_desc,
    NVL(rct.item_uom_code,rqi.uom_code) item_uom_code,
    NVL(rct.item_uom_desc,rqi.uom_desc) item_uom_desc,
    NVL(rct.out_onhand_quantity,0) out_onhand_quantity,
    NVL(rct.out_onhand_account,0) out_onhand_account,
    NVL(rct.receive_onhand_quantity,0) receive_onhand_quantity,
    NVL(rct.receive_onhand_account,0) receive_onhand_account,
    NVL(rqi.item_account,0) current_account,
    NVL(rqi.item_quantity,0) currentqty,
    rct.order_id,
    rct.order_code,
    rct.order_type
  FROM t_lis_report_core_transaction rct---出库、入库数量金额
  FULL JOIN v_lis_report_qty_item_now rqi
  ON rct.ou_id               =rqi.mis_ou_id
  AND rct.organization_id    =rqi.mis_io_id
  AND rct.warehouse_define_id=rqi.warehouse_define_id
  AND rct.item_category_code =rqi.concatenated_segments
  AND rct.item_id            =rqi.item_id
  AND rct.item_code          =rqi.item_code
  AND rct.item_desc          =rqi.item_desc
  AND rct.item_uom_code      =rqi.uom_code
  AND rct.item_uom_desc      =rqi.uom_desc
/

