create procedure proc_spm_product_item(startTimestamp timestamp,endTimestamp timestamp) as
total_value number(15);
count_success number(15);
count_value number(15);
exception_info varchar2(3000);
prod_seq_id number(19);
count_seq number(15);
cursor prod_item_csr is
select product_id,item_code,item_desc from i_spm_product_item where created_time between startTimestamp and endTimestamp;
item_csr prod_item_csr%rowtype;
begin
  count_success := 0;
  select count(seq_id) into count_seq from t_sys_spm_product_item where product_id in(select seq_id from t_sys_spm_products where product_id in (select product_id from i_spm_product_item where created_time between startTimestamp and endTimestamp)) ;
  if(count_seq != 0) then
      update t_sys_spm_product_item
         set status = 0,
             last_updated_date = sysdate
         where product_id in (select seq_id from t_sys_spm_products where product_id in (select product_id from i_spm_product_item where created_time between startTimestamp and endTimestamp));
  end if;
  select count(seq_id) into total_value from i_spm_product_item where created_time between startTimestamp and endTimestamp;
  open prod_item_csr;
  fetch prod_item_csr into item_csr;
  while(prod_item_csr%found) loop
      select seq_id into prod_seq_id from t_sys_spm_products where product_id = item_csr.product_id;
      select count(seq_id) into count_value from t_sys_spm_product_item where item_code = item_csr.item_code and product_id = prod_seq_id;
      if(count_value = 1) then
         update t_sys_spm_product_item
            set product_id = prod_seq_id,
                item_code = item_csr.item_code,
                item_desc = item_csr.item_desc,
                status = 1,
                last_updated_date = sysdate
            where item_code = item_csr.item_code and product_id = prod_seq_id;
      else
         insert into t_sys_spm_product_item (seq_id,product_id,item_code,item_desc,version,status,created_date,last_updated_date)
         values (seq_spm_product_item.nextval,prod_seq_id,item_csr.item_code,item_csr.item_desc,1,1,sysdate,sysdate);
     end if;
     fetch prod_item_csr into item_csr;
     count_success := count_success+1;
  end loop;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','t_sys_spm_product_item');
exception when others then
   exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
   insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_spm_product_item');
close prod_item_csr;
COMMIT;
end;
/

