create PROCEDURE "PROC_PJ" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_pj is
select seq_id, pj_id, pj_code, pj_name, enable_flag, start_data_active, end_data_active, erp_type, import_date from i_erp_pj_info
 where import_date > start_time and import_date < end_time order by erp_type desc;
i_pj csr_i_pj%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from I_ERP_PJ_INFO where import_date > start_time and import_date < end_time;
  open csr_i_pj;
  fetch csr_i_pj into i_pj;
while (csr_i_pj%found) loop
  select count(*) into count_value from T_SYS_ERP_PJ where ERP_PJ_ID = i_pj.pj_id and erp_type = i_pj.erp_type;
  if(count_value = 1 and i_pj.enable_flag = 'Y' and i_pj.end_data_active is null) then
      update T_SYS_ERP_PJ t set t.last_updated_date = sysdate,
      t.erp_pj_code = i_pj.pj_code,
      t.erp_pj_name = i_pj.pj_name,
      t.erp_type = i_pj.erp_type,
      t.start_date_active = i_pj.start_data_active,
      t.end_date_active = i_pj.end_data_active
      where t.erp_pj_id = i_pj.pj_id
      and t.erp_type = i_pj.erp_type;
   elsif(count_value = 1 and i_pj.enable_flag = 'N') then
   update T_SYS_ERP_PJ t set t.last_updated_date = sysdate,
      t.erp_pj_code = i_pj.pj_code,
      t.erp_pj_name = i_pj.pj_name,
      t.erp_type = i_pj.erp_type,
      t.start_date_active = i_pj.start_data_active,
      t.end_date_active = i_pj.end_data_active,
      t.status = 0
      where t.erp_pj_id = i_pj.pj_id
      and t.erp_type = i_pj.erp_type;
   elsif(count_value = 1 and i_pj.enable_flag = 'Y' and i_pj.end_data_active is not null) then
   update T_SYS_ERP_PJ t set t.last_updated_date = sysdate,
      t.erp_pj_code = i_pj.pj_code,
      t.erp_pj_name = i_pj.pj_name,
      t.erp_type = i_pj.erp_type,
      t.start_date_active = i_pj.start_data_active,
      t.end_date_active = i_pj.end_data_active,
      t.status = 0
      where t.erp_pj_id = i_pj.pj_id
      and t.erp_type = i_pj.erp_type;
 elsif(count_value = 0 and i_pj.end_data_active is null and i_pj.enable_flag = 'Y') then
insert into t_sys_erp_pj
  (erp_pj_id, erp_pj_code, erp_pj_name, erp_type, start_date_active, end_date_active, validity_flag, created_date, last_updated_date, status, version, seq_id)
values
  (i_pj.pj_id, i_pj.pj_code, i_pj.pj_name, i_pj.erp_type, i_pj.start_data_active, i_pj.end_data_active, i_pj.enable_flag, sysdate, sysdate, 1, 0, i_pj.seq_id);  
end if;
fetch csr_i_pj into i_pj;
count_success := count_success + 1;
end loop;
close csr_i_pj;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','T_SYS_ERP_PJ');
exception when others then
  rollback;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_ERP_PJ');
  commit;
end;
/

