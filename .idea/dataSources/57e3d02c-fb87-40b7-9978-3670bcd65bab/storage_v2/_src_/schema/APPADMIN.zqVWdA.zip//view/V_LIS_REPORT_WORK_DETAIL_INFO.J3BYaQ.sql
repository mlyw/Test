create view V_LIS_REPORT_WORK_DETAIL_INFO as
  SELECT
  /**以人员部门为维度的业务量统计视图*/
    tmp1.bussinessdate,
    tmp1.item_code,
    tmp1.item_desc,
    tmp1.item_id,
    tmp1.uom_code,
    tmp1.uom_desc,
    tmp1.concatenated_segments,
    tmp1.category_description,
    tmp1.warehouse_id,
    tmp1.warehouse_define_code,
    tmp1.warehouse_define_name,
    tmp1.ou_id,
    tmp1.mis_io_code,
    tmp1.mis_io_name,
    tmp1.mis_io_id,
    tmp1.handle_onhand_account,
    tmp1.handle_onhand_quantity,
    tmp1.order_id,
    tmp1.order_code,
    tmp1.order_type,
    tmp1.lines,
    '料帐' handle_type,
    tmp.Employee_Name,
    tmp.OU_EMPLOYEE_NUMBER,
    tmp.dept_name
  FROM
    (SELECT d.bussinessdate,
      d.item_code,
      d.item_desc,
      d.item_id,
      d.uom_code,
      d.uom_desc,
      d.concatenated_segments,
      d.category_description,
      d.warehouse_id,
      d.warehouse_define_code,
      d.warehouse_define_name,
      d.mis_ou_id ou_id,
      d.mis_io_id,
      d.mis_io_code,
      d.mis_io_name,
      d.order_id,
      d.order_code,
      d.order_type,
      d.lines,
      NVL(d.accounts,0) handle_onhand_account,
      NVL(d.quantities,0) handle_onhand_quantity
    FROM v_lis_report_work_order_info d,
      v_warehouse_define_by_purchase w,
      t_lis_flow_inst t
    WHERE d.warehouse_id=w.ID
    AND d.order_id      =t.bisiness_id
    ) tmp1
  JOIN
    (SELECT U.Employee_Name,
      U.OU_EMPLOYEE_NUMBER,
      u.dept_name,
      Ta.Current_Assignee,
      C.Step_Desc,
      Ta.Display_Flag,
      i.bisiness_id
    FROM T_Lis_Flow_Task ta
    JOIN T_Lis_Flow_Config c
    ON c.id             =Ta.Current_Flow_Config
    AND C.Current_Role IN ('ROLE_ACCOUNTING_CLERK','ROLE_BRANCH_ACCOUNTING_CLERK','ROLE_CNP_ACCOUNTING_CLERK')
    AND C.Next_Step     =99
    LEFT JOIN MV_T_LIS_OUUSER u
    ON u.ou_employee_number=Ta.Current_Assignee
    LEFT JOIN t_lis_flow_inst i
    ON ta.flow_inst_id    =i.id
    WHERE Ta.Display_Flag =1
    ) tmp ON tmp1.order_id=tmp.bisiness_id
  UNION ALL
  ---库存分配类型 只涉及到工程物资和cnp出库分配的流程
  SELECT tmp1.bussinessdate,
    tmp1.item_code,
    tmp1.item_desc,
    tmp1.item_id,
    tmp1.uom_code,
    tmp1.uom_desc,
    tmp1.concatenated_segments,
    tmp1.category_description,
    tmp1.warehouse_id,
    tmp1.warehouse_define_code,
    tmp1.warehouse_define_name,
    tmp1.ou_id,
    tmp1.mis_io_code,
    tmp1.mis_io_name,
    tmp1.mis_io_id,
    tmp1.handle_onhand_account,
    tmp1.handle_onhand_quantity,
    tmp1.order_id,
    tmp1.order_code,
    tmp1.order_type,
    tmp1.lines,
    '库存分配' handle_type,
    tmp.Employee_Name,
    tmp.OU_EMPLOYEE_NUMBER,
    tmp.dept_name
  FROM
    (SELECT d.bussinessdate,
      d.item_code,
      d.item_desc,
      d.item_id,
      d.uom_code,
      d.uom_desc,
      d.concatenated_segments,
      d.category_description,
      d.warehouse_id,
      d.warehouse_define_code,
      d.warehouse_define_name,
      d.mis_ou_id ou_id,
      d.mis_io_id,
      d.mis_io_code,
      d.mis_io_name,
      d.order_id,
      d.order_code,
      d.order_type,
      d.lines,
      NVL(d.accounts,0) handle_onhand_account,
      NVL(d.quantities,0) handle_onhand_quantity
    FROM v_lis_report_work_order_info d,
      v_warehouse_define_by_purchase w,
      t_lis_flow_inst t
    WHERE d.warehouse_id=w.ID
    AND d.order_id      =t.bisiness_id
    ) tmp1
  JOIN
    (SELECT U.Employee_Name,
      U.OU_EMPLOYEE_NUMBER,
      u.dept_name,
      Ta.Last_Updated_User,
      C.Step_Desc,
      Ta.Display_Flag,
      i.bisiness_id
    FROM T_Lis_Flow_Task ta
    JOIN T_Lis_Flow_Config c
    ON c.id               =Ta.Current_Flow_Config
    AND C.Current_Role   IN ('ROLE_CNP_DELIVERY_ADMIN','ROLE_WAREHOUSE_DISTRIBUTION')
    AND c.flow_full_code IN ('FLOW_MANAGER_CK','FLOW_CNP_DT','FLOW_CNP_NODT')
    AND c.next_step      IN (7,8)
    LEFT JOIN MV_T_LIS_OUUSER u
    ON u.ou_employee_number=Ta.Last_Updated_User
    LEFT JOIN t_lis_flow_inst i
    ON ta.flow_inst_id    =i.id
    WHERE Ta.Display_Flag =1
    ) tmp ON tmp1.order_id=tmp.bisiness_id
  UNION ALL
  ---实物收发类型
  /** 所有各种业务单据涉及到的实物收发接收确认流程节点的节点信息
  t_receiptorder_headerinfo     接收入库/接收直发
  16  FLOW_RK 1   WAREHOUSE_KEEPER  2     ROLE_ACCOUNTING_CLERK 料帐员确认
  123   FLOW_ZF   1  ROLE_PROJECT_MANAGER    2    ROLE_ACCOUNTING_CLERK    接收直发单
  t_returnorder_headerinfo    退货单据
  147   FLOW_TH   4  ROLE_DELIVERY_ADMIN   5  ROLE_ACCOUNTING_CLERK     料帐员确认
  T_Lis_Simcard_Sales_Month_Head     SIM卡销售月结
  477   FLOW_SIMC     2 ROLE_LVL3_APPROVOR     3 ROLE_BRANCH_ACCOUNTING_CLERK     料帐员确认
  t_chg_hd_ln       调拨
  178   FLOW_TK_N     5 ROLE_DELIVERY_ADMIN 6   ROLE_RECEIPT_ADMIN    调入确认（相当于调出放确认）
  179   FLOW_TK_N     6 ROLE_RECEIPT_ADMIN     7 ROLE_ACCOUNTING_CLERK   转料账员账务确认 （相当于调入确认）
  t_refundwastecard_head      报废卡退库
  549   FLOW_BFKTK_ZS    3    ROLE_CNP_WAREHOUSE_KEEPER   4  ROLE_CNP_ACCOUNTING_CLERK    料帐员确认（不配送）
  544   FLOW_BFKTK_PS    4    ROLE_CNP_WAREHOUSE_KEEPER   5  ROLE_CNP_ACCOUNTING_CLERK    料帐员确认（配送）
  t_out_hd      工程及cnp出库,杂发
  59  FLOW_MANAGER_CK    7    ROLE_DELIVERY_ADMIN  8     ROLE_ACCOUNTING_CLERK 账务确认
  t_out_hd      综合出库
  355   FLOW_CK_SALE   3  ROLE_LVL2_APPROVOR  5     ROLE_BRANCH_ACCOUNTING_CLERK   审批通过
  t_bck_hd      工程退库/工程杂收
  73  FLOW_EMPLOYEE_BK     6 ROLE_RECEIPT_ADMIN     7 ROLE_ACCOUNTING_CLERK   账务确认
  t_bck_hd      综合调增/综合退库
  343   FLOW_BK_SALE   2  ROLE_LVL3_APPROVOR  4     ROLE_BRANCH_ACCOUNTING_CLERK   审批通过
  346   FLOW_BK_SALE   3  ROLE_LVL2_APPROVOR  4     ROLE_BRANCH_ACCOUNTING_CLERK   审批通过
  **/
  SELECT tmp1.bussinessdate,
    tmp1.item_code,
    tmp1.item_desc,
    tmp1.item_id,
    tmp1.uom_code,
    tmp1.uom_desc,
    tmp1.concatenated_segments,
    tmp1.category_description,
    tmp1.warehouse_id,
    tmp1.warehouse_define_code,
    tmp1.warehouse_define_name,
    tmp1.ou_id,
    tmp1.mis_io_code,
    tmp1.mis_io_name,
    tmp1.mis_io_id,
    tmp1.handle_onhand_account,
    tmp1.handle_onhand_quantity,
    tmp1.order_id,
    tmp1.order_code,
    tmp1.order_type,
    tmp1.lines,
    '实物收发' handle_type,
    tmp.Employee_Name,
    tmp.OU_EMPLOYEE_NUMBER,
    tmp.dept_name
  FROM
    (SELECT d.bussinessdate,
      d.item_code,
      d.item_desc,
      d.item_id,
      d.uom_code,
      d.uom_desc,
      d.concatenated_segments,
      d.category_description,
      d.warehouse_id,
      d.warehouse_define_code,
      d.warehouse_define_name,
      d.mis_ou_id ou_id,
      d.mis_io_id,
      d.mis_io_code,
      d.mis_io_name,
      d.order_id,
      d.order_code,
      d.order_type,
      d.lines,
      NVL(d.accounts,0) handle_onhand_account,
      NVL(d.quantities,0) handle_onhand_quantity
    FROM v_lis_report_work_order_info d,
      v_warehouse_define_by_purchase w,
      t_lis_flow_inst t
    WHERE d.warehouse_id=w.ID
    AND d.order_id      =t.bisiness_id
    ) tmp1
  JOIN
    (SELECT U.Employee_Name,
      U.OU_EMPLOYEE_NUMBER,
      u.dept_name,
      Ta.Last_Updated_User,
      C.Step_Desc,
      Ta.Display_Flag,
      i.bisiness_id
    FROM T_Lis_Flow_Task ta
    JOIN T_Lis_Flow_Config c
    ON c.id   =Ta.Current_Flow_Config
    AND c.id IN (16,123,147,477,178,179,549,544,59,355,73,343,346)
    LEFT JOIN MV_T_LIS_OUUSER u
    ON u.ou_employee_number=Ta.Last_Updated_User
    LEFT JOIN t_lis_flow_inst i
    ON ta.flow_inst_id    =i.id
    WHERE Ta.Display_Flag =1
    ) tmp ON tmp1.order_id=tmp.bisiness_id
/

