create materialized view MV_T_LIS_DELIVERY_NOTICE
refresh force on demand
  as
    SELECT
  /**每小时运行一次:START WITH SYSDATE NEXT SYSDATE + 3600/86400 查询入库通知单信息*/
    uu.employee_name cgy,
    lu.employee_name dhcjr,
    tmp1.*,
    i.concatenated_segments pl_item_category_code,
    i.category_description pl_item_category_desc,
    sysdate builddate
  FROM
    (SELECT bs.mis_po_number po_mis_po_number,
      bs.spm_po_desc po_spm_po_desc,
      bs.agent_id po_agent_id,
      bs.vendor_name po_vendor_name,
      bs.vendor_id po_vendor_id,
      bs.ou_id po_ou_id,
      bl.spm_po_line_num pl_spm_po_line_num,
      bl.mis_po_line_num pl_mis_po_line_num,
      bl.spm_po_line_id pl_spm_po_line_id,
      dh.vendor_shipping_date,
      dh.delivery_order_code,
      dh.vendor_shipping_title,
      ah.Vendor_Arrival_Number,
      ah.Vendor_Arrival_Desc,
      ah.Vendor_Arrival_Date,
      ah.Vendor_Arrival_User,
      u.employee_name jsr,
      tmp.*
    FROM
      (SELECT dl.id dl_id,
        dl.header_id dl_header_id,
        dl.item_type_code dl_item_type_code,
        dl.item_id dl_item_id,
        dl.item_code dl_item_code,
        dl.item_desc dl_item_desc,
        dl.uom_code dl_uom_code,
        dl.uom_desc dl_uom_desc,
        dl.product_id dl_product_id,
        dl.product_code dl_product_code,
        dl.product_desc dl_product_desc,
        dl.delivery_quantity dl_delivery_quantity,
        dl.quota_status dl_quota_status,
        dl.delivery_date dl_delivery_date,
        dl.mis_po_line_num dl_mis_po_line_num,
        dl.vendor_shipping_header_id dl_vendor_shipping_header_id,
        dl.vendor_shipping_line_id dl_vendor_shipping_line_id,
        dl.spm_po_header_id dl_spm_po_header_id,
        dl.spm_po_number dl_spm_po_number,
        dl.spm_po_line_id dl_spm_po_line_id,
        dl.spm_po_distribution_id dl_spm_po_distribution_id,
        dl.mis_po_header_id dl_mis_po_header_id,
        dl.mis_po_number dl_mis_po_number,
        dl.mis_po_line_id dl_mis_po_line_id,
        dl.mis_po_distribution_id dl_mis_po_distribution_id,
        dl.uniqe_identifier_flag dl_uniqe_identifier_flag,
        dl.status dl_status,
        dl.arrival_site dl_arrival_site,
        dl.arrival_recipient dl_arrival_recipient,
        dl.arrival_recipient_tel dl_arrival_recipient_tel,
        dl.is_cross_docking dl_is_cross_docking,
        al.id al_id,
        al.status al_status,
        al.vendor_arrival_header_id al_vendor_arrival_header_id,
        al.vendor_arrival_line_id al_vendor_arrival_line_id,
        al.vendor_shipping_header_id al_vendor_shipping_header_id,
        al.vendor_shipping_line_id al_vendor_shipping_line_id,
        al.quantity_shipped al_quantity_shipped,
        al.arrival_plantime al_arrival_plantime,
        al.import_date al_import_date,
        al.material_volume al_material_volume
      FROM T_Lis_Delivery_Notice_Line dl,
        T_Spm_Arrival_Notice_Line al
      WHERE dl.vendor_shipping_line_id=al.vendor_shipping_line_id(+)
      AND dl.vendor_shipping_header_id=al.vendor_shipping_header_id(+)
      ) tmp
    LEFT JOIN T_Lis_Delivery_Notice_Header dh
    ON tmp.dl_header_id=dh.id
    LEFT JOIN T_Spm_Arrival_Notice_Header ah
    ON tmp.al_vendor_arrival_header_id=ah.vendor_arrival_header_id
    LEFT JOIN T_BASE_SPM_PUR_ORDER_LINES bl
    ON tmp.dl_spm_po_line_id=bl.spm_po_line_id
    LEFT JOIN T_BASE_SPM_PUR_ORDER_HEADERS bs
    ON tmp.dl_spm_po_header_id=bs.spm_po_header_id
    LEFT JOIN T_LIS_USER u
    ON tmp.dl_ARRIVAL_RECIPIENT=u.user_id
    WHERE tmp.dl_status        =1
    AND NVL(tmp.al_status,-1) !=0
    ) tmp1
  LEFT JOIN T_LIS_USER lu
  ON tmp1.VENDOR_ARRIVAL_USER=lu.user_id
  LEFT JOIN T_LIS_USER uu
  ON tmp1.po_agent_id=uu.employee_number
  LEFT JOIN t_sys_erp_items i
  ON tmp1.dl_item_id=i.seq_id

/

