create PROCEDURE PROC_ARRIVAL_NOTICE_SYNC AS 
  total_value number(15);
  count_value number(2);
  count_success number(15);
  exception_info varchar2(3000);
  notice_status number(19);
  cursor csr_i_header is
    select ih.SEQ_ID,
           ih.vendor_arrival_header_id,
           ih.vendor_arrival_number,
           ih.vendor_arrival_desc, 
           ih.vendor_arrival_date,
           ih.vendor_arrival_user,
           ih.vendor_shipping_header_id,
           ih.vendor_shipping_number
    from I_Spm_Arrival_Notice_Header ih
    where ih.time='1503381271517';
  i_header csr_i_header%rowtype;
BEGIN
  count_success := 0;
  select count(seq_id) into total_value from I_Spm_Arrival_Notice_Header ih where ih.time='1503381271517';
  open csr_i_header;
  fetch csr_i_header into i_header;
  while (csr_i_header%found) loop
    count_value := 0;
    select count(id) into count_value from T_Spm_Arrival_Notice_Header h where h.vendor_arrival_header_id=i_header.vendor_arrival_header_id;
    if(count_value = 0) then
      insert into T_SPM_ARRIVAL_NOTICE_HEADER(ID,
                  CREATED_DATE,
                  CREATED_USER,
                  DATE_VALUE1,
                  LAST_UPDATED_DATE,
                  LAST_UPDATED_USER,
                  NUMBER_VALUE1,
                  STATUS,
                  STRING_VALUE1,
                  VERSION,
                  VENDOR_ARRIVAL_HEADER_ID,
                  VENDOR_ARRIVAL_NUMBER,
                  VENDOR_ARRIVAL_DESC,
                  VENDOR_ARRIVAL_DATE,
                  VENDOR_ARRIVAL_USER,
                  VENDOR_SHIPPING_HEADER_ID,
                  VENDOR_SHIPPING_NUMBER,
                  notice_status)
      values(i_spm_arrivalnotice_seq.nextVal,
            sysdate,
            '12345678',
            null,
            sysdate,
            '12345678',
            null,
            1,null,1,
            i_header.VENDOR_ARRIVAL_HEADER_ID,
            i_header.VENDOR_ARRIVAL_NUMBER,
            i_header.VENDOR_ARRIVAL_DESC,
            i_header.VENDOR_ARRIVAL_DATE,
            i_header.VENDOR_ARRIVAL_USER,
            i_header.VENDOR_SHIPPING_HEADER_ID,
            i_header.VENDOR_SHIPPING_NUMBER,
            1);
    else
      select h.notice_status into notice_status from T_Spm_Arrival_Notice_Header h where h.vendor_arrival_header_id=i_header.vendor_arrival_header_id;
      /*
        如果已冻结或完成不更新
      */
      if( 1 = notice_status) then
        update T_Spm_Arrival_Notice_Header h
        set H.Last_Updated_Date=sysdate,
            H.Last_Updated_User='12345678',
            h.version=h.version+1,
            h.status=1,
            H.Vendor_Arrival_Date=i_header.Vendor_Arrival_Date,
            H.Vendor_Arrival_Desc=i_header.Vendor_Arrival_Desc,
            H.Vendor_Arrival_Number=i_header.Vendor_Arrival_Number,
            H.Vendor_Arrival_User=i_header.Vendor_Arrival_User,
            H.Vendor_Shipping_Header_Id=i_header.Vendor_Shipping_Header_Id,
            H.Vendor_Shipping_Number=i_header.Vendor_Shipping_Number
        where h.vendor_arrival_header_id=i_header.vendor_arrival_header_id;
      end if;
    end if;
    fetch csr_i_header into i_header;
    count_success:=count_success+1;
  end loop;
  close csr_i_header ;
  --插入日志
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','T_Spm_Arrival_Notice_Header');
  exception when others then
      exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
    insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_Spm_Arrival_Notice_Header');
  commit;
END PROC_ARRIVAL_NOTICE_SYNC;
/

