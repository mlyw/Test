create view V_LIS_REPORT_VENDOROVERACCOUNT as
  SELECT
    /**供应商维度呆滞物资占比7-9等分布视图*/
    o.ou_id,
    o.organization_id,
    o.warehouse_define_id,
    o.orginfo,
    o.warehouseinfo,
    o.vendor_id,
    v.vendor_name,
    o.item_category_code,
    o.item_category_name,
    o.item_id,
    o.item_code,
    o.item_desc,
    o.item_uom_code,
    o.item_uom_desc,
    NVL(o.item_quantity,0) item_quantity,
    NVL(o.item_account,0) item_account,
    NVL(o.over_item_account,0) over_item_account,
    NVL(to9.over_7to9_account,0) over_7to9_account ,
    NVL(to10.over_10to12_account,0) over_10to12_account,
    NVL(to13.over_13to18_account,0) over_13to18_account,
    NVL(to24.over_19to24_account,0) over_19to24_account,
    NVL(to25.over_25more_account,0) over_25more_account
  FROM v_lis_report_vendor_isover o
  LEFT JOIN v_lis_report_vendor_7to9 to9
  ON o.ou_id               =to9.ou_id
  AND o.organization_id    =to9.organization_id
  AND o.warehouse_define_id=to9.warehouse_define_id
  AND o.vendor_id          =to9.vendor_id
  AND o.item_id            =to9.item_id
  AND o.item_code          =to9.item_code
  AND o.item_desc          =to9.item_desc
  AND o.item_uom_code      =to9.item_uom_code
  AND o.item_uom_desc      =to9.item_uom_desc
  LEFT JOIN v_lis_report_vendor_10to12 to10
  ON o.ou_id               =to10.ou_id
  AND o.organization_id    =to10.organization_id
  AND o.warehouse_define_id=to10.warehouse_define_id
  AND o.vendor_id          =to10.vendor_id
  AND o.item_id            =to10.item_id
  AND o.item_code          =to10.item_code
  AND o.item_desc          =to10.item_desc
  AND o.item_uom_code      =to10.item_uom_code
  AND o.item_uom_desc      =to10.item_uom_desc
  LEFT JOIN v_lis_report_vendor_13to18 to13
  ON o.ou_id               =to13.ou_id
  AND o.organization_id    =to13.organization_id
  AND o.warehouse_define_id=to13.warehouse_define_id
  AND o.vendor_id          =to13.vendor_id
  AND o.item_id            =to13.item_id
  AND o.item_code          =to13.item_code
  AND o.item_desc          =to13.item_desc
  AND o.item_uom_code      =to13.item_uom_code
  AND o.item_uom_desc      =to9.item_uom_desc
  LEFT JOIN v_lis_report_vendor_19to24 to24
  ON o.ou_id               =to24.ou_id
  AND o.organization_id    =to24.organization_id
  AND o.warehouse_define_id=to24.warehouse_define_id
  AND o.vendor_id          =to24.vendor_id
  AND o.item_id            =to24.item_id
  AND o.item_code          =to24.item_code
  AND o.item_desc          =to24.item_desc
  AND o.item_uom_code      =to24.item_uom_code
  AND o.item_uom_desc      =to24.item_uom_desc
  LEFT JOIN v_lis_report_vendor_25more to25
  ON o.ou_id               =to25.ou_id
  AND o.organization_id    =to25.organization_id
  AND o.warehouse_define_id=to25.warehouse_define_id
  AND o.vendor_id          =to25.vendor_id
  AND o.item_id            =to25.item_id
  AND o.item_code          =to25.item_code
  AND o.item_desc          =to25.item_desc
  AND o.item_uom_code      =to25.item_uom_code
  AND o.item_uom_desc      =to25.item_uom_desc
  LEFT JOIN t_sys_erp_vendors v
  ON o.vendor_id=v.seq_id
/

