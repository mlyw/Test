create FUNCTION FINDFREEZENUM (v_line_id number, v_order_type varchar2)
return float
as
v_freeze_number number(19,5);
BEGIN
   select sum(nvl(rs.reserve_quantity,0)) into v_freeze_number from t_returnorder_lineinfo l
       inner join T_SYS_ITEM_RESEREVE_INFO rs on rs.order_line_id=l.id and rs.order_type=v_order_type
       and sysdate between rs.reserve_start_day and rs.reserve_end_day and rs.status=1
       inner join t_receiptorder_lineinfo rl on l.receipt_order_line_id=rl.receiptorderlineid
       where  rl.receiptorderlineid=v_line_id;
   RETURN nvl(v_freeze_number,0);
END;

/

