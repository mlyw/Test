create procedure proc_epm_project_manager(start_time timestamp,end_time timestamp) is
total_value number(15);
count_value number(2);
project_id_value number(15);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_epm_project_manager is
select seq_id, project_code, erp_type, pm_employee_number, pm_employee_name, process_type, import_date from i_epm_projects_manager t where t.import_date > start_time and t.import_date < end_time;
i_epm_project_manager csr_i_epm_project_manager%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_epm_projects_manager where import_date > start_time and import_date < end_time;
  open csr_i_epm_project_manager;
  fetch csr_i_epm_project_manager into i_epm_project_manager;
while (csr_i_epm_project_manager%found) loop
  select t.seq_id into project_id_value from t_sys_erp_projects t where t.project_code = i_epm_project_manager.project_code and t.erp_type = i_epm_project_manager.erp_type;
  if (i_epm_project_manager.process_type = 'NEW') then
    insert into t_sys_epm_projects_manager
      (seq_id, project_code, project_id, erp_type, pm_employee_number, pm_employee_name, created_date, last_updated_date, status, version)
    values
      (t_sys_epm_project_manager_seq.nextval, i_epm_project_manager.project_code, project_id_value, i_epm_project_manager.erp_type, i_epm_project_manager.pm_employee_number, i_epm_project_manager.pm_employee_name, sysdate, sysdate, 1, 0);
  elsif(i_epm_project_manager.process_type = 'DELETE') then
     update t_sys_epm_projects_manager t
               set
                   status = 0
             where t.project_code = i_epm_project_manager.project_code and t.pm_employee_number = i_epm_project_manager.pm_employee_number;
         end if;
  fetch csr_i_epm_project_manager into i_epm_project_manager;
  count_success:=count_success + 1;
 end loop;
 close csr_i_epm_project_manager;
 commit;
 insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_epm_projects_manager');
 exception when others then
  rollback;
  exception_info := 'ERR: An error occurred with info:project_id is ' || i_epm_project_manager.seq_id ||' ,'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_epm_projects_manager');
  commit;
end;
/

