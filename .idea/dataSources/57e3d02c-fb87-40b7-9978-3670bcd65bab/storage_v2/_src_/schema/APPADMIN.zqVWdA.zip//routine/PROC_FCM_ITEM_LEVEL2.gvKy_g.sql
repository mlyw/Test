create PROCEDURE PROC_FCM_Item_Level2(itime varchar2) AS 
  total_value number(15);
  count_value number(2);
  count_success number(15);
  exception_info varchar2(3000);
  cursor csr_ii_Fcm_Item_Level2 is
  select SEQ_ID,ITEM_ID,ITEM_NO,ITEM_NAME,STATE,DESCRIPTION,FATHER_ITEM,PAY_BANK,CAPITAL_AUDIT,REMARK1,REMARK2,
    SUB_CLAIM_ID,CAN_VIRTUAL_VENDOR,TYPE,TEMPLATE_NO,IF_MORE_VEN,IF_BOOK_CHEQUE,IF_CHEQUE_RATION,
    IF_BANK_CORP_PAY,BCP_DEPT_NAME,IF_PAYROLL,VENDOR_SITE_NAME,LIMITSTAT1,LIMITSTAT2,LIMITSTAT3,
    MANNER,CONTROL_AMOUNT,IS_NEED_UPDATE_FP_AMOUNT,OFFSET_FLAG,NOJOINCONTACTFLAG,IS_GENERAL_LEDGER,
    ACC_AUDIT_FLAG,PAY_TYPE,EEE3_NAME,ATTRIBUTE1,ATTRIBUTE2,ATTRIBUTE3,ATTRIBUTE4,ATTRIBUTE5,ATTRIBUTE6,
    ATTRIBUTE7,ATTRIBUTE8,ATTRIBUTE9,ATTRIBUTE10,ATTRIBUTE11,ATTRIBUTE12,ATTRIBUTE13,ATTRIBUTE14,ATTRIBUTE15,
    TIME,IMPORT_DATE
  from I_Fcm_Item_Level2 t where t.time=itime;
  ii_Fcm_Item_Level2 csr_ii_Fcm_Item_Level2%rowtype;
  lis_status number(2);
BEGIN
  count_success := 0;
  lis_status := 1;
  select count(ITEM_ID) into total_value from I_Fcm_Item_Level2 where time=itime;
  open csr_ii_Fcm_Item_Level2;
  fetch csr_ii_Fcm_Item_Level2 into ii_Fcm_Item_Level2;
  while (csr_ii_Fcm_Item_Level2%found) loop
    count_value := 0;
    select count(t.seq_id) into count_value from t_Fcm_Item_Level2 t where t.ITEM_ID=ii_Fcm_Item_Level2.ITEM_ID and t.status=1;
    if(ii_Fcm_Item_Level2.STATE != 1) then 
      lis_status := 1;
    end if;
    
    if(count_value = 0) then
      Insert into t_Fcm_Item_Level2(SEQ_ID,DATE_VALUE1,NUMBER_VALUE1,STATUS,STRING_VALUE1,VERSION,
      ITEM_ID,ITEM_NO,ITEM_NAME,STATE,DESCRIPTION,FATHER_ITEM,PAY_BANK,CAPITAL_AUDIT,REMARK1,REMARK2,
      SUB_CLAIM_ID,CAN_VIRTUAL_VENDOR,TYPE,TEMPLATE_NO,IF_MORE_VEN,IF_BOOK_CHEQUE,IF_CHEQUE_RATION,
      IF_BANK_CORP_PAY,BCP_DEPT_NAME,IF_PAYROLL,VENDOR_SITE_NAME,LIMITSTAT1,LIMITSTAT2,LIMITSTAT3,
      MANNER,CONTROL_AMOUNT,IS_NEED_UPDATE_FP_AMOUNT,OFFSET_FLAG,NOJOINCONTACTFLAG,IS_GENERAL_LEDGER,
      ACC_AUDIT_FLAG,PAY_TYPE,EEE3_NAME,ATTRIBUTE1,ATTRIBUTE2,ATTRIBUTE3,ATTRIBUTE4,ATTRIBUTE5,ATTRIBUTE6,
      ATTRIBUTE7,ATTRIBUTE8,ATTRIBUTE9,ATTRIBUTE10,ATTRIBUTE11,ATTRIBUTE12,ATTRIBUTE13,ATTRIBUTE14,ATTRIBUTE15,IMPORT_DATE) 
      values (S_FCM_Item.nextVal,null,null,lis_status,null,1,
      ii_Fcm_Item_Level2.ITEM_ID,ii_Fcm_Item_Level2.ITEM_NO,ii_Fcm_Item_Level2.ITEM_NAME,ii_Fcm_Item_Level2.STATE,ii_Fcm_Item_Level2.DESCRIPTION,ii_Fcm_Item_Level2.FATHER_ITEM,ii_Fcm_Item_Level2.PAY_BANK,ii_Fcm_Item_Level2.CAPITAL_AUDIT,ii_Fcm_Item_Level2.REMARK1,ii_Fcm_Item_Level2.REMARK2,
      ii_Fcm_Item_Level2.SUB_CLAIM_ID,ii_Fcm_Item_Level2.CAN_VIRTUAL_VENDOR,ii_Fcm_Item_Level2.TYPE,ii_Fcm_Item_Level2.TEMPLATE_NO,ii_Fcm_Item_Level2.IF_MORE_VEN,ii_Fcm_Item_Level2.IF_BOOK_CHEQUE,ii_Fcm_Item_Level2.IF_CHEQUE_RATION,
      ii_Fcm_Item_Level2.IF_BANK_CORP_PAY,ii_Fcm_Item_Level2.BCP_DEPT_NAME,ii_Fcm_Item_Level2.IF_PAYROLL,ii_Fcm_Item_Level2.VENDOR_SITE_NAME,ii_Fcm_Item_Level2.LIMITSTAT1,ii_Fcm_Item_Level2.LIMITSTAT2,ii_Fcm_Item_Level2.LIMITSTAT3,
      ii_Fcm_Item_Level2.MANNER,ii_Fcm_Item_Level2.CONTROL_AMOUNT,ii_Fcm_Item_Level2.IS_NEED_UPDATE_FP_AMOUNT,ii_Fcm_Item_Level2.OFFSET_FLAG,ii_Fcm_Item_Level2.NOJOINCONTACTFLAG,ii_Fcm_Item_Level2.IS_GENERAL_LEDGER,
      ii_Fcm_Item_Level2.ACC_AUDIT_FLAG,ii_Fcm_Item_Level2.PAY_TYPE,ii_Fcm_Item_Level2.EEE3_NAME,ii_Fcm_Item_Level2.ATTRIBUTE1,ii_Fcm_Item_Level2.ATTRIBUTE2,ii_Fcm_Item_Level2.ATTRIBUTE3,ii_Fcm_Item_Level2.ATTRIBUTE4,ii_Fcm_Item_Level2.ATTRIBUTE5,ii_Fcm_Item_Level2.ATTRIBUTE6,
      ii_Fcm_Item_Level2.ATTRIBUTE7,ii_Fcm_Item_Level2.ATTRIBUTE8,ii_Fcm_Item_Level2.ATTRIBUTE9,ii_Fcm_Item_Level2.ATTRIBUTE10,ii_Fcm_Item_Level2.ATTRIBUTE11,ii_Fcm_Item_Level2.ATTRIBUTE12,ii_Fcm_Item_Level2.ATTRIBUTE13,ii_Fcm_Item_Level2.ATTRIBUTE14,ii_Fcm_Item_Level2.ATTRIBUTE15,ii_Fcm_Item_Level2.IMPORT_DATE);
    else 
      update t_Fcm_Item_Level2 t 
      set t.VERSION=t.VERSION+1,
          t.DATE_VALUE1=sysdate,
          t.status=lis_status,
          t.ITEM_NO= ii_Fcm_Item_Level2.ITEM_NO,
          t.ITEM_NAME=ii_Fcm_Item_Level2.ITEM_NAME,
          t.STATE=ii_Fcm_Item_Level2.STATE,
          t.DESCRIPTION=ii_Fcm_Item_Level2.DESCRIPTION,
          t.FATHER_ITEM=ii_Fcm_Item_Level2.FATHER_ITEM,
          t.PAY_BANK=ii_Fcm_Item_Level2.PAY_BANK,
          t.CAPITAL_AUDIT=ii_Fcm_Item_Level2.CAPITAL_AUDIT,
          t.REMARK1=ii_Fcm_Item_Level2.REMARK1,
          t.REMARK2=ii_Fcm_Item_Level2.REMARK2,
          t.SUB_CLAIM_ID=ii_Fcm_Item_Level2.SUB_CLAIM_ID,
          t.CAN_VIRTUAL_VENDOR=ii_Fcm_Item_Level2.CAN_VIRTUAL_VENDOR,
          t.TYPE=ii_Fcm_Item_Level2.TYPE,
          t.TEMPLATE_NO=ii_Fcm_Item_Level2.TEMPLATE_NO,
          t.IF_MORE_VEN=ii_Fcm_Item_Level2.IF_MORE_VEN,
          t.IF_BOOK_CHEQUE=ii_Fcm_Item_Level2.IF_BOOK_CHEQUE,
          t.IF_CHEQUE_RATION=ii_Fcm_Item_Level2.IF_CHEQUE_RATION,
          t.IF_BANK_CORP_PAY=ii_Fcm_Item_Level2.IF_BANK_CORP_PAY,
          t.BCP_DEPT_NAME=ii_Fcm_Item_Level2.BCP_DEPT_NAME,
          t.IF_PAYROLL=ii_Fcm_Item_Level2.IF_PAYROLL,
          t.VENDOR_SITE_NAME=ii_Fcm_Item_Level2.VENDOR_SITE_NAME,
          t.LIMITSTAT1=ii_Fcm_Item_Level2.LIMITSTAT1,
          t.LIMITSTAT2=ii_Fcm_Item_Level2.LIMITSTAT2,
          t.LIMITSTAT3=ii_Fcm_Item_Level2.LIMITSTAT3,
          t.MANNER=ii_Fcm_Item_Level2.MANNER,
          t.CONTROL_AMOUNT=ii_Fcm_Item_Level2.CONTROL_AMOUNT,
          t.IS_NEED_UPDATE_FP_AMOUNT=ii_Fcm_Item_Level2.IS_NEED_UPDATE_FP_AMOUNT,
          t.OFFSET_FLAG=ii_Fcm_Item_Level2.OFFSET_FLAG,
          t.NOJOINCONTACTFLAG=ii_Fcm_Item_Level2.NOJOINCONTACTFLAG,
          t.IS_GENERAL_LEDGER=ii_Fcm_Item_Level2.IS_GENERAL_LEDGER,
          t.ACC_AUDIT_FLAG=ii_Fcm_Item_Level2.ACC_AUDIT_FLAG,
          t.PAY_TYPE=ii_Fcm_Item_Level2.PAY_TYPE,
          t.EEE3_NAME=ii_Fcm_Item_Level2.EEE3_NAME,
          t.ATTRIBUTE1=ii_Fcm_Item_Level2.ATTRIBUTE1,
          t.ATTRIBUTE2=ii_Fcm_Item_Level2.ATTRIBUTE2,
          t.ATTRIBUTE3=ii_Fcm_Item_Level2.ATTRIBUTE3,
          t.ATTRIBUTE4=ii_Fcm_Item_Level2.ATTRIBUTE4,
          t.ATTRIBUTE5=ii_Fcm_Item_Level2.ATTRIBUTE5,
          t.ATTRIBUTE6=ii_Fcm_Item_Level2.ATTRIBUTE6,
          t.ATTRIBUTE7=ii_Fcm_Item_Level2.ATTRIBUTE7,
          t.ATTRIBUTE8=ii_Fcm_Item_Level2.ATTRIBUTE8,
          t.ATTRIBUTE9=ii_Fcm_Item_Level2.ATTRIBUTE9,
          t.ATTRIBUTE10=ii_Fcm_Item_Level2.ATTRIBUTE10,
          t.ATTRIBUTE11=ii_Fcm_Item_Level2.ATTRIBUTE11,
          t.ATTRIBUTE12=ii_Fcm_Item_Level2.ATTRIBUTE12,
          t.ATTRIBUTE13=ii_Fcm_Item_Level2.ATTRIBUTE13,
          t.ATTRIBUTE14=ii_Fcm_Item_Level2.ATTRIBUTE14,
          t.ATTRIBUTE15=ii_Fcm_Item_Level2.ATTRIBUTE15,
          t.IMPORT_DATE=ii_Fcm_Item_Level2.IMPORT_DATE
      where t.ITEM_ID=ii_Fcm_Item_Level2.ITEM_ID and t.status=1;
    end if;
    fetch csr_ii_Fcm_Item_Level2 into ii_Fcm_Item_Level2;
    count_success:=count_success+1;
  end loop;
  close csr_ii_Fcm_Item_Level2 ;
  --插入日志
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_Fcm_Item_Level2');
  exception when others then
      exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
    insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_Fcm_Item_Level2');
  commit;
END PROC_FCM_Item_Level2;
/

