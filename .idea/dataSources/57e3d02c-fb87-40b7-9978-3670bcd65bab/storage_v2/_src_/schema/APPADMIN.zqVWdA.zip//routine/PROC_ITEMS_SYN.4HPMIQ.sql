create PROCEDURE "PROC_ITEMS_SYN" as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_items is
select seq_id, item_id, item_code, item_name, inventory_item_status_code, inventory_item_flag, purchasing_enabled_flag, expense_billable_flag, last_update_date, concatenated_segments, category_description, uom_code, uom_name, lot_control_code, serial_number_control_code, organization_id, erp_type from i_erp_items where seq_id=14224 order by erp_type desc;
i_items csr_i_items%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_erp_items where seq_id = 14224;
  open csr_i_items;
  fetch csr_i_items into i_items;
while (csr_i_items%found) loop
  select count(*) into count_value from t_sys_erp_items where item_id = i_items.item_id and erp_type = i_items.erp_type and organization_id = i_items.organization_id;
  if(count_value > 0) then
      update t_sys_erp_items t set t.last_updated_date = sysdate,
      t.erp_type = i_items.erp_type,
      t.item_code = i_items.item_code,
      t.item_name = i_items.item_name,
      t.uom_code = i_items.uom_code,
      t.uom_desc = i_items.uom_name,
      t.organization_id = i_items.organization_id,
      t.inventory_item_status_code = i_items.inventory_item_status_code,
      t.inventory_item_flag = i_items.inventory_item_flag,
      t.purchasing_enabled_flag = i_items.purchasing_enabled_flag,
      t.expense_billable_flag = i_items.expense_billable_flag,
      t.concatenated_segments = i_items.concatenated_segments,
      t.category_description = i_items.category_description,
      t.lot_control_code = i_items.lot_control_code - 1,
      t.serial_number_control_code = i_items.serial_number_control_code
      where t.item_id = i_items.item_id;
      fetch csr_i_items into i_items;
 else
insert into t_sys_erp_items
  (seq_id, item_id, item_code, item_name, uom_code, uom_desc, organization_id, erp_type, status, created_date, last_updated_date, inventory_item_status_code, inventory_item_flag, purchasing_enabled_flag, expense_billable_flag, concatenated_segments, category_description, lot_control_code, serial_number_control_code)
values
  (i_items.seq_id , i_items.item_id, i_items.item_code, i_items.item_name, i_items.uom_code, i_items.uom_name, i_items.organization_id, i_items.erp_type, 1, sysdate, sysdate, i_items.inventory_item_status_code, i_items.inventory_item_flag, i_items.purchasing_enabled_flag, i_items.expense_billable_flag, i_items.concatenated_segments, i_items.category_description, i_items.lot_control_code - 1, i_items.serial_number_control_code);
fetch csr_i_items into i_items;
count_success:=count_success+1;
end if;
end loop;
close csr_i_items;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_erp_items');
exception when others then
  --count_num := count_success;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_erp_items');
close csr_i_items;
commit;
end;
/

