create view V_LIS_REPORT_TRANSACTION_INTO as
  SELECT tmp.item_code,
    tmp.item_desc,
    tmp.item_id,
    tmp.uom_code,
    tmp.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.warehouse_receive_id,
    w.warehouse_define_code,
    w.warehouse_define_name,
    w.mis_ou_id,
    w.mis_ou_name,
    w.mis_io_id,
    w.mis_io_code,
    w.mis_io_name,
    tmp.product_unit_price,
    tmp.current_receive_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.current_receive_quantity,0) current_receive_account,
    tmp.accounting_confirm_date import_date,
    tmp.id order_id,
    tmp.receipt_order_code order_code,
    tmp.order_type， a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM
    (SELECT rl.item_id,
      rl.item_code,
      rl.item_desc,
      rl.uom_code,
      rl.uom_desc,
      NVL(rl.product_unit_price,0) product_unit_price,
      NVL(rl.current_receive_quantity,0) current_receive_quantity,
      rl.warehouse_receive_id,
      rl.accounting_confirm_date,
      rh.id,
      rh.receipt_order_code,
      '接收入库' order_type
    FROM t_receiptorder_headerinfo rh,
      t_receiptorder_lineinfo rl
    WHERE rl.status                                     =1
    AND rl.status                                       =1
    AND rh.order_status                                 =5
    AND rl.receipt_order_line_sid                       =2
    AND rl.receipt_order_id                             =rh.id
    AND TO_CHAR(rl.accounting_confirm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_warehouse_define w
  ON tmp.warehouse_receive_id=w.id
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define_area a
  ON tmp.warehouse_receive_id=a.warehouse_id
  UNION ALL
  ----rm销售数据
  SELECT i.item_code,
    i.item_name item_desc,
    rs.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    d.id warehouse_receive_id,
    rs.subinventory_code warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    0 product_unit_price,
    ABS(NVL(rs.quantity,0)) current_receive_quantity,
    0*NVL(ABS(NVL(rs.quantity,0)),0) current_receive_account,
    rs.transcation_date import_date,
    rs.seq_id order_id,
    rs.origin_filename order_code,
    '有价卡销售回退' order_type,
    a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM t_lis_rm_sales rs
  LEFT JOIN t_sys_erp_items i
  ON rs.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON rs.subinventory_code =d.warehouse_define_code
  LEFT JOIN t_warehouse_define_area a
  ON rs.subinventory_code                      =a.warehouse_code
  WHERE NVL(rs.quantity,0)                     <0
  AND TO_CHAR(rs.transcation_date,'yyyy-MM-dd')>'2016-12-31'
  AND NVL(rs.flag,'')                          ='Y'
  UNION ALL
  ----SIM卡销售月结-回退数
  SELECT i.item_code,
    i.item_name item_desc,
    tmp.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.wd_id warehouse_receive_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    0 product_unit_price,
    tmp.simcard_qty current_receive_quantity,
    0*NVL(tmp.simcard_qty,0) current_receive_account,
    tmp.transaction_processing_time import_date,
    tmp.id order_id,
    tmp.simcard_order_code order_code,
    tmp.order_type order_type， a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM
    (SELECT sl.item_id,
      sl.wd_id,
      ABS(sl.simcard_qty) simcard_qty,
      sh.transaction_processing_time,
      sh.id,
      sh.simcard_order_code,
      'SIM卡销售回退' order_type
    FROM T_Lis_Simcard_Sales_Month_Head sh,
      T_Lis_Simcard_Sales_Month_Line sl
    WHERE sl.status                                         =1
    AND sh.status                                           =1
    AND sl.head_id                                          =sh.id
    AND sh.head_status                                      =4
    AND sl.line_status                                      =4
    AND TO_CHAR(sh.transaction_processing_time,'yyyy-MM-dd')>'2016-12-31'
    AND NVL(sl.simcard_qty,0)                               <0
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.wd_id=d.id
  LEFT JOIN t_warehouse_define_area a
  ON tmp.wd_id=a.warehouse_id
  UNION ALL
  ----工程退库/工程杂收
  SELECT tmp.item_code,
    tmp.item_name item_desc,
    tmp.itemid item_id,
    i.uom_code,
    tmp.unit uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.warehousebacktoid warehouse_receive_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    tmp.prouintprice product_unit_price,
    tmp.acpt_cfm_quty current_receive_quantity,
    NVL(tmp.prouintprice,0)*NVL(tmp.acpt_cfm_quty,0) current_receive_account,
    tmp.acc_cfm_date import_date,
    tmp.id order_id,
    tmp.back_order_code order_code,
    tmp.order_type order_type,
    a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM
    (SELECT bl.item_code,
      bl.item_name,
      bl.itemid,
      bl.unit,
      bl.warehousebacktoid,
      bl.acpt_cfm_quty,
      bl.prouintprice,
      bl.acc_cfm_date,
      bh.id,
      bh.back_order_code,
      CASE
        WHEN bh.backtypeid=5
        THEN '杂收'
        ELSE '退库'
      END AS order_type
    FROM t_bck_hd bh,
      t_bck_ln bl
    WHERE bh.status                          =1
    AND bl.status                            =1
    AND bh.orderstatus                       =60
    AND bh.backtypeid                       IN (1,5)
    AND bl.backorderid                       =bh.id
    AND TO_CHAR(bl.acc_cfm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.itemid=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.warehousebacktoid=d.id
  LEFT JOIN t_warehouse_define_area a
  ON tmp.warehousebacktoid=a.warehouse_id
  UNION ALL
  ---综合调增/综合退库
  SELECT tmp.item_code,
    tmp.item_name item_desc,
    tmp.itemid item_id,
    i.uom_code,
    tmp.unit uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.warehousebacktoid warehouse_receive_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    tmp.prouintprice product_unit_price,
    tmp.backquantity current_receive_quantity,
    NVL(tmp.prouintprice,0)*NVL(tmp.backquantity,0) current_receive_account,
    tmp.acc_cfm_date import_date,
    tmp.id order_id,
    tmp.back_order_code order_code,
    tmp.order_type order_type， a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM
    (SELECT bl.item_code,
      bl.item_name,
      bl.itemid,
      bl.unit,
      bl.warehousebacktoid,
      bl.backquantity,
      bl.prouintprice,
      bl.acc_cfm_date,
      bh.id,
      bh.back_order_code,
      CASE
        WHEN bh.backtypeid=86
        THEN '杂收'
        ELSE '退库'
      END AS order_type
    FROM t_bck_hd bh,
      t_bck_ln bl
    WHERE bh.status                          =1
    AND bl.status                            =1
    AND bh.orderstatus                       =60
    AND bh.backtypeid                       IN (84,86)
    AND bl.backorderid                       =bh.id
    AND TO_CHAR(bl.acc_cfm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.itemid=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.warehousebacktoid=d.id
  LEFT JOIN t_warehouse_define_area a
  ON tmp.warehousebacktoid=a.warehouse_id
  UNION ALL
  ---调拨-调入方
  ----工程物资调拨
  SELECT tmp.item_code,
    tmp.item_desc,
    tmp.item_id,
    tmp.uom_code,
    tmp.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.wh_id_trf_into warehouse_receive_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    tmp.product_unit_price,
    tmp.change_quty current_receive_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.change_quty,0) current_receive_account,
    tmp.account_date import_date,
    tmp.id order_id,
    tmp.wh_chg_ord_code order_code,
    tmp.order_type order_type， a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM
    (SELECT hl.item_code,
      hl.item_id,
      hl.uom_desc,
      hl.item_desc,
      hl.uom_code,
      hl.wh_id_trf_into,
      NVL(hl.product_unit_price,0) product_unit_price,
      hl.change_quty,
      hd.account_date,
      hd.id,
      hd.wh_chg_ord_code,
      '调拨' order_type
    FROM t_chg_hd_ln hd,
      t_chg_ln hl
    WHERE hd.status                          =1
    AND hl.status                            =1
    AND hd.order_status                     IN (5,50)
    AND hl.chghdln_id                        =hd.id
    AND TO_CHAR(hd.account_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.wh_id_trf_into=d.id
  LEFT JOIN t_warehouse_define_area a
  ON tmp.wh_id_trf_into=a.warehouse_id
  UNION ALL
  ---报废卡退库 c999是接收入库
  SELECT i.item_code,
    i.item_name item_desc,
    tmp.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.receive_wd_id warehouse_receive_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    tmp.product_unit_price,
    tmp.actual_qty current_receive_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.actual_qty,0) current_receive_account,
    tmp.accounted_date import_date,
    tmp.seq_id order_id,
    tmp.order_code order_code,
    tmp.order_type order_type,
    a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM
    (SELECT rwl.item_id,
      rwl.receive_wd_id,
      0 product_unit_price,
      rwl.actual_qty,
      rwl.accounted_date,
      rwh.seq_id,
      rwh.order_code,
      '报废卡退库' order_type
    FROM t_refundwastecard_head rwh,
      t_refundwastecard_line rwl
    WHERE rwh.status                            =1
    AND rwl.status                              =1
    AND rwh.order_status                        =7
    AND rwl.order_line_status                   =7
    AND TO_CHAR(rwl.accounted_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.receive_wd_id=d.id
  LEFT JOIN t_warehouse_define_area a
  ON tmp.receive_wd_id=a.warehouse_id
  UNION ALL
  -----cnp出库时从C001出到具体的营业厅 具体营业厅的数据当做营业厅的入库数据
  SELECT tmp.item_code,
    i.item_name item_desc,
    tmp.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    d.id warehouse_receive_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    tmp.product_unit_price,
    tmp.Acpt_Cfm_Quty current_receive_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.Acpt_Cfm_Quty,0) current_receive_account,
    tmp.acc_cfm_date import_date,
    tmp.id order_id,
    tmp.out_ord_code order_code,
    tmp.order_type,
    a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM
    (SELECT m.item_id,
      m.item_code,
      l.to_subinventory_code,
      m.product_unit_price,
      m.Acpt_Cfm_Quty,
      m.acc_cfm_date,
      h.id,
      h.out_ord_code,
      '大库调入' order_type
    FROM t_out_hd h,
      t_out_ln l,
      t_out_notmk m
    WHERE h.status                          =1
    AND l.status                            =1
    AND m.status                            =1
    AND h.ord_status                        =6
    AND l.ord_ln_status                     =7
    AND m.asgn_ln_status                    =1
    AND m.outlninfo_id                      =l.id
    AND l.outhdinfo_id                      =h.id
    AND l.to_subinventory_code             IS NOT NULL
    AND TO_CHAR(m.acc_cfm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.to_subinventory_code=d.warehouse_define_code
  LEFT JOIN t_warehouse_define_area a
  ON tmp.to_subinventory_code=a.warehouse_code
/

