create PROCEDURE proc_expenditure_type (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_expenditure_type is
select expenditure_type_id, expenditure_type, description, expenditure_category, start_date_active, end_date_active, last_update_date, erp_type, import_date, seq_id, create_date from i_erp_expenditure_type where create_date > start_time and create_date < end_time order by erp_type desc;
i_expenditure_type csr_i_expenditure_type%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_erp_expenditure_type where create_date > start_time and create_date < end_time;
  open csr_i_expenditure_type;
  fetch csr_i_expenditure_type into i_expenditure_type;
while (csr_i_expenditure_type%found) loop
  select count(*) into count_value from t_Sys_Erp_Expenditure_Type where EXPENDITURE_TYPE_ID = i_expenditure_type.expenditure_type_id and erp_type = i_expenditure_type.erp_type;
  if(count_value = 1 and i_expenditure_type.end_date_active is null) then
      update t_Sys_Erp_Expenditure_Type t set t.last_updated_date = sysdate,
      t.expenditure_type = i_expenditure_type.expenditure_type,
      t.expenditure_type_name = i_expenditure_type.description,
      t.erp_type= i_expenditure_type.erp_type,
      t.expenditure_category = i_expenditure_type.expenditure_category,
      t.start_date_active = i_expenditure_type.start_date_active,
      t.end_date_active = i_expenditure_type.end_date_active
      where t.expenditure_type_id = i_expenditure_type.expenditure_type_id;
   elsif(count_value = 1 and i_expenditure_type.end_date_active is not null) then
      update t_Sys_Erp_Expenditure_Type t set t.last_updated_date = sysdate,
      t.expenditure_type = i_expenditure_type.expenditure_type,
      t.expenditure_type_name = i_expenditure_type.description,
      t.erp_type= i_expenditure_type.erp_type,
      t.expenditure_category = i_expenditure_type.expenditure_category,
      t.start_date_active = i_expenditure_type.start_date_active,
      t.end_date_active = i_expenditure_type.end_date_active,
      t.status = 0
      where t.expenditure_type_id = i_expenditure_type.expenditure_type_id;
 elsif(count_value = 0 and i_expenditure_type.end_date_active is null) then
  insert into t_sys_erp_expenditure_type
    (seq_id, expenditure_type_id, created_date, last_updated_date, status, erp_type, expenditure_type, expenditure_type_name, expenditure_category, start_date_active, end_date_active)
  values
    (i_expenditure_type.seq_id, i_expenditure_type.expenditure_type_id, sysdate, sysdate, 1, i_expenditure_type.erp_type, i_expenditure_type.expenditure_type, i_expenditure_type.description, i_expenditure_type.expenditure_category, i_expenditure_type.start_date_active, i_expenditure_type.end_date_active);
end if;
fetch csr_i_expenditure_type into i_expenditure_type;
count_success:=count_success+1;
end loop;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_Sys_Erp_Expenditure_Type');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_Sys_Erp_Expenditure_Type');
close csr_i_expenditure_type;
commit;
end;
/

