create trigger COSTPRICE_ONHAND
  before insert
  on T_WH_CURRENT_ONHAND_QUANTITY
  for each row
  BEGIN
    :new.Cost_Unit_Price := :new.Product_Unit_Price;
END;
/

