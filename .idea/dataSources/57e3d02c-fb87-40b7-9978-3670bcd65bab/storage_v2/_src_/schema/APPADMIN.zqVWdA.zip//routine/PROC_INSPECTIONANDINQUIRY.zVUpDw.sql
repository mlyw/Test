create procedure proc_inspectionandinquiry (result_lis out sys_refcursor)
as
begin    
  open result_lis for
  select l.spm_po_header_id ,l.spm_po_line_id,h.spm_po_number,l.item_code,p.product_code from t_base_spm_pur_order_lines l
  left join t_base_spm_pur_order_headers h on l.spm_po_header_id = h.spm_po_header_id
  left join t_sys_spm_products p on l.product_id = p.seq_id
  where l.status = 1 and h.status = 1 
  and l.is_need_check = '1'and l.quantity_receivable > 0 and l.is_exsit_detect is null;
end;
/

