create procedure proc_modify_epm_pm_project(start_time timestamp,end_time timestamp) as
 count_value_1 number(15);
 count_value_0 number(15);
 total_value number(15);
 exception_info varchar2(3000);
begin
  update t_sys_epm_projects_manager t set t.project_id = (select p.seq_id from t_sys_erp_projects p where p.project_code = t.project_code and p.last_updated_date > start_time 
  and p.last_updated_date < end_time and p.status = 1) where exists 
  (select * from t_sys_erp_projects p where p.project_code = t.project_code and p.last_updated_date > start_time and p.last_updated_date < end_time and p.status = 1);
  count_value_1 := sql%rowcount;
  update t_sys_epm_projects_manager t set t.status = 0 where exists 
  (select * from t_sys_erp_projects p where p.project_code = t.project_code and p.last_updated_date > start_time and p.last_updated_date < end_time and p.status = 0);
  count_value_0 := sql%rowcount;
  total_value := count_value_0 + count_value_1;
  dbms_output.put_line(count_value_0);
  dbms_output.put_line(count_value_1);
  dbms_output.put_line(total_value);
  commit;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'更新成功','t_sys_epm_projects_manager');
exception when others then
  rollback;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,exception_info,'t_sys_epm_projects_manager');
  commit;
end;
/

