create procedure PROC_SPM_DELIVERY_ORDER_LINE(startDate timestamp, endDate timestamp)
AS
    total_value number(19);
    count_success number(19);
    exception_info varchar2(3000);
    version_value NUMBER(10);
    count_value NUMBER(19);
    item_validate NUMBER(19);
    header_seqid NUMBER(19);
    status_value NUMBER(3);
    notice_count NUMBER(10);
    order_create_user VARCHAR2(30); -- 送货单创建人
    vendor_name_value VARCHAR(50); -- 供应商名
    price_value NUMBER(16, 4); -- 含税单价
    
    CURSOR cur_order_line IS
      SELECT
        DELIVERY_HEADER_ID, DELIVERY_LINE_ID,      
        SPM_PO_HEADER_ID, SPM_PO_NUMBER,       
        MIS_PO_HEADER_ID, MIS_PO_NUMBER,       
        SPM_PO_LINE_ID, SPM_PO_LINE_LOCATION_ID, 
        MIS_PO_LINE_ID, MIS_PO_LINE_DISTRIBUTION_ID, 
        PRODUCT_ID, PRODUCT_CODE, PRODUCT_DESC,     
        ITEM_ID, ITEM_CODE, ITEM_DESC,        
        UOM_CODE, UOM_DESC,           
        ORDERED_QUANTITY, DELIVERY_QUANTITY, 
        DELIVERY_PLAN_TIME,
        IMPORT_DATE, REMARK1, REMARK2, REMARK3, REMARK4, REMARK5, DELIVERY_TIME
      FROM I_SPM_DELIVERY_ORDER_LINE WHERE import_date BETWEEN startDate AND endDate;
    i_order_line cur_order_line%ROWTYPE;
      
begin
    total_value := 0;
    count_success := 0;
    
    SELECT COUNT(seq_id) INTO total_value FROM I_SPM_DELIVERY_ORDER_LINE WHERE import_date BETWEEN startDate AND endDate;

    OPEN cur_order_line;
    
    LOOP
      FETCH cur_order_line INTO i_order_line;
      EXIT WHEN (cur_order_line%NOTFOUND);
        
        status_value := 0;
        count_value := 0;
        header_seqid := 0;
        notice_count := 0;
        order_create_user := '';
        vendor_name_value := '';
        
        -- query delivery Header SeqId
        SELECT seq_id, delivery_order_createuser, vendor_name INTO header_seqid, order_create_user, vendor_name_value FROM t_Spm_Delivery_Order_Header WHERE status = 1
          AND delivery_order_id = i_order_line.delivery_header_id AND import_date BETWEEN startDate AND endDate;
        
        -- judging update or insert
        SELECT COUNT(seq_id) INTO count_value FROM T_SPM_DELIVERY_ORDER_LINE 
          WHERE
            delivery_header_id = i_order_line.delivery_header_id AND delivery_line_id = i_order_line.delivery_line_id;
        
        -- set version
        IF (count_value >= 1) THEN
          SELECT version INTO version_value FROM T_SPM_DELIVERY_ORDER_LINE 
            WHERE
              delivery_header_id = i_order_line.delivery_header_id AND delivery_line_id = i_order_line.delivery_line_id;
          version_value := version_value + 1;
        ELSE 
          version_value := 0;
        END IF;
        
        -- item_code validate
        SELECT COUNT(seq_id) INTO item_validate FROM t_sys_erp_items 
          WHERE status = 1 AND item_id = i_order_line.item_id AND item_code = i_order_line.item_code;
          
        IF (item_validate >= 1) THEN
            status_value := 1;
        ELSE
            status_value := 0;
        END IF;
        
        -- executing update or insert
        IF (count_value >= 1 AND header_seqid > 0) THEN
          UPDATE T_SPM_DELIVERY_ORDER_LINE
            SET
              DELIVERY_HEADER_ID = i_order_line.delivery_header_id,     
              DELIVERY_LINE_ID = i_order_line.delivery_line_id,       
              SPM_PO_HEADER_ID = i_order_line.spm_po_header_id,       
              SPM_PO_NUMBER = i_order_line.spm_po_number,        
              MIS_PO_HEADER_ID = i_order_line.mis_po_header_id,       
              MIS_PO_NUMBER = i_order_line.mis_po_number,        
              SPM_PO_LINE_ID = i_order_line.spm_po_line_id,         
              SPM_PO_LINE_LOCATION_ID = i_order_line.spm_po_line_location_id,
              MIS_PO_LINE_ID = i_order_line.mis_po_line_id,         
              MIS_PO_LINE_DISTRIBUTION_ID = i_order_line.mis_po_line_distribution_id, 
              PRODUCT_ID = i_order_line.product_id,          
              PRODUCT_CODE = i_order_line.product_code,        
              PRODUCT_DESC = i_order_line.product_desc,      
              ITEM_ID = i_order_line.item_id,               
              ITEM_CODE = i_order_line.item_code,           
              ITEM_DESC = i_order_line.item_desc,         
              UOM_CODE = i_order_line.uom_code,            
              UOM_DESC = i_order_line.uom_desc,            
              ORDERED_QUANTITY = i_order_line.ordered_quantity,      
              DELIVERY_QUANTITY = i_order_line.delivery_quantity,  
              DELIVERY_PLAN_TIME = i_order_line.delivery_plan_time,  
              "VERSION" = version_value,
              LAST_UPDATED_DATE = systimestamp,
              REMARK1 = i_order_line.remark1,
              REMARK2 = i_order_line.remark2,
              REMARK3 = i_order_line.remark3,
              REMARK4 = i_order_line.remark4,
              REMARK5 = i_order_line.remark5,
              DELIVERY_TIME = i_order_line.Delivery_Time，
              STATUS = status_value
            WHERE
              delivery_header_id = i_order_line.delivery_header_id AND delivery_line_id = i_order_line.delivery_line_id;
        ELSIF (header_seqid > 0) THEN
          INSERT INTO T_SPM_DELIVERY_ORDER_LINE(
              DELIVERY_HEADER_ID,     
              DELIVERY_LINE_ID,       
              SPM_PO_HEADER_ID,       
              SPM_PO_NUMBER,        
              MIS_PO_HEADER_ID,       
              MIS_PO_NUMBER,        
              SPM_PO_LINE_ID,         
              SPM_PO_LINE_LOCATION_ID,
              MIS_PO_LINE_ID,         
              MIS_PO_LINE_DISTRIBUTION_ID, 
              PRODUCT_ID,          
              PRODUCT_CODE,        
              PRODUCT_DESC,      
              ITEM_ID,               
              ITEM_CODE,           
              ITEM_DESC,         
              UOM_CODE,            
              UOM_DESC,            
              ORDERED_QUANTITY,      
              DELIVERY_QUANTITY,  
              DELIVERY_PLAN_TIME,  
              DELIVERY_ORDER_SEQID,  
              SEQ_ID,
              "VERSION", 
              STATUS,
              CREATED_DATE,
              LAST_UPDATED_DATE,
              REMARK1,
              REMARK2,
              REMARK3,
              REMARK4,
              REMARK5,
              DELIVERY_TIME
          ) VALUES(
              i_order_line.Delivery_Header_Id,
              i_order_line.Delivery_Line_Id,
              i_order_line.Spm_Po_Header_Id,
              i_order_line.Spm_Po_Number,
              i_order_line.Mis_Po_Header_Id,
              i_order_line.Mis_Po_Number,
              i_order_line.Spm_Po_Line_Id,
              i_order_line.Spm_Po_Line_Location_Id,
              i_order_line.Mis_Po_Line_Id,
              i_order_line.Mis_Po_Line_Distribution_Id,
              i_order_line.Product_Id,
              i_order_line.Product_Code,
              i_order_line.Product_Desc,
              i_order_line.Item_Id,
              i_order_line.Item_Code,
              i_order_line.Item_Desc,
              i_order_line.uom_code,
              i_order_line.uom_desc,
              i_order_line.ordered_quantity,
              i_order_line.delivery_quantity,
              i_order_line.delivery_plan_time,
              header_seqid,
              T_SIMPLE_DETECTION_SEQ.NEXTVAL,
              version_value,
              status_value,
              systimestamp,
              systimestamp,
              i_order_line.remark1,
              i_order_line.remark2,
              i_order_line.remark3,
              i_order_line.remark4,
              i_order_line.remark5,
              i_order_line.delivery_time
          );
        ELSE
          INSERT INTO i_erp_logs VALUES(i_erp_logs_seq.nextval, total_value, count_success, sysdate,
              '同步失败[' || i_order_line.delivery_line_id || ']没有找到指定头', 'T_SPM_DELIVERY_ORDER_LINE');
        END IF;
        
        -- executing udpate or insert (delivery_notice_management)
        -- 物料校验无结果，则不执行插入
        IF (item_validate > 0) THEN
          SELECT COUNT(id) INTO notice_count FROM delivery_notice_management WHERE ORDERSTATE = 1
              AND spm_po_line_id = i_order_line.spm_po_line_id AND DELIVERY_ORDER_LINE_ID = i_order_line.delivery_line_id;
          
          SELECT PRODUCT_UNIT_PRICE INTO price_value FROM t_base_spm_pur_order_lines 
              WHERE status = 1 AND SPM_PO_LINE_ID = i_order_line.spm_po_line_id;
          
          IF (notice_count > 0) THEN
            price_value := 0;
          
            UPDATE delivery_notice_management
              SET
                EXECUTOR = order_create_user,
                ORDERCODE = i_order_line.mis_po_number,
                VENDORNAME = vendor_name_value,
                ITEMCODE = i_order_line.item_code,
                ITEMDESC = i_order_line.item_desc,
                PRICE = price_value,
                ORDERQUANTITY = i_order_line.ordered_quantity,
                UNIT = i_order_line.uom_desc,
                QUANTITYREPLENISHMENT = i_order_line.delivery_quantity,
                PLANARRIVALDATE = i_order_line.delivery_plan_time,
                ACTUALARRIVALDATE = i_order_line.delivery_time
              WHERE ORDERSTATE = 1
                AND spm_po_line_id = i_order_line.spm_po_line_id AND DELIVERY_ORDER_LINE_ID = i_order_line.delivery_line_id;
          ELSE
            INSERT INTO delivery_notice_management(
                id,
                EXECUTOR,
                ORDERCODE,
                VENDORNAME,
                ITEMCODE,
                ITEMDESC,
                PRICE,
                ORDERQUANTITY,
                UNIT,
                QUANTITYREPLENISHMENT,
                PLANARRIVALDATE,
                ACTUALARRIVALDATE,
                ORDERSTATE,
                SPM_PO_LINE_ID,
                DELIVERY_ORDER_LINE_ID
            ) VALUES (
                delivery_notice_management_seq.nextval,
                order_create_user,
                i_order_line.mis_po_number,
                vendor_name_value,
                i_order_line.item_code,
                i_order_line.item_desc,
                price_value,
                i_order_line.ordered_quantity,
                i_order_line.uom_desc,
                i_order_line.delivery_quantity,
                i_order_line.delivery_plan_time,
                i_order_line.delivery_time,
                1,
                i_order_line.spm_po_line_id,
                i_order_line.delivery_line_id
            );
          END IF;
        END IF;
        
        count_success := count_success + 1;
    END LOOP;
    
    -- log
    INSERT INTO i_erp_logs VALUES(i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','T_SPM_DELIVERY_ORDER_LINE');
    EXCEPTION WHEN OTHERS THEN 
        exception_info := 'ERR: An error occurred with info:' || to_char(sqlcode) || ' ' || sqlerrm;
        INSERT INTO i_erp_logs 
          VALUES(i_erp_logs_seq.nextval, total_value,count_success, sysdate, exception_info, 'T_SPM_DELIVERY_ORDER_LINE');
    
    CLOSE cur_order_line;
    COMMIT;
end PROC_SPM_DELIVERY_ORDER_LINE;
/

