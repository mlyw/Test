create PROCEDURE "PROC_LOCATORS" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
subin_id number(19);
exception_info varchar2(3000);
cursor csr_i_locators is
select location_id, locator_code, subinventory_code, organization_id, organization_code, ou_id, erp_type, disable_date, last_update_date, import_date, seq_id, locator_name from i_erp_locators
where create_date > start_time and create_date < end_time order by erp_type desc;
i_locators csr_i_locators%rowtype;
begin
  count_success := 0;
  select count(seq_id) into total_value from i_erp_locators where create_date > start_time and create_date < end_time;
  open csr_i_locators;
  fetch csr_i_locators into i_locators;
while (csr_i_locators%found) loop
  select t.seq_id into subin_id from t_sys_erp_subinventory t where t.status = 1
  and t.subinventory_code = i_locators.subinventory_code and t.erp_type = i_locators.erp_type 
  and t.organizations_id = i_locators.organization_id;
  select count(*) into count_value from t_sys_erp_locators where LOCATOR_ID = i_locators.location_id and erp_type = i_locators.erp_type;
  if(count_value = 1 and i_locators.DISABLE_DATE is null) then
      update t_sys_erp_locators t set t.last_updated_date = sysdate,
      t.locator_code = i_locators.locator_code,
      t.erp_type = i_locators.erp_type,
      t.subinventory_id = subin_id,
      t.ou_id = i_locators.ou_id,
      t.organization_id = i_locators.organization_id,
      t.locator_name = i_locators.locator_name
      where t.locator_id = i_locators.location_id;
   elsif(count_value = 1 and i_locators.disable_date is not null) then
   update t_Sys_Erp_Locators t set t.last_updated_date = sysdate,
      t.locator_code = i_locators.locator_code,
      t.erp_type = i_locators.erp_type,
      t.subinventory_id = subin_id,
      t.ou_id = i_locators.ou_id,
      t.organization_id = i_locators.organization_id,
      t.disable_date = i_locators.disable_date,
      t.locator_name = i_locators.locator_name,
      t.status = 0
      where t.locator_id = i_locators.location_id;
 elsif(count_value = 0 and i_locators.disable_date is null) then
  insert into t_sys_erp_locators
    (seq_id, locator_id, created_date, last_updated_date, status, erp_type, locator_code, subinventory_id, ou_id, disable_date, organization_id, locator_name)
  values
    (i_locators.seq_id, i_locators.location_id, sysdate, sysdate, 1, i_locators.erp_type, i_locators.locator_code, subin_id, i_locators.ou_id, i_locators.disable_date, i_locators.organization_id, i_locators.locator_name);
end if;
fetch csr_i_locators into i_locators;
count_success:=count_success+1;
end loop;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_erp_locators');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_erp_locators');
close csr_i_locators;
commit;
end;
/

