create materialized view MV_SYS_SHM_HALL
refresh force on demand
  as
    SELECT
  /**每6个小时运行一次:START WITH SYSDATE NEXT SYSDATE + 21600/86400*/
  d.id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    h.hall_dept_name,
    sysdate builddate
  FROM t_warehouse_define d,
    t_sys_shm_hall h
  WHERE d.warehouse_define_code=h.hall_mis_code
  AND d.status                 =1
  AND h.status                 =1

/

