create PROCEDURE PROC_DELIVERY_NOTICE_LINE(itime varchar2) AS 
  total_value number(15);
  count_value number(2);
  count_success number(15);
  exception_info varchar2(3000);
  itemTypeCode varchar2(30);
  headerID number(19);
  itemSeqId number(19);
  notice_status number(19);
  cursor csr_i_spm_vendorShipping is
  select  t.SEQ_ID,
          t.VENDOR_SHIPPING_HEADER_ID,
          t.VENDOR_SHIPPING_LINE_ID,
          t.SPM_PO_HEADER_ID,
          t.SPM_PO_LINE_ID,
          t.SPM_PO_DISTRIBUTION_ID,
          t.MIS_PO_LINE_ID, 
          t.MIS_PO_DISTRIBUTION_ID,
          t.PRODUCT_ID,
          t.PRODUCT_CODE,
          t.PRODUCT_NAME,
          t.ITEM_ID,
          t.ITEM_CODE,
          t.ITEM_DESC,
          t.UOM_CODE,
          t.UOM_DESC,
          t.QUANTITY_SHIPPED,
          t.ARRIVAL_TIME,
          decode(t.UNIQE_IDENTIFIER_FLAG,'Y',1,'N',0) UNIQE_IDENTIFIER_FLAG,
          t.IMPORT_DATE,
          t.LONG_ATTRIBUTE,
          t.STRING_ATTRIBUTE,
          t.DATETIME_ATTRIBUTE,
          t.DOUBLE_ATTRIBUTE,
          t.ARRIVAL_SITE,
          t.ARRIVAL_RECIPIENT,
          t.ARRIVAL_RECIPIENT_TEL,
          t.IS_CROSS_DOCKING
  from i_spm_vendorshipping t
  where t.time=itime;
  i_vendorshipping csr_i_spm_vendorShipping%rowtype;
BEGIN
  count_success := 0;
  select count(distinct VENDOR_SHIPPING_LINE_ID) into total_value from i_spm_vendorshipping where time=itime;
  open csr_i_spm_vendorShipping;
  fetch csr_i_spm_vendorShipping into i_vendorshipping;
  while (csr_i_spm_vendorShipping%found) loop
    count_value := 0;
    select count(id) into count_value from t_lis_delivery_notice_line l where l.VENDOR_SHIPPING_LINE_ID=i_vendorshipping.VENDOR_SHIPPING_LINE_ID;
    if(count_value = 0) then
      count_value:=0;
      select count(*) into count_value from t_sys_erp_items it,t_lis_item_type ty
      where it.organization_id=ty.organazation_id
            and it.erp_type=ty.erp_type
            and it.status=1 and ty.status=1
            and it.item_id = i_vendorshipping.ITEM_ID;
      if(count_value = 0) then
        itemTypeCode:='';
      else     
        select ty.sys_code into itemTypeCode from T_Base_Spm_Pur_Order_Lines l, t_lis_item_type ty
        where l.organization_id=ty.organazation_id
          and L.Spm_Line_Id = i_vendorshipping.SPM_PO_LINE_ID;
      end if;
      --查询headerid
      count_value:=0;
      select id into headerid from t_lis_delivery_notice_header h where h.VENDOR_SHIPPING_HEADER_ID=i_vendorshipping.VENDOR_SHIPPING_HEADER_ID;
      insert into t_lis_delivery_notice_line(ID,
                HEADER_ID,
                ITEM_TYPE_CODE,
                ITEM_ID,
                ITEM_CODE,
                ITEM_DESC,
                UOM_CODE,
                UOM_DESC,
                PRODUCT_ID,
                PRODUCT_CODE,
                PRODUCT_DESC,
                DELIVERY_QUANTITY,
                QUOTA_STATUS,
                DELIVERY_DATE,
                VENDOR_SHIPPING_HEADER_ID,
                VENDOR_SHIPPING_LINE_ID,
                SPM_PO_HEADER_ID,
                SPM_PO_LINE_ID,
                SPM_PO_DISTRIBUTION_ID,
                MIS_PO_LINE_ID,
                MIS_PO_DISTRIBUTION_ID,
                UNIQE_IDENTIFIER_FLAG,
                STATUS,
                VERSION,
                CREATED_USER,
                CREATED_DATE,
                LAST_UPDATED_USER,
                LAST_UPDATED_DATE,
                ARRIVAL_SITE,
                ARRIVAL_RECIPIENT,
                ARRIVAL_RECIPIENT_TEL,
                IS_CROSS_DOCKING)
      values(seq_lis_delivery_notice_line.nextval,headerid,itemTypeCode,
            (select max(L.Item_Id) from T_Base_Spm_Pur_Order_Lines l where L.Spm_Line_Id = i_vendorshipping.Spm_Po_Line_Id
              and L.Spm_Po_Header_Id=i_vendorshipping.SPM_PO_HEADER_ID),
            i_vendorshipping.ITEM_CODE,
            i_vendorshipping.ITEM_DESC,i_vendorshipping.UOM_CODE,i_vendorshipping.UOM_DESC,
            i_vendorshipping.PRODUCT_ID,i_vendorshipping.PRODUCT_CODE,i_vendorshipping.PRODUCT_NAME,
            i_vendorshipping.QUANTITY_SHIPPED,-2,
            i_vendorshipping.ARRIVAL_TIME,
            i_vendorshipping.VENDOR_SHIPPING_HEADER_ID,
            i_vendorshipping.VENDOR_SHIPPING_LINE_ID,
            i_vendorshipping.SPM_PO_HEADER_ID,
            i_vendorshipping.SPM_PO_DISTRIBUTION_ID,--SPM_PO_DISTRIBUTION_ID 对应订单 spm_po_line_id
            0,
            i_vendorshipping.MIS_PO_LINE_ID,
            i_vendorshipping.MIS_PO_DISTRIBUTION_ID,
            i_vendorshipping.UNIQE_IDENTIFIER_FLAG,
            1,1,'12345678',sysdate,'12345678',sysdate,
            i_vendorshipping.ARRIVAL_SITE,
            i_vendorshipping.ARRIVAL_RECIPIENT,
            i_vendorshipping.ARRIVAL_RECIPIENT_TEL,
            i_vendorshipping.IS_CROSS_DOCKING
      );
    else 
      select h.notice_status into notice_status from T_Lis_Delivery_Notice_Header h where H.Vendor_Shipping_Header_Id=i_vendorshipping.VENDOR_SHIPPING_HEADER_ID;
      /*
        如果已冻结或完成不更新
      */
      if( 1 = notice_status) then
        update t_lis_delivery_notice_line l
        set l.VERSION=l.VERSION+1,
            l.LAST_UPDATED_DATE=sysdate,
            l.ITEM_TYPE_CODE = itemTypeCode,
            l.ITEM_ID=(select L.Item_Id from T_Base_Spm_Pur_Order_Lines l where L.Spm_Line_Id = i_vendorshipping.Spm_Po_Line_Id
              and L.Spm_Po_Header_Id=i_vendorshipping.SPM_PO_HEADER_ID),
            l.ITEM_CODE=i_vendorshipping.ITEM_CODE,
            l.ITEM_DESC=i_vendorshipping.ITEM_DESC,
            l.UOM_CODE=i_vendorshipping.UOM_CODE,
            l.UOM_DESC=i_vendorshipping.UOM_DESC,
            l.PRODUCT_ID=i_vendorshipping.PRODUCT_ID,
            l.PRODUCT_CODE=i_vendorshipping.PRODUCT_CODE,
            l.PRODUCT_DESC=i_vendorshipping.PRODUCT_NAME,
            l.DELIVERY_QUANTITY=i_vendorshipping.QUANTITY_SHIPPED,
            l.DELIVERY_DATE=i_vendorshipping.ARRIVAL_TIME,
            l.SPM_PO_HEADER_ID=i_vendorshipping.SPM_PO_HEADER_ID,
            l.SPM_PO_LINE_ID=i_vendorshipping.SPM_PO_DISTRIBUTION_ID,
            --l.SPM_PO_DISTRIBUTION_ID=i_vendorshipping.SPM_PO_DISTRIBUTION_ID,
            l.MIS_PO_LINE_ID=i_vendorshipping.MIS_PO_LINE_ID,
            l.MIS_PO_DISTRIBUTION_ID=i_vendorshipping.MIS_PO_DISTRIBUTION_ID,
            l.UNIQE_IDENTIFIER_FLAG=i_vendorshipping.UNIQE_IDENTIFIER_FLAG,
            l.ARRIVAL_SITE=i_vendorshipping.ARRIVAL_SITE,
            l.ARRIVAL_RECIPIENT=i_vendorshipping.ARRIVAL_RECIPIENT,
            l.ARRIVAL_RECIPIENT_TEL=i_vendorshipping.ARRIVAL_RECIPIENT_TEL,
            l.IS_CROSS_DOCKING=i_vendorshipping.IS_CROSS_DOCKING
        where l.VENDOR_SHIPPING_LINE_ID=i_vendorshipping.VENDOR_SHIPPING_LINE_ID;
      end if;
    end if;
    fetch csr_i_spm_vendorShipping into i_vendorshipping;
    count_success:=count_success+1;
  end loop;
  --插入日志
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_lis_delivery_notice_line');
  exception when others then
      exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
    insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_lis_delivery_notice_line');
  commit;
END PROC_DELIVERY_NOTICE_LINE;
/

