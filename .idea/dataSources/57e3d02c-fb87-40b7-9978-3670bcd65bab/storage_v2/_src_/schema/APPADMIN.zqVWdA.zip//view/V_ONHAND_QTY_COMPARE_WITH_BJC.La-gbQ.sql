create view V_ONHAND_QTY_COMPARE_WITH_BJC as
  select "ITEM_CODE","MIS_PIC_CODE","ORGANIZATION_CODE","SUBINVENTORY_CODE","LOCATOR_CODE","MIS_ONHAND_QUANTITY","LIS_ONHAND_QUANTITY","MISTOLIS_SUBTRACT_QUANTITY" from v_onhand_qty_compare_with_mis t where (t.misTolis_subtract_quantity is null or t.misTolis_subtract_quantity!=0) and t.organization_code='BJC' and t.subinventory_code not in ('C990')
/

