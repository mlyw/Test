create materialized view MV_T_LIS_ORDER_DELIVERY_NOTICE
refresh force on demand
  as
    SELECT
  /**每小时运行一次:START WITH SYSDATE NEXT SYSDATE + 3600/86400 查询订单到货统计表信息**/
    vpo.po_mis_po_number,
    vpo.po_spm_po_desc,
    vpo.po_agent_id,
    vpo.po_vendor_id,
    vpo.po_vendor_name,
    vpo.po_spm_po_header_id,
    vpo.po_erp_type,
    vpo.po_ou_id,
    vpo.po_mis_po_line_num,
    i.concatenated_segments po_item_category_code,
    i.category_description po_item_category_desc,
    vpo.po_item_code,
    vpo.po_item_desc,
    vpo.po_uom_desc,
    vpo.po_product_unit_price,
    vpo.pol_quantity_ordered,
    vpo.pol_quantity_ordered_account,
    vpo.pol_quantity_received,
    vpo.pol_quantity_received_account,
    vpo.pol_quantity_receivable,
    vpo.pol_quantity_receiable_account,
    vpo.pol_is_need_check,
    vpo.pol_spm_po_line_id,
    vpo.pol_organization_id,
    (o.organization_code
    || ' '
    || o.organization_name) pol_org_name,
    NVL(pro.ret_return_quantity,0) po_return_quantity,
    (NVL(pro.ret_return_quantity,0)*NVL(vpo.po_product_unit_price,0)) po_return_account,
    u.employee_name po_cgy ,
    prto.rec_receipt_date,
    prto.rec_receipt_pic_code,
    prto.rec_current_receive_quantity,
    prto.rec_receipt_user_id,
    prto.rec_employee_name,
    prto.rec_mis_pic_code,
    prto.rec_locator_id,
    prto.rec_locator_code,
    sysdate builddate
  FROM v_Spm_Pur_Order_info vpo
  LEFT JOIN v_spm_pur_order_return_info pro
  ON pro.ret_spm_po_header_id=vpo.po_spm_po_header_id
  LEFT JOIN v_spm_pur_order_receipt_info prto
  ON prto.rec_spm_po_line_id=vpo.pol_spm_po_line_id
  LEFT JOIN t_lis_user u
  ON vpo.po_agent_id=u.employee_number
  LEFT JOIN t_sys_erp_items i
  ON vpo.item_id=i.seq_id
  LEFT JOIN t_sys_erp_organizations o
  ON vpo.pol_organization_id=o.organization_id

/

