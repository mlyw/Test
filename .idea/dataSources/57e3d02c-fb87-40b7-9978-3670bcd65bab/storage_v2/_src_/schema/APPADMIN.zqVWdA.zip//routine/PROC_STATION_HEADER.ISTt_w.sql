create PROCEDURE proc_station_header (start_time timestamp,end_time timestamp) as

total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
version_value number(19); 

cursor csr_i_station_header is
select seq_id,project_code, mis_no,project_name,string_attr,long_attr,datetime_attr,double_attr,import_date from I_EPM_STATION_HEADER  where import_date between start_time and end_time;

i_station_header csr_i_station_header%rowtype;

begin
  count_success := 0;
  count_value:= 0;
  total_value:= 0;
  version_value:= 0;
  
  select count(seq_id) into total_value from I_EPM_STATION_HEADER where import_date between start_time and  end_time;
   
  open csr_i_station_header;
  
  fetch csr_i_station_header into i_station_header;
  
  while (csr_i_station_header%found) loop
      select count(seq_id) into count_value from T_SYS_EPM_STATION_HEADER where project_code = i_station_header.project_code and mis_no= i_station_header.mis_no;
        
      if(i_station_header.seq_id is not null) then
          if(count_value > 0) then
              select t.version into version_value from T_SYS_EPM_STATION_HEADER  t where t.project_code = i_station_header.project_code and mis_no= i_station_header.mis_no;
          elsif(count_value = 0 ) then
              version_value := 1;
          end if;
      end if;
  
  if(count_value = 1) then
    update T_SYS_EPM_STATION_HEADER set 
        project_name      = i_station_header.project_name,
        string_attr       = i_station_header.string_attr,
        long_attr         = i_station_header.long_attr,
        datetime_attr     = i_station_header.datetime_attr,
        double_attr       = i_station_header.double_attr,
        last_updated_date = sysdate,
        version = version_value + 1
    where project_code = i_station_header.project_code and mis_no= i_station_header.mis_no;
 else 
    insert into T_SYS_EPM_STATION_HEADER
    (
        seq_id,
        project_code,
        mis_no,
        project_name,
        string_attr,
        long_attr,
        datetime_attr,
        double_attr,
        created_user,
        created_date,
        last_updated_user,
        last_updated_date,
        version,
        status
      )
      values
      (
        SEQ_EPM_STATION.nextval,
        i_station_header.project_code,
        i_station_header.mis_no,
        i_station_header.project_name,
        i_station_header.string_attr,
        i_station_header.long_attr,
        i_station_header.datetime_attr,
        i_station_header.double_attr,
        '',
        sysdate,
        '',
        sysdate,
        version_value,
        1
      );
end if;

  fetch csr_i_station_header into i_station_header;
    count_success:=count_success+1;
  end loop;
close csr_i_station_header;


--log
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','T_SYS_EPM_STATION_HEADER');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_EPM_STATION_HEADER');
commit;
end;
/

