create FUNCTION "ONHAND_BY_EMPLOYEE"(v_item_seqid      number,
                                                v_pic_code        varchar2,
                                                v_employee_number varchar2,
                                                v_receipt_num     number,
                                                organizationId    number)
  return float as
  v_onhand_number number(19, 5);
  v_freeze_number number(19, 5);
BEGIN
  select sum(nvl(rs.reserve_quantity, 0))
    into v_freeze_number
    from t_wh_current_onhand_quantity wh
   inner join T_SYS_ITEM_RESEREVE_INFO rs
      on rs.onhand_id = wh.id
     and sysdate between rs.reserve_start_day and rs.reserve_end_day
     and rs.status = 1
   where wh.item_id = v_item_seqid
     and wh.receipt_pic_code = v_pic_code
     and wh.status = 1
     and wh.onhand_quantity > 0
     and wh.warehouse_define_id in
         (select a.id
            from t_warehouse_define a
           where a.mis_io_id = organizationId)
     and exists (select 1
            from t_warehouse_access_user a,
                 t_warehouse_define      d,
                 t_warehouse_category    wc
           where a.WAREHOUSE_DEFINE_ID = wh.warehouse_define_id
             and d.id = a.warehouse_define_id
             and wc.id = d.category_id
             and wc.code in ('01', '02','04')
             and wc.status = 1
             and a.EMPLOY_NUMBER = v_employee_number
             and d.is_storage = 'Y');
  dbms_output.put('v_freeze_number=' || v_freeze_number);
  select sum(nvl(wh.onhand_quantity, 0))
    into v_onhand_number
    from t_wh_current_onhand_quantity wh
   where wh.item_id = v_item_seqid
     and wh.receipt_pic_code = v_pic_code
     and wh.status = 1
     and wh.onhand_quantity > 0
    /* and wh.warehouse_define_id in
         (select a.id
            from t_warehouse_define a
           where a.mis_io_id = organizationId)*/
     and wh.warehouse_define_id in
         (select a.id
            from t_warehouse_define a
           where a.mis_io_id = organizationId)
     and exists (select 1
            from t_warehouse_access_user a,
                 t_warehouse_define      d,
                 t_warehouse_category    wc
           where a.warehouse_define_id = wh.warehouse_define_id
             and d.id = a.warehouse_define_id
             and wc.id = d.category_id
             and wc.code in ('01', '02','04')
             and wc.status = 1
             and a.EMPLOY_NUMBER = v_employee_number
             and d.is_storage = 'Y');
  dbms_output.put('v_onhand_number=' || v_onhand_number);

  v_onhand_number := nvl(v_onhand_number, 0) - nvl(v_freeze_number, 0);
  dbms_output.put('v_onhand_number=' || v_onhand_number);
  dbms_output.put('v_receipt_num=' || v_receipt_num);
  IF v_onhand_number > nvl(v_receipt_num, 0.0) THEN
    v_onhand_number := v_receipt_num;
  END IF;
  RETURN nvl(v_onhand_number, 0);

END;
/

