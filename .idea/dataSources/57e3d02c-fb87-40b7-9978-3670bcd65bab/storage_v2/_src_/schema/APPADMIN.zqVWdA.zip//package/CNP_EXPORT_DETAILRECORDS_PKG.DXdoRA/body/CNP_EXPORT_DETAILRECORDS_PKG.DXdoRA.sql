create package body cnp_export_detailrecords_pkg is
 
procedure proc_inventory_detail_date(item_codee in varchar2,warehouse_id in varchar2,checkDate in varchar2,endDate in varchar2,inventory_detail out cur_dynamic_checking)
as
begin

  delete from TEMP_DETAIL_EXPORT_CNP;
  delete from temp_dynamic_warehouse;
--迭代仓库向临时表中插数据
 insert into temp_dynamic_warehouse(col_warehouse_id)
  select t.id
    from t_warehouse_define t
    left join t_warehouse_category ware_cate
      on t.category_id = ware_cate.id
   where t.status = 1
     and ware_cate.code in('01','02')
     and ware_cate.status = 1
   start with t.id = warehouse_id
  connect by prior t.id = t.parent_warehouse_id;
--select * from t_warehouse_define where id=299

--直发和入库
   insert into TEMP_DETAIL_EXPORT_CNP(
      inventory_detail_excle_id, acc_cfm_imptomis_date, confirm_date,item_code, item_name,
      uom_code, source_warehouse_define_code, source_warehouse_define_name, source_locator_code,
      target_WAREHOUSE_DEFINE_CODE, target_WAREHOUSE_DEFINE_NAME, target_locator_code,
      trf_out_cfm_quty, product_unit_price, transaction_amount, transaction_type,CARD_NUMBER_FROM,CARD_NUMBER_TO,Line_Status,
      out_ord_code, project_code, project_name, created_user, operator,mis_pic_code, io_code,order_desc,
      vendor_name, spm_po_code, product_id, product_code, product_desc, product_category_id,dept_name_level2)
    select T_INV_DETAIL_EXCLE.NEXTVAL,export.import_date, export.receipt_confirm_date, export.item_code, export.item_desc,
           export.uom_desc, export.warehouse_define_code, export.warehouse_define_name,
           export.locator_code, '','','',export.current_receive_quantity, export.product_unit_price,
           export.received_price, export.is_straight,'','',export.order_status, export.receipt_order_code,
           export.project_code, export.project_name, export.created_user, export.operator,mis_pic_code, io_code,order_desc,
           export.vendor_name, export.spm_po_code, export.product_id, export.product_code, export.product_desc, export.product_category_id,export.dept_name_level2
     from (
        select
            d.warehouse_define_code as warehouse_define_code,
            d.warehouse_define_name as warehouse_define_name,
            l.item_code as item_code,
            l.item_desc as item_desc,
            l.uom_desc as uom_desc,
            l.locator_code as locator_code,
            l.current_receive_quantity as current_receive_quantity,
            l.product_unit_price as product_unit_price,
            l.current_receive_quantity*l.product_unit_price as received_price,
            ---to_char(receipt_confirm_date,'yyyy-MM-dd') as receipt_confirm_date,
            l.accounting_confrim_import_date as import_date,--导入mis时间
            receipt_confirm_date as receipt_confirm_date,--确认接收时间
            case h.is_straight when 1 then '采购接收直发' else '采购接收入库' end as is_straight,
            case h.order_status when 4 then '已接收' when 5 then '已完成' else null end as order_status,
            h.receipt_order_code as receipt_order_code,
            p.project_code as project_code,
            p.project_name as project_name,
            (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=l.receipt_order_line_uid) as created_user,
            (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=l.accounting_confirm_by_uid) as operator,
            (select dept.dept_name from t_lis_dept dept where dept.id in (select d.parent_id from t_lis_dept d where d.dept_code in (select ou.ou_dept_code from t_lis_ouuser ou where ou.ou_employee_number = l.receipt_order_line_uid)) and (select ds.parent_id from t_lis_dept ds where id = dept.parent_id) is null and dept.parent_id is not null) dept_name_level2,
            d.mis_io_code as io_code,
            l.mis_pic_code as mis_pic_code,h.spm_po_desc as order_desc,
            poh.vendor_name as vendor_name,
            h.spm_po_code||'/'||poh.mis_po_number as spm_po_code,
            l.product_id product_id,
            l.product_code product_code,
            l.product_desc product_desc,
            l.product_category_id product_category_id
          from t_receiptorder_lineinfo l, t_receiptorder_headerinfo h ,t_sys_erp_projects p ,t_warehouse_define d, t_base_spm_pur_order_headers poh
         where l.receipt_order_id=h.id and h.is_cnp = 'Y' and l.receipt_order_line_sid=2 and d.id=l.warehouse_receive_id
               and l.item_code = (case when nvl(item_codee, '*') = '*' then l.item_code else item_codee end)
               and p.seq_id(+)=l.project_id and l.status=1 and h.status=1
               and l.receipt_confirm_date between to_date(checkDate,'yyyy-MM-dd hh24:mi:ss') and to_date(endDate,'yyyy-MM-dd hh24:mi:ss')
               and l.warehouse_receive_id = warehouse_id
               and h.po_id = poh.spm_po_header_id
             ) export;


--出库
   insert into TEMP_DETAIL_EXPORT_CNP(
        inventory_detail_excle_id, acc_cfm_imptomis_date,confirm_date, item_code, item_name,
        uom_code, source_warehouse_define_code, source_warehouse_define_name, source_locator_code,
        target_WAREHOUSE_DEFINE_CODE, target_WAREHOUSE_DEFINE_NAME, target_locator_code,
        trf_out_cfm_quty, product_unit_price, transaction_amount, transaction_type,CARD_NUMBER_FROM,CARD_NUMBER_TO,Line_Status,
        out_ord_code, project_code, project_name,created_user,operator,mis_pic_code, io_code,order_desc,
        product_id, product_code, product_desc, product_category_id, dept_name_level2)
      select T_INV_DETAIL_EXCLE.NEXTVAL, export.acc_cfm_imptomis_date, export.confirm_date,export.item_code, export.item_name,
             export.uom_desc, export.warehouse_define_code, export.warehouse_define_name,
             export.locator_code, '','','',export.trf_out_cfm_quty, export.product_unit_price_ex_tax,
             export.received_price, '出库',export.CARD_NUMBER_FROM,export.CARD_NUMBER_TO,export.ASGN_LN_STATUS,export.out_ord_code,
             export.project_code, export.project_name,created_user,operator,mis_pic_code, io_code,order_desc,
             export.product_id, export.product_code, export.product_desc, export.product_category_id, export.dept_name_level2
      from(
          Select Info.Acc_cfm_imptomis_date as acc_cfm_imptomis_date ,--导mis时间
                 Info.asgn_time as confirm_date,--分配时间
            Item.Item_code as item_code ,
            Item.Item_name as item_name ,
            Item.Uom_Desc as uom_desc ,
            Ware.Warehouse_define_code as warehouse_define_code ,
            Ware.Warehouse_define_name as warehouse_define_name ,
            Info.LOCATOR_CODE as locator_code ,
            Info.Trf_out_cfm_quty as trf_out_cfm_quty ,
            ln.CARD_NUMBER_FROM as CARD_NUMBER_FROM,
            ln.CARD_NUMBER_TO as CARD_NUMBER_TO,case Info.ASGN_LN_STATUS when 1 then '完成' when 5 then '已收货' end  as ASGN_LN_STATUS,
            Nvl(Onhand.Product_unit_price_ex_tax,0) as product_unit_price_ex_tax,
            Nvl(Round((Info.Trf_out_cfm_quty*Onhand.Product_unit_price_ex_tax),5),0) as received_price ,
            Transactiontype.Transaction_type as transaction_type ,
            H.Out_ord_code as out_ord_code ,
            H.Project_code as project_code,
            H.Project_name as project_name,
            (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=H.Created_User) as created_user,
            (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=DECODE(null,Info.ACC_CFM_BYUSER_ID,Info.A_L_C_P_BYUSER_ID,Info.ACC_CFM_BYUSER_ID)) as operator,
            (select dept.dept_name from t_lis_dept dept where dept.id in (select d.parent_id from t_lis_dept d where d.dept_code in (select ou.ou_dept_code from t_lis_ouuser ou where ou.ou_employee_number = H.Created_User)) and (select ds.parent_id from t_lis_dept ds where id = dept.parent_id) is null and dept.parent_id is not null) dept_name_level2,
            Info.mis_pic_code as mis_pic_code,Ware.Mis_Io_Code as io_code, H.Ord_Desc as order_desc,
            ln.prod_id product_id, ln.prod_code product_code, ln.prod_name product_desc, ln.prod_ctgr_id product_category_id
          From
            (Select Trf_out_cfm_quty, Item_id, Productid,LOCATOR_CODE,
              Warehouseid , Warehouse_onhand_id,  Out_ord_id,  outlninfo_id,Acc_cfm_imptomis_date,asgn_time,ACC_CFM_BYUSER_ID,A_L_C_P_BYUSER_ID,MIS_PIC_CODE,CARD_NUMBER_FROM,CARD_NUMBER_TO,ASGN_LN_STATUS
            From T_out_notmk 
            Where (Asgn_ln_status=1 or Asgn_ln_status=5 ) And Status=1
              And ACC_CFM_DATE between to_date(checkDate,'yyyy-MM-dd hh24:mi:ss') and to_date(endDate,'yyyy-MM-dd hh24:mi:ss')
            ) Info
            Join T_sys_erp_items Item On Item.Seq_id = Info.Item_id
            Join T_wh_current_onhand_quantity Onhand On Info.Warehouse_onhand_id=Onhand.Id
            Join T_warehouse_define Ware On Info.Warehouseid=Ware.Id
            Join T_out_hd H On H.Id=Info.Out_ord_id and H.item_type_id=2
            Join t_out_ln ln on ln.outhdinfo_id = H.Id
            Join (Select h1.id,(
                          Case
                            When H1.Item_type_id=1
                            Then '工程物资出库'
                            When H1.Item_type_id=2
                            Then '市场物资-CNP出库'
                            When H1.Item_type_id=3
                            Then '备品备件出库'
                            When H1.Item_type_id=4
                            Then '杂品出库'
                            When H1.Item_type_id=5
                            Then '工程物资杂项发放'
                            When H1.Item_type_id=6
                            Then '市场物资-其他出库'
                            Else Null
                          End) Transaction_type
                        From T_out_hd H1 
                        Where H1.Status=1
                        ) Transactiontype On Transactiontype.id=h.id
            Where H.Status=1 and ln.id=info.outlninfo_id and ln.item_code = (case when nvl(item_codee, '*') = '*' then ln.item_code else item_codee end)  and exists (select 1 from temp_dynamic_warehouse where Ware.id = col_warehouse_id)
          ) export;


--退库
    insert into TEMP_DETAIL_EXPORT_CNP(
            inventory_detail_excle_id, acc_cfm_imptomis_date, confirm_date,item_code, item_name,
            uom_code, source_warehouse_define_code, source_warehouse_define_name, source_locator_code,
            target_WAREHOUSE_DEFINE_CODE, target_WAREHOUSE_DEFINE_NAME, target_locator_code,
            trf_out_cfm_quty, product_unit_price, transaction_amount, transaction_type,CARD_NUMBER_FROM,CARD_NUMBER_TO,Line_Status,
            out_ord_code, project_code, project_name,created_user,operator,mis_pic_code, io_code,order_desc,
            product_id, product_code, product_desc, product_category_id, dept_name_level2)
          select T_INV_DETAIL_EXCLE.NEXTVAL, export.transcationdate, export.confirm_date,export.item_code, export.item_name,
                 export.unit, export.warehouse_define_code, export.warehouse_define_name,
                 export.locator_code, '','','',export.quty, export.prouint_price,
                 export.received_price, '退库', export.backordercode,export.CARD_NUMBER_FROM,export.CARD_NUMBER_TO,'',
                 export.project_code, export.project_name,export.created_user,export.operator, export.mis_pic_code, export.io_code,order_desc,
                 export.product_id, export.product_code, export.product_desc, export.product_category_id, export.dept_name_level2
          from(
             select bckln.item_code as item_code,  bckln.item_name as item_name,  bckln.unit as unit,
                w.warehouse_define_code as warehouse_define_code , w.warehouse_define_name as warehouse_define_name ,
                '' as fromlocator,  bckln.locator_code as locator_code,  bckln.acpt_cfm_quty as quty,
                bckln.card_number_from as CARD_NUMBER_FROM,bckln.card_number_to as CARD_NUMBER_TO,
                bckln.prouintprice as prouint_price, bckln.acpt_cfm_quty*bckln.prouintprice as received_price,
                hd.sendmis_date as transcationdate,  hd.warereceiver_date as confirm_date, hd.back_order_desc as order_desc,
                CASE backtypeid  WHEN 1 THEN '工程物资'
                  WHEN 2 THEN '市场物资'
                  WHEN 3 THEN '备品备件'
                  WHEN 4 THEN '杂品'
                  WHEN 5 THEN '工程物资杂项接收' ELSE '无来源' END  as transaction_type,
                'move order' as sourcetype,
                CASE bckln.backorderflag  WHEN 0 THEN 'LIS出库记录'
                  WHEN 1 THEN 'MIS历史出库记录'
                  WHEN 2 THEN '手工'
                 ELSE '无来源' END  as transaction_type,
                hd.back_order_code backordercode,  'move desc' as movedesc,
                hd.project_code as project_code, hd.project_name as project_name,w.mis_io_code as io_code, bckln.mis_pic_code as mis_pic_code,
                (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=hd.created_user) as created_user,
                (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=bckln.acccfm_by_userid) as operator,
                (select dept.dept_name from t_lis_dept dept where dept.id in (select d.parent_id from t_lis_dept d where d.dept_code in (select ou.ou_dept_code from t_lis_ouuser ou where ou.ou_employee_number = hd.created_user)) and (select ds.parent_id from t_lis_dept ds where id = dept.parent_id) is null and dept.parent_id is not null) dept_name_level2,
                bckln.productid product_id, bckln.product_code product_code, bckln.product_name product_desc, bckln.productcategoryid product_category_id
                from T_BCK_LN bckln  join T_BCK_HD hd on bckln.bckHdInfo_id = hd.id
                join t_warehouse_define w on bckln.warehousebacktoid=w.id
                 and bckln.item_code = (case when nvl(item_codee, '*') = '*' then bckln.item_code else item_codee end)
                 and (hd.orderstatus = 50 or hd.orderstatus = 60)
                 and (bckln.line_status_id = 40 or bckln.line_status_id = 50 or bckln.line_status_id = 60)
                 and hd.status=1 and bckln.status=1 and hd.backtypeid = 2
                 and exists (select 1 from temp_dynamic_warehouse where w.id = col_warehouse_id)
                 and hd.warereceiver_date between to_date(checkDate,'yyyy-MM-dd hh24:mi:ss') and to_date(endDate,'yyyy-MM-dd hh24:mi:ss')
          ) export;
          
--报废卡退库
       insert into TEMP_DETAIL_EXPORT_CNP(
            inventory_detail_excle_id, acc_cfm_imptomis_date, confirm_date,item_code, item_name,
            source_warehouse_define_code, source_warehouse_define_name,
            target_WAREHOUSE_DEFINE_CODE, target_WAREHOUSE_DEFINE_NAME, 
            trf_out_cfm_quty, transaction_type,Line_Status,
            out_ord_code,created_user,operator,mis_pic_code, io_code,order_desc,dept_name_level2)
            select T_INV_DETAIL_EXCLE.NEXTVAL,export.accounted_date,export.confirm_date,export.item_code,export.item_name,export.source_warehouse_define_code,
            export.source_warehouse_define_name,export.receive_warehouse_define_code,export.receive_warehouse_define_name,export.actual_qty,'报废卡退库',
            export.order_line_status,export.order_code,export.created_user,export.operator,
            export.mis_pic_num,'BJC',export.order_desc,export.dept_name_level2            
            from (
                 select 'BJC' as io_code,sei.item_code as item_code,sei.item_name as item_name,wd.warehouse_define_code as source_warehouse_define_code,wd.warehouse_define_name as source_warehouse_define_name,
                 wd2.warehouse_define_code as receive_warehouse_define_code,wd2.warehouse_define_name as receive_warehouse_define_name,rfl.actual_qty as actual_qty,rfl.mis_pic_num as mis_pic_num,
                 case rfl.order_line_status when 1 then '审批中' when 4 then '待收货' when 5 then '待确认接收' when 6 then '待入账' when 7 then '已完成' when 8 then '已取消' else null end as order_line_status,
                 (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=hd.created_user) as created_user,
                 (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=rfl.accounted_user) as operator,
                 (select dept.dept_name from t_lis_dept dept where dept.id in (select d.parent_id from t_lis_dept d where d.dept_code in (select ou.ou_dept_code from t_lis_ouuser ou where ou.ou_employee_number = HD.Created_User)) and (select ds.parent_id from t_lis_dept ds where id = dept.parent_id) is null and dept.parent_id is not null) dept_name_level2,            
            
                 rfl.receive_date as confirm_date,rfl.accounted_date as accounted_date,hd.created_dept_id as created_dept_id,hd.order_code as order_code, hd.order_desc as order_desc from t_refundwastecard_line rfl left join t_refundwastecard_head hd on rfl.head_id = hd.seq_id
                 left join t_sys_erp_items sei on rfl.item_id = sei.seq_id 
                 left join t_warehouse_define wd on rfl.sub_wd_id = wd.id  -- 来源子库
                 left join t_warehouse_define wd2 on rfl.receive_wd_id = wd2.id --C999 
                 where sei.item_code = (case when nvl(item_codee, '*') = '*' then sei.item_code else item_codee end) and hd.status = 1 and rfl.status = 1 and rfl.order_line_status = 7
                 and rfl.receive_wd_id = warehouse_id and rfl.receive_confirm_date between to_date(checkDate,'yyyy-MM-dd hh24:mi:ss') 
                 and to_date(endDate,'yyyy-MM-dd hh24:mi:ss')            
            ) export;
     
       open inventory_detail for select * from TEMP_DETAIL_EXPORT_CNP c order by c.out_ord_code;
       commit;
end;
--根据类型分组， 查询出单号数量
procedure proc_inventory_detail_count(warehouse_id in varchar2,checkDate in varchar2,endDate in varchar2, temp_count out cur_temp_count)
as
begin

-- delete from TEMP_DETAIL_EXPORT_CNP;
-- delete from temp_dynamic_warehouse;
--迭代仓库向临时表中插数据
 insert into temp_dynamic_warehouse(col_warehouse_id)
  select t.id
    from t_warehouse_define t
    left join t_warehouse_category ware_cate
      on t.category_id = ware_cate.id
   where t.status = 1
     and ware_cate.code = '01'
     and ware_cate.status = 1
   start with t.id = warehouse_id
  connect by prior t.id = t.parent_warehouse_id;
--select * from t_warehouse_define where id=299

--直发和入库
    insert into TEMP_DETAIL_EXPORT_CNP(
      inventory_detail_excle_id, acc_cfm_imptomis_date, confirm_date,item_code, item_name,
      uom_code, source_warehouse_define_code, source_warehouse_define_name, source_locator_code,
      target_WAREHOUSE_DEFINE_CODE, target_WAREHOUSE_DEFINE_NAME, target_locator_code,
      trf_out_cfm_quty, product_unit_price, transaction_amount, transaction_type,
      out_ord_code, project_code, project_name, created_user, operator,mis_pic_code, io_code,order_desc,
      vendor_name, spm_po_code)
    select T_INV_DETAIL_EXCLE.NEXTVAL,export.import_date, export.receipt_confirm_date, export.item_code, export.item_desc,
           export.uom_desc, export.warehouse_define_code, export.warehouse_define_name,
           export.locator_code, '','','',export.current_receive_quantity, export.product_unit_price,
           export.received_price, export.is_straight, export.receipt_order_code,
           export.project_code, export.project_name, export.created_user, export.operator,mis_pic_code, io_code,order_desc,
           export.vendor_name, export.spm_po_code
    from (
        select
            d.warehouse_define_code as warehouse_define_code,
            d.warehouse_define_name as warehouse_define_name,
            l.item_code as item_code,
            l.item_desc as item_desc,
            l.uom_desc as uom_desc,
            l.locator_code as locator_code,
            l.current_receive_quantity as current_receive_quantity,
            l.product_unit_price as product_unit_price,
            l.current_receive_quantity*l.product_unit_price as received_price,
            ---to_char(receipt_confirm_date,'yyyy-MM-dd') as receipt_confirm_date,
            l.accounting_confrim_import_date as import_date,
            receipt_confirm_date as receipt_confirm_date,
            case h.is_straight when 1 then '采购接收直发' else '采购接收入库' end as is_straight,
            h.receipt_order_code as receipt_order_code,
            p.project_code as project_code,
            p.project_name as project_name,
            (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=l.receipt_order_line_uid) as created_user,
            (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=l.accounting_confirm_by_uid) as operator,
            d.mis_io_code as io_code,
            l.mis_pic_code as mis_pic_code,h.spm_po_desc as order_desc,
            poh.vendor_name as vendor_name,
            h.spm_po_code||'/'||poh.mis_po_number as spm_po_code
          from t_receiptorder_lineinfo l, t_receiptorder_headerinfo h ,t_sys_erp_projects p ,t_warehouse_define d, t_base_spm_pur_order_headers poh
         where l.receipt_order_id=h.id and l.receipt_order_line_sid=2 and d.id=l.warehouse_receive_id
               and p.seq_id(+)=l.project_id and l.status=1 and h.status=1
               and l.receipt_confirm_date between to_date(checkDate,'yyyy-MM-dd hh24:mi:ss') and to_date(endDate,'yyyy-MM-dd hh24:mi:ss')
               and exists (select 1 from temp_dynamic_warehouse where d.id = col_warehouse_id)
               and h.po_id = poh.spm_po_header_id
             ) export;


--出库
   insert into TEMP_DETAIL_EXPORT_CNP(
        inventory_detail_excle_id, acc_cfm_imptomis_date,confirm_date, item_code, item_name,
        uom_code, source_warehouse_define_code, source_warehouse_define_name, source_locator_code,
        target_WAREHOUSE_DEFINE_CODE, target_WAREHOUSE_DEFINE_NAME, target_locator_code,
        trf_out_cfm_quty, product_unit_price, transaction_amount, transaction_type,
        out_ord_code, project_code, project_name,created_user,operator,mis_pic_code, io_code,order_desc)
      select T_INV_DETAIL_EXCLE.NEXTVAL, export.acc_cfm_imptomis_date, export.confirm_date,export.item_code, export.item_name,
             export.uom_desc, export.warehouse_define_code, export.warehouse_define_name,
             export.locator_code, '','','',export.trf_out_cfm_quty, export.product_unit_price_ex_tax,
             export.received_price, '出库', export.out_ord_code,
             export.project_code, export.project_name,created_user,operator,mis_pic_code, io_code,order_desc
      from(
          Select Info.Acc_cfm_imptomis_date as acc_cfm_imptomis_date ,
                 Info.ASGN_TIME as confirm_date,
            Item.Item_code as item_code ,
            Item.Item_name as item_name ,
            Item.Uom_Desc as uom_desc ,
            Ware.Warehouse_define_code as warehouse_define_code ,
            Ware.Warehouse_define_name as warehouse_define_name ,
            Info.LOCATOR_CODE as locator_code ,
            Info.Trf_out_cfm_quty as trf_out_cfm_quty ,
            Nvl(Onhand.Product_unit_price_ex_tax,0) as product_unit_price_ex_tax,
            Nvl(Round((Info.Trf_out_cfm_quty*Onhand.Product_unit_price_ex_tax),5),0) as received_price ,
            Transactiontype.Transaction_type as transaction_type ,
            H.Out_ord_code as out_ord_code ,
            H.Project_code as project_code,
            H.Project_name as project_name,
            (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=H.Created_User) as created_user,
            (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=decode(null,Info.ACC_CFM_BYUSER_ID,Info.TRF_OUT_CFM_BYUSER_ID,Info.ACC_CFM_BYUSER_ID)) as operator,
            Info.mis_pic_code as mis_pic_code,Ware.Mis_Io_Code as io_code, H.Ord_Desc as order_desc
          From
            (Select Trf_out_cfm_quty, Item_id, Productid,LOCATOR_CODE,
              Warehouseid , Warehouse_onhand_id,  Out_ord_id,  Acc_cfm_imptomis_date, ASGN_TIME,ACC_CFM_BYUSER_ID,TRF_OUT_CFM_BYUSER_ID,MIS_PIC_CODE
            From T_out_notmk
            Where (Asgn_ln_status=1 Or Asgn_ln_status=5 ) And Status=1
              And acc_cfm_imptomis_date between to_date(checkDate,'yyyy-MM-dd hh24:mi:ss') and to_date(endDate,'yyyy-MM-dd hh24:mi:ss')
            ) Info
            Join T_sys_erp_items Item On Item.Seq_id = Info.Item_id
            Join T_wh_current_onhand_quantity Onhand On Info.Warehouse_onhand_id=Onhand.Id
            Join T_warehouse_define Ware On Info.Warehouseid=Ware.Id
            Join T_out_hd H On H.Id=Info.Out_ord_id
            Join (Select h1.id,(
                          Case
                            When H1.Item_type_id=1
                            Then '工程物资出库'
                            When H1.Item_type_id=2
                            Then '市场物资-CNP出库'
                            When H1.Item_type_id=3
                            Then '备品备件出库'
                            When H1.Item_type_id=4
                            Then '杂品出库'
                            When H1.Item_type_id=5
                            Then '工程物资杂项发放'
                            When H1.Item_type_id=6
                            Then '市场物资-其他出库'
                            Else Null
                          End) Transaction_type
                        From T_out_hd H1
                        Where H1.Status=1
                        ) Transactiontype On Transactiontype.id=h.id
            Where H.Status=1 and exists (select 1 from temp_dynamic_warehouse where Ware.id = col_warehouse_id)
          ) export;


--退库
    insert into TEMP_DETAIL_EXPORT_CNP(
            inventory_detail_excle_id, acc_cfm_imptomis_date, confirm_date,item_code, item_name,
            uom_code, source_warehouse_define_code, source_warehouse_define_name, source_locator_code,
            target_WAREHOUSE_DEFINE_CODE, target_WAREHOUSE_DEFINE_NAME, target_locator_code,
            trf_out_cfm_quty, product_unit_price, transaction_amount, transaction_type,
            out_ord_code, project_code, project_name,created_user,operator,mis_pic_code, io_code,order_desc)
          select T_INV_DETAIL_EXCLE.NEXTVAL, export.transcationdate, export.confirm_date,export.item_code, export.item_name,
                 export.unit, export.warehouse_define_code, export.warehouse_define_name,
                 export.locator_code, '','','',export.quty, export.prouint_price,
                 export.received_price, '退库', export.backordercode,
                 export.project_code, export.project_name,export.created_user,export.operator, export.mis_pic_code, export.io_code,order_desc
          from(
             select bckln.item_code as item_code,  bckln.item_name as item_name,  bckln.unit as unit,
                w.warehouse_define_code as warehouse_define_code , w.warehouse_define_name as warehouse_define_name ,
                '' as fromlocator,  bckln.locator_code as locator_code,  bckln.acpt_cfm_quty as quty,
                bckln.prouintprice as prouint_price, bckln.acpt_cfm_quty*bckln.prouintprice as received_price,
                hd.sendmis_date as transcationdate,  hd.warereceiver_date as confirm_date, hd.back_order_desc as order_desc,
                CASE backtypeid  WHEN 1 THEN '工程物资'
                  WHEN 2 THEN '市场物资'
                  WHEN 3 THEN '备品备件'
                  WHEN 4 THEN '杂品'
                  WHEN 5 THEN '工程物资杂项接收' ELSE '无来源' END  as transaction_type,
                'move order' as sourcetype,
                CASE bckln.backorderflag  WHEN 0 THEN 'LIS出库记录'
                  WHEN 1 THEN 'MIS历史出库记录'
                  WHEN 2 THEN '手工'
                 ELSE '无来源' END  as transaction_type,
                hd.back_order_code backordercode,  'move desc' as movedesc,
                hd.project_code as project_code, hd.project_name as project_name,w.mis_io_code as io_code, bckln.mis_pic_code as mis_pic_code,
                (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=hd.created_user) as created_user,
                (select distinct employee_name from t_lis_user u,t_lis_ouuser ouuser where ouuser.employee_number=u.employee_number and ouuser.ou_employee_number=bckln.acccfm_by_userid) as operator
                from T_BCK_LN bckln  join T_BCK_HD hd on bckln.bckHdInfo_id = hd.id
                join t_warehouse_define w on bckln.warehousebacktoid=w.id
                 and (hd.orderstatus = 50 or hd.orderstatus = 60)
                 and (bckln.line_status_id = 40 or bckln.line_status_id = 50 or bckln.line_status_id = 60)
                 and hd.status=1 and bckln.status=1
                 and exists (select 1 from temp_dynamic_warehouse where w.id = col_warehouse_id)
                 and hd.warereceiver_date between to_date(checkDate,'yyyy-MM-dd hh24:mi:ss') and to_date(endDate,'yyyy-MM-dd hh24:mi:ss')
          ) export;

--调库
   insert into TEMP_DETAIL_EXPORT_CNP(
        inventory_detail_excle_id, acc_cfm_imptomis_date, confirm_date,item_code, item_name,
        uom_code, source_warehouse_define_code, source_warehouse_define_name, source_locator_code,
        target_WAREHOUSE_DEFINE_CODE, target_WAREHOUSE_DEFINE_NAME, target_locator_code,
        trf_out_cfm_quty, product_unit_price, transaction_amount, transaction_type,
        out_ord_code, project_code, project_name,created_user,operator,mis_pic_code, io_code,order_desc)
      select T_INV_DETAIL_EXCLE.NEXTVAL, export.ACCOUNT_DATE,export.receipt_date ,export.item_code, export.item_desc,
             export.uom_desc, export.source_warehouse_define_code, export.source_warehouse_define_name,
             export.source_locator_code, export.target_WAREHOUSE_DEFINE_CODE, export.target_WAREHOUSE_DEFINE_NAME,
             export.target_locator_code, export.change_quty, export.product_unit_price,
             export.received_price, '调库', wh_chg_ord_code,
             export.project_code, export.project_name,created_user,operator,mis_pic_code,io_code,order_desc
      from(
        select
            a.wh_chg_ord_code wh_chg_ord_code,
            a.fact_created_date fact_created_date,
            a.GREATION_DATE "调库单创建时间",
            a.DELIVERY_DATE "发货时间",
            a.RECEIPT_DATE receipt_date,--"收货时间"
            a.ACCOUNT_DATE ACCOUNT_DATE,--"账务确认时间"
            b.item_code item_code,
            b.item_desc item_desc,
            b.uom_desc uom_desc,
            b.mis_pic_code as mis_pic_code,
            (select w.mis_io_code from T_WAREHOUSE_DEFINE w where w.id=b.WH_ID_TRF_FROM) io_code,
            (select w.WAREHOUSE_DEFINE_CODE from T_WAREHOUSE_DEFINE w where w.id=b.WH_ID_TRF_FROM) source_warehouse_define_code,
            (select w.WAREHOUSE_DEFINE_name from T_WAREHOUSE_DEFINE w where w.id=b.WH_ID_TRF_FROM) source_warehouse_define_name,
            (select l.locator_Code from T_SYS_ERP_LOCATORS l where l.locator_id=b.LOCATOR_ID and l.locator_code=b.LOCATOR_CODE group by l.locator_Code ) source_locator_code,
            (select l.locator_name from T_SYS_ERP_LOCATORS l where l.locator_id=b.LOCATOR_ID and l.locator_code=b.LOCATOR_CODE group by l.locator_name ) "调出货位名称",
            (select w.WAREHOUSE_DEFINE_CODE from T_WAREHOUSE_DEFINE w where w.id=b.WH_ID_TRF_INTO) target_WAREHOUSE_DEFINE_CODE,
            (select w.WAREHOUSE_DEFINE_name from T_WAREHOUSE_DEFINE w where w.id=b.WH_ID_TRF_INTO) target_WAREHOUSE_DEFINE_NAME,
            (select l.locator_Code from T_SYS_ERP_LOCATORS l where l.locator_id=b.TO_LOCATOR_ID and l.locator_code=b.TO_LOCATOR_code group by l.locator_Code ) target_locator_code,
            (select l.locator_name from T_SYS_ERP_LOCATORS l where l.locator_id=b.TO_LOCATOR_ID and l.locator_code=b.TO_LOCATOR_code group by l.locator_name) "调入货位名称",
            b.change_quty change_quty,
            b.product_unit_price product_unit_price,
            (b.change_quty * b.product_unit_price) received_price,
            (select distinct u.employee_name from T_LIS_OUUSER o,T_LIS_USER u where o.ou_employee_number=a.created_user and o.employee_number=u.employee_number) as created_user,
            (select distinct u.employee_name from T_LIS_OUUSER o,T_LIS_USER u where o.ou_employee_number=a.ware_receipt_user and o.employee_number=u.employee_number) as operator,
            a.receipt_date "收货时间",
            (select p.project_code  from T_SYS_ERP_PROJECTS p where p.seq_id=b.PRJ_ID_TRF_FROM) project_code,
            (select p.project_name  from T_SYS_ERP_PROJECTS p where p.seq_id=b.PRJ_ID_TRF_FROM) project_name,
            (select p.project_code  from T_SYS_ERP_PROJECTS p where p.seq_id=b.PRJ_ID_TRF_INTO) "调入项目code",
            (select p.project_name  from T_SYS_ERP_PROJECTS p where p.seq_id=b.PRJ_ID_TRF_INTO) "调入项目名称",
            a.wh_chg_desc as order_desc
            --b.onhand_id "现有量ID"
           from T_CHG_HD_LN a,T_CHG_LN b
           where a.id =b.chghdln_id AND a.order_type = 'CNPDB'
                  and a.RECEIPT_DATE is not null
                  and a.receipt_date between to_date(checkDate,'yyyy-MM-dd hh24:mi:ss') and to_date(endDate,'yyyy-MM-dd hh24:mi:ss')
                  and exists (select 1 from temp_dynamic_warehouse where b.WH_ID_TRF_FROM = col_warehouse_id or b.WH_ID_TRF_INTO = col_warehouse_id)
           order by a.wh_chg_ord_code,a.GREATION_DATE) export;

      open temp_count for select transaction_type, count(distinct out_ord_code) as out_ord_code_count from TEMP_DETAIL_EXPORT_CNP group by transaction_type;
       commit;
end;
end;
/

