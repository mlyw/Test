create function formatDate(strDate varchar2)
 return date as
begin
  if length(strDate) < 11 then 
    return to_date(strDate,'yyyy-mm-dd');
 elsif length(strDate) > 10 then
    return to_date(strDate,'yyyy-mm-dd hh24:mi:ss');
end if;

  return null;
end;
/

