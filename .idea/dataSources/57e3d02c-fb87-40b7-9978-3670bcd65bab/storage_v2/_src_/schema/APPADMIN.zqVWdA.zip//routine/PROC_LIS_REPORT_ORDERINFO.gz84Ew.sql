create PROCEDURE proc_lis_report_orderinfo(
    executedate DATE)
AS
  exception_info VARCHAR2(3000);
  v_date date;
  pre_count number(15);---执行前条数
  aft_count number(15);---执行后条数
BEGIN
  if (executedate is null) then 
    v_date:=to_date(to_char(sysdate,'yyyy-mm-dd'),'yyyy-MM-dd');
   else
     v_date:=executedate;
  end if;
  ---插入出库信息表
  select count(*) into pre_count from t_lis_report_core_outinfo;
  INSERT
  INTO t_lis_report_core_outinfo
    (
      create_date,
      bussiness_date,
      string_value1,
      status,
      version,
      item_desc,
      item_id,
      item_uom_code,
      item_uom_desc,
      warehouse_define_id,
      out_onhand_quantity,
      out_onhand_account,
      order_id,
      order_type,
      project_code,
      liaozhang_name,
      shiwu_name,
      company,
      hall,
      item_code,
      order_desc
    )
  /**增量写入每天的出入库单据数据**/
  SELECT v_date create_date,
    (v_date-1) bussiness_date,
    '' string_value1,
    1 status,
    1 version,
    tmp.item_desc,
    tmp.item_id,
    tmp.uom_code,
    tmp.uom_desc,
    tmp.warehouse_id,
    NVL(tmp.current_out_quantity,0) current_out_quantity,
    NVL(tmp.current_out_account,0) current_out_account,
    tmp.order_id,
    tmp.order_type,
    tmp.project_code,
    tmp.liaozhang_name,
    tmp.shiwu_name,
    tmp.company,
    tmp.hall,
    tmp.item_code,
    tmp.ordercomtent
  FROM
    (SELECT item_id,
      warehouse_out_id warehouse_id,
      item_desc,
      uom_code,
      uom_desc,
      order_id,
      order_type,
      current_out_quantity,
      current_out_account,
      project_code,
      liaozhang_name,
      shiwu_name,
      company,
      hall,
      item_code,
      ordercomtent
    FROM V_LIS_REPORT_TRAN_OUT_DETAILS
    WHERE TO_CHAR(import_date,'yyyy-MM-dd')=TO_CHAR((v_date-1),'yyyy-MM-dd')
    ) tmp,
    mv_warehouse_define w
  WHERE tmp.warehouse_id=w.id;
  COMMIT;
  select count(*) into aft_count from t_lis_report_core_outinfo;
  ----插入入库信息表
  INSERT
  INTO t_lis_report_core_intoinfo
    (
      create_date,
      bussiness_date,
      string_value1,
      status,
      version,
      item_desc,
      item_id,
      item_uom_code,
      item_uom_desc,
      warehouse_define_id,
      receive_onhand_quantity,
      receive_onhand_account,
      order_id,
      order_type,
      project_code,
      liaozhang_name,
      shiwu_name,
      company,
      hall,
      item_code,
      order_desc
    )
  /**增量写入每天的入库单据数据**/
  SELECT v_date create_date,
    (v_date-1) bussiness_date,
    '' string_value1,
    1 status,
    1 version,
    tmp.item_desc,
    tmp.item_id,
    tmp.uom_code,
    tmp.uom_desc,
    tmp.warehouse_id,
    NVL(tmp.current_receive_quantity,0),
    NVL(tmp.current_receive_account,0),
    tmp.order_id,
    tmp.order_type,
    tmp.project_code,
    tmp.liaozhang_name,
    tmp.shiwu_name,
    tmp.company,
    tmp.hall,
    tmp.item_code,
    tmp.ordercomtent
  FROM
    (SELECT item_id,
      warehouse_receive_id warehouse_id,
      item_desc,
      uom_code,
      uom_desc,
      order_id,
      order_type,
      current_receive_quantity,
      current_receive_account,
      project_code,
      liaozhang_name,
      shiwu_name,
      company,
      hall,
      item_code,
      ordercomtent
    FROM V_LIS_REPORT_TRAN_into_DETAILS
    WHERE TO_CHAR(import_date,'yyyy-MM-dd')=TO_CHAR((v_date-1),'yyyy-MM-dd')
    ) tmp,
    mv_warehouse_define w
  WHERE tmp.warehouse_id=w.id;
  COMMIT;
  --插入日志
  INSERT
  INTO i_erp_logs VALUES
    (
      i_erp_logs_seq.nextval,
      pre_count,
      aft_count,
      sysdate,
      '每天增量交易单据信息执行成功',
      't_lis_report_core_outinfo/intoinfo'
    );
EXCEPTION
WHEN OTHERS THEN
  exception_info := 'ERR: An error occurred with info:'||TO_CHAR(SQLCODE)||' '||sqlerrm;
  INSERT
  INTO i_erp_logs VALUES
    (
      i_erp_logs_seq.nextval,
      0,0,
      sysdate,
      exception_info,
      't_lis_report_core_outinfo/intoinfo'
    );
  COMMIT;
END proc_lis_report_orderinfo;
/

