create PROCEDURE proc_designing_line (start_time timestamp,end_time timestamp) as

  total_value number(15);
  count_value number(2);
  count_success number(15);
  exception_info varchar2(3000);
  header_seq_id_value number(19); 
  version_value number(19);
  misno_value varchar2(30);
  itemid_value number(19);
  count_itemid_value  number(20);
  status_value number(2);
  
cursor csr_i_designing_line is
  select 
  seq_id,
  design_line_id,
  design_id,
  material_type,
  item_code,
  item_name,
  item_type,
  item_model,
  dmd_quantity,
  measur_unit,
  firm,
  place_code,
  dep_code,
  dep_name,
  person_id,
  remark,
  create_dt,
  modify_dt,
  string_attr,
  long_attr,
  datetime_attr,
  double_attr,
  import_date
from I_EPM_DESIGNINGFORM_LINE  where import_date between start_time and end_time;
  
  i_designing_line csr_i_designing_line%rowtype;

begin
    count_success := 0;
    count_value := 0;
    total_value:= 0;
    version_value:= 0;
    header_seq_id_value:= 0;
    itemid_value:=0;
    misno_value:='';
    count_itemid_value:=0;
    status_value:=1;
  
    select count(seq_id) into total_value from I_EPM_DESIGNINGFORM_LINE where import_date between start_time and end_time;
  
  open csr_i_designing_line;
    fetch csr_i_designing_line into i_designing_line;
    
while (csr_i_designing_line%found) loop
   select count(seq_id) into count_value from T_SYS_EPM_DESIGNINGFORM_LINE where  design_id  = i_designing_line.design_id and  design_line_id  = i_designing_line.design_line_id;
   select mis_no into misno_value from T_SYS_EPM_DESIGNINGFORM_HEADER where design_id = i_designing_line.design_id;
   
    if(i_designing_line.seq_id is not null) then
          if(count_value > 0) then
              select version into version_value from T_SYS_EPM_DESIGNINGFORM_LINE   where design_id = i_designing_line.design_id and  design_line_id  = i_designing_line.design_line_id;
          elsif(count_value = 0 ) then
              version_value := 1;
              select seq_id into header_seq_id_value from T_SYS_EPM_DESIGNINGFORM_HEADER  where design_id = i_designing_line.design_id;
          end if;
          
         if(i_designing_line.item_code is not null and misno_value is not null) then
                  select count(its.seq_id) into count_itemid_value from t_sys_erp_items its where its.status = 1
                    and its.item_code = i_designing_line.item_code 
                    and its.organization_id in (
                    select 
                    org.organization_id 
                    from t_sys_erp_organizations org 
                    inner join t_sys_erp_projects prj on prj.ou_id = org.ou_id
                    where org.status = 1 
                    and prj.status = 1
                    and org.organization_code in ('BJE', '10E', 'HJE')
                    and prj.project_code = misno_value
                    );
          end if;
          
          if(count_itemid_value > 0) then
              select its.seq_id into itemid_value from t_sys_erp_items its where its.status = 1
                    and its.item_code = i_designing_line.item_code 
                    and its.organization_id in (
                    select 
                    org.organization_id 
                    from t_sys_erp_organizations org 
                    inner join t_sys_erp_projects prj on prj.ou_id = org.ou_id
                    where org.status = 1 
                    and prj.status = 1
                    and org.organization_code in ('BJE', '10E', 'HJE')
                    and prj.project_code = misno_value
                    );
          elsif(count_itemid_value = 0 ) then
              itemid_value := 0;
          end if;
      end if;
  
  if(itemid_value = 0) then
      status_value:=0;
  end if;
         
  if(count_value = 1) then
        update T_SYS_EPM_DESIGNINGFORM_LINE set
         design_line_id  = i_designing_line.design_line_id,
         design_id         = i_designing_line.design_id,
         material_type     = i_designing_line.material_type,
         item_id           = itemid_value,
         item_code         = i_designing_line.item_code,
         item_name         = i_designing_line.item_name,
         item_type         = i_designing_line.item_type,
         item_model        = i_designing_line.item_model,
         dmd_quantity      = i_designing_line.dmd_quantity,
         measur_unit       = i_designing_line.measur_unit,
         firm              = i_designing_line.firm,
         place_code        = i_designing_line.place_code,
         dep_code          = i_designing_line.dep_code,
         dep_name          = i_designing_line.dep_name,
         person_id         = i_designing_line.person_id,
         remark            = i_designing_line.remark,
         create_dt         = i_designing_line.create_dt,
         modify_dt         = i_designing_line.modify_dt,
         string_attr       = i_designing_line.string_attr,
         long_attr         = i_designing_line.long_attr,
         datetime_attr     = i_designing_line.datetime_attr,
         double_attr       = i_designing_line.double_attr,
         last_updated_date = sysdate,
        version = version_value + 1,
        status = status_value
    where design_id =  i_designing_line.design_id and  design_line_id  = i_designing_line.design_line_id;
 else
  insert into T_SYS_EPM_DESIGNINGFORM_LINE
  (
    seq_id,
    header_seq_id,
    design_line_id,
    design_id,
    material_type,
    item_id,
    item_code,
    item_name,
    item_type,
    item_model,
    dmd_quantity,
    measur_unit,
    firm,
    place_code,
    dep_code,
    dep_name,
    person_id,
    remark,
    create_dt,
    modify_dt,
    string_attr,
    long_attr,
    datetime_attr,
    double_attr,
    created_user,
    created_date,
    last_updated_user,
    last_updated_date,
    version,
    status
  )
  values
  (
    SEQ_EPM_DESIGNINGFORM.nextval,
    header_seq_id_value,
	  i_designing_line.design_line_id,
	  i_designing_line.design_id,
	  i_designing_line.material_type,
    itemid_value,
	  i_designing_line.item_code,
	  i_designing_line.item_name,
	  i_designing_line.item_type,
    i_designing_line.item_model,
    i_designing_line.dmd_quantity,
    i_designing_line.measur_unit,
    i_designing_line.firm,
    i_designing_line.place_code,
    i_designing_line.dep_code,
    i_designing_line.dep_name,
    i_designing_line.person_id,
    i_designing_line.remark,
    i_designing_line.create_dt,
    i_designing_line.modify_dt,
    i_designing_line.string_attr,
    i_designing_line.long_attr,
    i_designing_line.datetime_attr,
    i_designing_line.double_attr,
    '',
    sysdate,
    '',
    sysdate,
    version_value,
    status_value
  );
end if;

  fetch csr_i_designing_line into i_designing_line;
    count_success:=count_success+1;
  end loop;

--log
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','T_SYS_EPM_DESIGNINGFORM_LINE');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_EPM_DESIGNINGFORM_LINE');
close csr_i_designing_line;
commit;
end;
/

