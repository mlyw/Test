create view V_SPM_PUR_ORDER_RETURN_INFO as
  SELECT
  /**订单到货统计表物化视图依赖的视图*/
  bh.mis_po_number ret_mis_po_number,
    bh.spm_po_header_id ret_spm_po_header_id,
    SUM(rtl.return_quantity) ret_return_quantity
  FROM t_returnorder_lineinfo rtl,
    t_returnorder_headerinfo rth,
    t_receiptorder_lineinfo rl,
    T_Base_Spm_Pur_Order_Headers bh,
    T_Base_Spm_Pur_Order_Lines bl
  WHERE rth.order_status       =4
  AND rtl.return_order_id      =rth.id
  AND rtl.receipt_order_line_id=rl.receiptorderlineid
  AND bh.spm_po_header_id      =bl.spm_po_header_id
  AND rl.spm_po_line_id        =bl.spm_po_line_id
  GROUP BY bh.mis_po_number,
    bh.spm_po_header_id
/

