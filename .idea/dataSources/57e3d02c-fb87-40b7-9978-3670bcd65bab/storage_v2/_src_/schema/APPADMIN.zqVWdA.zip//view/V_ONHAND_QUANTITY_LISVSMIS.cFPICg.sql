create view V_ONHAND_QUANTITY_LISVSMIS as
  SELECT
  /**供应链与ERP库存稽核表物化视图依赖的视图*/
    t1.item_code,
    t1.item_desc,
    t1.uom_code,
    t1.mis_pic_code,
    t1.organization_code,
    t1.subinventory_code,
    t1.locator_code,
    t1.mis_onhand_quantity,
    t2.lis_onhand_quantity,
    NVL(t1.mis_onhand_quantity,0) - NVL(t2.lis_onhand_quantity, 0) misTolis_subtract_quantity
  FROM
    (SELECT 1,
      t.item_code item_code,
      t.item_description item_desc,
      t.uom_code uom_code,
      t.lot_number mis_pic_code,
      t.organization_code organization_code,
      t.subinventory_code subinventory_code,
      CASE
        WHEN t.locator_code IS NULL
        THEN '||'
        ELSE
          CASE
            WHEN t.locator_code='||'
            THEN t.locator_code
            ELSE
              CASE
                WHEN SUBSTR(t.locator_code,LENGTH(t.locator_code)  -1,2)='||'
                THEN SUBSTR(t.locator_code,0,LENGTH(t.locator_code)-2)
                ELSE
                  CASE
                    WHEN SUBSTR(t.locator_code,LENGTH(t.locator_code),1)='|'
                    THEN SUBSTR(t.locator_code,0,LENGTH(t.locator_code)-1)
                  END
              END
          END
      END AS locator_code,
      SUM(ROUND(NVL(t.onhand_quantity, 0),5)) mis_onhand_quantity
    FROM t_sys_erp_onhand_quantity_day t
    GROUP BY t.organization_code,
      t.subinventory_code,
      t.locator_code,
      t.item_code,
      t.lot_number,
      t.uom_code,
      t.item_description
    ) t1,
    (SELECT 2,
      ta.item_code item_code,
      ta.item_desc item_desc,
      ta.uom_code uom_code,
      ta.mis_pic_code mis_pic_code,
      td.mis_io_code organization_code,
      td.mis_subinventory_name subinventory_code,
      NVL(ta.locator_code, '||') locator_code,
      SUM(ROUND(ta.onhand_quantity, 5)) lis_onhand_quantity
    FROM t_wh_current_onhand_quantity ta,
      t_warehouse_define td
    WHERE ta.warehouse_define_id = td.id
    AND td.warehouse_define_code NOT LIKE 'ZC%'
    AND ta.status                  = 1
    AND NVL(ta.onhand_quantity, 0) > 0
    GROUP BY td.mis_io_code,
      td.mis_subinventory_name,
      ta.locator_code,
      ta.item_code,
      ta.mis_pic_code,
      ta.item_desc,
      ta.uom_code
    ) t2
  WHERE t1.item_code       = t2.item_code(+)
  AND t1.mis_pic_code      = t2.mis_pic_code(+)
  AND t1.organization_code = t2.organization_code(+)
  AND t1.subinventory_code = t2.subinventory_code(+)
  AND t1.locator_code      = t2.locator_code(+)
  UNION
  SELECT t2.item_code,
    t2.item_desc,
    t2.uom_code,
    t2.mis_pic_code,
    t2.organization_code,
    t2.subinventory_code,
    t2.locator_code,
    t1.mis_onhand_quantity,
    t2.lis_onhand_quantity,
    NVL(t1.mis_onhand_quantity,0) - NVL(t2.lis_onhand_quantity, 0) misTolis_subtract_quantity
  FROM
    (SELECT 1,
      t.item_code item_code,
      t.item_description item_desc,
      t.uom_code uom_code,
      t.lot_number mis_pic_code,
      t.organization_code organization_code,
      t.subinventory_code subinventory_code,
      CASE
        WHEN t.locator_code IS NULL
        THEN '||'
        ELSE
          CASE
            WHEN t.locator_code='||'
            THEN t.locator_code
            ELSE
              CASE
                WHEN SUBSTR(t.locator_code,LENGTH(t.locator_code)  -1,2)='||'
                THEN SUBSTR(t.locator_code,0,LENGTH(t.locator_code)-2)
                ELSE
                  CASE
                    WHEN SUBSTR(t.locator_code,LENGTH(t.locator_code),1)='|'
                    THEN SUBSTR(t.locator_code,0,LENGTH(t.locator_code)-1)
                  END
              END
          END
      END AS locator_code,
      SUM(ROUND(NVL(t.onhand_quantity, 0),5)) mis_onhand_quantity
    FROM t_sys_erp_onhand_quantity_day t
    GROUP BY t.organization_code,
      t.subinventory_code,
      t.locator_code,
      t.item_code,
      t.lot_number,
      t.item_description,
      t.uom_code
    ) t1,
    (SELECT 2,
      ta.item_code item_code,
      ta.item_desc item_desc,
      ta.uom_code uom_code,
      ta.mis_pic_code mis_pic_code,
      td.mis_io_code organization_code,
      td.mis_subinventory_name subinventory_code,
      NVL(ta.locator_code, '||') locator_code,
      SUM(ROUND(ta.onhand_quantity, 5)) lis_onhand_quantity
    FROM t_wh_current_onhand_quantity ta,
      t_warehouse_define td
    WHERE ta.warehouse_define_id = td.id
    AND td.warehouse_define_code NOT LIKE 'ZC%'
    AND ta.status                  = 1
    AND NVL(ta.onhand_quantity, 0) > 0
    GROUP BY td.mis_io_code,
      td.mis_subinventory_name,
      ta.locator_code,
      ta.item_code,
      ta.mis_pic_code， ta.item_desc,
      ta.uom_code
    ) t2
  WHERE t2.item_code       = t1.item_code(+)
  AND t2.mis_pic_code      = t1.mis_pic_code(+)
  AND t2.organization_code = t1.organization_code(+)
  AND t2.subinventory_code = t1.subinventory_code(+)
  AND t2.locator_code      = t1.locator_code(+)
/

