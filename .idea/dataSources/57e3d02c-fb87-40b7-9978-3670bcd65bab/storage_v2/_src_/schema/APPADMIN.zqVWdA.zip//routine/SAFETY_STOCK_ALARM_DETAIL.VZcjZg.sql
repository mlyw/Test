create procedure safety_stock_alarm_detail(createdate date,thistype varchar2)
as
  var_sql varchar2(5000);
  var_use_type varchar2(10);
  var_thisid varchar2(50);
begin
  var_use_type:='R';
  var_thisid:=get_this_code(thistype);
  update t_safety_stock_alarm_notice set has_used = var_use_type where has_used = 'N' and creation_date = createdate and material_type = thistype;
  commit;
  if(3 = thistype) then
     var_sql:='insert into t_safety_stock_quantity
              (id,
               notice_id,
               warehouse_id,
               warehouse_define_code,
               warehouse_define_name,
               project_id,
               project_number,
               project_name,
               uom_desc,
               quantity_count,
               version,
               status)
              select s_safety_stock_quantity_id.nextval,
                     notice.id,
                     detail.warehouse_define_id,
                     detail.warehouse_define_code,
                     detail.warehouse_define_name,
                     detail.project_id,
                     detail.project_number,
                     detail.project_name,
                     notice.uom_desc,
                     detail.quantity,
                     0,
                     1
                from t_safety_stock_alarm_notice notice,
                     (select MAX(H.id) as item_group_id,sum(round(t.Quantity/L.Convert_Ratio,5)) quantity,
                        t.warehouse_define_id,
                             t.warehouse_define_code,
                             t.warehouse_define_name,
                             t.project_id,
                             t.project_number,
                             t.project_name,
                             ''item_group_id'',
                             t.organization_id
                        from T_Lis_Itemgroup_Head h
                        left join T_Lis_Itemgroup_Line l on L.Item_Group_Headid=H.Id 
                        join (select sum(quan.onhand_quantity) quantity, quan.item_id thisid,
                             warehouse_define_id,
                             ware.warehouse_define_code,
                             ware.warehouse_define_name,
                             project_id,
                             project_number,
                             project_name,
                             its.organization_id
                              from t_wh_current_onhand_quantity quan,
                              t_sys_erp_items its,
                              t_warehouse_define ware
                              where quan.onhand_quantity > 0 and quan.status = 1
                              and quan.item_id=its.seq_id
                              and ware.id(+) = quan.warehouse_define_id
                              and quan.status = 1
                              and ware.id in (
                                  SELECT wd.id
                                  FROM T_Warehouse_Define wd JOIN T_WAREHOUSE_CATEGORY twc ON wd.CATEGORY_ID = twc.id AND Twc.Code =''01'' AND Twc.Status =1
                                  WHERE Wd.Warehouse_Define_Code NOT IN(SELECT * FROM t_lis_un_wa) AND Wd.Status =1
                                  START WITH Wd.Parent_Warehouse_Id IN
                                  (SELECT wd.id FROM T_Warehouse_Define wd
                                    WHERE Wd.Warehouse_Define_Code in
                                      (SELECT Org.Organization_Code FROM T_Lis_Item_Type lit JOIN T_Sys_Erp_Organizations org
                                        ON Org.Organization_Id=Lit.Organazation_Id
                                       AND Org.Status  = 1 ) )
                                  CONNECT BY PRIOR wd.id=Wd.Parent_Warehouse_Id
                              )
                              group by its.organization_id,
                                       quan.warehouse_define_id,
                                       ware.warehouse_define_code,
                                       ware.warehouse_define_name,
                                       quan.project_id,
                                       quan.project_number,
                                       quan.project_name,
                                       quan.item_id) t on t.thisid=L.Item_Id
                        where  H.Status =1 AND H.if_lock=0
                        group by t.organization_id,
                                 h.id,
                                 t.warehouse_define_id,
                                 t.warehouse_define_code,
                                 t.warehouse_define_name,
                                 t.project_id,
                                 t.project_number,
                                 t.project_name,
                                 L.Item_Id) detail
               where has_used = '''||var_use_type||'''
                 and detail.'||var_thisid||' = notice.'||var_thisid||'
                  and detail.organization_id = notice.Organizationid
                 and creation_date =  '''||createdate||' 12.00.00.000000 上午''
                 and material_type =  '''||thistype||'''';
    dbms_output.put_line(var_sql);
    execute immediate var_sql;
    commit;
  else
    var_sql:='insert into t_safety_stock_quantity
              (id,
               notice_id,
               warehouse_id,
               warehouse_define_code,
               warehouse_define_name,
               project_id,
               project_number,
               project_name,
               uom_desc,
               quantity_count,
               version,
               status)
              select s_safety_stock_quantity_id.nextval,
                     notice.id,
                     detail.warehouse_define_id,
                     detail.warehouse_define_code,
                     detail.warehouse_define_name,
                     detail.project_id,
                     detail.project_number,
                     detail.project_name,
                     notice.uom_desc,
                     detail.quantity,
                     0,
                     1
                from t_safety_stock_alarm_notice notice,
                     (select sum(onhand_quantity) quantity,
                             warehouse_define_id,
                             ware.warehouse_define_code,
                             ware.warehouse_define_name,
                             project_id,
                             project_number,
                             project_name,
                             '||var_thisid||'
                        from t_wh_current_onhand_quantity quan,
                        t_warehouse_define ware
                       where onhand_quantity > 0
                         and ware.id(+) = quan.warehouse_define_id
                         and quan.status = 1
                         and ware.id in (
                              SELECT wd.id
                              FROM T_Warehouse_Define wd JOIN T_WAREHOUSE_CATEGORY twc ON wd.CATEGORY_ID = twc.id AND Twc.Code =''01'' AND Twc.Status =1
                              WHERE Wd.Warehouse_Define_Code NOT IN(SELECT * FROM t_lis_un_wa) AND Wd.Status =1
                              START WITH Wd.Parent_Warehouse_Id IN
                              (SELECT wd.id FROM T_Warehouse_Define wd
                                WHERE Wd.Warehouse_Define_Code in
                                  (SELECT Org.Organization_Code FROM T_Lis_Item_Type lit JOIN T_Sys_Erp_Organizations org
                                    ON Org.Organization_Id=Lit.Organazation_Id
                                   AND Org.Status  = 1 ) )
                              CONNECT BY PRIOR wd.id=Wd.Parent_Warehouse_Id
                          )
                       group by quan.warehouse_define_id,
                                ware.warehouse_define_code,
                                ware.warehouse_define_name,
                                quan.project_id,
                                quan.project_number,
                                quan.project_name,
                                quan.'||var_thisid||') detail
               where has_used = '''||var_use_type||'''
                 and detail.'||var_thisid||' = notice.'||var_thisid||'
                 and creation_date =  '''||createdate||' 12.00.00.000000 上午''
                 and material_type =  '''||thistype||'''';
    execute immediate var_sql;
    commit;
  end if;
  
  --汇总工程需求数量
  var_sql:='insert into t_safety_stock_use_need
              (id,
               notice_id,
               project_id,
               project_number,
               project_name,
               need_date,
               need_count,
               uom_desc,
               version,
               status)
               select s_safety_stock_use_need_id.nextval,
                     touserneed.noticeid,
                     touserneed.projectid,
                     touserneed.projectcode,
                     touserneed.projectname,
                     touserneed.needdate,
                     touserneed.asgnquty,
                     touserneed.uomdesc,
                     touserneed.v,
                     touserneed.s
               from (select
                       notice.id noticeid,
                       outhd.project_id projectid,
                       outhd.project_code projectcode,
                       outhd.project_name projectname,
                       outln.need_date needdate,
                       sum(notmk.asgn_quty) asgnquty,
                       notice.uom_desc uomdesc,
                       0 v,
                       1 s
                from t_out_ln outln, t_out_hd outhd, t_safety_stock_alarm_notice notice,t_out_notmk notmk
               where outln.outhdinfo_id = outhd.id
                 and (outhd.ord_status = 3 or outln.ord_ln_status = 3 or notmk.asgn_ln_status= 4)
                 and notmk.ord_ln_id = outln.id
                 and has_used = '''||var_use_type||'''
                 and notice.creation_date =  '''||createdate||' 12.00.00.000000 上午''
                 and notice.material_type =  '''||thistype||'''';
  if thistype = '2' then
    var_sql := var_sql||' and notmk.productid = notice.'||var_thisid||'';
  elsif thistype = '3' then
    var_sql := var_sql||' and outln.item_id = notice.'||var_thisid||'';
  else  
    var_sql := var_sql||' and notmk.item_id = notice.'||var_thisid||'';
  end if;
  var_sql := var_sql||' group by notice.id,outhd.project_id, outhd.project_code,outhd.project_name,outln.need_date,notice.uom_desc) touserneed';
  --insert into test123(a) values (var_sql);
  --commit;
  execute immediate var_sql;
  commit;
end safety_stock_alarm_detail;
/

