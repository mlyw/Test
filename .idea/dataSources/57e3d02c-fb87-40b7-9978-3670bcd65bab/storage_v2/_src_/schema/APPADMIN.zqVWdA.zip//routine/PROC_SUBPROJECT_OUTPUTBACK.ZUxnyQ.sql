create procedure proc_subproject_outputback(tableName in varchar2, btype in number) as
v_cnt number(1);
begin
  if (1 = btype) then
    execute immediate 'create table ' || tableName || ' as select mk.outlninfo_id lineId, sum(mk.asgn_quty) quantity ,max(wd.warehouse_define_code || ''-'' || wd.warehouse_define_name) warehouse from t_out_notmk mk left join t_warehouse_define wd on wd.id=mk.warehouseid where mk.status =1  group by mk.outlninfo_id';
  elsif (2 = btype) then
    select count(*) into v_cnt from user_tables where table_name = tableName;
    if(1 = v_cnt) then
      execute immediate 'drop table ' || tableName;
    end if;
  end if;
end;
/

