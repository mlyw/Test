create PROCEDURE proc_designing_line_test (start_time timestamp,end_time timestamp) as

  total_value number(15);
  -- count_value number(2);
  count_success number(15);
  exception_info varchar2(3000);
  header_seq_id_value number(19);
  version_value number(19);
  misno_value varchar2(30);
  itemid_value number(19);
  count_itemid_value  number(20);
  status_value number(2);
  design_status_value_var VARCHAR2(10);
  COUNT_ITEMGROUP_VALUE NUMBER(19);
  
cursor csr_i_designing_line is
  select
  seq_id,
  design_line_id,
  design_id,
  material_type,
  item_code,
  item_name,
  item_type,
  item_model,
  dmd_quantity,
  measur_unit,
  firm,
  place_code,
  dep_code,
  dep_name,
  person_id,
  remark,
  create_dt,
  modify_dt,
  string_attr,
  long_attr,
  datetime_attr,
  double_attr,
  import_date,
  item_group_id
from I_EPM_DESIGNINGFORM_LINE  where import_date between start_time and end_time;

  i_designing_line csr_i_designing_line%rowtype;

begin
    count_success := 0;
    total_value:= 0;
    version_value:= 0;
    header_seq_id_value:= 0;
    itemid_value:=0;
    misno_value:='';
    count_itemid_value:=0;
    status_value:=1;
    design_status_value_var := '';

    select count(seq_id) into total_value from I_EPM_DESIGNINGFORM_LINE where import_date between start_time and end_time;

  open csr_i_designing_line;
    fetch csr_i_designing_line into i_designing_line;

while (csr_i_designing_line%found) loop
   
   SELECT design_status INTO design_status_value_var from I_EPM_DESIGNINGFORM_HEADER WHERE design_id = i_designing_line.design_id AND import_date between start_time and end_time;
   
    if(i_designing_line.seq_id is not null) then

        version_value := 1;
        -- 根据不同状态获取业务表头ID
        IF (design_status_value_var = 'new') THEN
            select seq_id, mis_no into header_seq_id_value, misno_value from T_SYS_EPM_DESIGNINGFORM_HEADER where design_id = i_designing_line.design_id AND design_status = 'new' AND status = 1;
        ELSIF (design_status_value_var = 'updateing') THEN 
            select seq_id, mis_no into header_seq_id_value, misno_value from T_SYS_EPM_DESIGNINGFORM_HEADER where design_id = i_designing_line.design_id AND design_status = 'updateing' AND status = 1;
        ELSIF (design_status_value_var = 'updated') THEN 
            select seq_id, mis_no into header_seq_id_value, misno_value from T_SYS_EPM_DESIGNINGFORM_HEADER where design_id = i_designing_line.design_id AND design_status = 'updated' AND status = 1;
        END IF;

        -- 校验物料编码真实性
        if(i_designing_line.item_code is not NULL AND misno_value is not null) THEN
            SELECT COUNT(ITS.SEQ_ID)
              INTO COUNT_ITEMID_VALUE
              FROM T_SYS_ERP_ITEMS ITS
             WHERE ITS.STATUS = 1
               AND ITS.ITEM_CODE = I_DESIGNING_LINE.ITEM_CODE
               AND ITS.ORGANIZATION_ID IN (SELECT ORG.ORGANIZATION_ID
                                             FROM T_SYS_ERP_ORGANIZATIONS ORG
                                            INNER JOIN T_SYS_ERP_PROJECTS PRJ
                                               ON PRJ.OU_ID = ORG.OU_ID
                                            WHERE ORG.STATUS = 1
                                              AND PRJ.STATUS = 1
                                              AND ORG.ORGANIZATION_CODE IN ('BJE', '10E', 'HJE')
                                              AND PRJ.PROJECT_CODE = MISNO_VALUE);
        end if;
        
        -- 获取物料编码对应的SEQ_ID
        if(count_itemid_value > 0) then
            SELECT ITS.SEQ_ID
              INTO ITEMID_VALUE
              FROM T_SYS_ERP_ITEMS ITS
             WHERE ITS.STATUS = 1
               AND ITS.ITEM_CODE = I_DESIGNING_LINE.ITEM_CODE
               AND ITS.ORGANIZATION_ID IN (SELECT ORG.ORGANIZATION_ID
                                             FROM T_SYS_ERP_ORGANIZATIONS ORG
                                            INNER JOIN T_SYS_ERP_PROJECTS PRJ
                                               ON PRJ.OU_ID = ORG.OU_ID
                                            WHERE ORG.STATUS = 1
                                              AND PRJ.STATUS = 1
                                              AND ORG.ORGANIZATION_CODE IN ('BJE', '10E', 'HJE')
                                              AND PRJ.PROJECT_CODE = MISNO_VALUE);
        elsif(count_itemid_value = 0 ) then
            itemid_value := 0;
        end if;
        
        -- 判断物料组是否有效
        IF (i_designing_line.Item_Group_Id IS NOT NULL) THEN
            SELECT COUNT(OHG.ID) INTO COUNT_ITEMGROUP_VALUE FROM T_LIS_ITEMGROUP_HEAD OHG
            WHERE OHG.STATUS = 1 AND OHG.ID = i_designing_line.Item_Group_Id
            AND OHG.ORGANIZATION_ID IN (SELECT ORG.ORGANIZATION_ID
                                         FROM T_SYS_ERP_ORGANIZATIONS ORG
                                        INNER JOIN T_SYS_ERP_PROJECTS PRJ
                                           ON PRJ.OU_ID = ORG.OU_ID
                                        WHERE ORG.STATUS = 1
                                          AND PRJ.STATUS = 1
                                          AND ORG.ORGANIZATION_CODE IN ('BJE', '10E', 'HJE')
                                          AND PRJ.PROJECT_CODE = MISNO_VALUE);
        END IF;
        
  end if;

  if(itemid_value = 0) then
      status_value:=0;
  end if;
  
  IF (i_designing_line.Item_Group_Id IS NOT NULL AND COUNT_ITEMGROUP_VALUE <> 0) THEN
      status_value := 1;
  END IF;
  
  insert into T_SYS_EPM_DESIGNINGFORM_LINE
  (
    seq_id,
    header_seq_id,
    design_line_id,
    design_id,
    material_type,
    item_id,
    item_code,
    item_name,
    item_type,
    item_model,
    dmd_quantity,
    measur_unit,
    firm,
    place_code,
    dep_code,
    dep_name,
    person_id,
    remark,
    create_dt,
    modify_dt,
    string_attr,
    long_attr,
    datetime_attr,
    double_attr,
    created_user,
    created_date,
    last_updated_user,
    last_updated_date,
    version,
    status,
    item_group_id
  )
  values
  (
    SEQ_EPM_DESIGNINGFORM.nextval,
    header_seq_id_value,
    i_designing_line.design_line_id,
    i_designing_line.design_id,
    i_designing_line.material_type,
    itemid_value,
    i_designing_line.item_code,
    i_designing_line.item_name,
    i_designing_line.item_type,
    i_designing_line.item_model,
    i_designing_line.dmd_quantity,
    i_designing_line.measur_unit,
    i_designing_line.firm,
    i_designing_line.place_code,
    i_designing_line.dep_code,
    i_designing_line.dep_name,
    i_designing_line.person_id,
    i_designing_line.remark,
    i_designing_line.create_dt,
    i_designing_line.modify_dt,
    i_designing_line.string_attr,
    i_designing_line.long_attr,
    i_designing_line.datetime_attr,
    i_designing_line.double_attr,
    '',
    sysdate,
    '',
    sysdate,
    version_value,
    status_value,
    i_designing_line.item_group_id
  );

  fetch csr_i_designing_line into i_designing_line;
    count_success:=count_success+1;
  end loop;

--log
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','T_SYS_EPM_DESIGNINGFORM_LINE');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_EPM_DESIGNINGFORM_LINE');
close csr_i_designing_line;
commit;
end;
/

