create PROCEDURE PROC_ARRIVAL_NOTICE_UUID(itime varchar) AS 
  total_value number(15);
  count_value number(2);
  count_success number(15);
  temp_value number(19);
  exception_info varchar2(3000);
  cursor csr_i_uuid is
    select iuuid.SEQ_ID,
           iuuid.BOX_UID,
           iuuid.MATERIAL_UID,
           iuuid.MATERIAL_SN,
           iuuid.ARRIVAL_NOTICE_LINE_ID
    from I_Spm_Arrival_Notice_uuid iuuid
    where iuuid.time=itime;
  i_uuid csr_i_uuid%rowtype;
BEGIN
  count_success := 0;
  select count(seq_id) into total_value from I_Spm_Arrival_Notice_uuid iuuid where iuuid.time=itime;
  open csr_i_uuid;
  fetch csr_i_uuid into i_uuid;
  while (csr_i_uuid%found) loop
    select Il.Vendor_Arrival_Line_Id into temp_value from I_Spm_Arrival_Notice_line il where Il.Seq_Id=i_uuid.ARRIVAL_NOTICE_LINE_ID;
    delete from T_Spm_Arrival_Notice_Uuid t
    where T.Vendor_Arrival_Line_Id= temp_value;
    insert into T_Spm_Arrival_Notice_Uuid(ID,
                CREATED_DATE,
                CREATED_USER,
                DATE_VALUE1,
                LAST_UPDATED_DATE,
                LAST_UPDATED_USER,
                NUMBER_VALUE1,
                STATUS,
                STRING_VALUE1,
                VERSION,
                BOX_UID,
                MATERIAL_UID,
                MATERIAL_SN,
                VENDOR_ARRIVAL_LINE_ID)
    values(i_spm_arrivalnotice_seq.nextVal,
            sysdate,
            '12345678',
            null,
            sysdate,
            '12345678',
            null,
            1,null,1,
            i_uuid.BOX_UID,
            i_uuid.MATERIAL_UID,
            i_uuid.MATERIAL_SN,temp_value);
    fetch csr_i_uuid into i_uuid;
    count_success:=count_success+1;
  end loop;
  close csr_i_uuid ;
  --插入日志
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','T_Spm_Arrival_Notice_uuid');
  exception when others then
      exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
    insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_Spm_Arrival_Notice_uuid');
  commit;
END PROC_ARRIVAL_NOTICE_UUID;
/

