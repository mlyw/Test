create view V_LIS_REPORT_VENDOR_ACCOUNT as
  SELECT
    /**统计周期内全量的供应商以供货的单据数据及金额*/
    rl.item_id,
    rl.item_code,
    rl.item_desc,
    rl.uom_code,
    rl.uom_desc,
    NVL(rl.product_unit_price,0) product_unit_price,
    NVL(rl.current_receive_quantity,0) current_receive_quantity,
    (NVL(rl.product_unit_price,0)*NVL(rl.current_receive_quantity,0)) current_receive_account,
    rl.warehouse_receive_id,
    TO_CHAR(rl.accounting_confirm_date,'yyyy-MM-dd') bussinessdate,
    rh.receipt_order_code,
    rh.po_id,
    o.vendor_id,
    o.vendor_name,
    o.mis_po_number,
    o.spm_po_desc,
    l.mis_po_line_num
  FROM t_receiptorder_headerinfo rh,
    t_receiptorder_lineinfo rl,
    t_base_spm_pur_order_headers o,
    T_Base_Spm_Pur_Order_Lines l
  WHERE rl.status                                     =1
  AND rl.status                                       =1
  AND rh.order_status                                 =5
  AND rl.receipt_order_line_sid                       =2
  AND rl.receipt_order_id                             =rh.id
  AND rh.po_id                                        =o.spm_po_header_id
  AND rl.spm_po_line_id                               =l.spm_po_line_id
  AND o.vendor_id                                    IS NOT NULL
  AND TO_CHAR(rl.accounting_confirm_date,'yyyy-MM-dd')>'2016-12-31'
/

