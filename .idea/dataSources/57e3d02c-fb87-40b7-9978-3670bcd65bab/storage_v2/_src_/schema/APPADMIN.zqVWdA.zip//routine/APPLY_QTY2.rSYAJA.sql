create FUNCTION "APPLY_QTY2"(v_head_id       number,
                                        v_item_group_id number)
  return float as
  v_ck_allot_front_qty number(19, 5); --分配前出库单数量
  v_ck_allot_qty       number(19, 5); --分配后出库单数量
  v_bck_qty            number(19, 5); --退库单数量
  v_crossdocking_qty   number(19, 5); --入库转越库数量
  v_qty                number(19, 5);
  v_project_no         varchar2(64);
  v_project_code       varchar2(32);
BEGIN

  select h.project_no
    into v_project_no
    from T_SYS_EPM_DESIGNINGFORM_HEADER h
   where h.seq_id = v_head_id;
  select h.mis_no
    into v_project_code
    from T_SYS_EPM_DESIGNINGFORM_HEADER h
   where h.seq_id = v_head_id;
  --已提交、已审批 - (分配前)
  --8,2,3  not 1,4
  select sum(ln.apply_quty)
    into v_ck_allot_front_qty
    from t_out_ln ln
   inner join t_out_hd hd
      on hd.id = ln.outhdinfo_id
     and (hd.ord_status is null or hd.ord_status in (8, 2, 3))
   where (ln.ord_ln_status is null or ln.ord_ln_status in (8, 2, 3))
     and ln.project_no = v_project_no
     and ln.item_group_id = v_item_group_id
     and hd.project_code = v_project_code;

  --已分配、已出库、已完成
  select sum(ln.tol_asgn_quty)
    into v_ck_allot_qty
    from t_out_ln ln
   inner join t_out_hd hd
      on hd.id = ln.outhdinfo_id
   where ln.ord_ln_status in (1, 2, 5, 6, 7)
     and ln.project_no = v_project_no
     and ln.item_group_id = v_item_group_id
     and hd.project_code = v_project_code;

  -- 50,60 not 0,5
  select sum(bl.backquantity)
    into v_bck_qty
    from t_bck_hd bh
   inner join t_bck_ln bl
      on bl.bckhdinfo_id = bh.id
     and bl.backorderflag = 0 --根据LIS出库记录退
   where bh.orderstatus in (50, 60)
     and bl.line_status_id in (50, 60)
     and bh.status = 1
     and exists (select 1
            from t_out_ln ol, t_out_notmk om
           where om.id = bl.invitemassignlineid
             and om.outlninfo_id = ol.id
             and ol.item_group_id = v_item_group_id)
        --and bl.item_code = v_item_code
     and bh.project_code = v_project_code
     and bl.project_no = v_project_no;
  --审批中，审批通过，接收确认，待入账
  select sum(cl.apply_quty)
    into v_crossdocking_qty
    from t_crossdocking_line cl
   inner join t_crossdocking_head ch
      on ch.id = cl.head_id
     and ch.ord_status in (1, 2, 3, 5)
   where ch.status = 1
     and cl.item_group_id = v_item_group_id
     and ch.project_code = v_project_code
     and cl.project_no = v_project_no;

  v_qty := nvl(v_ck_allot_front_qty, 0) + nvl(v_ck_allot_qty, 0) +
           nvl(v_crossdocking_qty, 0) - nvl(v_bck_qty, 0);

  RETURN nvl(v_qty, 0);
END;
/

