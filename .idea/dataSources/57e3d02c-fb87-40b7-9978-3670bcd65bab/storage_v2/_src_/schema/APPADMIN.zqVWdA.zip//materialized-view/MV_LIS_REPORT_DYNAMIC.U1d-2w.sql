create materialized view MV_LIS_REPORT_DYNAMIC
refresh force on demand
  as
    SELECT
    /**每6小时运行一次:START WITH SYSDATE NEXT SYSDATE + 21600/86400 查询库存无动态情况主表统计信息*/
    item_code,
    item_name,
    item_id,
    uom_code,
    uom_desc,
    concatenated_segments,
    category_description,
    warehouse_define_id,
    warehouse_define_code,
    warehouse_define_name,
    mis_ou_id,
    mis_ou_name,
    mis_io_code,
    mis_io_name,
    mis_io_id,
    receipt_pic_code,
    accotunt,
    afterdate,
    beforedate,
    outdate,
    dynamistimes,
    sysdate bulidtime
  FROM V_LIS_REPORT_DYNAMIC

/

