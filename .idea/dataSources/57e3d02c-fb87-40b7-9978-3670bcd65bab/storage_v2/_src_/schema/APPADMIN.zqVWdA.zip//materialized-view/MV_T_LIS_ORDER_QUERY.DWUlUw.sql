create materialized view MV_T_LIS_ORDER_QUERY
refresh force on demand
  as
    SELECT
  /**每1小时运行一次:START WITH SYSDATE NEXT SYSDATE + 3600/86400 统计采购订单查询报表物化视图*/
  v.*,
    CASE
      WHEN ((tmp.pol_quantity_ordered-tmp.pol_Quantity_Received+tmp.ret_return_quantity)= 0)
      THEN '已接收'
      WHEN (tmp.pol_Quantity_Received = 0)
      THEN '未接收'
      ELSE '部分接收'
    END AS head_status
  FROM v_LIS_ORDER_QUERY v
  LEFT JOIN
    (SELECT po_mis_po_number,
      SUM(NVL(pol_quantity_ordered,0)) pol_quantity_ordered,
      SUM(NVL(pol_Quantity_Received,0)) pol_Quantity_Received,
      SUM(NVL(ret_return_quantity,0)) ret_return_quantity
    FROM v_LIS_ORDER_QUERY
    GROUP BY po_mis_po_number
    ) tmp
  ON v.po_mis_po_number=tmp.po_mis_po_number

/

