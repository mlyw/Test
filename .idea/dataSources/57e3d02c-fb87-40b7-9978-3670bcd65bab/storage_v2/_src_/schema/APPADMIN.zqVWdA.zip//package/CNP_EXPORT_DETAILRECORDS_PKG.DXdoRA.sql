create package cnp_export_detailrecords_pkg is
type cur_dynamic_checking is ref cursor;
   type cur_temp_count is ref cursor;   
   procedure proc_inventory_detail_date(item_codee in varchar2,warehouse_id in varchar2,checkDate in varchar2, endDate in varchar2,inventory_detail out cur_dynamic_checking);
   procedure proc_inventory_detail_count(warehouse_id in varchar2,checkDate in varchar2, endDate in varchar2, temp_count out cur_temp_count);
end cnp_export_detailrecords_pkg;
/

