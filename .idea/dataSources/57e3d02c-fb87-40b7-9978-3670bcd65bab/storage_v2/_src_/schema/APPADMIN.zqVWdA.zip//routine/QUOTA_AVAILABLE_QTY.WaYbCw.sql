create FUNCTION "QUOTA_AVAILABLE_QTY" (v_detail_id number, v_item_id number)
return number
as
v_quota_quantity number(19,5);
BEGIN
   select sum(detail.available_quantity) into v_quota_quantity from (
       select dnl.item_id itemId, dnl.item_type_code itemTypeCode, detail.dept_id deptId
        from t_lis_recipient_quota_detail detail
        inner join t_lis_recipient_quota_line rl on rl.status = 1 and rl.id = detail.line_id and rl.header_id = detail.header_id
        inner join t_lis_delivery_notice_line dnl on dnl.id = rl.delivery_notice_line_id
        where detail.status = 1 and detail.id = v_detail_id and dnl.item_id = v_item_id) t
    inner join t_lis_delivery_notice_line dnl on dnl.item_id = t.itemid and dnl.item_type_code = t.itemtypecode
    inner join t_lis_recipient_quota_line rl on rl.status = 1 and dnl.id = rl.delivery_notice_line_id
    inner join t_lis_recipient_quota_detail detail on detail.status = 1 and detail.dept_id = t.deptid and rl.id = detail.line_id and rl.header_id = detail.header_id;

   RETURN nvl(v_quota_quantity,0);
END;
/

