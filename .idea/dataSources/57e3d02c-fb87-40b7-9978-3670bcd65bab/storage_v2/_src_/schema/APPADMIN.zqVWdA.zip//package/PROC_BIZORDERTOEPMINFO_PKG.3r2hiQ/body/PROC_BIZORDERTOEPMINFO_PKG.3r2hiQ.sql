create PACKAGE BODY PROC_BIZORDERTOEPMINFO_PKG is

    --查询头信息
   PROCEDURE PROC_BIZORDERTOEMPINFO(startdate in varchar2,enddate in varchar2,ordercode in varchar2,temp_list out cursor_list) as
   
BEGIN

   /* 每次执行存储过程时,删除表中所有的数据 */
   DELETE FROM TEMP_BIZORDERTOEPMINFO;
  
   COMMIT;
   
  /*插入某个时间段的头数据到头临时表中*/
    INSERT INTO TEMP_BIZORDERTOEPMINFO
    (
      ORDER_ID,
      ORDER_CODE,
      ORDER_TYPE,
      MIS_PO_NUMBER,
      CREATED_USER,
      CREATED_DEPT,
      CREATED_DATE,
      ORDER_DESC,
      ORDER_LINE_ID,
      ORDER_QUANTITY,
      ITEM_CODE,
      ITEM_DESC,
      UOM_CODE,
      UOM_DESC,
      SOURCE_WAREHOUSE_CODE,
      SOURCE_WAREHOUSE_NAME,
      SOURCE_GOODSALLOCATION_CODE,
      TARGET_WAREHOUSE_CODE,
      TARGET_WAREHOUSE_NAME,
      TARGET_GOODSALLOCATION_CODE,
      SOURCE_PROJECT_ID,
      SOURCE_PROJECT_CODE,
      SOURCE_PROJECT_NAME,
      TARGET_PROJECT_ID,
      TARGET_PROJECT_CODE,
      TARGET_PROJECT_NAME,
      MIS_PIC_CODE,
      LIS_PIC_CODE,
      ORDER_LINE_DATE,
      ACCOUNT_DATE,
      PRODUCT_UNIT_PRICE,
      PRODUCT_UNIT_PRICE_EXTAX,
      EPM_TASKCODE,
      EPM_TASKNAME,
      PROJECT_NO,
      REL_ORDER_ID,
      REL_ORDER_LINE_ID
    )
    /**直发单**/
    SELECT TRH.ID                         AS ORDER_ID, --单据头ID
           TRH.RECEIPT_ORDER_CODE         AS ORDER_CODE, --单据编号
           'JSZF'                         AS ORDER_TYPE, --单据类型
           TBH.MIS_PO_NUMBER              AS MIS_PO_NUMBER, -- 订单编号,
           TLU.EMPLOYEE_NAME              AS CREATED_USER, -- 创建人
           DPT.DEPT_NAME 		              AS CREATED_DEPT, -- 创建部门
           TRUNC(TRH.RECEIPT_DATE)        AS CREATED_DATE,
           '' 					                  AS ORDER_DESC,
           TRL.RECEIPTORDERLINEID         AS ORDER_LINE_ID, --事务处理ID
           TRL.CURRENT_RECEIVE_QUANTITY   AS ORDER_QUANTITY, -- 接收数量,
           TRL.ITEM_CODE                  AS ITEM_CODE, -- 物料编码,
           TRL.ITEM_DESC                  AS ITEM_DESC, -- 物料说明,
           TRL.UOM_CODE                   AS UOM_CODE, -- 计量单位编码
           TRL.UOM_DESC                   AS UOM_DESC, --计量单位说明,
           ''                             AS SOURCE_WAREHOUSE_CODE, --源仓库编码
           ''                             AS SOURCE_WAREHOUSE_NAME, --源仓库名称
           ''                             AS SOURCE_GOODSALLOCATION_CODE, --源货位编码
           WD.WAREHOUSE_DEFINE_CODE       AS TARGET_WAREHOUSE_CODE, --目标仓库编码
           WD.WAREHOUSE_DEFINE_NAME       AS TARGET_WAREHOUSE_NAME, --目标仓库名称
           TRL.LOCATOR_CODE               AS TARGET_GOODSALLOCATION_CODE, --目标货位编码
           NULL                           AS SOURCE_PROJECT_ID, 
           ''                             AS SOURCE_PROJECT_CODE,
           ''                             AS SOURCE_PROJECT_NAME,
           to_char(TSP.PROJECT_ID)        AS TARGET_PROJECT_ID, --目标项目ID
           TSP.PROJECT_CODE               AS TARGET_PROJECT_CODE, --目标项目编码
           TSP.PROJECT_NAME               AS TARGET_PROJECT_NAME, --目标项目名称
           TRL.MIS_PIC_CODE               AS MIS_PIC_CODE, -- MIS批次号,
           TRL.RECEIPT_PIC_CODE           AS LIS_PIC_CODE, -- 接收批次号
           CAST(TRH.RECEIPT_DATE  AS TIMESTAMP)     AS ORDER_LINE_DATE, -- 接收日期,
           TRL.ACCOUNTING_CONFRIM_IMPORT_DATE AS ACCOUNT_DATE, --接收入MIS账日期,
           TRL.PRODUCT_UNIT_PRICE         AS PRODUCT_UNIT_PRICE, --含税采购价格,
           TRL.PRODUCT_UNIT_PRICE_EX_TAX  AS PRODUCT_UNIT_PRICE_EXTAX, -- 不含税采购价格,
           TRL.EPM_TASK_CODE              AS EPM_TASKCODE,
           TRL.EPM_TASK_NAME              AS EPM_TASKNAME,
           --TRL.PROJECT_NO                 AS PROJECT_NO, -- EPM工程号
           ''                             AS PROJECT_NO,
           NULL                           AS REL_ORDER_ID,
           NULL                           AS REL_ORDER_LINE_ID    
     FROM  T_RECEIPTORDER_HEADERINFO    TRH,   
           T_BASE_SPM_PUR_ORDER_HEADERS TBH,
           T_LIS_OUUSER                 TLOU,
           T_LIS_USER                   TLU,
           T_LIS_DEPT                   DPT,
           T_RECEIPTORDER_LINEINFO      TRL,
           T_SYS_ERP_PROJECTS           TSP,
           T_WAREHOUSE_DEFINE WD
     WHERE TRH.STATUS = 1
       AND TRH.IS_STRAIGHT = 1
       AND TRH.IS_TEMP = 0
       AND (TRH.ORDER_STATUS = 4 OR TRH.ORDER_STATUS = 5) -- LIS已完成和导MIS成功
       AND TRH.PO_ID = TBH.SPM_PO_HEADER_ID
       AND TRH.RECEIPT_USER_ID = TLOU.OU_EMPLOYEE_NUMBER
       AND TLOU.EMPLOYEE_NUMBER = TLU.EMPLOYEE_NUMBER
       AND DPT.ID = TRH.APPLY_DEPT_ID
       AND EXISTS 
       (
          SELECT 1 FROM T_RECEIPTORDER_LINEINFO TRL, T_WAREHOUSE_DEFINE ORG WHERE TRL.STATUS =1 AND ORG.STATUS =1 
          AND TRL.RECEIPT_ORDER_ID = TRH.ID
          AND TRL.WAREHOUSE_RECEIVE_ID = ORG.ID 
          AND ORG.MIS_IO_CODE IN ('BJF', '10F', 'HJF')
        )
       AND TRH.ID = TRL.RECEIPT_ORDER_ID
       AND WD.ID(+) = TRL.ADDRESS_ID
       AND TRL.WAREHOUSE_RECEIVE_ID IN (SELECT ORG.ID FROM T_WAREHOUSE_DEFINE ORG WHERE ORG.STATUS = 1 AND ORG.MIS_IO_CODE IN ('BJF', '10F', 'HJF'))
       AND TRL.PROJECT_ID = TSP.SEQ_ID(+)
       AND TRH.RECEIPT_DATE  BETWEEN to_timestamp(startdate, 'yyyy-mm-dd hh24:mi:ss') and to_timestamp(enddate, 'yyyy-mm-dd hh24:mi:ss')

  UNION ALL
          
 /**出库**/
    SELECT TOH.ID 			                                AS ORDER_ID, 
           TOH.OUT_ORD_CODE                             AS ORDER_CODE,
           'CK' 			                                  AS ORDER_TYPE,
           '' 				                                  AS MIS_PO_NUMBER,
           TLU.EMPLOYEE_NAME                            AS CREATED_USER,
           TLD.DEPT_NAME 	                              AS CREATED_DEPT,
           CAST (TOH.CREATION_DATE AS TIMESTAMP)        AS CREATED_DATE,
           TOH.ORD_DESC 	                              AS ORDER_DESC,
           TOM.ID                                       AS ORDER_LINE_ID, -- 事务处理ID,
           TOM.TRF_OUT_CFM_QUTY                         AS ORDER_UANTITY, -- 出库数量,
           TOL.ITEM_CODE                                AS ITEM_CODE, --物料编码,
           TOL.ITEM_NAME                                AS ITEM_DESC, -- 物料说明,
           ITS.UOM_CODE                                 AS UOM_CODE, 
           TOL.UNIT                                     AS UOM_DESC, --计量单位,
           TWD.WAREHOUSE_DEFINE_CODE                    AS SOURCE_WAREHOUSE_CODE,
           TWD.WAREHOUSE_DEFINE_NAME                    AS SOURCE_WAREHOUSE_NAME,
           TOM.LOCATOR_CODE                             AS SOURCE_GOODSALLOCATION_CODE,
           DEST.WAREHOUSE_DEFINE_CODE                   AS TARGET_WAREHOUSE_CODE,
           DEST.WAREHOUSE_DEFINE_NAME                   AS TARGET_WAREHOUSE_NAME,
           ''                                           AS TARGET_GOODSALLOCATION_CODE,
           NULL                                         AS SOURCE_PROJECT_ID,
           ''                                           AS SOURCE_PROJECT_CODE,
           ''                                           AS SOURCE_PROJECT_NAME,
           to_char(PRJ.PROJECT_ID)                      AS TARGET_PROJECT_ID,
           TOH.PROJECT_CODE                             AS TARGET_PROJECT_CODE,
           TOH.PROJECT_NAME                             AS TARGET_PROJECT_NAME,
           TOM.MIS_PIC_CODE                             AS MIS_PIC_CODE,
           TOM.RCP_PIC_CODE                             AS LIS_PIC_CODE,
           CAST(TOM.TRF_OUT_CFM_DATE AS TIMESTAMP)      AS ORDER_LINE_DATE, -- 出库时间,
           CAST(TOM.ACC_CFM_IMPTOMIS_DATE AS TIMESTAMP) AS ACCOUNT_DATE,  --料账日期
           TOM.PRODUCT_UNIT_PRICE                       AS PRODUCT_UNIT_PRICE,
           TOM.PRODUCT_UNIT_PRICE_EX_TAX                AS PRODUCT_UNIT_PRICE_EXTAX,
           TOL.EPMTASK_CODE                             AS EPM_TASKCODE,
           TOL.EPMTASK_NAME                             AS EPM_TASKNAME,
           --TOL.PROJECT_NO                               AS PROJECT_NO ,--EPM 工程号
           ''                                           AS PROJECT_NO,
           NULL                                         AS REL_ORDER_ID,
           NULL                                         AS REL_ORDER_LINE_ID
     FROM  T_OUT_HD           TOH,
           T_LIS_OUUSER       TLOU,
           T_LIS_USER         TLU,
           T_LIS_DEPT         TLD,
           T_OUT_NOTMK        TOM,
           T_OUT_LN           TOL, 
           T_SYS_ERP_ITEMS    ITS,
           T_WAREHOUSE_DEFINE TWD,
           T_WAREHOUSE_DEFINE DEST,
           T_SYS_ERP_PROJECTS PRJ
     WHERE TOH.STATUS = 1
        AND  TOH.OUT_ORD_CODE LIKE '%-CK-%'
        AND  TOH.ITEM_TYPE_ID = 1  -- 工程物资出库
        AND  TOH.ORD_STATUS = 6 -- 已完成
        AND  TOH.CREATED_USER = TLOU.OU_EMPLOYEE_NUMBER
        AND  TLOU.EMPLOYEE_NUMBER = TLU.EMPLOYEE_NUMBER
        AND  TOH.CRE_DEPT_ID = TLD.ID
        AND  TOH.ID = TOL.OUTHDINFO_ID
        AND  TOL.ID = TOM.OUTLNINFO_ID
        AND  TOL.STATUS = 1
        AND  (TOL.ORD_LN_STATUS = 6 OR TOL.ORD_LN_STATUS = 7)
        AND  TOH.PROJECT_ID = PRJ.SEQ_ID(+)--项目
        AND  TOM.ITEM_ID = ITS.SEQ_ID
        AND  TOM.RCP_PIC_CODE IS NOT NULL
        AND  TOM.WAREHOUSEID = TWD.ID(+)
        AND  TOL.RCPT_PLACE_ID = DEST.ID(+)
        AND  TOM.TRF_OUT_CFM_DATE BETWEEN to_timestamp(startdate, 'yyyy-mm-dd hh24:mi:ss') and to_timestamp(enddate, 'yyyy-mm-dd hh24:mi:ss')

  UNION ALL
  
         
    /**退库**/
    SELECT  HD.ID                     AS ORDER_ID,
            HD.BACK_ORDER_CODE        AS ORDER_CODE,
            'TK'                      AS ORDER_TYPE,
            BCKLN.MIS_PIC_CODE        AS MIS_PIC_CODE,
            (SELECT DISTINCT EMPLOYEE_NAME FROM T_LIS_USER U,T_LIS_OUUSER OUUSER WHERE OUUSER.EMPLOYEE_NUMBER =U.EMPLOYEE_NUMBER AND OUUSER.OU_EMPLOYEE_NUMBER=HD.CREATED_USER) AS CREATED_USER,
            (SELECT D.DEPT_NAME FROM T_LIS_DEPT D WHERE D.ID = HD.CREATIONDEPTID) AS  CREATED_DEPT,
            HD.CREATED_DATE          AS CREATED_DATE,
            HD.BACK_ORDER_DESC       AS ORDER_DESC,
            BCKLN.ID                      AS ORDER_LINE_ID,
            BCKLN.BACKQUANTITY            AS ORDER_QUANTITY,
            BCKLN.ITEM_CODE               AS ITEM_CODE,
            BCKLN.ITEM_NAME               AS ITEM_DESC,
            --(SELECT T.UOM_CODE FROM T_SYS_ERP_ITEMS T WHERE T.ITEM_CODE = BCKLN.ITEM_CODE)  AS UOM_CODE,
            ITS.UOM_CODE                  AS UOM_CODE,
            BCKLN.UNIT                    AS UOM_DESC,
            ''                            AS SOURCE_WAREHOUSE_CODE,
            ''                            AS SOURCE_WAREHOUSE_NAME,
            ''                            AS SOURCE_GOODSALLOCATION_CODE,
            W.WAREHOUSE_DEFINE_CODE       AS TARGET_WAREHOUSE_CODE,
            W.WAREHOUSE_DEFINE_NAME       AS TARGET_WAREHOUSE_NAME,
            BCKLN.LOCATOR_CODE            AS TARGET_GOODSALLOCATION_CODE,
            NULL                          AS SOURCE_PROJECT_ID,
            ''                            AS SOURCE_PROJECT_CODE,
            ''                            AS SOURCE_PROJECT_NAME,
            to_char(HD.PROJECTID)         AS TARGET_PROJECT_ID,
            HD.PROJECT_CODE               AS TARGET_PROJECT_CODE,
            HD.PROJECT_NAME               AS TARGET_PROJECT_NAME,
            BCKLN.MIS_PIC_CODE            AS MIS_PIC_CODE,
            BCKLN.RCPT_PIC_CODE           AS LIS_PIC_CODE,
            CAST(BCKLN.TRS_OUT_CFM_DATE AS TIMESTAMP)      AS ORDER_LINE_DATE,
            BCKLN.ACCCFMIMPTOMIS_DATE     AS ACCOUNT_DATE,
            BCKLN.PROUINTPRICE            AS PRODUCT_UNIT_PRICE,
            BCKLN.PROUINTPRICEEXTAX       AS PRODUCT_UNIT_PRICE_EXTAX,
            ''                            AS EPM_TASKCODE,
            ''                            AS EPM_TASKNAME,
           -- BCKLN.PROJECT_NO              AS PROJECT_NO,
            ''                             AS PROJECT_NO,
            NULL                          AS REL_ORDER_ID,
            NULL                          AS REL_ORDER_LINE_ID
      FROM  T_BCK_LN BCKLN
      LEFT JOIN T_SYS_ERP_ITEMS    ITS ON ITS.SEQ_ID = BCKLN.ITEMID
      INNER JOIN T_BCK_HD HD ON BCKLN.BCKHDINFO_ID = HD.ID
      INNER JOIN T_WAREHOUSE_DEFINE W ON BCKLN.WAREHOUSEBACKTOID=W.ID
            AND HD.ORDERSTATUS        = 60 
            AND HD.STATUS             =1
            AND BCKLN.STATUS          =1
      WHERE HD.BACK_ORDER_CODE LIKE '2710-TK-%'
            OR HD.BACK_ORDER_CODE LIKE '6710-TK-%' 
            OR HD.BACK_ORDER_CODE LIKE '5927-TK-%'
            AND BCKLN.TRS_OUT_CFM_DATE BETWEEN to_timestamp(startdate, 'yyyy-mm-dd hh24:mi:ss') and to_timestamp(enddate, 'yyyy-mm-dd hh24:mi:ss')

  UNION ALL
  
     /**调库**/
    SELECT HD.ID                     AS ORDER_ID,
           HD.WH_CHG_ORD_CODE        AS ORDER_CODE,
           'DB'                      AS ORDER_TYPE,
           ''                        AS MIS_PO_NUMBER, -- 订单编号,
           HD.CREATED_USER           AS CREATED_USER,
           E.DEPT_NAME               AS CREATED_DEPT,
           HD.CREATED_DATE           AS CREATED_DATE,
           HD.WH_CHG_DESC            AS ORDER_DESC,
           OLI.ID                    AS ORDER_LINE_ID,
           OLI.CHANGE_QUTY           AS ORDER_QUANTITY,
           OLI.ITEM_CODE             AS ITEM_CODE,
           OLI.ITEM_DESC             AS ITEM_DESC,
           ITS.UOM_CODE              AS UOM_CODE,
           ITS.UOM_DESC              AS UOM_DESC,
           WD.WAREHOUSE_DEFINE_CODE  AS SOURCE_WAREHOUSE_CODE,
           WD.WAREHOUSE_DEFINE_NAME  AS SOURCE_WAREHOUSE_NAME,
           OLI.LOCATOR_CODE          AS SOURCE_GOODSALLCATION_CODE,
           WDI.WAREHOUSE_DEFINE_CODE AS TARGET_WAREHOUSE_CODE,
           WDI.WAREHOUSE_DEFINE_NAME AS TARGET_WAREHOUSE_NAME,
           OLI.TO_LOCATOR_CODE       AS TARGET_GOODSALLCATION_CODE,
           PRO.PROJECT_ID            AS SOURCE_PROJECT_ID,
           PRO.PROJECT_CODE          AS SOURCE_PROJECT_CODE,
           PRO.PROJECT_NAME          AS SOURCE_PROJECT_NAME,
           to_char(PRO1.PROJECT_ID)  AS TARGET_PROJECT_ID,
           PRO1.PROJECT_CODE         AS TARGET_PROJECT_CODE,
           PRO1.PROJECT_NAME         AS TARGET_PROJECT_NAME,
           OLI.MIS_PIC_CODE          AS MIS_PIC_CODE,
           OLI.RCPT_PIC_CODE         AS LIS_PIC_CODE,
           CAST(HD.DELIVERY_DATE AS TIMESTAMP)       AS ORDER_LINE_DATE,
           HD.ACCOUNT_DATE           AS ACCOUNT_DATE,
           OLI.PRODUCT_UNIT_PRICE    AS PRODUCT_UNIT_PRICE,
          -- ''                        AS PRODUCT_UNIT_PRICE_EXTAX,
           NULL                      AS PRODUCT_UNIT_PRICE_EXTAX,
           ''                        AS EPM_TASKCODE,
           ''                        AS EPM_TASKNAME,
           ''                        AS PROJECT_NO,
           NULL                      AS REL_ORDER_ID,
           NULL                      AS REL_ORDER_LINE_ID
     FROM  T_CHG_LN OLI
           LEFT JOIN T_CHG_HD_LN HD ON OLI.CHGHDLN_ID = HD.ID  
           LEFT JOIN T_LIS_DEPT E   ON E.ID = HD.CRT_DEPT_ID
           LEFT JOIN T_WAREHOUSE_DEFINE WD ON WD.ID = OLI.WH_ID_TRF_FROM
           LEFT JOIN T_WAREHOUSE_DEFINE WDI ON WDI.ID = OLI.WH_ID_TRF_INTO
           LEFT JOIN T_SYS_EPM_PROJECTS_MANAGER PRO ON PRO.PROJECT_ID = OLI.PRJ_ID_TRF_FROM
           LEFT JOIN T_SYS_EPM_PROJECTS_MANAGER PRO1 ON PRO1.PROJECT_ID = OLI.PRJ_ID_TRF_INTO
           LEFT JOIN T_SYS_ERP_ITEMS ITS ON ITS.SEQ_ID = OLI.ITEM_ID
     WHERE  OLI.STATUS = 1  
            AND HD.STATUS = 1
            AND HD.DELIVERY_DATE BETWEEN to_timestamp(startdate, 'yyyy-mm-dd hh24:mi:ss') and to_timestamp(enddate, 'yyyy-mm-dd hh24:mi:ss')
            
   UNION ALL
   
       /**退货**/
    SELECT  H.ID                         AS ORDER_ID,
            H.RETURN_ORDER_CODE          AS ORDER_CODE ,
            'TH'                         AS ORDER_TYPE,
            BH.MIS_PO_NUMBER             AS MIS_PO_NUMBER,
            HUSER.EMPLOYEE_NAME          AS CREATED_USER,
            HDEPT.DEPT_NAME              AS CREATED_DEPT,
            H.ORDER_CREATION_DATE        AS CREATED_DATE,
            H.RETURN_DESC                AS ORDER_DESC,
            L.ID                         AS ORDER_LINE_ID,
            L.RETURN_QUANTITY            AS ORDER_QUANTITY,
            RL.ITEM_CODE                 AS ITEM_CODE,
            RL.ITEM_DESC                 AS ITEM_DESC,
            RL.UOM_CODE                  AS UOM_CODE,
            RL.UOM_DESC                  AS UOM_DESC,
            D.WAREHOUSE_DEFINE_CODE      AS SOURCE_WAREHOUSE_CODE,
            D.WAREHOUSE_DEFINE_NAME      AS SOURCE_WAREHOUSE_NAME,
            RL.LOCATOR_CODE              AS SOURCE_GOODSALLOCATION_CODE,
            ''                           AS TARGET_WAREHOUSE_CODE,
            ''                           AS TARGET_WAREHOUSE_NAME,
            ''                           AS TARGET_GOODSALLOCATION_CODE,
            P.PROJECT_ID                 AS SOURCE_PROJECT_ID,
            P.PROJECT_CODE               AS SOURCE_PROJECT_CODE,
            P.PROJECT_NAME               AS SOURCE_PROJECT_NAME,
            ''                           AS TARGET_PROJECT_ID,
            ''                           AS TARGET_PROJECT_CODE,
            ''                           AS TARGET_PROJECT_NAME,
            L.MIS_PIC_CODE               AS MIS_PIC_CODE,
            L.RECEIPT_PIC_CODE           AS LIS_PIC_CODE,
            CAST(H.ORDER_CREATION_DATE AS TIMESTAMP)        AS ORDER_LINE_DATE,
            L.ACCOUNTING_CONFIRM_DATE    AS ACCOUNT_DATE,
            RL.PRODUCT_UNIT_PRICE        AS PRODUCT_UNIT_PRICE,
            RL.PRODUCT_UNIT_PRICE_EX_TAX AS PRODUCT_UNIT_PRICE_EXTAX,
            RL.EPM_TASK_CODE             AS EPM_TASKCODE,
            RL.EPM_TASK_NAME             AS EPM_TASKNAME,
            --RL.PROJECT_NO                AS PROJECT_NO,
            ''                           AS PROJECT_NO, 
            RL.RECEIPT_ORDER_ID          AS REL_ORDER_ID,
            L.RECEIPT_ORDER_LINE_ID      AS REL_ORDER_LINE_ID
     FROM   T_RETURNORDER_LINEINFO L
            INNER JOIN T_RETURNORDER_HEADERINFO H ON H.ID = L.RETURN_ORDER_ID
            INNER JOIN T_BASE_SPM_PUR_ORDER_HEADERS BH ON BH.SPM_PO_HEADER_ID = H.PO_ID
            INNER JOIN T_LIS_OUUSER HOUUSER ON HOUUSER.OU_EMPLOYEE_NUMBER = H.ORDER_CREATED_BY_UID
            INNER JOIN T_LIS_USER HUSER ON HUSER.EMPLOYEE_NUMBER = HOUUSER.EMPLOYEE_NUMBER
            INNER JOIN T_LIS_DEPT HDEPT ON HDEPT.ID = H.ORDER_CREATION_DEPT_ID
            INNER JOIN T_RECEIPTORDER_LINEINFO RL ON RL.RECEIPTORDERLINEID = L.RECEIPT_ORDER_LINE_ID
            INNER JOIN T_WAREHOUSE_DEFINE D ON D.ID = RL.WAREHOUSE_RECEIVE_ID
            LEFT  JOIN T_SYS_ERP_PROJECTS P ON P.SEQ_ID = L.PROJECT_ID 
      WHERE  H.ORDER_CREATION_DATE BETWEEN to_timestamp(startdate, 'yyyy-mm-dd hh24:mi:ss') and to_timestamp(enddate, 'yyyy-mm-dd hh24:mi:ss');

   COMMIT;
   
   open temp_list for 
    SELECT  ORDER_ID,
            ORDER_CODE,
            ORDER_TYPE,
            MIS_PO_NUMBER,
            CREATED_USER,
            CREATED_DEPT,
            CREATED_DATE,
            ORDER_DESC,
            ORDER_LINE_ID,
            ORDER_QUANTITY,
            ITEM_CODE,
            ITEM_DESC,
            UOM_CODE,
            UOM_DESC,
            SOURCE_WAREHOUSE_CODE,
            SOURCE_WAREHOUSE_NAME,
            SOURCE_GOODSALLOCATION_CODE,
            TARGET_WAREHOUSE_CODE,
            TARGET_WAREHOUSE_NAME,
            TARGET_GOODSALLOCATION_CODE,
            SOURCE_PROJECT_ID,
            SOURCE_PROJECT_CODE,
            SOURCE_PROJECT_NAME,
            TARGET_PROJECT_ID,
            TARGET_PROJECT_CODE,
            TARGET_PROJECT_NAME,
            MIS_PIC_CODE,
            LIS_PIC_CODE,
            ORDER_LINE_DATE,
            ACCOUNT_DATE,
            PRODUCT_UNIT_PRICE,
            PRODUCT_UNIT_PRICE_EXTAX,
            EPM_TASKCODE,
            EPM_TASKNAME,
            PROJECT_NO,
            REL_ORDER_ID,
            REL_ORDER_LINE_ID
          FROM TEMP_BIZORDERTOEPMINFO ;
   
END PROC_BIZORDERTOEMPINFO;

END PROC_BIZORDERTOEPMINFO_PKG;
/

