create PROCEDURE PROC_MATERIAL_STEP_SYNC AS 
cursor ms_c is 
  select m.quantity, m.itemcode from m_step_temp m;
  
i_mc  ms_c%rowtype;
count_value number;
BEGIN
  open ms_c;
  fetch ms_c into i_mc;
  while (ms_c%found) loop
      count_value := 0;
      select count(*) into count_value from T_SAFETY_STOCK_MATERIAL_SETUP ms where ms.item_code = i_mc.itemCode;
      if(count_value = 0) then 
        insert into T_SAFETY_STOCK_MATERIAL_SETUP
      elsif 
        
      end if;
  end loop;
END PROC_MATERIAL_STEP_SYNC;
/

