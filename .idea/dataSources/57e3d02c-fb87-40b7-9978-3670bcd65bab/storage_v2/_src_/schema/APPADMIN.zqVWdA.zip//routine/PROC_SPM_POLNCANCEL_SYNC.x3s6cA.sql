create procedure proc_spm_polncancel_sync(start_time in timestamp, end_time in timestamp, errorFlag out number,errorMsg out varchar2)
as
  total_value number(15);
  count_value number(2);
  count_success number(15);
  exception_info varchar2(3000);
  tooManyRows Exception;
  spmPoHeaderId number(19);
  spmPoNumber varchar2(30);
  spmPoLineId number(19);
  spmLineId number(19);
  spmPoDistributionId number(19);
  misPoHeaderId number(19);
  misPoNumber varchar2(30);
  misPoLineId number(19);
  misPoDistributionId number(19);

 --定义游标
  cursor csr_i_spm_purchaseordercancel is
         select seq_id,
                spm_po_header_id,
                spm_po_number,
                spm_po_line_id,
                spm_po_distribution_id,
                mis_po_header_id,
                mis_po_number,
                mis_po_line_id,
                mis_po_distribution_id,
                order_line_status,
                create_time,
                long_attribute,
                string_attribute,
                datetime_attribute,
                double_attribute
         from I_SPM_POLINE_CANCEL
         where create_time between start_time and end_time;
  i_spm_purchaseordercancel csr_i_spm_purchaseordercancel%rowtype;
begin
  count_success := 0;
  errorFlag := -1;
  select count(seq_id) into total_value from I_SPM_POLINE_CANCEL where create_time between start_time and end_time;
  open csr_i_spm_purchaseordercancel;
  fetch csr_i_spm_purchaseordercancel into i_spm_purchaseordercancel;
  while(csr_i_spm_purchaseordercancel%found) loop
  
        spmPoHeaderId := i_spm_purchaseordercancel.spm_po_header_id;
        spmPoNumber := i_spm_purchaseordercancel.spm_po_number;
        spmPoLineId := i_spm_purchaseordercancel.spm_po_line_id;
        spmLineId := i_spm_purchaseordercancel.spm_po_distribution_id;
        spmPoDistributionId := i_spm_purchaseordercancel.spm_po_distribution_id;
        misPoHeaderId := i_spm_purchaseordercancel.mis_po_header_id;
        misPoNumber := i_spm_purchaseordercancel.mis_po_number;
        misPoLineId := i_spm_purchaseordercancel.mis_po_line_id;
        misPoDistributionId := i_spm_purchaseordercancel.mis_po_distribution_id;
        
      --查询t_base_spm_pur_order_lines表是否存在唯一的一行
      select count(*) into count_value 
      from t_base_spm_pur_order_headers th,t_base_spm_pur_order_lines tl 
      where th.spm_po_header_id = tl.spm_po_header_id and th.status = 1 and tl.status = 1 
            and th.mis_po_header_id = tl.mis_po_header_id
            and th.mis_po_header_id = i_spm_purchaseordercancel.mis_po_header_id
            and th.mis_po_number = i_spm_purchaseordercancel.mis_po_number
            and tl.mis_po_line_id = i_spm_purchaseordercancel.mis_po_line_id
            and tl.mis_po_distribution_id = i_spm_purchaseordercancel.mis_po_distribution_id;
      if(count_value = 0) then
      errorFlag := 0;--未找到订单行
      raise No_data_found;
      end if;
      if(count_value = 1) then
        --做更新操作--(i_spm_purchaseordercancel.POLINE_CANCEL_STATUS, '1','待取消','2','已取消','3','撤销取消')
        update t_base_spm_pur_order_lines tl
        set tl.last_updated_date = sysdate, tl.version = tl.version + 1,
            tl.POLINE_CANCEL_STATUS = i_spm_purchaseordercancel.order_line_status
        where tl.spm_po_line_id = (
                      select tl.spm_po_line_id from t_base_spm_pur_order_headers th,t_base_spm_pur_order_lines tl
                      where th.spm_po_header_id = tl.spm_po_header_id 
                      and th.mis_po_header_id = tl.mis_po_header_id
                      and th.status = 1 and tl.status = 1 
                      and th.mis_po_header_id = i_spm_purchaseordercancel.mis_po_header_id
                      and th.mis_po_number = i_spm_purchaseordercancel.mis_po_number
                      and tl.mis_po_line_id = i_spm_purchaseordercancel.mis_po_line_id)
                      and tl.mis_po_distribution_id = i_spm_purchaseordercancel.mis_po_distribution_id;
        count_success:=count_success+1;
        errorFlag := 1;--更新成功
      else 
        --存在不唯一的订单行，抛出错误信息
        errorFlag := 2;--存在多行
        raise tooManyRows;
      end if;
  fetch csr_i_spm_purchaseordercancel into i_spm_purchaseordercancel;
  end loop; 
  close csr_i_spm_purchaseordercancel;
  errorMsg := ' ' || count_success;
 --插入日志
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'更新成功','t_base_spm_pur_order_lines');
  exception 
    WHEN  tooManyRows THEN
      errorMsg := '错误原因: 根据条件';
      if spmPoHeaderId is not null then
        errorMsg := errorMsg || 'spm_po_header_id:' || spmPoHeaderId || ',';
        end if;
      if spmPoNumber is not null then
        errorMsg := errorMsg || 'spm_po_number:' || spmPoNumber || ',';
        end if;
      if spmPoLineId is not null then
        errorMsg := errorMsg || 'spm_po_line_id:' || spmPoLineId || ',';
        end if;
      if spmPoDistributionId is not null then
        errorMsg := errorMsg || 'spm_po_distribution_id:' || spmPoDistributionId || ',';
        end if;
      errorMsg := errorMsg || 'mis_po_header_id:' || misPoHeaderId || ',';
      errorMsg := errorMsg || 'mis_po_number:' || misPoNumber || ',';
      errorMsg := errorMsg || 'mis_po_line_id:' || misPoLineId || ',';
      errorMsg := errorMsg || 'mis_po_distribution_id:' || misPoDistributionId || '查询订单行不唯一。'; 
    when No_data_found then
       errorMsg := '错误原因: 根据条件';
      if spmPoHeaderId is not null then
        errorMsg := errorMsg || 'spm_po_header_id:' || spmPoHeaderId || ',';
        end if;
      if spmPoNumber is not null then
        errorMsg := errorMsg || 'spm_po_number:' || spmPoNumber || ',';
        end if;
      if spmPoLineId is not null then
        errorMsg := errorMsg || 'spm_po_line_id:' || spmPoLineId || ',';
        end if;
      if spmPoDistributionId is not null then
        errorMsg := errorMsg || 'spm_po_distribution_id:' || spmPoDistributionId || ',';
        end if;
      errorMsg := errorMsg || 'mis_po_header_id:' || misPoHeaderId || ',';
      errorMsg := errorMsg || 'mis_po_number:' || misPoNumber || ',';
      errorMsg := errorMsg || 'mis_po_line_id:' || misPoLineId || ',';
      errorMsg := errorMsg || 'mis_po_distribution_id:' || misPoDistributionId || '没有找到订单行。'; 
    when others then
      exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
      errorMsg := exception_info;
    insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'po_cancel->t_base_spm_pur_order_lines' || errorMsg);
  commit;
end;
/

