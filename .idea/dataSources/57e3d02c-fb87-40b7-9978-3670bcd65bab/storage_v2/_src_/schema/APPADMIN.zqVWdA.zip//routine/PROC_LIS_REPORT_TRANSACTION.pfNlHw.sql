create PROCEDURE proc_lis_report_transaction(
    executedate DATE)
AS
  exception_info VARCHAR2(3000);
  v_date date;
  pre_count number(15);---执行前条数
  aft_count number(15);---执行后条数
BEGIN
  if (executedate is null) then 
    v_date:=to_date(to_char(sysdate,'yyyy-mm-dd'),'yyyy-MM-dd');
   else
     v_date:=executedate;
  end if;
  select count(*) into pre_count from t_lis_report_core_transaction;
  INSERT INTO t_lis_report_core_transaction
  /**增量写入每天的出入库交易数据**/
  SELECT resultdata.*
  FROM
    (SELECT v_date create_date,
      (v_date-1)  bussiness_date,
      '' string_value1,
      1 status,
      1 version,
      tmp.item_code,
      tmp.item_desc,
      tmp.item_id,
      tmp.uom_code,
      tmp.uom_desc,
      tmp.concatenated_segments,
      tmp.category_description,
      tmp.warehouse_id,
      tmp.warehouse_define_code,
      tmp.warehouse_define_name,
      tmp.mis_ou_id,
      tmp.mis_ou_name,
      tmp.mis_io_code,
      tmp.mis_io_name,
      tmp.mis_io_id,
      SUM(NVL(tmp.current_receive_quantity,0)) current_receive_quantity,
      SUM(NVL(tmp.current_receive_account,0)) current_receive_account,
      SUM(NVL(tmp.current_out_quantity,0)) current_out_quantity,
      SUM(NVL(tmp.current_out_account,0)) current_out_account,
      tmp.order_id,
      tmp.order_code,
      tmp.order_type,
      occupy_areainfo
    FROM
      (SELECT item_id,
        mis_ou_id,
        mis_io_id,
        warehouse_receive_id warehouse_id,
        item_code,
        item_desc,
        uom_code,
        uom_desc,
        concatenated_segments,
        category_description,
        warehouse_define_code,
        warehouse_define_name,
        mis_ou_name,
        mis_io_code,
        mis_io_name,
        order_id,
        order_code,
        order_type,
        SUM(current_receive_quantity) current_receive_quantity,
        SUM(current_receive_account) current_receive_account,
        0 current_out_quantity,
        0 current_out_account,
        occupy_areainfo
      FROM v_lis_report_transaction_into
      WHERE TO_CHAR(import_date,'yyyy-MM-dd')=TO_CHAR((v_date-1),'yyyy-MM-dd')
      GROUP BY item_id,
        mis_ou_id,
        mis_io_id,
        warehouse_receive_id,
        item_code,
        item_desc,
        uom_code,
        uom_desc,
        concatenated_segments,
        category_description,
        warehouse_define_code,
        warehouse_define_name,
        mis_ou_name,
        mis_io_code,
        mis_io_name,
        order_id,
        order_code,
        order_type,
        occupy_areainfo
      UNION ALL
      SELECT item_id,
        mis_ou_id,
        mis_io_id,
        warehouse_out_id warehouse_id,
        item_code,
        item_desc,
        uom_code,
        uom_desc,
        concatenated_segments,
        category_description,
        warehouse_define_code,
        warehouse_define_name,
        mis_ou_name,
        mis_io_code,
        mis_io_name,
        order_id,
        order_code,
        order_type,
        0 current_receive_quantity,
        0 current_receive_account,
        SUM(current_out_quantity) current_out_quantity,
        SUM(current_out_account) current_out_account,
        occupy_areainfo
      FROM v_lis_report_transaction_out
      WHERE TO_CHAR(import_date,'yyyy-MM-dd')=TO_CHAR((v_date-1),'yyyy-MM-dd')
      GROUP BY item_id,
        mis_ou_id,
        mis_io_id,
        warehouse_out_id,
        item_code,
        item_desc,
        uom_code,
        uom_desc,
        concatenated_segments,
        category_description,
        warehouse_define_code,
        warehouse_define_name,
        mis_ou_name,
        mis_io_code,
        mis_io_name,
        order_id,
        order_code,
        order_type,
        occupy_areainfo
      ) tmp
    GROUP BY tmp.item_id,
      tmp.mis_ou_id,
      tmp.mis_io_id,
      tmp.warehouse_id,
      tmp.item_code,
      tmp.item_desc,
      tmp.uom_code,
      tmp.uom_desc,
      tmp.concatenated_segments,
      tmp.category_description,
      tmp.warehouse_define_code,
      tmp.warehouse_define_name,
      tmp.mis_ou_name,
      tmp.mis_io_code,
      tmp.mis_io_name,
      tmp.order_id,
      tmp.order_code,
      tmp.order_type,
      tmp.occupy_areainfo
    ) resultdata,
    mv_warehouse_define w
  WHERE resultdata.warehouse_id=w.id;
  COMMIT;
  select count(*) into aft_count from t_lis_report_core_transaction;
  --插入日志
  INSERT
  INTO i_erp_logs VALUES
    (
      i_erp_logs_seq.nextval,
      pre_count,
      aft_count,
      sysdate,
      '每天增量交易数据执行成功',
      't_lis_report_core_transaction'
    );
EXCEPTION
WHEN OTHERS THEN
  exception_info := 'ERR: An error occurred with info:'||TO_CHAR(SQLCODE)||' '||sqlerrm;
  INSERT
  INTO i_erp_logs VALUES
    (
      i_erp_logs_seq.nextval,
      pre_count,0,
      sysdate,
      exception_info,
      't_lis_report_core_transaction'
    );
  COMMIT;
END proc_lis_report_transaction;
/

