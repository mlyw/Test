create function get_lever2_dept_by_empnum(v_employeeNumber varchar2)
return number is deptId number(16);
begin
    select id into deptId from (select id,dept_code,dept_name,parent_id  from t_lis_dept where status=1
    start with id=(select ou.ou_dept_id from t_lis_ouuser ou where ou.employee_number=v_employeeNumber and ou.ou_id=82 and ou.status=1)
    connect by prior parent_id=id) paretDept
    where parent_id  =(select tld_p1.id  from t_lis_dept tld_p1 where tld_p1.dept_name='中国移动通信集团北京有限公司');

    return deptId;
end;
/

