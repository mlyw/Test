create procedure PROC_MATERIALPOOL_BREAK
          (productcode in varchar2,lisWareName in varchar2,currentquty in number,erpType in varchar2,ouEmployeeNumber in varchar2,flag out number,resultInfo out varchar2) as
          onhandID number(19,0);
          onhandQuty number(19,0);
          exception_info varchar2(3000);
   CURSOR CURSOR_ONHAND_QUANTITY_LIST IS
      select temp.id,temp.product_code,temp.receipt_pic_code,temp.onhand_quantity-nvl(f.RESERVE_QUANTITY,0) as onhandQuty,temp.product_count as productCount from
          (select wcoq.id as id,wcoq.product_code as product_code,wcoq.receipt_pic_code as receipt_pic_code,sum(wcoq.onhand_quantity) as onhand_quantity,max(wcoq.product_count) as product_count from (select distinct max(wcoq.id) as id,
           wcoq.item_package_id,
           wcoq.product_code        as product_code,
           max(wcoq.receipt_pic_code)    as receipt_pic_code,
           max(wcoq.onhand_quantity)     as onhand_quantity,
           pro.product_count        as product_count
      from t_wh_current_onhand_quantity wcoq,
           t_item_package_head          iph,
           t_sys_spm_products_products  pro,
       
           t_warehouse_access_user      wau,
           t_lis_ouuser                 ou
     where wcoq.item_package_id = iph.id
     and iph.product_id = pro.product_id
       and wcoq.product_code = pro.child_product_code 
       and wau.employ_number = ou.employee_number
       and wau.warehouse_define_id = wcoq.warehouse_define_id
       and ou.ou_employee_number = ouEmployeeNumber
       and iph.order_code = productcode
       and wcoq.warehouse_define_id in
           (select cfg.warehouse_define_id
              from t_lis_warehouse_config cfg, t_lis_warehouse_config_head cfhd
             where cfhd.line_id = cfg.head_id
               and cfhd.lis_warehouse_define_name = lisWareName
               and cfg.erp_type = erpType)
       and wcoq.status = 1
       and iph.status = 1
       and pro.status = 1
       and wau.status = 1
       and ou.status = 1
       and wcoq.onhand_quantity > 0 group by wcoq.item_package_id,wcoq.product_code,pro.product_count) wcoq
      group by wcoq.id,wcoq.product_code,wcoq.receipt_pic_code ) temp 
      left join (select e.onhand_id,sum(nvl(e.RESERVE_QUANTITY,0)) as RESERVE_QUANTITY
      from T_SYS_ITEM_RESEREVE_INFO e where sysdate < e.reserve_end_day and e.status = 1 
      group by e.onhand_id) f on temp.ID=f.onhand_id order by temp.receipt_pic_code;                
     /* SELECT WCOQ.ID ID,WCOQ.ITEM_CODE itemCode,WCOQ.ITEM_DESC itemDesc,WCOQ.ONHAND_QUANTITY-nvl(f.RESERVE_QUANTITY,0) onhandQuty ,pro.product_count productCount      
      FROM T_WH_CURRENT_ONHAND_QUANTITY WCOQ 
      left join t_item_package_head pd on pd.id = wcoq.item_package_id
      left join t_sys_spm_products_products pro on pro.child_product_code = WCOQ.Product_Code
      left join (select e.onhand_id,sum(nvl(e.RESERVE_QUANTITY,0)) as RESERVE_QUANTITY
      from T_SYS_ITEM_RESEREVE_INFO e where sysdate < e.reserve_end_day and e.status = 1 
      group by e.onhand_id) f on WCOQ.ID=f.onhand_id  
      WHERE WCOQ.status = 1 AND WCOQ.Warehouse_Define_Id in (select cfg.warehouse_define_id 
      from t_lis_warehouse_config cfg, t_lis_warehouse_config_head cfhd where cfhd.line_id = cfg.head_id 
      AND cfhd.lis_warehouse_define_name = lisWareName and cfg.erp_type = erpType) AND WCOQ.Onhand_Quantity>0      
      AND pd.status = 1 AND pd.order_code = productcode AND WCOQ.ERP_TYPE = erpType order by WCOQ.Created_Date, WCOQ.Receipt_Pic_Code;  */    
      CURRENT_ONHAND_QUANTITY CURSOR_ONHAND_QUANTITY_LIST%rowtype;     
EXECUTING_EXCEPTION exception;
begin
      open CURSOR_ONHAND_QUANTITY_LIST;
      fetch CURSOR_ONHAND_QUANTITY_LIST into CURRENT_ONHAND_QUANTITY;
      while(CURSOR_ONHAND_QUANTITY_LIST%found) loop
      exit when onhandQuty=0;
      exit when CURSOR_ONHAND_QUANTITY_LIST%notfound;
      select S_WH_CURRENT_ONHAND_QUANTITY.Nextval into onhandID from dual;
      
        if(currentquty*CURRENT_ONHAND_QUANTITY.PRODUCTCOUNT>CURRENT_ONHAND_QUANTITY.ONHANDQUTY) then--要拆包的数量大于可用量 异常
            raise EXECUTING_EXCEPTION;
        elsif(currentquty*CURRENT_ONHAND_QUANTITY.PRODUCTCOUNT=CURRENT_ONHAND_QUANTITY.ONHANDQUTY) then
            flag:=1;
            resultInfo:='物料包实例编码'||productcode||'拆包完成';
            update t_wh_current_onhand_quantity w set w.is_item_package ='',w.item_package_id = '' where w.id = CURRENT_ONHAND_QUANTITY.ID;
            
        elsif(currentquty*CURRENT_ONHAND_QUANTITY.PRODUCTCOUNT<CURRENT_ONHAND_QUANTITY.ONHANDQUTY) then
             update t_wh_current_onhand_quantity w set w.onhand_quantity = w.onhand_quantity-currentquty*CURRENT_ONHAND_QUANTITY.PRODUCTCOUNT where w.id = CURRENT_ONHAND_QUANTITY.ID;
             insert into t_wh_current_onhand_quantity (id,created_date,created_user,last_updated_date,last_updated_user,status,item_code,item_desc,item_id
             ,mis_pic_code,product_code,project_id,receipt_pic_code,uom_code,uom_desc,warehouse_define_id,locator_id,locator_code,erp_type,onhand_quantity,epm_task_code,epm_task_name,is_item_package,item_package_id,is_fittings,string_value1) 
             select onhandID,created_date,created_user,sysdate,'12345678',status,item_code,item_desc,item_id
             ,mis_pic_code,product_code,project_id,receipt_pic_code,uom_code,uom_desc,warehouse_define_id,locator_id,locator_code,erp_type,currentquty*CURRENT_ONHAND_QUANTITY.PRODUCTCOUNT,epm_task_code,epm_task_name,'','',is_fittings,'from materialpool' from t_wh_current_onhand_quantity woq where woq.id = CURRENT_ONHAND_QUANTITY.ID;--新增一条现有量为拆包数量的记录 物料编码为空
             flag:=1;
             resultInfo:='物料包实例编码'||productcode||'拆包完成';
            
          commit;
        end if;
        
         --其它 去掉物料包编码，新增现有量-currenqty数量的现有量
        fetch CURSOR_ONHAND_QUANTITY_LIST into CURRENT_ONHAND_QUANTITY;
   end loop;     
   close CURSOR_ONHAND_QUANTITY_LIST;
   
   exception
   when EXECUTING_EXCEPTION then
     flag:=-1;
     resultInfo:='物料包实例编码'||productcode||'可用量不足，请联系管理员！';
      exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm; 
      insert into i_erp_logs values (i_erp_logs_seq.nextval,'','',sysdate,exception_info,'T_WH_CURRENT_ONHAND_QUANTITY');
end;
/

