create view V_LIS_REPORT_QTY_VENDOR_NOW as
  SELECT
  /**按照供应商ou库存子库物料为维度的当前库存数量及金额数据*/
    w.mis_ou_id,
    w.mis_io_id,
    (w.mis_io_code
    ||' '
    ||w.mis_io_name) orginfo,
    q.warehouse_define_id,
    (w.warehouse_define_code
    ||' '
    ||w.warehouse_define_name) warehouseinfo,
    v.seq_id vednor_id,
    v.vendor_name,
    i.concatenated_segments,
    i.category_description,
    q.item_id,
    q.item_code,
    q.item_desc,
    q.uom_code,
    q.uom_desc,
    SUM(NVL(q.onhand_quantity,0)) item_quantity,
    SUM(NVL(q.cost_unit_price,0)*NVL(q.onhand_quantity,0)) item_account
  FROM t_wh_current_onhand_quantity q,
    mv_warehouse_define w,
    t_sys_erp_items i,
    t_sys_erp_vendors v
  WHERE q.warehouse_define_id=w.id
  AND q.item_id              =i.seq_id
  AND q.vendor_id            =v.seq_id
  AND v.status               =1
  AND q.status               =1
  AND w.status               =1
  AND q.onhand_quantity      >0
  GROUP BY w.mis_ou_id,
    w.mis_io_id,
    w.mis_io_code,
    w.mis_io_name,
    q.warehouse_define_id,
    w.warehouse_define_code,
    w.warehouse_define_name,
    i.concatenated_segments,
    i.category_description,
    q.item_id,
    q.item_code,
    q.item_desc,
    q.uom_code,
    q.uom_desc,
    v.seq_id,
    v.vendor_name
/

