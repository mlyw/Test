create PROCEDURE proc_ou as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_ou is
select ou_id,ou_code,ou_name,effective_date_form,effective_date_to,erp_type from I_ERP_OU;
i_ou csr_i_ou%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from I_ERP_OU;
  open csr_i_ou;
  fetch csr_i_ou into i_ou;
while (csr_i_ou%found) loop
  select count(*) into count_value from t_sys_erp_ou where OU_ID = i_ou.ou_id;
  if(count_value = 1) then
      update t_sys_erp_ou t set t.last_updated_date = sysdate,
      t.erp_type = i_ou.erp_type,
      t.ou_code = i_ou.ou_code,
      t.ou_name = i_ou.ou_name,
      t.effective_date_to = i_ou.effective_date_to,
      t.effective_date_form = i_ou.effective_date_form
      where ou_id = i_ou.ou_id;
      fetch csr_i_ou into i_ou;
 else
insert into t_sys_erp_ou (ou_id, created_date, last_updated_date,status,erp_type, ou_code, ou_name, effective_date_to, effective_date_form)
values (i_ou.ou_id,sysdate,sysdate,'1',i_ou.erp_type,i_ou.ou_code,i_ou.ou_name,i_ou.effective_date_to,i_ou.effective_date_form);
fetch csr_i_ou into i_ou;
count_success:=count_success+1;
end if;
end loop;
close csr_i_ou;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_erp_ou');
exception when others then
  --count_num := count_success;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_erp_ou');
close csr_i_ou;
commit;
end;
/

