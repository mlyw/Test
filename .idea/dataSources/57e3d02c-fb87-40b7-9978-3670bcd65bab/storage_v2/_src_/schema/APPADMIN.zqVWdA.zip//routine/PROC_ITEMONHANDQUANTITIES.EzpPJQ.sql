create PROCEDURE proc_itemonhandquantities (start_time timestamp,end_time timestamp) as

total_value number(15);
count_success number(15);
exception_info varchar2(3000);

cursor csr_i_itemonhandquantities is

select id,organization_code,subinventory_code,locator_code,item_code,item_description,uom_code,onhand_quantity,lot_number,project_num,last_export_date,import_date from i_sys_erp_onhand_quantity  where import_date between start_time and end_time;

i_itemonhandquantities csr_i_itemonhandquantities%rowtype;

begin
  count_success := 0;
  total_value:= 0;
  
  select count(id) into total_value from i_sys_erp_onhand_quantity where import_date between start_time and  end_time;
  
  if(total_value > 0 ) then
         delete from t_sys_erp_onhand_quantity;
         commit;
  end if;
      
  open csr_i_itemonhandquantities;
  
  fetch csr_i_itemonhandquantities into i_itemonhandquantities;
  
  while (csr_i_itemonhandquantities%found) loop
     
      insert into t_sys_erp_onhand_quantity
      (
        id,
        organization_code,
        subinventory_code,
        locator_code,
        item_code,
        item_description,
        uom_code,
        onhand_quantity,
        lot_number,
        project_num,
        last_export_date,
        import_date
      )
      values
      (
        SEQ_ERP_ONHAND_QUANTITY.nextval,
        i_itemonhandquantities.organization_code,
        i_itemonhandquantities.subinventory_code,
        i_itemonhandquantities.locator_code,
        i_itemonhandquantities.item_code,
        i_itemonhandquantities.item_description,
        i_itemonhandquantities.uom_code,
        i_itemonhandquantities.onhand_quantity,
        i_itemonhandquantities.lot_number,
        i_itemonhandquantities.project_num,
        i_itemonhandquantities.last_export_date,
        sysdate
      );

  fetch csr_i_itemonhandquantities into i_itemonhandquantities;
    count_success:=count_success+1;
  end loop;
close csr_i_itemonhandquantities;


--log
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','t_sys_erp_onhand_quantity');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_erp_onhand_quantity');
commit;
end;
/

