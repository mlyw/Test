create view V_SYS_ERP_ORGANIZATIONS as
  SELECT
  /**报表库存组织查询框统一视图（业务量统计、库存无动态情况查询除外）*/
  "ORGANIZATION_ID",
    "CREATED_DATE",
    "CREATED_USER",
    "DATE_VALUE1",
    "LAST_UPDATED_DATE",
    "LAST_UPDATED_USER",
    "NUMBER_VALUE1",
    "STATUS",
    "STRING_VALUE1",
    "VERSION",
    "ERP_TYPE",
    "MATERIAL_TYPE",
    "ORGANIZATION_CODE",
    "ORGANIZATION_NAME",
    "OU_ID",
    "DISABLE_DATE",
    "ENABLE_DATE",
    "IS_STRAIGHT"
  FROM t_sys_erp_organizations o
  WHERE o.is_straight          =0
  AND o.status                 =1
  AND o.organization_code NOT IN ('BJA','10T','10A','10P','10C','10O')
/

