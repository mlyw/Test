create PROCEDURE PROC_RETURNPURCHASE (returnHeaderId number,currentstatus number,defaultstatus number,shortcode varchar2,v_count out number)
as
count_value number(2);
v_raise EXCEPTION;
exception_info varchar2(3000);
begin
  select count(huid.id) into count_value  from T_WAREHOUSE_CURRENT_ONHAND_UID huid where exists(select 1 from T_SYS_ITEM_RESEREVE_INFO_UID ruid
 ,T_SYS_ITEM_RESEREVE_INFO resereve, T_RETURNORDER_LINEINFO line  where resereve.order_type='TH' and huid.material_uid=ruid.material_uid and resereve.reserveid=ruid.resereve_info_id and
 resereve.order_line_id = line.id and resereve.MATERIAL_ONHAND_ID is not null and line.return_order_id=returnHeaderId);

 if(count_value>0)  then
        update T_WAREHOUSE_CURRENT_ONHAND_UID huid set huid.status=defaultstatus
        where  huid.status=currentstatus and exists(select 1 from T_SYS_ITEM_RESEREVE_INFO_UID ruid,T_SYS_ITEM_RESEREVE_INFO resereve, T_RETURNORDER_LINEINFO line
        where resereve.order_type=shortcode and huid.material_uid=ruid.material_uid and resereve.reserveid=ruid.resereve_info_id and
        resereve.order_line_id = line.id and resereve.MATERIAL_ONHAND_ID is not null and line.return_order_id=returnHeaderId);

        if(sql%rowcount != count_value) then
            v_count:=-1;
            RAISE v_raise;
        end if;
        delete from T_SYS_ITEM_RESEREVE_INFO_UID ruid where exists(select 1 from T_SYS_ITEM_RESEREVE_INFO re, T_RETURNORDER_LINEINFO line
        where  ruid.resereve_info_id =re.reserveid and re.order_type='TH' and  re.order_line_id = line.id and line.return_order_id = returnHeaderId);

 end if;
  delete from T_SYS_ITEM_RESEREVE_INFO re where exists(select 1 from T_RETURNORDER_LINEINFO line
  where re.order_type='TH' and line.id=re.order_line_id  and line.return_order_id=returnHeaderId);
  v_count:= sql%rowcount;
  EXCEPTION
   WHEN v_raise THEN
    rollback;
    exception_info:='更新失败,数据不一致';
    insert into I_ERP_LOGS (SEQ_ID,exceptions) values (I_ERP_LOGS_seq.nextval,exception_info);
   WHEN others THEN
    rollback;
    v_count:=-2;
    exception_info:='异常信息';
    insert into I_ERP_LOGS (SEQ_ID,exceptions) values (I_ERP_LOGS_seq.nextval,exception_info);
end;
/

