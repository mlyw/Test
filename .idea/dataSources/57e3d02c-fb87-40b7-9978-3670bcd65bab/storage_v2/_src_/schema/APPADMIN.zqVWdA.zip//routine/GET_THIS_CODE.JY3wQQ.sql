create function GET_THIS_CODE(
THISTYPE in VARCHAR2
)
return VARCHAR2 is
  Result  VARCHAR2(50);
begin
  select
          case when THISTYPE='1' then 'item_id'
                when THISTYPE ='2' then 'product_id'
                when THISTYPE ='3' then 'item_group_id'
                END
                INTO Result
                FROM DUAL;


  return(Result);
end GET_THIS_CODE;
/

