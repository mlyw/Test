create PACKAGE "PROC_RMSALES_ONHAND_PKG" is
  type cursor_rmsales_list is ref cursor;
  procedure "PROC_RMSALES_DEDUCTION_ONHAND"(filename         in varchar2,
                                            rmsalesid        in number,
                                            itemcode         in varchar2,
                                            erporderbatch    in varchar2,
                                            quantity         in number,
                                            subinventorycode in varchar2,
                                            orgcode          in varchar2,
                                            temp_list        out cursor_rmsales_list);
end PROC_RMSALES_ONHAND_PKG;
/

