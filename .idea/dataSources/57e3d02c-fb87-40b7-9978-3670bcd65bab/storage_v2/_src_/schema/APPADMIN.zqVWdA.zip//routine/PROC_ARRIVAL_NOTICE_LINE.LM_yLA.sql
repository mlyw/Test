create PROCEDURE PROC_ARRIVAL_NOTICE_LINE(itime varchar) AS
  total_value number(15);
  count_value number(2);
  count_success number(15);
  exception_info varchar2(3000);
  notice_status number(19);
  flag  number(1); 
  erp_type varchar2(2);
  ou_id number(3);
  receipt_user_number varchar2(30);
  receipt_user_name varchar2(30);
  cur_flow_config_id number(19);
  arrivalNoticeHeader_id number(19);
  orderCode varchar2(50);
  order_desc varchar2(300);
  has_flow number(1);
  current_id number(19);
  expense_status number(1);
  inventory_status number(1);
  org_id number(19);
  proj_id number(19);
  proj_manager varchar2(50);
  TYPE pmeArr IS TABLE OF varchar2(50) INDEX BY BINARY_INTEGER; 
  pme pmeArr; 
  pmeStr varchar2(1000);
  TYPE applicantArr IS TABLE OF varchar2(50) INDEX BY BINARY_INTEGER; 
  applica applicantArr; 
  applicaStr varchar2(1000);
  applicaEmp varchar2(50);
  bisinessId number(19);
  v_cnt NUMBER(19); 
  receiptAdminPre varchar2(50);
  is_cross_docking varchar2(10);
  fs  number(1);
  cursor csr_i_line is
    select il.SEQ_ID,
           il.VENDOR_ARRIVAL_HEADER_ID,
           il.VENDOR_ARRIVAL_LINE_ID,
           il.VENDOR_SHIPPING_HEADER_ID,
           il.VENDOR_SHIPPING_LINE_ID,
           il.QUANTITY_SHIPPED,
           il.ARRIVAL_PLANTIME,
           il.IMPORT_DATE,
           il.LONG_ATTRIBUTE,
           il.STRING_ATTRIBUTE,
           il.DATETIME_ATTRIBUTE,
           il.DOUBLE_ATTRIBUTE,
           il.CREATED_DATE
    from I_Spm_Arrival_Notice_line il
    where il.time=itime;
  i_line csr_i_line%rowtype;
BEGIN
  expense_status := 0;
  inventory_status := 0;
  has_flow := 0;
  flag := 1;
  proj_id := 0;
  applicaEmp := '12345678';
  ou_id := 82;
  count_success := 0;
  pmeStr := '()';
  applicaStr := '()';
  receiptAdminPre:='仓库';
  fs := 1;
  notice_status:=1;--默认为未冻结
  select count(seq_id) into total_value from I_Spm_Arrival_Notice_line il where il.time=itime;
  open csr_i_line;
  fetch csr_i_line into i_line;
  while (csr_i_line%found) loop
    count_value := 0;
    --库存组织
    select Spl.Organization_Id,nvl(Spl.Project_Id,0),nvl(Spl.Applicant_Employee_Number,'12345678') into org_id,proj_id,applicaEmp from T_Lis_Delivery_Notice_Line dl 
            join T_Base_Spm_Pur_Order_Lines spl on Spl.Spm_Po_Line_Id=Dl.Spm_Po_Line_Id and Dl.Spm_Po_Header_Id=Spl.Spm_Po_Header_Id
    where Dl.Vendor_Shipping_Header_Id=i_line.VENDOR_SHIPPING_HEADER_ID
      and Dl.Vendor_Shipping_Line_Id=i_line.Vendor_Shipping_Line_Id;
    if(84 = org_id or 85 = org_id or 105 = org_id or 190 = org_id or 104 = org_id) then
      if(84 = org_id or 104 = org_id) then
        receiptAdminPre :='分公司';
        --综合类需要拿到申请人
        --Dbms_Output.Put_Line(instr(applicaStr, '('||applicaEmp||')'));
        if(instr(applicaStr, '('||applicaEmp||')') = 0) then
          applicaStr := applicaStr||'('||applicaEmp||')';
          applica(applica.count+1) := applicaEmp; 
            --Dbms_Output.Put_Line(applicaStr);
        end if;
      end if;
      inventory_status := 1;
    elsif(to_number(392) = org_id or 128 = org_id or 195 = org_id) then 
      --直发单需要拿到项目
      if(0 != proj_id) then 
        select count(1) into count_value from T_Sys_Erp_Projects p left join T_Sys_Epm_Projects_Manager pm on Pm.Project_Id=P.Seq_Id
        where P.Status = 1 and p.project_status_code = 'APPROVED' and Pm.Status = 1 and P.Seq_Id=proj_id;
        if(count_value>0) then 
          select max(nvl(Pm.Pm_Employee_Number,'12345678')) into proj_manager from T_Sys_Erp_Projects p left join T_Sys_Epm_Projects_Manager pm on Pm.Project_Id=P.Seq_Id
          where P.Status = 1 and p.project_status_code = 'APPROVED' and Pm.Status = 1 and P.Seq_Id=proj_id;
          if(instr(pmeStr, '('||proj_manager||')') = 0) then
            pmeStr := pmeStr||'('||proj_manager||')';
            pme(pme.count+1) := proj_manager; 
          end if;
        elsif(count_value=0) then
          --如果未找到项目经理，则用超级用户
          if(instr(pmeStr, '(12345678)') = 0) then
            pmeStr := pmeStr||'(12345678)';
            pme(pme.count+1) := '12345678'; 
          end if;
        end if;
        expense_status := 1; 
      end if;
    end if;
    
    --插入更新
    count_value:=0;
    select count(id) into count_value from T_Spm_Arrival_Notice_Line l where l.VENDOR_ARRIVAL_LINE_ID=i_line.VENDOR_ARRIVAL_LINE_ID;
    if(count_value = 0) then
      insert into T_Spm_Arrival_Notice_Line(ID,
                  CREATED_DATE,
                  CREATED_USER,
                  DATE_VALUE1,
                  LAST_UPDATED_DATE,
                  LAST_UPDATED_USER,
                  NUMBER_VALUE1,
                  STATUS,
                  STRING_VALUE1,
                  VERSION,
                  VENDOR_ARRIVAL_HEADER_ID,
                  VENDOR_ARRIVAL_LINE_ID,
                  VENDOR_SHIPPING_HEADER_ID,
                  VENDOR_SHIPPING_LINE_ID,
                  QUANTITY_SHIPPED,
                  ARRIVAL_PLANTIME,
                  IMPORT_DATE)
      values(i_spm_arrivalnotice_seq.nextVal,
            sysdate,
            '12345678',
            null,
            sysdate,
            '12345678',
            null,
            1,null,1,
            i_line.VENDOR_ARRIVAL_HEADER_ID,
            i_line.VENDOR_ARRIVAL_LINE_ID,
            i_line.VENDOR_SHIPPING_HEADER_ID,
            i_line.VENDOR_SHIPPING_LINE_ID,
            i_line.QUANTITY_SHIPPED,
            i_line.ARRIVAL_PLANTIME,
            i_line.IMPORT_DATE);
    else 
      select h.notice_status into notice_status from T_Lis_Delivery_Notice_Header h where H.Vendor_Shipping_Header_Id=i_line.VENDOR_SHIPPING_HEADER_ID;
      /*
        如果已冻结或完成不更新
      */
      if( 1 = notice_status) then
        update T_Spm_Arrival_Notice_Line l
        set l.CREATED_DATE=sysdate, 
            l.LAST_UPDATED_DATE=sysdate,
            l.VERSION=l.VERSION+1,
            l.VENDOR_SHIPPING_HEADER_ID=i_line.VENDOR_SHIPPING_HEADER_ID,
            l.VENDOR_SHIPPING_LINE_ID=i_line.VENDOR_SHIPPING_LINE_ID,
            l.QUANTITY_SHIPPED=i_line.QUANTITY_SHIPPED,
            l.ARRIVAL_PLANTIME=i_line.ARRIVAL_PLANTIME,
            l.IMPORT_DATE=i_line.IMPORT_DATE
        where l.VENDOR_ARRIVAL_LINE_ID=i_line.VENDOR_ARRIVAL_LINE_ID;
      end if;
    end if;
    if(1 = flag) then
      --erp
      select Sph.Erp_Type into erp_type from T_Lis_Delivery_Notice_Header h join T_Base_Spm_Pur_Order_Headers sph on H.Mis_Po_Number=Sph.Mis_Po_Number
        and H.Spm_Po_Header_Id = Sph.Spm_Po_Header_Id and H.Vendor_Shipping_Header_Id=i_line.VENDOR_SHIPPING_HEADER_ID;
      if('TD' = erp_type) then 
        ou_id := 102;
      elsif('TT' = erp_type)then
        ou_id := 192;
      end if;
      --id number desc
      select H.id, H.Vendor_Arrival_Number,H.Vendor_Arrival_Desc into arrivalNoticeHeader_id,orderCode, order_desc from  T_Spm_Arrival_Notice_Header h where H.Vendor_Arrival_Header_Id=i_line.VENDOR_ARRIVAL_HEADER_ID;
      --判断是否是越库
      select nvl(L.Is_Cross_Docking, 'N') into is_cross_docking from T_Lis_Delivery_Notice_Line l where L.Vendor_Shipping_Line_Id=i_line.VENDOR_SHIPPING_LINE_ID;
      flag := 2;
    end if;
    fetch csr_i_line into i_line;
    count_success:=count_success+1;
  end loop;
  close csr_i_line ;
  commit;
  --未冻结
  fs := 2;
  if( 1 = notice_status) then
    if('N' = is_cross_docking) then ---------------------------------------非越库
    fs := 3;
      --入库
      if(1 = inventory_status and 0 = expense_status) then 
        if('分公司'=receiptAdminPre) then
          v_cnt := applica.COUNT; 
          FOR i IN 1 .. v_cnt LOOP
            count_value := 0;
            select count(1) into count_value from t_lis_user u where (U.Employee_Number=applica(i) or U.Employee_Num_Ext=applica(i)) and u.status=1;
            if(count_value > 0) then 
              select MAX(U.Employee_Number),MAX(U.Employee_Name) into receipt_user_number,receipt_user_name from t_lis_user u where (U.Employee_Number=applica(i) or U.Employee_Num_Ext=applica(i)) and u.status=1;
              select LIS_ORDER_SEQ.nextVal into current_id from dual;
              --1 新建状态 2生成单据 3已完成, 新建状态创建人写null，提交单据时写入 综合类记录订单申请人
              insert into T_Spm_Arrival_Notice_flow values(current_id, orderCode||'-'||current_id, arrivalNoticeHeader_id,sysdate, 1, null,ou_id ||'_'||receipt_user_number,ou_id,1);
              bisinessId := current_id;
              select s_lis_flow_inst.nextVal into current_id from dual;
              select id into cur_flow_config_id from T_Lis_Flow_Config c where C.Flow_Full_Code='FLOW_ARRIVAL_NOTICE_ZH' and C.Current_Step=1;
              --插入流程实例
             insert into T_Lis_Flow_Inst
              values(current_id,
                    receiptAdminPre||'收货管理员-到货通知接收入库',
                    'FLOW_ARRIVAL_NOTICE_ZH',
                    cur_flow_config_id,bisinessId,1,1,
                    ou_id ||'_'||receipt_user_number,sysdate,
                    ou_id ||'_'||receipt_user_number,sysdate,null,null,
                    orderCode||'-'||bisinessId,order_desc,'系统管理员');
              --插入流程节点
              insert into T_Lis_Flow_Task 
              values(s_lis_flow_task.nextVal,
                    current_id,
                    0,
                    cur_flow_config_id,
                    ou_id||'_12345678',null,sysdate,0,1,1,
                    ou_id||'_12345678',sysdate,
                    ou_id||'_12345678',sysdate,null,
                    ou_id||'_12345678','系统管理员',sysdate,
                    orderCode||'-'||bisinessId,'系统管理员',ou_id,null);
              end if; 
          END LOOP; 
        elsif('仓库'=receiptAdminPre) then 
          /*生成代办*/
          --select count(id) into has_flow from T_Lis_Flow_Inst ins where Ins.Bisiness_Id=arrivalNoticeHeader_id and Ins.Order_Code=orderCode and exists(select 1 from T_Lis_Flow_Task ta where Ta.Flow_Inst_Id = ins.id and Ta.Display_Flag = 0);
          --if(0 = has_flow) then
            select s_lis_flow_inst.nextVal into current_id from dual;
            select id into cur_flow_config_id from T_Lis_Flow_Config c where C.Flow_Full_Code='FLOW_ARRIVAL_NOTICE' and C.Current_Step=1;
            --插入流程实例
            insert into T_Lis_Flow_Inst
            values(current_id,
                  receiptAdminPre||'收货管理员-到货通知接收入库',
                  'FLOW_ARRIVAL_NOTICE',
                  cur_flow_config_id,
                  arrivalNoticeHeader_id,1,1,
                  ou_id ||'_12345678',sysdate,
                  ou_id ||'_12345678',sysdate,null,null,
                  orderCode,order_desc,'超级管理员');
            --插入流程节点
            insert into T_Lis_Flow_Task 
            values(s_lis_flow_task.nextVal,
                  current_id,
                  0,
                  cur_flow_config_id,
                  ou_id||'_12345678',null,sysdate,0,1,1,
                  ou_id||'_12345678',sysdate,
                  ou_id||'_12345678',sysdate,null,
                  ou_id||'_12345678','超级管理员',sysdate,
                  orderCode,'超级管理员',ou_id,null);
          --end if;
        end if;
      end if;
      --------------------------------------------------------------------------------------------------------------------------------------------
      --直发
      fs := 4;
      if(0 = inventory_status and 1 = expense_status) then 
      --生成代办时，直发就不判断重复了，太复杂， 接口有传入就生成代办，人工来区分处理
        v_cnt := pme.COUNT; 
        FOR i IN 1 .. v_cnt LOOP
          count_value := 0;
          select count(1) into count_value from t_lis_user u where u.user_id=pme(i);
          if(count_value > 0) then 
            select MAX(U.Employee_Number),MAX(U.Employee_Name) into receipt_user_number,receipt_user_name from t_lis_user u where u.user_id=pme(i);
            select LIS_ORDER_SEQ.nextVal into current_id from dual;
            --1 新建状态 2生成单据 3已完成, 新建状态创建人写null，提交单据时写入
            insert into T_Spm_Arrival_Notice_flow values(current_id, orderCode||'-'||current_id, arrivalNoticeHeader_id,sysdate, 1, null,ou_id ||'_'||receipt_user_number,ou_id,0);
            bisinessId := current_id;
            select s_lis_flow_inst.nextVal into current_id from dual;
            select id into cur_flow_config_id from T_Lis_Flow_Config c where C.Flow_Full_Code='FLOW_ARRIVAL_NOTICE_ZF' and C.Current_Step=1;
            --插入流程实例
            insert into T_Lis_Flow_Inst
            values(current_id,
                  receipt_user_name||'-到货通知接收直发',
                  'FLOW_ARRIVAL_NOTICE_ZF',
                  cur_flow_config_id,bisinessId,1,1,
                  ou_id ||'_12345678',sysdate,
                  ou_id ||'_12345678',sysdate,null,null,
                  orderCode||'-'||bisinessId,
                  order_desc,'超级管理员');
            --插入流程节点
            insert into T_Lis_Flow_Task 
            values(s_lis_flow_task.nextVal,
                  current_id,ou_id ||'_'||receipt_user_number,
                  cur_flow_config_id,
                  ou_id||'_12345678',null,sysdate,0,1,1,
                  ou_id||'_12345678',sysdate,
                  ou_id||'_12345678',sysdate,null,
                  ou_id||'_12345678','超级管理员',sysdate,
                  orderCode||'-'||bisinessId,'超级管理员',ou_id,null
            );
          end if; 
        END LOOP; 
      end if;
      -------------------------------------------------------------------------------------------------------------------------------------------------
      --入库
      if(1 = expense_status and 1 = inventory_status) then 
        --首先生成入库代办
       -- select count(id) into has_flow from T_Lis_Flow_Inst ins where Ins.Bisiness_Id=arrivalNoticeHeader_id and Ins.Order_Code=orderCode and exists(select 1 from T_Lis_Flow_Task ta where Ta.Flow_Inst_Id = ins.id and Ta.Display_Flag = 0);
        if(0 = has_flow) then
          select s_lis_flow_inst.nextVal into current_id from dual;
          select id into cur_flow_config_id from T_Lis_Flow_Config c where C.Flow_Full_Code='FLOW_ARRIVAL_NOTICE' and C.Current_Step=1;
          --插入流程实例
          insert into T_Lis_Flow_Inst
          values(current_id,
                receiptAdminPre||'收货管理员-到货通知接收入库',
                'FLOW_ARRIVAL_NOTICE',
                cur_flow_config_id,
                arrivalNoticeHeader_id,1,1,
                ou_id ||'_12345678',sysdate,
                ou_id ||'_12345678',sysdate,null,null,
                orderCode,order_desc,'超级管理员');
          --插入流程节点
          insert into T_Lis_Flow_Task 
          values(s_lis_flow_task.nextVal,
                current_id,
                0,
                cur_flow_config_id,
                ou_id||'_12345678',null,sysdate,0,1,1,
                ou_id||'_12345678',sysdate,
                ou_id||'_12345678',sysdate,null,
                ou_id||'_12345678','超级管理员',sysdate,
                orderCode,'超级管理员',ou_id,null);
        end if;
        
        --再插入直发代办
        v_cnt := pme.COUNT; 
        FOR i IN 1 .. v_cnt LOOP
          count_value := 0;
          select count(1) into count_value from t_lis_user u where u.user_id=pme(i);
          if(count_value > 0) then 
            select U.Employee_Number,U.Employee_Name into receipt_user_number,receipt_user_name from t_lis_user u where u.user_id=pme(i);
            select LIS_ORDER_SEQ.nextVal into current_id from dual;
            --1 新建状态 2生成单据 3已完成, 新建状态创建人写null，提交单据时写入
            insert into T_Spm_Arrival_Notice_flow values(current_id, orderCode||'-'||current_id, arrivalNoticeHeader_id,sysdate, 1, null,ou_id ||'_'||receipt_user_number,ou_id,0);
            bisinessId := current_id;
            select s_lis_flow_inst.nextVal into current_id from dual;
            select id into cur_flow_config_id from T_Lis_Flow_Config c where C.Flow_Full_Code='FLOW_ARRIVAL_NOTICE_ZF' and C.Current_Step=1;
            --插入流程实例
            insert into T_Lis_Flow_Inst
            values(current_id,
                  receipt_user_name||'-到货通知接收直发',
                  'FLOW_ARRIVAL_NOTICE_ZF',
                  cur_flow_config_id,bisinessId,1,1,
                  ou_id ||'_12345678',sysdate,
                  ou_id ||'_12345678',sysdate,null,null,
                  orderCode||'-'||bisinessId,
                  order_desc,'超级管理员');
            --插入流程节点
            insert into T_Lis_Flow_Task 
            values(s_lis_flow_task.nextVal,
                  current_id,ou_id ||'_'||receipt_user_number,
                  cur_flow_config_id,
                  ou_id||'_12345678',null,sysdate,0,1,1,
                  ou_id||'_12345678',sysdate,
                  ou_id||'_12345678',sysdate,null,
                  ou_id||'_12345678','超级管理员',sysdate,
                  orderCode||'-'||bisinessId,'超级管理员',ou_id,null
            );
          end if; 
        END LOOP; 
      end if;
    elsif('Y' = is_cross_docking) then 
    fs := 2;
      --入库转越库代办
      if(1 = inventory_status and 0 = expense_status) then 
        /*生成代办*/
        --select count(id) into has_flow from T_Lis_Flow_Inst ins where Ins.Bisiness_Id=arrivalNoticeHeader_id and Ins.Order_Code=orderCode and exists(select 1 from T_Lis_Flow_Task ta where Ta.Flow_Inst_Id = ins.id and Ta.Display_Flag = 0);
        if(0 = has_flow) then
          select s_lis_flow_inst.nextVal into current_id from dual;
          select id into cur_flow_config_id from T_Lis_Flow_Config c where C.Flow_Full_Code='FLOW_ARRIVAL_NOTICE_YK' and C.Current_Step=1;
          --插入流程实例
          insert into T_Lis_Flow_Inst
          values(current_id,
                receiptAdminPre||'收货管理员-入库转越库到货通知',
                'FLOW_ARRIVAL_NOTICE_YK',
                cur_flow_config_id,
                arrivalNoticeHeader_id,1,1,
                ou_id ||'_12345678',sysdate,
                ou_id ||'_12345678',sysdate,null,null,
                orderCode,order_desc,'超级管理员');
          --插入流程节点
          insert into T_Lis_Flow_Task 
          values(s_lis_flow_task.nextVal,
                current_id,
                0,
                cur_flow_config_id,
                ou_id||'_12345678',null,sysdate,0,1,1,
                ou_id||'_12345678',sysdate,
                ou_id||'_12345678',sysdate,null,
                ou_id||'_12345678','超级管理员',sysdate,
                orderCode,'超级管理员',ou_id,null);
        end if;
      end if;
    end if;
  end if;
  --插入日志
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','T_Spm_Arrival_Notice_Line'||fs||'--'||itime);
  exception when others then
    exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
    insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_Spm_Arrival_Notice_Line'||fs||'--'||itime);
  commit;
END PROC_ARRIVAL_NOTICE_LINE;
/

