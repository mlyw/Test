create package cnp_dynamic_report_pkg is
  type cur_dynamic_checking is ref cursor;
   procedure proc_execute_cnpreport(item_codee in varchar2,warehouse_id in varchar2,diff in number,checkDate in varchar2, endDate in varchar2,dynamic_checking out cur_dynamic_checking,total out number);
end cnp_dynamic_report_pkg;
/

