create PROCEDURE PROC_INVENTORY_AGING_REPORTS as
  material_status varchar2(5);
BEGIN
  --查询是按条件获得库存信息，还是获取全部库存信息
  select ims.material_status
    into material_status
    from t_inventory_material_status ims;
  --删除所有需要库龄告警基础信息
  delete from t_inventory_aging_reports;

  if (material_status = 1) then
    insert into t_inventory_aging_reports
      (id,
       item_category_code,
       item_id,
       product_id,
       uom_desc,
       receipt_pic_code,
       storage_date,
       storage_price_ex_tax,
       storage_price,
       balance_quantity,
       balance_price_ex_tax,
       balance_price,
       quantity_days,
       time_slot,
       warehouse_define_id,
       status,
       created_date,
       erp_type)
      select t_inventory_reports.nextval, wh.*
        from (select w.item_category_code,
                     w.item_id,
                     w.product_id,
                     w.uom_desc,
                     w.receipt_pic_code,
                     w.date_value1,
                     w.product_unit_price_ex_tax,
                     w.product_unit_price,
                     sum(nvl(w.onhand_quantity, 0)),
                     sum(nvl(w.onhand_quantity, 0) *
                         nvl(w.product_unit_price_ex_tax, 0)),
                     sum(nvl(w.onhand_quantity, 0) *
                         nvl(w.cost_unit_price, 0)),
                     CEIL((sysdate - cast(w.date_value1 as date))),
                     (select ip.inventory_aging_beginning || '-' ||
                             ip.inventory_aging_end
                        from t_inventory_analysis_period ip
                       where CEIL((sysdate - cast(w.date_value1 as date))) between
                             ip.inventory_aging_beginning and
                             ip.inventory_aging_end),
                     w.warehouse_define_id,
                     1,
                     sysdate,
                     w.erp_type
                from t_wh_current_onhand_quantity  w,
                     t_warehouse_define            wd,
                     t_warehouse_category          wc,
                     t_inventory_analysis_material im
               where w.status = 1
                 and nvl(w.onhand_quantity, 0) > 0
                 and (w.item_id = im.item_id or w.product_id = im.product_id)
                 and wc.code = '01'
                 and wd.id = w.warehouse_define_id
                 and wd.category_id = wc.id
                 and wd.MIS_SUBINVENTOEY_ID in
                     (select sub.SUBINVENTORY_ID
                        from T_SYS_ERP_SUBINVENTORY sub
                       inner join T_SYS_ERP_ORGANIZATIONS org
                          on org.ORGANIZATION_ID = sub.ORGANIZATIONS_ID
                       where org.ORGANIZATION_CODE in
                             ('BJE', 'BJF', 'HJE', 'HJF', '10E', '10F'))
                 and w.date_value1 is not null
               group by w.item_category_code,
                        w.item_id,
                        w.product_id,
                        w.uom_desc,
                        w.warehouse_define_id,
                        w.product_unit_price_ex_tax,
                        w.product_unit_price,
                        w.receipt_pic_code,
                        w.date_value1,
                        w.erp_type) wh;
  
  else
    --添加库龄告警基础信息
    insert into t_inventory_aging_reports
      (id,
       item_category_code,
       item_id,
       product_id,
       uom_desc,
       receipt_pic_code,
       storage_date,
       storage_price_ex_tax,
       storage_price,
       balance_quantity,
       balance_price_ex_tax,
       balance_price,
       quantity_days,
       time_slot,
       warehouse_define_id,
       status,
       created_date,
       erp_type)
      select t_inventory_reports.nextval, wh.*
        from (select w.item_category_code,
                     w.item_id,
                     w.product_id,
                     w.uom_desc,
                     w.receipt_pic_code,
                     w.date_value1,
                     w.product_unit_price_ex_tax,
                     w.product_unit_price,
                     sum(nvl(w.onhand_quantity, 0)),
                     sum(nvl(w.onhand_quantity, 0) *
                         nvl(w.product_unit_price_ex_tax, 0)),
                     sum(nvl(w.onhand_quantity, 0) *
                         nvl(w.cost_unit_price, 0)),
                     CEIL((sysdate - cast(w.date_value1 as date))),
                     (select ip.inventory_aging_beginning || '-' ||
                             ip.inventory_aging_end
                        from t_inventory_analysis_period ip
                       where CEIL((sysdate - cast(w.date_value1 as date))) between
                             ip.inventory_aging_beginning and
                             ip.inventory_aging_end),
                     w.warehouse_define_id,
                     1,
                     sysdate,
                     w.erp_type
                from t_wh_current_onhand_quantity w,
                     t_warehouse_define           wd,
                     t_warehouse_category         wc
               where w.status = 1
                 and nvl(w.onhand_quantity, 0) > 0
                 and wc.code = '01'
                 and wd.id = w.warehouse_define_id
                 and wd.category_id = wc.id
                 and wd.MIS_SUBINVENTOEY_ID in
                     (select sub.SUBINVENTORY_ID
                        from T_SYS_ERP_SUBINVENTORY sub
                       inner join T_SYS_ERP_ORGANIZATIONS org
                          on org.ORGANIZATION_ID = sub.ORGANIZATIONS_ID
                       where org.ORGANIZATION_CODE in
                             ('BJE', 'BJF', 'HJE', 'HJF', '10E', '10F'))
                 and w.date_value1 is not null
               group by w.item_category_code,
                        w.item_id,
                        w.product_id,
                        w.uom_desc,
                        w.warehouse_define_id,
                        w.product_unit_price_ex_tax,
                        w.product_unit_price,
                        w.receipt_pic_code,
                        w.date_value1,
                        w.erp_type) wh;
  end if;
  commit;
END;
/

