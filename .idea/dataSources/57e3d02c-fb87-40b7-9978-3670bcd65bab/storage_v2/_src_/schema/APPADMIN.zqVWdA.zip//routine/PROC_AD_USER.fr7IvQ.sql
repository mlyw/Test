create procedure "PROC_AD_USER"(start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_disabled number(15);--user失效状态
count_disabled1 number(15);--ouuser失效状态
count_ouuser number(15); 
count_success number(15);
deptId number(15);
deptCode varchar2(100);
exception_info varchar2(3000);
cursor csr_ad_user is 
select 
       SEQ_ID,U_ID,U_NAME,DEPT_NAME,INNER_MAIL,TITLE,OFFICE_PHONE,PHONE,MIS_ID,EMPLOYEE_NUMBER
       from T_AD_USER where EMPLOYEE_NUMBER not in
        (select em from ((select count(a.employee_number) cco, a.employee_number em from  T_AD_USER a where a.IMPORT_DATE 
                between start_time and end_time and a.employee_number like '2%' group by a.employee_number) temp) 
        where temp.cco>1) and EMPLOYEE_NUMBER like '2%' and IMPORT_DATE between start_time and end_time ;              
ad_users csr_ad_user%rowtype;

cursor csr_dis_user is
select 
       distinct U_ID,U_NAME,EMPLOYEE_NUMBER
       from T_AD_USER where EMPLOYEE_NUMBER like '2%'
       minus 
       select U_ID,U_NAME,EMPLOYEE_NUMBER
       from T_AD_USER where EMPLOYEE_NUMBER like '2%' and IMPORT_DATE between start_time and end_time ;
dis_users csr_dis_user%rowtype; 
begin
  --处理失效（离职员工）数据
open csr_dis_user;
fetch csr_dis_user into dis_users;
while (csr_dis_user%found) loop
  update t_lis_user t set t.status = 0,t.string_value1='sync from adUser',t.last_updated_date=sysdate where t.employee_number = dis_users.employee_number;
  update t_lis_ouuser ou set ou.status = 0,ou.string_value1='sync from adUser',ou.last_updated_date=sysdate where ou.employee_number = dis_users.employee_number;
 fetch csr_dis_user into dis_users;
end loop;
close csr_dis_user;
commit;
--处理新增、更新数据
  count_success :=0;
  select count(SEQ_ID) into total_value from T_AD_USER where EMPLOYEE_NUMBER like '2%'  and IMPORT_DATE between start_time and end_time ;
  open csr_ad_user ;
  fetch csr_ad_user into ad_users;
while (csr_ad_user%found) loop
  BEGIN
       select d.id into deptId from t_lis_dept d where d.dept_name=ad_users.dept_name and d.status = 1;
  EXCEPTION
      WHEN NO_DATA_FOUND THEN
        deptId := NULL;
  END;  
   
  BEGIN   --查询dept_code
       select dt.dept_code into deptCode from t_lis_dept dt where dt.dept_name = ad_users.dept_name and dt.status =1 ;
  EXCEPTION
      WHEN NO_DATA_FOUND THEN
        deptCode := NULL;
  END;
   --操作t_lis_user 
   select count(employee_number) into count_disabled from t_lis_user where employee_number = ad_users.employee_number and status = 0;
  if(count_disabled=0) then 
  select count(employee_number) into count_value
  from t_lis_user where employee_number = ad_users.employee_number  and status = 1;
  if(count_value=1) then 
  update t_lis_user r
   set r.employee_name =ad_users.u_name,r.org_code=deptCode,r.org_name =ad_users.dept_name,r.office_tel =ad_users.phone,r.email =ad_users.inner_mail,r.user_id =ad_users.u_id
   ,r.employee_num_ext =ad_users.employee_number,r.dept_id =deptId,r.last_updated_date = systimestamp,r.last_updated_user='12345678',r.version = r.version+1
   where r.employee_number = ad_users.employee_number ; --如果存在则更新？？？
  count_success := count_success + 1;
 elsif(count_value= 0) then    
  insert into t_lis_user(                      --初始密码password MD5(ika,123)=7C837AC658FD72AB90C0C3E145E9953A
   employee_number,employee_name,employee_num_ext,org_code,org_name,office_tel,mobile_phone,email,user_id,dept_id,created_date,password,type,status,version,string_value1,created_user
  ) values(
    ad_users.employee_number,ad_users.u_name,ad_users.employee_number,deptCode,ad_users.dept_name,ad_users.office_phone,ad_users.phone,ad_users.inner_mail,ad_users.u_id,deptId,sysdate,'F146A144911EB0190985E68B7C126356',2,1,0,'sync from adUser','12345678'
  );
  count_success := count_success + 1;
  end if;
end if;

  --操作t_lis_ouuser
  select count(id) into count_disabled1 from t_lis_ouuser ou where ou.employee_number = ad_users.employee_number and ou.status =0;
  if(count_disabled1=0) then
  select count(id) into count_ouuser from t_lis_ouuser ou where ou.employee_number = ad_users.employee_number and ou.status =1;
  --更新
  if(count_ouuser >=1) then
  update t_lis_ouuser o
  set o.ou_dept_id = deptId,o.ou_dept_code = deptCode,o.version = o.version+1,o.last_updated_date = sysdate,o.last_updated_user = '12345678'where o.ou_employee_number ='82_'||ad_users.employee_number and o.status = 1;
  
  update t_lis_ouuser o
  set o.ou_dept_id = deptId,o.ou_dept_code = deptCode,o.version = o.version+1,o.last_updated_date = sysdate,o.last_updated_user = '12345678' where o.ou_employee_number ='102_'||ad_users.employee_number and o.status = 1;
  
  update t_lis_ouuser o
  set o.ou_dept_id = deptId,o.ou_dept_code = deptCode,o.version = o.version+1,o.last_updated_date = sysdate,o.last_updated_user = '12345678' where o.ou_employee_number ='192_'||ad_users.employee_number and o.status = 1;
  
  count_success := count_success + 1;
  --新增
  elsif(count_ouuser= 0) then
  --82
  insert into t_lis_ouuser o (id,employee_number,ou_employee_number,ou_dept_code,ou_id,ou_dept_id,status,version,created_user,created_date,string_value1
  ) values (
  LIS_ORDER_SEQ.NEXTVAL,ad_users.employee_number,'82_'||ad_users.employee_number,deptCode,82,deptId,1,0,'12345678',sysdate,'sync from adUser'
  );
  --102
  insert into t_lis_ouuser o (id,employee_number,ou_employee_number,ou_dept_code,ou_id,ou_dept_id,status,version,created_user,created_date,string_value1
  ) values (
  LIS_ORDER_SEQ.NEXTVAL,ad_users.employee_number,'102_'||ad_users.employee_number,deptCode,102,deptId,1,0,'12345678',sysdate,'sync from adUser'
  );
  --192
  insert into t_lis_ouuser o (id,employee_number,ou_employee_number,ou_dept_code,ou_id,ou_dept_id,status,version,created_user,created_date,string_value1
  ) values (
  LIS_ORDER_SEQ.NEXTVAL,ad_users.employee_number,'192_'||ad_users.employee_number,deptCode,192,deptId,1,0,'12345678',sysdate,'sync from adUser'
  );
  count_success := count_success + 1;
  end if;
end if; 
fetch csr_ad_user into ad_users;
end loop;
close csr_ad_user;
commit;

--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value, count_success, sysdate,'同步成功','T_AD_USER');
exception when others then
  rollback;
  --count_num := count_success;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_AD_USER');
close csr_ad_user;
commit;
end;
/

