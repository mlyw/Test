create view V_SPM_PUR_ORDER_RECEIPT_INFO as
  SELECT
  /**订单到货统计表物化视图依赖的视图*/
  rh.receipt_user_id rec_receipt_user_id,
    u.employee_name rec_employee_name,
    rh.receipt_date rec_receipt_date,
    rl.spm_po_line_id rec_spm_po_line_id,
    rl.receipt_pic_code rec_receipt_pic_code,
    rl.current_receive_quantity rec_current_receive_quantity,
    rl.mis_pic_code rec_mis_pic_code,
    rl.locator_id rec_locator_id,
    rl.locator_code rec_locator_code
  FROM t_receiptorder_headerinfo rh,
    t_receiptorder_lineinfo rl,
    t_lis_ouuser uo,
    t_lis_user u
  WHERE rl.receipt_order_id   =rh.id
  AND rh.status               =1
  AND rl.status               =1
  AND u.employee_number       =uo.employee_number
  AND rh.receipt_user_id      =uo.ou_employee_number
  AND NVL(rh.order_status,0) IN (4,5)
/

