create view V_LIS_REPORT_TURNOVER_RATE as
  SELECT
    /**以ou/库存/子库/物料分类/物料为维度的周转率统计原始表视图（由于需要动态传参数，视图仅供sql实例参考）*/
    resultdata.ou_id,
    resultdata.organization_id,
    resultdata.orginfo,
    resultdata.warehouse_define_id,
    resultdata.warehouseinfo,
    resultdata.item_category_code,
    resultdata.item_category_name,
    resultdata.item_id,
    resultdata.item_code,
    resultdata.item_desc,
    resultdata.item_uom_code,
    resultdata.item_uom_desc,
    SUM(resultdata.startaccount) startaccount,
    SUM(resultdata.startqty) startqty,
    SUM(resultdata.endaccount) endaccount,
    SUM(resultdata.endqty) endqty,
    SUM(resultdata.out_onhand_account) out_onhand_account,
    SUM(resultdata.out_onhand_quantity) out_onhand_quantity,
    ROUND(DECODE(SUM(resultdata.startaccount+resultdata.endaccount),0,0,(SUM(resultdata.out_onhand_account)/(((SUM(resultdata.startaccount+resultdata.endaccount))/2)))),2) trunoverpersent
  FROM
    (
    ----期初期末金额及数量
    SELECT rss.ou_id,
      rss.organization_id,
      (dd.mis_io_code
      ||' '
      ||dd.mis_io_name) orginfo,
      rss.warehouse_define_id,
      (dd.warehouse_define_code
      ||' '
      ||dd.warehouse_define_name) warehouseinfo,
      rss.item_category_code,
      rss.item_category_name,
      rss.item_id,
      rss.item_code,
      rss.item_desc,
      rss.item_uom_code,
      rss.item_uom_desc,
      SUM(rss.startaccount) startaccount,
      SUM(rss.startqty) startqty,
      SUM(rss.endaccount) endaccount,
      SUM(rss.endqty) endqty,
      0 out_onhand_account,
      0 out_onhand_quantity
    FROM v_lis_report_start_stop rss
    LEFT JOIN t_warehouse_define dd
    ON rss.warehouse_define_id=dd.id
    WHERE ((rss.bussiness_date='201702'
    AND rss.endaccount        =0
    AND rss.endqty            =0)
    OR (rss.bussiness_date    ='201708'
    AND rss.startaccount      =0
    AND rss.startqty          =0))
    AND 1                     =1
    GROUP BY rss.ou_id,
      rss.organization_id,
      dd.mis_io_code,
      dd.mis_io_name,
      rss.warehouse_define_id,
      dd.warehouse_define_code,
      dd.warehouse_define_name,
      rss.item_category_code,
      rss.item_category_name,
      rss.item_id,
      rss.item_code,
      rss.item_desc,
      rss.item_uom_code,
      rss.item_uom_desc
    UNION ALL
    ----统计周期内出入库金额及数量
    SELECT rct.ou_id,
      rct.organization_id,
      (rct.organization_code
      ||' '
      ||rct.organization_name) orginfo,
      rct.warehouse_define_id,
      (rct.warehouse_define_code
      ||' '
      ||rct.warehouse_define_desc) warehouseinfo,
      rct.item_category_code,
      rct.item_category_name,
      rct.item_id,
      rct.item_code,
      rct.item_desc,
      rct.item_uom_code,
      rct.item_uom_desc,
      0 startaccount,
      0 startqty,
      0 endaccount,
      0 endqty,
      SUM(rct.out_onhand_account) out_onhand_account,
      SUM(rct.out_onhand_quantity) out_onhand_quantity
    FROM t_lis_report_core_transaction rct
    WHERE TO_CHAR(rct.bussiness_date,'yyyyMMdd')>='201702'
    AND TO_CHAR(rct.bussiness_date,'yyyyMMdd')  <='201708'
    AND 1                                        =1
    GROUP BY rct.ou_id,
      rct.organization_id,
      rct.organization_code,
      rct.organization_name,
      rct.warehouse_define_id,
      rct.warehouse_define_code,
      rct.warehouse_define_desc,
      rct.item_category_code,
      rct.item_category_name,
      rct.item_id,
      rct.item_code,
      rct.item_desc,
      rct.item_uom_code,
      rct.item_uom_desc
    ) resultdata
  GROUP BY resultdata.ou_id,
    resultdata.organization_id,
    resultdata.orginfo,
    resultdata.warehouse_define_id,
    resultdata.warehouseinfo,
    resultdata.item_category_code,
    resultdata.item_category_name,
    resultdata.item_id,
    resultdata.item_code,
    resultdata.item_desc,
    resultdata.item_uom_code,
    resultdata.item_uom_desc
/

