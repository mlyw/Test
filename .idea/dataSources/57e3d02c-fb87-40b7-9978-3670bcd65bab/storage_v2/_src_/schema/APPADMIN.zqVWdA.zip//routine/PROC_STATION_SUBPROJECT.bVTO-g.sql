create PROCEDURE proc_station_subproject (start_time timestamp,end_time timestamp) as

  total_value number(15);
  count_value number(2);
  count_success number(15);
  exception_info varchar2(3000);
  header_seq_id_value number(19); 
  version_value number(19); 
  count_user number(2);
  subprojectPersonName varchar2(50);
  E_EXECUTING_EXCEPTION exception;
cursor csr_i_station_subproject is
 select seq_id,sub_project_no,sub_project_person,sub_project_status,import_date from i_epm_station_subproject where import_date between start_time and end_time;
  i_station_subproject csr_i_station_subproject%rowtype;

begin
  count_success := 0;
  count_value := 0;
  total_value:= 0;
  select count(seq_id) into total_value from i_epm_station_subproject where import_date between start_time and  end_time;
  open csr_i_station_subproject;
  fetch csr_i_station_subproject into i_station_subproject;
  while (csr_i_station_subproject%found) loop
   version_value:= 0;
   header_seq_id_value:= 0;
   --首先判断子项目是失效还是有效 0: 删除   1有效 
   if('0' = i_station_subproject.sub_project_status) then 
    --更新失效操作
    update T_SYS_EPM_STATION_SUBPROJECT
            set status = 0,
                SUB_PROJECT_STATUS = i_station_subproject.sub_project_status
    where sub_project_no = i_station_subproject.sub_project_no ;
    --and sub_project_person = i_station_subproject.sub_project_person;
   elsif ('1' = i_station_subproject.sub_project_status) then 
    --有效操作
    select count(seq_id) into count_value from T_SYS_EPM_STATION_SUBPROJECT 
          where sub_project_no  = i_station_subproject.sub_project_no 
                --and sub_project_person = i_station_subproject.sub_project_person
                ;
    if(i_station_subproject.seq_id is not null) then
      if(count_value > 0) then
          select version into version_value from T_SYS_EPM_STATION_SUBPROJECT
                where sub_project_no  = i_station_subproject.sub_project_no 
                       --and sub_project_person = i_station_subproject.sub_project_person
                       ;
      elsif(count_value = 0 ) then
          version_value := 1;
          select seq_id into header_seq_id_value from T_SYS_EPM_STATION_HEADER  
                where mis_no = substr(i_station_subproject.sub_project_no,0,instr(i_station_subproject.sub_project_no,'-')-1);
      end if;
      if(count_value = 1) then
        count_user := 0;
        subprojectPersonName := '';
        select count(u.employee_name) into count_user from t_lis_user u where u.user_id = i_station_subproject.sub_project_person and u.status=1;
        if(count_user > 0) then 
          select max(u.employee_name) into subprojectPersonName from t_lis_user u where u.user_id = i_station_subproject.sub_project_person and u.status=1;
        end if;
        update T_SYS_EPM_STATION_SUBPROJECT set
         version = version_value + 1,Sub_Project_Person=i_station_subproject.sub_project_person,Sub_Project_Person_Name=subprojectPersonName
        where sub_project_no  = i_station_subproject.sub_project_no 
                       --and sub_project_person = i_station_subproject.sub_project_person
                       ;
      else 
        count_user := 0;
        subprojectPersonName := '';
        select count(u.employee_name) into count_user from t_lis_user u where u.user_id = i_station_subproject.sub_project_person and u.status=1;
        if(count_user > 0) then 
          select max(u.employee_name) into subprojectPersonName from t_lis_user u where u.user_id = i_station_subproject.sub_project_person and u.status=1;
        end if;
        insert into T_SYS_EPM_STATION_SUBPROJECT(SEQ_ID,
                                                 header_seq_id,
                                                 SUB_PROJECT_NO,
                                                 SUB_PROJECT_PERSON,
                                                 SUB_PROJECT_PERSON_NAME,
                                                 CREATED_USER,
                                                 CREATED_DATE,
                                                 LAST_UPDATED_USER,
                                                 LAST_UPDATED_DATE,
                                                 VERSION,
                                                 STATUS,
                                                 SUB_PROJECT_STATUS)
         values(SEQ_EPM_STATION.nextval,
                header_seq_id_value,
                i_station_subproject.sub_project_no,
                i_station_subproject.sub_project_person,
                subprojectPersonName,
                '12345678',
                sysdate,
                '12345678',
                sysdate,
                version_value,
                1,
                i_station_subproject.sub_project_status);
      end if;
    end if;
   else 
    exception_info := 'ERR: An error occurred with info: 子项目状态值有错误.' || i_station_subproject.sub_project_no || ',import_date:' || i_station_subproject.import_date;
    raise E_EXECUTING_EXCEPTION;
   end if;
   fetch csr_i_station_subproject into i_station_subproject;
    count_success:=count_success+1;
  end loop;


insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','T_SYS_EPM_STATION_SUBPROJECT');
exception 
  when E_EXECUTING_EXCEPTION  then
    insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_EPM_STATION_SUBPROJECT');
  when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_EPM_STATION_SUBPROJECT');
close csr_i_station_subproject;
commit;
end;
/

