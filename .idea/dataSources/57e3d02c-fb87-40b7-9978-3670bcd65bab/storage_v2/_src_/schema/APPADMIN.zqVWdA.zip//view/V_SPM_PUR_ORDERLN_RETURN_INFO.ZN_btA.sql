create view V_SPM_PUR_ORDERLN_RETURN_INFO as
  SELECT
  /**采购订单查询物化视图依赖的视图*/
  bh.spm_po_header_id ret_spm_po_header_id,
    rl.spm_po_line_id ret_spm_po_line_id,
    SUM(rtl.return_quantity) ret_return_quantity
  FROM t_returnorder_lineinfo rtl,
    t_returnorder_headerinfo rth,
    t_receiptorder_lineinfo rl,
    T_Base_Spm_Pur_Order_Headers bh,
    T_Base_Spm_Pur_Order_Lines bl
  WHERE rth.order_status       =4
  AND rtl.return_order_id      =rth.id
  AND rtl.receipt_order_line_id=rl.receiptorderlineid
  AND bh.spm_po_header_id      =bl.spm_po_header_id
  AND rl.spm_po_line_id        =bl.spm_po_line_id
  GROUP BY rl.spm_po_line_id,
    bh.spm_po_header_id
/

