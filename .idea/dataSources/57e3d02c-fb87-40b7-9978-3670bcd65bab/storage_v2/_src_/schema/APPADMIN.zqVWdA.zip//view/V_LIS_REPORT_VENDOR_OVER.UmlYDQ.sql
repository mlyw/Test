create view V_LIS_REPORT_VENDOR_OVER as
  SELECT
    /**供应商维度呆滞物资占比及当前库存金额视图*/
    tmp.vednor_id,
    tmp.vendor_name,
    SUM(tmp.nowaccount) nowaccount,
    SUM(tmp.overaccount) overaccount,
    ROUND(DECODE(SUM(tmp.nowaccount),0,0,(SUM(tmp.overaccount)*100/(SUM(tmp.nowaccount)))),6) overpersent
  FROM
    (SELECT rqv.vednor_id,
      rqv.vendor_name,
      rqv.item_account nowaccount,
      0 overaccount
    FROM v_lis_report_qty_vendor_now rqv
    UNION ALL
    SELECT rca.vendor_id,
      rca.vendor_name,
      0 nowaccount,
      rca.item_account overaccount
    FROM t_lis_report_core_ageinfo rca
    WHERE rca.isover   =1
    AND rca.vendor_id IS NOT NULL
    ) tmp
  GROUP BY tmp.vednor_id,
    tmp.vendor_name
/

