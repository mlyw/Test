create view V_LIS_REPORT_AGEINFO as
  SELECT
  /**给存储过程用的库龄视图*/
    sysdate create_date,
    (sysdate-1) bussiness_date,
    '' string_value1,
    1 status,
    1 version,
    tmp.item_code,
    tmp.item_desc item_name,
    tmp.item_id,
    tmp.uom_code,
    tmp.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.warehouse_define_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_code,
    d.mis_io_name,
    d.mis_io_id,
    tmp.receipt_pic_code,
    tmp.initdate,
    tmp.product_unit_price,
    tmp.onhand_quantity,
    tmp.onhand_account,
    tmp.isover,
    tmp.itemage,
    tmp.age_7to9,
    tmp.age_10to12,
    tmp.age_13to18,
    tmp.age_19to24,
    tmp.age_25more,
    tmp.mis_pic_code,
    tmp.vendor_id,
    v.vendor_name,
    tmp.locator_code,
    tmp.locator_id,
    tmp.project_id,
    tmp.project_name,
    tmp.project_number
  FROM
    (SELECT q.item_id,
      q.item_code,
      q.item_desc,
      q.uom_code,
      q.uom_desc,
      q.warehouse_define_id,
      q.receipt_pic_code,
      q.product_unit_price,
      q.mis_pic_code,
      q.vendor_id,
      q.locator_code,
      q.locator_id,
      q.project_id,
      q.project_name,
      q.project_number,
      SUM(q.onhand_quantity) onhand_quantity,
      (NVL(q.Cost_Unit_Price,0)*SUM(q.onhand_quantity)) onhand_account,
      TO_CHAR(MIN(q.created_date),'yyyy-MM-dd') initdate,
      (to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd') - to_date(TO_CHAR(MIN(q.created_date),'yyyy-MM-dd'),'yyyy-MM-dd')) itemage,
      CASE
        WHEN (to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd') - to_date(TO_CHAR(MIN(q.created_date),'yyyy-MM-dd'),'yyyy-MM-dd'))>=180
        THEN 1
        ELSE 0
      END AS isover,
      CASE
        WHEN (((to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd') - to_date(TO_CHAR(MIN(q.created_date),'yyyy-MM-dd'),'yyyy-MM-dd'))) >180
        AND ((to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd')   - to_date(TO_CHAR(MIN(q.created_date),'yyyy-MM-dd'),'yyyy-MM-dd')))<=270)
        THEN 1
        ELSE 0
      END AS age_7to9,
      CASE
        WHEN (((to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd') - to_date(TO_CHAR(MIN(q.created_date),'yyyy-MM-dd'),'yyyy-MM-dd'))) >270
        AND ((to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd')   - to_date(TO_CHAR(MIN(q.created_date),'yyyy-MM-dd'),'yyyy-MM-dd')))<=360)
        THEN 1
        ELSE 0
      END AS age_10to12,
      CASE
        WHEN (((to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd') - to_date(TO_CHAR(MIN(q.created_date),'yyyy-MM-dd'),'yyyy-MM-dd'))) >360
        AND ((to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd')   - to_date(TO_CHAR(MIN(q.created_date),'yyyy-MM-dd'),'yyyy-MM-dd')))<=540)
        THEN 1
        ELSE 0
      END AS age_13to18,
      CASE
        WHEN (((to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd') - to_date(TO_CHAR(MIN(q.created_date),'yyyy-MM-dd'),'yyyy-MM-dd'))) >540
        AND ((to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd')   - to_date(TO_CHAR(MIN(q.created_date),'yyyy-MM-dd'),'yyyy-MM-dd')))<=720)
        THEN 1
        ELSE 0
      END AS age_19to24,
      CASE
        WHEN (((to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd') - to_date(TO_CHAR(MIN(q.created_date),'yyyy-MM-dd'),'yyyy-MM-dd')))>720)
        THEN 1
        ELSE 0
      END AS age_25more
    FROM t_wh_current_onhand_quantity q,
      mv_warehouse_define w
    WHERE q.warehouse_define_id=w.id
    AND w.status               =1
    AND q.status               =1
    GROUP BY q.item_id,
      q.item_desc,
      q.item_code,
      q.uom_desc,
      q.uom_code,
      q.warehouse_define_id,
      q.receipt_pic_code,
      q.product_unit_price,
      q.cost_unit_price,
      q.mis_pic_code,
      q.vendor_id,
      q.locator_code,
      q.locator_id,
      q.project_id,
      q.project_name,
      q.project_number
    HAVING SUM(NVL(q.onhand_quantity,0))>0
    ORDER BY to_number(to_date(TO_CHAR(sysdate,'yyyy-MM-dd'),'yyyy-MM-dd') - to_date(TO_CHAR(MIN(q.created_date),'yyyy-MM-dd'),'yyyy-MM-dd'))
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.warehouse_define_id=d.id
  LEFT JOIN t_sys_erp_vendors v
  ON tmp.vendor_id=v.seq_id
/

