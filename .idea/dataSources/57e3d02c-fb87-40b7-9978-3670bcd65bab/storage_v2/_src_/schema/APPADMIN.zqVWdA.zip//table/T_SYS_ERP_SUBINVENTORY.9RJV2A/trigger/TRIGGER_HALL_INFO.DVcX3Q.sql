create trigger TRIGGER_HALL_INFO
  before insert or update
  on T_SYS_ERP_SUBINVENTORY
  for each row
  declare
  count_shm_hall number(15);--营业厅处理记录
  exception_info varchar2(3000 BYTE);--异常信息
  isCountShm number;---营业厅是否存在记录
  V_Hall_Dept_Id number;---分公司ID 
  V_hall_dept_name VARCHAR2(256 BYTE);---分公司名称
  V_Hall_Type number;---营业厅类型
  V_Hall_Status VARCHAR2(10 BYTE); ----营业厅状态
  V_Hall_Area_Type  VARCHAR2(20 BYTE);--营业厅范围属性
  V_If_Distribution number;--是否配送
BEGIN
  if(:new.Attribute10 is not null and :new.Attribute11 is not null) then 
    select count(seq_id) into isCountShm from T_SYS_SHM_HALL where status=1 and hall_mis_code=:new.Subinventory_Code;
    if(:new.Attribute10 = 'SE101')  then
      V_Hall_Area_Type := '市区';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27570000'; 
    elsif(:new.Attribute10='SE102') then 
      V_Hall_Area_Type := '市区';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27590000'; 
    elsif(:new.Attribute10='SE105') then
      V_Hall_Area_Type := '市区';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27580000'; 
    elsif(:new.Attribute10='SE201') then
      V_Hall_Area_Type := '郊县';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27320000'; 
    elsif(:new.Attribute10='SE202') then
      V_Hall_Area_Type := '郊县';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27300000'; 
    elsif(:new.Attribute10='SE203') then
      V_Hall_Area_Type := '郊县';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27310000';       
    elsif(:new.Attribute10='SE204') then
      V_Hall_Area_Type := '郊县';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27260000';  
    elsif(:new.Attribute10='SE205') then
      V_Hall_Area_Type := '郊县';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27240000';   
    elsif(:new.Attribute10='SE206') then
      V_Hall_Area_Type := '郊县';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27270000';        
    elsif(:new.Attribute10='SE207') then
      V_Hall_Area_Type := '郊县';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27290000';   
    elsif(:new.Attribute10='SE208') then
      V_Hall_Area_Type := '郊县';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27250000';
    elsif(:new.Attribute10='SE209') then
      V_Hall_Area_Type := '郊县';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27280000'; 
    elsif(:new.Attribute10='SE302') then
      V_Hall_Area_Type := '市区';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27120000'; 
    elsif(:new.Attribute10='SE303') then
      V_Hall_Area_Type := '市区';
      select id,dept_name into V_Hall_Dept_Id,V_hall_dept_name from T_LIS_DEPT where status=1 and DEPT_CODE='27620000'; 
    else 
      V_Hall_Area_Type := '市区';
    end if;
    ---数据初始化
    count_shm_hall:= 0;
    if(:new.Attribute11='主厅') then
      V_Hall_Type := 1;
      V_If_Distribution := 1;
      if(:new.status=1) then
        V_Hall_Status := '正式营业';
      else
        V_Hall_Status := '关厅';
      end if;
    else
      V_Hall_Type := 0;
      V_If_Distribution := 0;
      if(:new.status=1) then
        V_Hall_Status := '开厅';
      else
        V_Hall_Status := '关厅';
      end if;
    end if;
    ---同步营业厅信息
    if isCountShm > 0 then
        ---更新营业厅信息
        update T_SYS_SHM_HALL  set hall_name=:new.Subinventory_Name, 
        HALL_CODE = :new.Attribute9,
        HALL_DEPT_ID = V_Hall_Dept_Id,
        HALL_DEPT_CODE =  :new.Attribute10,
        HALL_DEPT_NAME = V_hall_dept_name,
        HALL_TYPE = V_Hall_Type,
        HALL_ADDRESS  = :new.Subinventory_Name,
        HALL_STATUS = V_Hall_Status,
        EXPIRED_DATE = :new.DISABLE_DATE,
        HALL_AREA_TYPE = V_Hall_Area_Type,
        IF_DISTRIBUTION = V_If_Distribution,
        VERSION = VERSION+1,
        STATUS = :new.status,
        LAST_UPDATED_DATE = sysdate,
        LAST_UPDATED_USER = '12345678'
        where hall_mis_code = :new.Subinventory_Code;
        count_shm_hall := count_shm_hall + 1;
    else 
        ---新建营业厅信息
        INSERT INTO T_SYS_SHM_HALL 
              (
                SEQ_ID,
                HALL_CODE,
                HALL_MIS_CODE,
                HALL_NAME,
                HALL_DEPT_ID,
                HALL_DEPT_CODE,
                HALL_DEPT_NAME,
                HALL_TYPE,
                HALL_ADDRESS,
                HALL_STATUS,
                EXPIRED_DATE,
                HALL_AREA_TYPE,
                IF_DISTRIBUTION,
                VERSION,
                STATUS,
                CREATED_USER,
                CREATED_DATE,
                STRING_VALUE1
              )
        values
              (
                SEQ_SYS_SHM_HALL.NEXTVAL,
                :new.Attribute9,
                :new.Subinventory_Code,
                :new.SUBINVENTORY_NAME,
                V_Hall_Dept_Id,
                :new.Attribute10,
                V_hall_dept_name,
                V_Hall_Type,
                :new.SUBINVENTORY_NAME,
                V_Hall_Status,
                :new.DISABLE_DATE,
                V_Hall_Area_Type,
                V_If_Distribution,
                0,
                :new.status,
                '12345678',
                sysdate,
                'trigger_hall_info触发器同步'
              );
              count_shm_hall := count_shm_hall + 1;
     end if;
   end if;
---插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,count_shm_hall,count_shm_hall,sysdate,'同步成功;'||:new.Subinventory_Code,'trigger_hall_info:t_sys_erp_subinventory->t_sys_shm_hall');
exception when others then
  exception_info := 'trigger_hall_info:'||:new.Subinventory_Code||' An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,count_shm_hall,count_shm_hall,sysdate,exception_info,'trigger_hall_info:t_sys_erp_subinventory->t_sys_shm_hall');
END TRIGGER_HALL_INFO;
/

