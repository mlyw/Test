create view V_ONHAND_QTY_COMPARE_WITH_MIS as
  select t1.item_code,t1.mis_pic_code,t1.organization_code,t1.subinventory_code,t1.locator_code,t1.mis_onhand_quantity,
       t2.lis_onhand_quantity, nvl(t1.mis_onhand_quantity,0) - nvl(t2.lis_onhand_quantity, 0) misTolis_subtract_quantity
  from (select 1,
               t.item_code item_code,
               t.lot_number mis_pic_code,
               t.organization_code organization_code,
               t.subinventory_code subinventory_code,
               case when t.locator_code is null then
                    '||'
                else case when t.locator_code='||' then
                     t.locator_code
                else case when substr(t.locator_code,length(t.locator_code)-1,2)='||' then
                     substr(t.locator_code,0,length(t.locator_code)-2)
                else case when substr(t.locator_code,length(t.locator_code),1)='|' then
                     substr(t.locator_code,0,length(t.locator_code)-1)
                end
                end
                end
                end as locator_code,
               sum(round(nvl(t.onhand_quantity, 0),5)) mis_onhand_quantity
          from t_sys_erp_onhand_quantity t
         group by t.organization_code,
                  t.subinventory_code,
                  t.locator_code,
                  t.item_code,
                  t.lot_number) t1,
       (select 2,
               ta.item_code item_code,
               ta.mis_pic_code mis_pic_code,
               td.mis_io_code organization_code,
               td.mis_subinventory_name subinventory_code,
               nvl(ta.locator_code, '||') locator_code,
               sum(round(ta.onhand_quantity, 5)) lis_onhand_quantity
          from t_wh_current_onhand_quantity ta, t_warehouse_define td
         where ta.warehouse_define_id = td.id
           and td.warehouse_define_code not like 'ZC%'
           and ta.erp_type <> 'TT'
           and (ta.is_compare_with_mis is null or ta.is_compare_with_mis <>'N')--add by lmt,2018-11-15
           and ta.status = 1
           and nvl(ta.onhand_quantity, 0) > 0
         group by td.mis_io_code,
                  td.mis_subinventory_name,
                  ta.locator_code,
                  ta.item_code,
                  ta.mis_pic_code) t2
 where t1.item_code = t2.item_code(+)
   and t1.mis_pic_code = t2.mis_pic_code(+)
   and t1.organization_code = t2.organization_code(+)
   and t1.subinventory_code = t2.subinventory_code(+)
   and t1.locator_code = t2.locator_code(+)
union
select t2.item_code,t2.mis_pic_code,t2.organization_code,t2.subinventory_code,t2.locator_code,t1.mis_onhand_quantity,
       t2.lis_onhand_quantity, nvl(t1.mis_onhand_quantity,0) - nvl(t2.lis_onhand_quantity, 0) misTolis_subtract_quantity
  from (select 1,
               t.item_code item_code,
               t.lot_number mis_pic_code,
               t.organization_code organization_code,
               t.subinventory_code subinventory_code,
               case when t.locator_code is null then
                    '||'
                else case when t.locator_code='||' then
                     t.locator_code
                else case when substr(t.locator_code,length(t.locator_code)-1,2)='||' then
                     substr(t.locator_code,0,length(t.locator_code)-2)
                else case when substr(t.locator_code,length(t.locator_code),1)='|' then
                     substr(t.locator_code,0,length(t.locator_code)-1)
                end
                end
                end
                end as locator_code,
               sum(round(nvl(t.onhand_quantity, 0),5)) mis_onhand_quantity
          from t_sys_erp_onhand_quantity t
         group by t.organization_code,
                  t.subinventory_code,
                  t.locator_code,
                  t.item_code,
                  t.lot_number) t1,
       (select 2,
               ta.item_code item_code,
               ta.mis_pic_code mis_pic_code,
               td.mis_io_code organization_code,
               td.mis_subinventory_name subinventory_code,
               nvl(ta.locator_code, '||') locator_code,
               sum(round(ta.onhand_quantity, 5)) lis_onhand_quantity
          from t_wh_current_onhand_quantity ta, t_warehouse_define td
         where ta.warehouse_define_id = td.id
           and td.warehouse_define_code not like 'ZC%'
           and ta.erp_type <> 'TT'
           and (ta.is_compare_with_mis is null or ta.is_compare_with_mis <>'N')--add by lmt,2018-11-15
           and ta.status = 1
           and nvl(ta.onhand_quantity, 0) > 0
         group by td.mis_io_code,
                  td.mis_subinventory_name,
                  ta.locator_code,
                  ta.item_code,
                  ta.mis_pic_code) t2
 where t2.item_code = t1.item_code(+)
   and t2.mis_pic_code = t1.mis_pic_code(+)
   and t2.organization_code = t1.organization_code(+)
   and t2.subinventory_code = t1.subinventory_code(+)
   and t2.locator_code = t1.locator_code(+)
/

