create view V_LIS_REPORT_WORK_ORDER_INFO as
  SELECT
    /**工作单据及业务量统计视图*/
    tmp.bussinessdate,
    tmp.item_code,
    tmp.item_desc,
    tmp.item_id,
    tmp.uom_code,
    tmp.uom_desc,
    tmp.concatenated_segments,
    tmp.category_description,
    tmp.warehouse_id,
    tmp.warehouse_define_code,
    tmp.warehouse_define_name,
    tmp.mis_ou_id,
    tmp.mis_io_code,
    tmp.mis_io_name,
    tmp.mis_io_id,
    SUM(NVL(tmp.quantities,0)) quantities,
    SUM(NVL(tmp.accounts,0)) accounts,
    tmp.order_id,
    tmp.order_code,
    tmp.order_type,
    SUM(NVL(tmp.lines,0)) lines
  FROM
    (SELECT o.mis_ou_id,
      o.mis_io_id,
      o.warehouse_out_id warehouse_id,
      o.mis_io_code,
      o.mis_io_name,
      o.warehouse_define_code,
      o.warehouse_define_name,
      o.order_code,
      CASE
        WHEN (o.order_type='报废卡退库'
        OR o.order_type   ='有价卡销售'
        OR o.order_type   ='SIM卡销售')
        THEN '出库'
        ELSE o.order_type
      END order_type,
      o.order_id,
      o.category_description,
      o.concatenated_segments,
      o.item_id,
      o.item_code,
      o.item_desc,
      o.uom_code,
      o.uom_desc,
      TO_CHAR(o.import_date,'yyyy-MM-dd') bussinessdate,
      COUNT(o.order_code) lines,
      SUM(o.current_out_quantity) quantities,
      SUM(o.current_out_account) accounts
    FROM V_LIS_REPORT_TRANSACTION_OUT o
    GROUP BY o.mis_ou_id,
      o.mis_io_id,
      o.warehouse_out_id,
      o.mis_io_code,
      o.mis_io_name,
      o.warehouse_define_code,
      o.warehouse_define_name,
      o.order_type,
      o.order_code,
      o.order_id,
      o.category_description,
      o.concatenated_segments,
      o.item_id,
      o.item_code,
      o.item_desc,
      o.uom_code,
      o.uom_desc,
      TO_CHAR(o.import_date,'yyyy-MM-dd')
    UNION ALL
    SELECT r.mis_ou_id,
      r.mis_io_id,
      r.warehouse_receive_id warehouse_id,
      r.mis_io_code,
      r.mis_io_name,
      r.warehouse_define_code,
      r.warehouse_define_name,
      r.order_code,
      CASE
        WHEN (r.order_type='SIM卡销售回退'
        OR r.order_type   ='有价卡销售回退'
        OR r.order_type   ='报废卡退库'
        OR r.order_type   ='大库调入')
        THEN '接收入库'
        WHEN (r.order_code LIKE '%JSZF%')
        THEN '接收直发'
        WHEN (r.order_code LIKE '%JSRK%')
        THEN '接收入库'
        ELSE r.order_type
      END order_type,
      r.order_id,
      r.category_description,
      r.concatenated_segments,
      r.item_id,
      r.item_code,
      r.item_desc,
      r.uom_code,
      r.uom_desc,
      TO_CHAR(r.import_date,'yyyy-MM-dd') bussinessdate,
      COUNT(r.order_code) orders,
      SUM(r.current_receive_quantity) quantities,
      SUM(r.current_receive_account) accounts
    FROM v_Lis_Report_Transaction_Into r
    GROUP BY r.mis_ou_id,
      r.mis_io_id,
      r.warehouse_receive_id,
      r.mis_io_code,
      r.mis_io_name,
      r.warehouse_define_code,
      r.warehouse_define_name,
      r.order_type,
      r.order_code,
      r.order_id,
      r.category_description,
      r.concatenated_segments,
      r.item_id,
      r.item_code,
      r.item_desc,
      r.uom_code,
      r.uom_desc,
      TO_CHAR(r.import_date,'yyyy-MM-dd')
    ) tmp
  GROUP BY tmp.mis_ou_id,
    tmp.mis_io_id,
    tmp.warehouse_id,
    tmp.mis_io_code,
    tmp.mis_io_name,
    tmp.warehouse_define_code,
    tmp.warehouse_define_name,
    tmp.order_code,
    tmp.order_type,
    tmp.order_id,
    tmp.order_code,
    tmp.category_description,
    tmp.concatenated_segments,
    tmp.item_id,
    tmp.item_code,
    tmp.item_desc,
    tmp.uom_code,
    tmp.uom_desc,
    tmp.bussinessdate
/

