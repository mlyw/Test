create procedure "PROC_AD_DEPT"(start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
parentId number(15);
deptCode varchar2(200);
count_success number(15);
count_disable number(15);
exception_info varchar2(3000);
cursor csr_ad_dept is 
select 
       SEQ_ID,PARENT_DEPT_NAME,DEPT_NAME,IF_ROOT,DISTINGUISHED_NAME
       from t_ad_dept where IMPORT_DATE between start_time and end_time ;
ad_depts csr_ad_dept%rowtype;
cursor csr_dis_dept is 
select distinct
       PARENT_DEPT_NAME,DEPT_NAME from t_ad_dept 
       minus
select PARENT_DEPT_NAME,DEPT_NAME from t_ad_dept where IMPORT_DATE between start_time and end_time;
dis_depts csr_dis_dept%rowtype;
begin
  --处理失效部门
  open csr_dis_dept;
  fetch csr_dis_dept into dis_depts;
  while(csr_dis_dept%found) loop
  update t_lis_dept d set d.status = 0,d.string_value1 = 'sync from adDept',d.last_updated_date=sysdate where d.dept_name = dis_depts.dept_name;
  fetch csr_dis_dept into dis_depts;
  end loop;
  close csr_dis_dept;
  commit; 
  --处理更新、新增部门
 count_success :=0;
  select count(SEQ_ID) into total_value from t_ad_dept where IMPORT_DATE between start_time and end_time ;
  open csr_ad_dept ;
  fetch csr_ad_dept into ad_depts;
while (csr_ad_dept%found) loop
  BEGIN
    select d.id into parentId from t_lis_dept d where  d.status = 1 and d.dept_name in( 
    select distinct dt.parent_dept_name from t_ad_dept dt where dt.dept_name = ad_depts.dept_name);
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      parentId :=NULL;
   END;
   
  BEGIN
    select d.dept_code into deptCode from t_lis_dept d where d.dept_name = ad_depts.dept_name and d.status = 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      deptCode :=NULL;
   END;
  --处理t_lis_dept
  select count(ID) into count_disable from t_lis_dept where DEPT_NAME = ad_depts.dept_name and status =0;
  
  if(count_disable=0) then
  select count(ID) into count_value from t_lis_dept where DEPT_NAME = ad_depts.dept_name and status = 1;
  if(count_value=1) then 
  if parentId is null then
  update t_lis_dept d
   set d.LAST_UPDATED_DATE = systimestamp,d.version = d.version+1
   where d.dept_name = ad_depts.dept_name ; --如果存在则更新？？？
   elsif parentId is not null then 
       update t_lis_dept d
   set d.LAST_UPDATED_DATE = systimestamp,d.version = d.version+1,d.parent_id = parentId
   where d.dept_name = ad_depts.dept_name ; --如果存在则更新？？？
  end if;
  count_success := count_success + 1;
elsif(count_value= 0 ) then
    -- select parent_id into count_parent
    --  from t_lis_dept where dept_name = ad_depts.parent_dept_name;
  --    if count_parent is null then 
  if parentId is null then
  insert into t_lis_dept(
    id,dept_name,dept_code,comp_code,ou_id,parent_id,status,created_user,created_date,version
  ) values(
    lis_order_seq.nextval,ad_depts.dept_name,deptCode,2710,82,251,1,12345678,sysdate,0
 );
 elsif parentId is not null then  
   insert into t_lis_dept(
    id,dept_name,dept_code,comp_code,ou_id,parent_id,status,created_user,created_date,version
   ) values(
    lis_order_seq.nextval,ad_depts.dept_name,deptCode,2710,82,parentId,1,12345678,sysdate,0
   );
  count_success := count_success + 1;
   
  end if;
 end if;
end if;
fetch csr_ad_dept into ad_depts;
end loop;
close csr_ad_dept;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value, count_success, sysdate,'同步成功','T_AD_DEPT');
exception when others then
  rollback;
  --count_num := count_success;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_AD_DEPT');
close csr_ad_dept;
commit;
end;
/

