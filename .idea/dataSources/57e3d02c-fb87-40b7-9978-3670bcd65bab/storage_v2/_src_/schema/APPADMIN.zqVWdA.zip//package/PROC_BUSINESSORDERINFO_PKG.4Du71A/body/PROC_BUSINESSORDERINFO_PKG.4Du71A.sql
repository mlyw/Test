create PACKAGE BODY PROC_BUSINESSORDERINFO_PKG is

    --查询头信息
   PROCEDURE PROC_BUSINESSORDERINFO_HEADERS(startdate in date,enddate in date,temp_headerlist out cursor_header_list) as
BEGIN
  /* 每次执行存储过程时,删除表中所有的数据 */
  delete from temp_businessorderinfo_header;

  /*插入某个时间段的头数据到头临时表中*/
  INSERT INTO temp_businessorderinfo_header(order_id, order_num,  order_desc,order_type, created_user, dept_name, created_date)
  SELECT outhd.ID,outhd.OUT_ORD_CODE,
        decode(outhd.ORD_DESC, null, '', outhd.ORD_DESC),
        '出库单',
        outhd.created_user, dept.dept_name, outhd.CREATED_DATE
        FROM T_OUT_HD outhd INNER JOIN T_LIS_DEPT dept ON outhd.CRE_DEPT_ID = dept.id
                            LEFT JOIN (select max(mk.out_ord_id) out_ord_id ,max(mk.acc_cfm_date) acc_cfm_date from t_out_notmk mk
                                                          where mk.status=1 and mk.asgn_ln_status=1
                                                          group by mk.out_ord_id
                                        ) notmk on notmk.out_ord_id=outhd.id
        where (outhd.OUT_ORD_CODE like '%-CK-%' or outhd.OUT_ORD_CODE like '%-ZHCK-%' or outhd.OUT_ORD_CODE like '%-CNPCK-%')
                and outhd.OUT_ORD_CODE is not null
                and outhd.created_user is not null
                and outhd.CRE_DEPT_ID is not null
                --指明规定的时间
                and outhd.ord_status = 6
                and outhd.status=1
                and  notmk.acc_cfm_date >= startdate and notmk.acc_cfm_date <=enddate 
  union all
  SELECT  bkhd.ID, bkhd.BACK_ORDER_CODE,
          decode(bkhd.BACK_ORDER_DESC, null, '', bkhd.BACK_ORDER_DESC) orderDesc,
          '退库单',
        bkhd.created_user,dept.dept_name,bkhd.created_date
        FROM T_BCK_HD bkhd INNER JOIN T_LIS_DEPT dept ON bkhd.CREATIONDEPTID=dept.id
        where (bkhd.BACK_ORDER_CODE like '%-TK-%' or bkhd.BACK_ORDER_CODE like '%-CNPTK-%' or bkhd.BACK_ORDER_CODE like '%-ZHBK-%')
             and bkhd.BACK_ORDER_CODE is not null
             and  bkhd.created_user is not null
             and bkhd.CREATIONDEPTID is not null
             --指明规定的时间
             and bkhd.orderstatus = 60
             and bkhd.status=1
             and bkhd.ledger_date >= startdate and bkhd.ledger_date <= enddate
    union all
    SELECT  chg.ID,
            chg.WH_CHG_ORD_CODE,
            decode(chg.WH_CHG_DESC, null, '', chg.WH_CHG_DESC) orderDesc,
            '调拨单',
        chg.created_user, dept.dept_name, chg.created_date
        FROM T_CHG_HD_LN chg INNER JOIN T_LIS_DEPT dept ON chg.CRT_DEPT_ID=dept.id
        where (chg.WH_CHG_ORD_CODE like '%-DB-%' or chg.WH_CHG_ORD_CODE like '%-CNPDB-%' or chg.WH_CHG_ORD_CODE like '%-ZHDB-%')
                and chg.WH_CHG_ORD_CODE is not null
               -- and chg.created_user is not null
               -- and chg.CRT_DEPT_ID is not null
                -- 指明规定给的时间
                and (chg.order_status = 5 or chg.order_status=50)
                and chg.status=1
               and  chg.account_date >= startdate and chg.account_date <= enddate
     union all
     --sim卡
     SELECT simhd.id,
       simhd.simcard_order_code,'',
       (SELECT CASE WHEN wd.warehouse_define_code like 'C00%'then '调拨单' else '出库单' end FROM  T_LIS_SIMCARD_SALES_MONTH_LINE simline INNER JOIN T_WAREHOUSE_DEFINE wd ON simline.wd_id=wd.id WHERE simline.head_id=simhd.id and rownum=1),
       simhd.created_user,
       (select dept.dept_name
        from  t_lis_dept dept left join t_lis_ouuser ou ON ou.ou_dept_id=dept.id
        WHERE ou.ou_employee_number=simhd.created_user),
       simhd.created_date
       FROM T_LIS_SIMCARD_SALES_MONTH_HEAD simhd
       WHERE simhd.created_user is not null  and simhd.status=1 and simhd.head_status=4
             and simhd.transaction_processing_time >= startdate and simhd.transaction_processing_time <=enddate
   ORDER BY 7;

   commit;
   open temp_headerlist for select order_id,order_num,order_type,order_desc,created_user, dept_name, created_date from temp_businessorderinfo_header;
END PROC_BUSINESSORDERINFO_HEADERS;

    --根据点头主键和单子类型查询行信息
    PROCEDURE PROC_BUSINESSORDERINFO_LINES(startdate in date,enddate in date,orderid in number,ordertype in varchar2,ordernum in varchar2,temp_linelist out cursor_line_list) as
BEGIN
    /* 每次执行存储过程时,删除表中所有的数据 */
  delete from temp_businessorderinfo_line;

  /*根据主键和类型查找行，插入行临时表*/
  --由于sim卡与其他不耦合，所以先判断是不是sim卡类型
  if ( (ordertype like '%出库单%') or (ordertype like '%调拨单%') ) and (ordernum like '%-SIMC-%') then
                  INSERT INTO temp_businessorderinfo_line(order_line_id,
                                           order_quantity,
                                           uom_code,
                                           uom_desc,
                                           source_warehouse_id,
                                           source_warehouse_code,
                                           source_warehouse_name,
                                           source_goodsallocation_code,
                                           target_warehouse_id,
                                           target_warehouse_code,
                                           target_warehouse_name,
                                           target_goodsallocation_code,
                                           source_project_id,
                                           source_project_code,
                                           source_project_name,
                                           target_project_id,
                                           target_project_code,
                                           target_project_name,
                                           mis_pic_code,
                                           lis_pic_code)
                                    SELECT  simline.id,
                                           simline.simcard_qty,
                                           item.uom_code,
                                           item.uom_desc,
                                            0,
                                           '无',
                                           '无',
                                           '无',
                                           wd.id,
                                           wd.warehouse_define_code,
                                           wd.warehouse_define_name,
                                           '无',
                                            0,
                                           '无',
                                           '无',
                                            0,
                                           '无',
                                           '无',
                                           '无',
                                           decode(simline.line_pic,null,'无',simline.line_pic)
                                    FROM T_LIS_SIMCARD_SALES_MONTH_LINE simline LEFT JOIN t_sys_erp_items item ON simline.item_id=item.item_id
                                         LEFT JOIN t_warehouse_define wd ON simline.wd_id=wd.id
                                    where simline.head_id=orderid;
    end if;
  if ordertype like '%出库单%' then
     INSERT INTO temp_businessorderinfo_line(order_line_id,
                                           order_quantity,
                                           uom_code,
                                           uom_desc,
                                           source_warehouse_id,
                                           source_warehouse_code,
                                           source_warehouse_name,
                                           source_goodsallocation_code,
                                           target_warehouse_id,
                                           target_warehouse_code,
                                           target_warehouse_name,
                                           target_goodsallocation_code,
                                           source_project_id,
                                           source_project_code,
                                           source_project_name,
                                           target_project_id,
                                           target_project_code,
                                           target_project_name,
                                           mis_pic_code,
                                           lis_pic_code)
                    SELECT distinct
                          outmk.id,
                          outmk.asgn_quty,
                          item.uom_code,
                          item.uom_desc,
                          wd.id,
                          wd.warehouse_define_code,
                          wd.warehouse_define_name,
                          outmk.locator_code,
                          0,
                         '无',
                         '无',
                         '无',
                         prj.project_id,
                         prj.project_code,
                         prj.project_name,
                         0,
                         '无',
                         '无',
                         decode(outmk.mis_pic_code,
                                            null,
                                            '无',
                                            outln.mis_pic_code),
                         decode(outmk.rcp_pic_code,null,'无',outmk.rcp_pic_code)
                    FROM t_out_hd outhd INNER JOIN t_out_ln outln ON outhd.id=outln.outhdinfo_id
                         INNER JOIN t_out_notmk outmk ON outln.id=outmk.ord_ln_id
                         LEFT JOIN t_sys_erp_items item ON item.item_id=outln.item_id and item.erp_type='2G'
                         LEFT JOIN t_warehouse_define wd ON wd.id=outmk.warehouseid
                         LEFT JOIN t_sys_erp_projects prj ON outhd.project_id = prj.project_id
                  where outhd.id=orderid;-- AND (outln.created_date between startdate and enddate);
      elsif ordertype like '%调拨单%' then
        INSERT INTO temp_businessorderinfo_line(order_line_id,
                                           order_quantity,
                                           uom_code,
                                           uom_desc,
                                           source_warehouse_id,
                                           source_warehouse_code,
                                           source_warehouse_name,
                                           source_goodsallocation_code,
                                           target_warehouse_id,
                                           target_warehouse_code,
                                           target_warehouse_name,
                                           target_goodsallocation_code,
                                           source_project_id,
                                           source_project_code,
                                           source_project_name,
                                           target_project_id,
                                           target_project_code,
                                           target_project_name,
                                           mis_pic_code,
                                           lis_pic_code)
            SELECT chgln.id,
                   chgln.change_quty,
                   chgln.uom_code,
                   chgln.uom_desc,
                   (SELECT wd.id FROM t_warehouse_define wd WHERE wd.id=chgln.wh_id_trf_from),
                   (SELECT wd.warehouse_define_code FROM t_warehouse_define wd WHERE wd.id=chgln.wh_id_trf_from),
                   (SELECT wd.warehouse_define_name FROM t_warehouse_define wd WHERE wd.id=chgln.wh_id_trf_from),
                   chgln.locator_code,
                   (SELECT towd.id FROM t_warehouse_define towd WHERE towd.id=chgln.wh_id_trf_into),
                   (SELECT towd.warehouse_define_code FROM t_warehouse_define towd WHERE towd.id=chgln.wh_id_trf_into),
                   (SELECT towd.warehouse_define_name FROM t_warehouse_define towd WHERE towd.id=chgln.wh_id_trf_into),
                   chgln.to_locator_code,
                   decode(prj.project_id,null,0,prj.project_id),
                   decode(prj.project_code,null,'无',prj.project_code),
                   decode(prj.project_name,null,'无',prj.project_name),
                   decode(prjto.project_id,null,0,prjto.project_id),
                   decode(prjto.project_code,null,'无',prjto.project_code),
                   decode(prjto.project_name,null,'无',prjto.project_name),
                   decode(chgln.mis_pic_code, null, '无', chgln.mis_pic_code),
                   decode(chgln.rcpt_pic_code, null, '无', chgln.rcpt_pic_code)
            FROM t_chg_ln chgln LEFT JOIN t_sys_erp_projects prj ON prj.project_id=chgln.prj_id_trf_from
                 LEFT JOIN t_sys_erp_projects prjto ON prjto.project_id=chgln.prj_id_trf_into
            WHERE chgln.chghdln_id=orderid;
      elsif ordertype like '%退库单%' then
            INSERT INTO temp_businessorderinfo_line(order_line_id,
                                           order_quantity,
                                           uom_code,
                                           uom_desc,
                                           source_warehouse_id,
                                           source_warehouse_code,
                                           source_warehouse_name,
                                           source_goodsallocation_code,
                                           target_warehouse_id,
                                           target_warehouse_code,
                                           target_warehouse_name,
                                           target_goodsallocation_code,
                                           source_project_id,
                                           source_project_code,
                                           source_project_name,
                                           target_project_id,
                                           target_project_code,
                                           target_project_name,
                                           mis_pic_code,
                                           lis_pic_code)
            SELECT bckln.id,
                     bckln.backquantity,
                     item.uom_code,
                     item.uom_desc,
                     0,
                     '无',
                     '无',
                     '无',
                     wd.id,
                     wd.warehouse_define_code,
                     wd.warehouse_define_name,
                     bckln.locator_code,
                     0,
                     '无',
                     '无',
                     decode(prj.project_id,null,0,prj.project_id),
                     decode(prj.project_code,null,'无',prj.project_code),
                     decode(prj.project_name,null,'无',prj.project_name),
                     decode(bckln.mis_pic_code, null, '无', bckln.mis_pic_code),
                     decode(bckln.rcpt_pic_code, null, '无', bckln.rcpt_pic_code)
                      FROM t_bck_ln bckln
                      LEFT JOIN t_bck_hd bckhd
                        ON bckln.bckhdinfo_id = bckhd.id
                     LEFT JOIN t_sys_erp_projects prj
                        ON bckhd.projectid = prj.project_id
                      LEFT JOIN t_sys_erp_items item
                        ON bckln.itemid = item.item_id and item.erp_type='2G'
                     LEFT JOIN t_warehouse_define wd
                        ON bckln.warehousebacktoid = wd.id
                   where bckhd.id=orderid;
  end if;
  commit;
  open temp_linelist for
      select order_line_id,
      order_quantity,
      uom_code,
      uom_desc,
      source_warehouse_id,
      source_warehouse_code,
      source_warehouse_name,
      source_goodsallocation_code,
      target_warehouse_id,
      target_warehouse_code,
      target_warehouse_name,
      target_goodsallocation_code,
      source_project_id,
      source_project_code,
      source_project_name,
      target_project_id,
      target_project_code,
      target_project_name,
      mis_pic_code,
      lis_pic_code
      from temp_businessorderinfo_line;
END PROC_BUSINESSORDERINFO_LINES;

end PROC_BUSINESSORDERINFO_PKG;
/

