create view V_LIS_REPORT_START_STOP as
  SELECT
    /**以ou/库存/子库/物料分类/物料为维度的期初期末现有量统计视图（含当前月份当前日期的动态期末数据）*/
    lrc.bussiness_date,
    lrc.ou_id,
    lrc.organization_id,
    lrc.warehouse_define_id,
    lrc.item_category_code,
    lrc.item_category_name,
    lrc.item_id,
    lrc.item_code,
    lrc.item_desc,
    lrc.item_uom_code,
    lrc.item_uom_desc,
    SUM(lrc.onhand_quantity_account) startaccount,
    SUM(lrc.onhand_quantity) startqty,
    0 endaccount,
    0 endqty
  FROM t_lis_report_core_onhandqty lrc
  WHERE lrc.data_type=1
  GROUP BY lrc.bussiness_date,
    lrc.ou_id,
    lrc.organization_id,
    lrc.warehouse_define_id,
    lrc.item_category_code,
    lrc.item_category_name,
    lrc.item_id,
    lrc.item_code,
    lrc.item_desc,
    lrc.item_uom_code,
    lrc.item_uom_desc
  UNION ALL
  SELECT lrc.bussiness_date,
    lrc.ou_id,
    lrc.organization_id,
    lrc.warehouse_define_id,
    lrc.item_category_code,
    lrc.item_category_name,
    lrc.item_id,
    lrc.item_code,
    lrc.item_desc,
    lrc.item_uom_code,
    lrc.item_uom_desc,
    0 startaccount,
    0 startqty,
    SUM(lrc.onhand_quantity_account) endaccount,
    SUM(lrc.onhand_quantity) endqty
  FROM t_lis_report_core_onhandqty lrc
  WHERE lrc.data_type=2
  GROUP BY lrc.bussiness_date,
    lrc.ou_id,
    lrc.organization_id,
    lrc.warehouse_define_id,
    lrc.item_category_code,
    lrc.item_category_name,
    lrc.item_id,
    lrc.item_code,
    lrc.item_desc,
    lrc.item_uom_code,
    lrc.item_uom_desc
  UNION ALL
  SELECT vrc.bussinessdate,
    vrc.ou_id,
    vrc.organization_id,
    vrc.warehouse_define_id,
    vrc.item_category_code,
    vrc.item_category_name,
    vrc.item_id,
    vrc.item_code,
    vrc.item_desc,
    vrc.item_uom_code,
    vrc.item_uom_desc,
    0 startaccount,
    0 startqty,
    SUM(vrc.onhand_quantity_account) endaccount,
    SUM(vrc.onhand_quantity) endqty
  FROM v_lis_report_onhandqty_nowend vrc
  GROUP BY vrc.bussinessdate,
    vrc.ou_id,
    vrc.organization_id,
    vrc.warehouse_define_id,
    vrc.item_category_code,
    vrc.item_category_name,
    vrc.item_id,
    vrc.item_code,
    vrc.item_desc,
    vrc.item_uom_code,
    vrc.item_uom_desc
/

