create view V_SPM_PUR_ORDER_INFO as
  SELECT
  /**采购订单查询物化视图依赖的视图*/
  bh.mis_po_number po_mis_po_number,
    bh.spm_po_desc po_spm_po_desc,
    bh.agent_id po_agent_id,
    bh.vendor_id po_vendor_id,
    bh.vendor_name po_vendor_name,
    bh.spm_po_header_id po_spm_po_header_id,
    bh.erp_type po_erp_type,
    bh.ou_id po_ou_id,
    bl.mis_po_line_num po_mis_po_line_num,
    bl.item_category_id po_item_category_id,
    bl.item_category_code po_item_category_code,
    bl.item_category_desc po_item_category_desc,
    bl.item_id,
    bl.item_code po_item_code,
    bl.item_desc po_item_desc,
    bl.uom_desc po_uom_desc,
    bl.uom_code po_uom_code,
    bl.product_unit_price po_product_unit_price,
    bl.quantity_ordered pol_quantity_ordered,
    (NVL(bl.quantity_ordered,0)*NVL(bl.product_unit_price,0)) pol_quantity_ordered_account,
    bl.Quantity_Received pol_Quantity_Received,
    (NVL(bl.Quantity_Received,0)*NVL(bl.product_unit_price,0)) pol_quantity_Received_account,
    bl.Quantity_Receivable pol_Quantity_Receivable,
    (NVL(bl.Quantity_Receivable,0)*NVL(bl.product_unit_price,0)) pol_quantity_Receiable_account,
    bl.is_need_check pol_is_need_check,
    bl.spm_po_line_id pol_spm_po_line_id,
    bl.organization_id pol_organization_id,
    bh.po_approval_date
  FROM T_Base_Spm_Pur_Order_Headers bh,
    T_Base_Spm_Pur_Order_Lines bl
  WHERE bh.spm_po_header_id=bl.spm_po_header_id
  AND bh.status            =1
  AND bl.status            =1
  AND bl.quantity_ordered  >0
/

