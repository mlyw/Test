create materialized view MV_T_LIS_USER
refresh force on demand
  as
    SELECT
    /**每6小时运行一次:START WITH SYSDATE NEXT SYSDATE + 21600/86400
    查询采购订单中的采购员信息*/
    tmp.h_agent_id,
    tmp1.v_employee_name,
    tmp1.v_org_code,
    tmp1.v_org_name,
    tmp1.v_office_tel,
    tmp1.v_mobile_phone,
    tmp1.v_email,
    tmp1.v_dept_id,
    tmp1.v_user_id,
    sysdate builddate
  FROM
    (SELECT DISTINCT(h.agent_id) h_agent_id
    FROM T_Base_Spm_Pur_Order_Headers h
    WHERE h.status=1
    ) tmp,
    (SELECT u.employee_number v_employee_number,
      u.employee_name v_employee_name,
      u.user_id v_user_id,
      u.org_code v_org_code,
      u.org_name v_org_name,
      u.office_tel v_office_tel,
      u.mobile_phone v_mobile_phone,
      u.email v_email,
      u.dept_id v_dept_id
    FROM t_lis_user u
    ) tmp1
  WHERE tmp.h_agent_id=tmp1.v_employee_number

/

