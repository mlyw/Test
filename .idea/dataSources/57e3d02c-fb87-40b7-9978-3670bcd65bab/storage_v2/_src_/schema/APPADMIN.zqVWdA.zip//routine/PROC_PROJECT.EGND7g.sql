create PROCEDURE "PROC_PROJECT" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_project is
select project_id, project_code, project_name, description, project_type, ou_id, project_status_code, case offset_flag when 'Y' then 1 when 'N' then 0 end as offset_flag, start_date, completion_date, creation_date, last_update_date, erp_type, import_date, seq_id, create_date from i_erp_projects
where create_date > start_time and create_date <= end_time order by erp_type desc;
i_project csr_i_project%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_erp_projects where create_date > start_time and create_date <= end_time;
  open csr_i_project;
  fetch csr_i_project into i_project;
while (csr_i_project%found) loop
  select count(*) into count_value from t_sys_erp_projects where project_id = i_project.project_id and erp_type = i_project.erp_type;
  if(count_value = 1 and i_project.project_status_code = 'APPROVED' and i_project.completion_date is null) then
      update t_Sys_Erp_Projects t set t.last_updated_date = sysdate,
      t.project_code = i_project.project_code,
      t.project_name = i_project.project_name,
      t.project_type_name = i_project.project_type,
      t.project_status_code = i_project.project_status_code,
      t.ou_id = i_project.ou_id,
      t.is_movable = i_project.offset_flag,
      t.start_date = i_project.start_date,
      t.completion_date = i_project.completion_date,
      t.description = i_project.description,
      t.status = 1
      where t.project_id = i_project.project_id;
   elsif(count_value = 1 and i_project.project_status_code = 'APPROVED' and i_project.completion_date is not null and i_project.completion_date > sysdate) then
   update t_Sys_Erp_Projects t set t.last_updated_date = sysdate,
      t.project_code = i_project.project_code,
      t.project_name = i_project.project_name,
      t.project_type_name = i_project.project_type,
      t.project_status_code = i_project.project_status_code,
      t.ou_id = i_project.ou_id,
      t.is_movable = i_project.offset_flag,
      t.start_date = i_project.start_date,
      t.completion_date = i_project.completion_date,
      t.description = i_project.description,
      t.status = 1
      where t.project_id = i_project.project_id;
   elsif(count_value = 1 and i_project.project_status_code = 'APPROVED' and i_project.completion_date is not null and i_project.completion_date < sysdate) then
   update t_Sys_Erp_Projects t set t.last_updated_date = sysdate,
      t.project_code = i_project.project_code,
      t.project_name = i_project.project_name,
      t.project_type_name = i_project.project_type,
      t.project_status_code = i_project.project_status_code,
      t.ou_id = i_project.ou_id,
      t.is_movable = i_project.offset_flag,
      t.start_date = i_project.start_date,
      t.completion_date = i_project.completion_date,
      t.description = i_project.description,
      t.status = 0
      where t.project_id = i_project.project_id;
 elsif(count_value = 1 and i_project.project_status_code != 'APPROVED') then
      update t_Sys_Erp_Projects t set t.last_updated_date = sysdate,
      t.project_code = i_project.project_code,
      t.project_name = i_project.project_name,
      t.project_type_name = i_project.project_type,
      t.project_status_code = i_project.project_status_code,
      t.ou_id = i_project.ou_id,
      t.is_movable = i_project.offset_flag,
      t.start_date = i_project.start_date,
      t.completion_date = i_project.completion_date,
      t.description = i_project.description,
      t.status = 0
      where t.project_id = i_project.project_id;
  elsif(count_value = 0 and i_project.project_status_code = 'APPROVED' and i_project.completion_date is null) then
  insert into t_sys_erp_projects
    (seq_id, project_id, created_date, last_updated_date, status, erp_type, project_code, project_name, project_type_name, ou_id, is_movable, project_status_code, start_date, completion_date, description)
  values
    (i_project.seq_id, i_project.project_id, sysdate, sysdate, 1, i_project.erp_type, i_project.project_code, i_project.project_name, i_project.project_type, i_project.ou_id, i_project.offset_flag, i_project.project_status_code, i_project.start_date, i_project.completion_date, i_project.description);
  end if;
fetch csr_i_project into i_project;
count_success:=count_success + 1;
end loop;
close csr_i_project;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_erp_projects');
exception when others then
  rollback;
  exception_info := 'ERR: An error occurred with info:project_id is ' || i_project.project_id ||' ,'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_erp_projects');
  commit;
end;
/

