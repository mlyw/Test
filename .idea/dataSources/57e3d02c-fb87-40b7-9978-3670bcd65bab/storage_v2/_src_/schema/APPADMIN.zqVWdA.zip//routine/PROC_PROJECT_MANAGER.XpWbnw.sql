create PROCEDURE proc_project_manager as
total_value number(15);
count_success number(15);
exception_info varchar2(3000);
begin
select count(*) into total_value from i_erp_projects_manager;
delete from t_sys_erp_projects_manager;
insert into t_sys_erp_projects_manager
  (id, project_id, employee_number, last_name)
select t.seq_id,t.project_id,t.employee_number,t.last_name from i_erp_projects_manager t;
count_success := sql%rowcount;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_erp_projects_manager');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_erp_projects_manager');
commit;
end;
/

