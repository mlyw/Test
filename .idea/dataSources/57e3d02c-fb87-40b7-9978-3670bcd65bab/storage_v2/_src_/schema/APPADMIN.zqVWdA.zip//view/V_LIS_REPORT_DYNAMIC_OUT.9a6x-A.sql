create view V_LIS_REPORT_DYNAMIC_OUT as
  SELECT tmp.item_code,
    tmp.item_desc,
    tmp.item_id,
    tmp.uom_code,
    tmp.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.wh_id_trf_from warehouse_out_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    tmp.product_unit_price,
    tmp.change_quty current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.change_quty,0) current_out_account,
    tmp.account_date import_date,
    tmp.id order_id,
    tmp.wh_chg_ord_code order_code,
    tmp.order_type order_type,
    tmp.receipt_pic_code
  FROM
    (SELECT hl.item_code,
      hl.item_id,
      hl.uom_desc,
      hl.uom_code,
      hl.item_desc,
      hl.wh_id_trf_from,
      NVL(hl.product_unit_price,0) product_unit_price,
      hl.change_quty,
      hd.account_date,
      hd.id,
      hd.wh_chg_ord_code,
      '调拨' order_type,
      q.receipt_pic_code
    FROM t_chg_hd_ln hd,
      t_chg_ln hl,
      t_wh_current_onhand_quantity q
    WHERE hd.status      =1
    AND hl.status        =1
    AND hd.order_status IN (5,50)
    AND hl.chghdln_id    =hd.id
    AND hl.onhand_id     =q.id
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.wh_id_trf_from=d.id
  UNION ALL
  ---工程及cnp出库,杂发
  SELECT tmp.item_code,
    i.item_name item_desc,
    tmp.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.warehouseid warehouse_out_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    tmp.product_unit_price,
    tmp.Acpt_Cfm_Quty current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.Acpt_Cfm_Quty,0) current_out_account,
    tmp.acc_cfm_date import_date,
    tmp.id order_id,
    tmp.out_ord_code order_code,
    tmp.order_type,
    tmp.receipt_pic_code
  FROM
    (SELECT om.item_id,
      om.item_code,
      om.warehouseid,
      om.product_unit_price,
      om.Acpt_Cfm_Quty,
      om.acc_cfm_date,
      oh.id,
      oh.out_ord_code,
      CASE
        WHEN oh.item_type_id=5
        THEN '杂发'
        ELSE '出库'
      END AS order_type,
      q.receipt_pic_code
    FROM t_out_hd oh,
      t_out_ln ol,
      t_out_notmk om,
      t_wh_current_onhand_quantity q
    WHERE oh.status             =1
    AND ol.status               =1
    AND om.status               =1
    AND ol.Outhdinfo_Id         =oh.id
    AND om.Outlninfo_Id         =ol.id
    AND om.warehouse_onhand_id  = q.id
    AND oh.item_type_id        IN (1,5,2)
    AND oh.ord_status           =6
    AND om.asgn_ln_status       =1
    AND ol.ord_ln_status        =7
    AND om.warehouse_onhand_id IS NOT NULL
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.warehouseid=d.id
  UNION ALL
  ----综合出库
  SELECT tmp.item_code,
    i.item_name item_desc,
    tmp.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.warehouseid warehouse_out_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    tmp.product_unit_price,
    tmp.Asgn_Quty current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.Asgn_Quty,0) current_out_account,
    tmp.acc_cfm_date import_date， tmp.id order_id,
    tmp.out_ord_code,
    tmp.order_type,
    tmp.receipt_pic_code
  FROM
    (SELECT om.item_id,
      om.item_code,
      om.warehouseid,
      om.product_unit_price,
      om.Asgn_Quty,
      om.acc_cfm_date,
      oh.id,
      oh.out_ord_code,
      CASE
        WHEN oh.item_type_id=86
        THEN '杂发'
        ELSE '出库'
      END AS order_type,
      q.receipt_pic_code
    FROM t_out_hd oh,
      t_out_ln ol,
      t_out_notmk om,
      t_wh_current_onhand_quantity q
    WHERE oh.status             =1
    AND ol.status               =1
    AND om.status               =1
    AND om.warehouse_onhand_id  =q.id
    AND ol.Outhdinfo_Id         =oh.id
    AND om.Outlninfo_Id         =ol.id
    AND oh.item_type_id        IN (84,86)
    AND oh.ord_status           =6
    AND om.asgn_ln_status       =1
    AND ol.ord_ln_status        =7
    AND om.warehouse_onhand_id IS NOT NULL
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.warehouseid=d.id
/

