create PROCEDURE proc_po_header_syn as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
vendor_id_count_value number(2);
vendor_id_seq number(15);
vendor_name_value varchar2(2000);
cursor csr_i_po_header is
select id, spm_po_header_id, spm_po_number, mis_po_header_id, mis_po_number, po_desc, contract_number, contract_desc, mis_vendor_id, agent_employee_number, receive_type, creation_date, approved_date, po_status, total_amount, offset_flag, ou_id, erp_type, is_cross_docking,import_date
from i_spm_po_header where id in (
50617
  );
i_po_header csr_i_po_header%rowtype;
begin
  count_success := 0;
  select count(id) into total_value from i_spm_po_header where id in (
50617
  );
  open csr_i_po_header;
  fetch csr_i_po_header into i_po_header;
while (csr_i_po_header%found) loop
  select count(*) into count_value from T_BASE_SPM_PUR_ORDER_HEADERS where SPM_PO_HEADER_ID = i_po_header.spm_po_header_id;
  if(i_po_header.mis_vendor_id is null) then
  vendor_id_seq := null;
  elsif(i_po_header.mis_vendor_id is not null) then
    select count(*) into vendor_id_count_value from t_sys_erp_vendors where vendor_id = i_po_header.mis_vendor_id and erp_type = i_po_header.erp_type and status = 1;
    if(vendor_id_count_value > 0) then
    select seq_id,vendor_name into vendor_id_seq,vendor_name_value from t_sys_erp_vendors where vendor_id = i_po_header.mis_vendor_id and erp_type = i_po_header.erp_type and status = 1;
    elsif(vendor_id_count_value = 0 ) then
    vendor_id_seq:= null;
    vendor_name_value := null;
    end if;
  end if;
  if(count_value = 1) then
    update t_base_spm_pur_order_headers
       set last_updated_date = sysdate,
           erp_type = i_po_header.erp_type,
           is_cross_docking = i_po_header.is_cross_docking,
           mis_po_header_id = i_po_header.mis_po_header_id,
           mis_po_number = i_po_header.mis_po_number,
           ou_id = i_po_header.ou_id,
           po_status = i_po_header.po_status,
           receive_type = i_po_header.receive_type,
           spm_po_number = i_po_header.spm_po_number,
           total_amount = i_po_header.total_amount,
           vendor_id = vendor_id_seq,
           spm_po_desc = i_po_header.po_desc,
           po_approval_date = i_po_header.approved_date,
           po_contract_num = i_po_header.contract_number,
           po_contract_desc = i_po_header.contract_desc,
           agent_id = i_po_header.agent_employee_number,
           deductible = i_po_header.offset_flag,
           VENDOR_NAME = vendor_name_value
     where spm_po_header_id = i_po_header.spm_po_header_id;
 else
   insert into t_base_spm_pur_order_headers
     (spm_po_header_id, created_date,  last_updated_date,  status, version, erp_type,is_cross_docking, mis_po_header_id, mis_po_number, ou_id, po_status, receive_type, spm_po_number, total_amount, vendor_id, spm_po_desc, po_approval_date, po_contract_num, po_contract_desc, agent_id, deductible, received_amount, extax_received_amount, vendor_name)
   values
     (i_po_header.spm_po_header_id, sysdate, sysdate, 1, 0, i_po_header.erp_type, i_po_header.is_cross_docking,i_po_header.mis_po_header_id, i_po_header.mis_po_number, i_po_header.ou_id, i_po_header.po_status, i_po_header.receive_type, i_po_header.spm_po_number, i_po_header.total_amount, vendor_id_seq, i_po_header.po_desc, i_po_header.approved_date, i_po_header.contract_number, i_po_header.contract_desc, i_po_header.agent_employee_number, i_po_header.offset_flag, 0, 0, vendor_name_value);
end if;
fetch csr_i_po_header into i_po_header;
count_success:=count_success+1;
end loop;
close csr_i_po_header;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_base_spm_pur_order_headers');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_base_spm_pur_order_headers');
commit;
end;
/

