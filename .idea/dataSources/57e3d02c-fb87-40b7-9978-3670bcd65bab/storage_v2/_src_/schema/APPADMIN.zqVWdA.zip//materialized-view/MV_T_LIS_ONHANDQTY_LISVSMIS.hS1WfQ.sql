create materialized view MV_T_LIS_ONHANDQTY_LISVSMIS
refresh force on demand
  as
    SELECT sysdate bulidtime,i.uom_desc,
    tmp.*　from
    (SELECT v.*,
      d.mis_ou_id,
      d.mis_ou_name,
      d.mis_io_name,
      d.mis_io_id,
      (d.warehouse_define_code
      ||'_'
      ||d.warehouse_define_name) subinventory_full_name
    FROM v_onhand_quantity_lisVSmis v
    LEFT JOIN t_warehouse_define d
    ON v.subinventory_code=d.warehouse_define_code
    WHERE d.status        =1
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON i.organization_id=tmp.mis_io_id
  AND i.item_code     =tmp.item_code
  AND i.uom_code      =tmp.uom_code
  AND i.status        =1

/

