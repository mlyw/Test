create procedure proc_spm_vndrshipuuid_sync(start_time timestamp, end_time timestamp) as
       total_value number(15);
       count_value number(2);
       vendorshippingid number(19);
       count_success number(15);
       exception_info varchar2(3000);
cursor csr_i_spm_vendorShippingUUID is
select seq_id,box_uid,material_uid,material_sn,create_time from i_spm_vendorshipping_puuid where create_time >= start_time and create_time <= end_time;
i_vendorshippinguuid csr_i_spm_vendorShippingUUID%rowtype;
begin
  count_success := 0;
  --产品唯一识别信息条数
  select count(*) into total_value from i_spm_vendorshipping_puuid where create_time >= start_time and create_time <= end_time;

  open csr_i_spm_vendorShippingUUID;

  fetch csr_i_spm_vendorShippingUUID into i_vendorshippinguuid;

  --首先查出头上的主键
  select seq_id into vendorshippingid from t_sys_spm_vendorshipping where create_time >= start_time and create_time <= end_time;
  while (csr_i_spm_vendorShippingUUID%found) loop
    select count(*) into count_value from t_sys_spm_vendorshipping_puuid where material_uid = i_vendorshippinguuid.material_uid;
    if(count_value = 1) then
                   update t_sys_spm_vendorshipping_puuid
                         set last_updated_date = sysdate,
                             box_uid = i_vendorshippinguuid.box_uid,
                             material_sn = i_vendorshippinguuid.material_sn,
                             create_time = i_vendorshippinguuid.create_time
                   where material_uid = i_vendorshippinguuid.material_uid;
    else
                   insert into t_sys_spm_vendorshipping_puuid(seq_id, vendorshipping_id, created_date, last_updated_date, status, version, box_uid, material_uid, material_sn, create_time)
                   values (seq_spm_vendorshipping.nextval, vendorshippingid, sysdate, sysdate, 1, 0, i_vendorshippinguuid.box_uid, i_vendorshippinguuid.material_uid,i_vendorshippinguuid.material_sn,i_vendorshippinguuid.create_time );
    end if;
  fetch csr_i_spm_vendorShippingUUID into i_vendorshippinguuid;
  count_success:=count_success+1;
  end loop;
  close csr_i_spm_vendorShippingUUID ;
  --插入日志
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_spm_vendorshippinguuid');
  exception when others then
      exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
    insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_spm_vendorshippinguuid');
  COMMIT;
end;
/

