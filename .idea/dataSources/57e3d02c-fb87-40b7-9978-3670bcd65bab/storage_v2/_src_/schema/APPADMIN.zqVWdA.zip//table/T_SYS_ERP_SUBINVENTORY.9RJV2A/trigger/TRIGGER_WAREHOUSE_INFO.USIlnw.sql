create trigger TRIGGER_WAREHOUSE_INFO
  before insert or update
  on T_SYS_ERP_SUBINVENTORY
  for each row
  declare
  count_warehouse_define number(15);--仓库处理记录
  count_warehouse_user number(15);--授权处理记录
  exception_info varchar2(3000 BYTE);--异常信息
  v_warehouse_id   number;---新仓库数据id
  v_mis_io_name VARCHAR2(240 BYTE);---库存组织名称
  v_mis_io_code VARCHAR2(20 BYTE);---库存组织编码
  v_mis_io_id number;---库存组织id
  v_mis_ou_id number;---ou组织id
  v_mis_ou_name VARCHAR2(240 BYTE);--ou组织名称
  v_ou_code VARCHAR2(30 BYTE);---ou组织编码
  v_category_id number;--仓库分类ID
  v_warehouse_count   number;---仓库信息数量
  v_warehouse_user_count     number;---仓库授权信息数量
begin
   count_warehouse_define:= 0;
   count_warehouse_user:= 0;
  if(:new.Attribute10 is not null and :new.Attribute11 is not null) then
    select count(id) into v_warehouse_count from t_warehouse_define where warehouse_define_code=:new.subinventory_code and status=1;
    select count(id) into v_warehouse_user_count from t_warehouse_access_user where status=1 and employ_number = '12345678' and warehouse_define_id in (select d.id from t_warehouse_define d where d.warehouse_define_code=:new.subinventory_code and d.status=1);
    select id into v_category_id from t_warehouse_category where code='02';---市场末梢仓库分类信息
    select ou_id,ou_name,ou_code into v_mis_ou_id,v_mis_ou_name,v_ou_code from t_sys_erp_ou where ou_id=:new.ou_id;---仓库ou信息
    select organization_name,organization_code,organization_id into v_mis_io_name,v_mis_io_code,v_mis_io_id from t_sys_erp_organizations where organization_id =:new.organizations_id;---物资分类信息
    if (v_warehouse_count > 0) then
      select d.id into v_warehouse_id from t_warehouse_define d
      where d.status=1 and d.warehouse_define_code=:new.subinventory_code;
      update t_warehouse_define
      set
       last_updated_date = sysdate,
       last_updated_user = '12345678',
       status = :new.status,
       string_value1 = 'trigger_warehouse_info触发器自动同步更新,version=' || (version+1),
       version =  version+1,
       mis_io_code = v_mis_io_code,
       mis_io_id = v_mis_io_id,
       mis_io_name = v_mis_io_name,
       mis_ou_id = v_mis_ou_id,
       mis_ou_name = v_mis_ou_name,
       mis_subinventory_desc = :new.Subinventory_Name,
       mis_subinventory_name = :new.subinventory_code,
       warehouse_address = :new.Subinventory_Name,
       warehouse_define_name = :new.Subinventory_Name,
       warehouse_full_code = v_ou_code || '.' || v_mis_io_code || '.' || :new.subinventory_code,
       warehouse_full_name = :new.subinventory_code || '-' || :new.Subinventory_Name,
       warehouse_notes = :new.Subinventory_Name,
       category_id = v_category_id,
       mis_subinventoey_id = :new.subinventory_id,
       is_storage = 'N'
      where warehouse_define_code = :new.subinventory_code;
      count_warehouse_define := count_warehouse_define + 1;
    else
      select S_WAREHOUSE_DEFINE.NEXTVAL into v_warehouse_id from dual;
      insert into t_warehouse_define
             (id,
             created_date,
             created_user,
             status,
             string_value1,
             version,
             mis_io_code,
             mis_io_id,
             mis_io_name,
             mis_ou_id,
             mis_ou_name,
             mis_subinventory_desc,
             mis_subinventory_name,
             voi_vmi_flag,
             warehouse_address,
             warehouse_capital_type,
             warehouse_define_code,
             warehouse_define_name,
             warehouse_full_code,
             warehouse_full_name,
             warehouse_notes,
             category_id,
             parent_warehouse_id,
             mis_subinventoey_id,
             is_storage)
        values
             (v_warehouse_id,
             sysdate,
             '12345678',
             :new.status,
             'trigger_warehouse_info触发器自动同步新增',
             0,
             v_mis_io_code,
             v_mis_io_id,
             v_mis_io_name,
             v_mis_ou_id,
             v_mis_ou_name,
             :new.Subinventory_Name,
             :new.subinventory_code,
             '自有',
             :new.Subinventory_Name,
             '带资金',
             :new.subinventory_code,
             :new.Subinventory_Name,
             v_ou_code || '.' || v_mis_io_code || '.' || :new.subinventory_code,
             :new.subinventory_code || '-' || :new.Subinventory_Name,
             :new.Subinventory_Name,
             v_category_id,
             2993,
             :new.subinventory_id,
             'N');
             count_warehouse_define := count_warehouse_define + 1;
    end if;
    if (v_warehouse_user_count > 0) then
      update t_warehouse_access_user
         set
             last_updated_date = sysdate,
             last_updated_user = '12345678',
             status = :new.status,
             string_value1 = 'trigger_warehouse_info触发器自动同步更新 version=' ||  (version+1),
             version = version+1
       where  warehouse_define_id = v_warehouse_id and employ_number = '12345678';
       count_warehouse_user := count_warehouse_user + 1;
    else
      insert into t_warehouse_access_user
        (id,
        created_date,
        created_user,
        status,
        string_value1,
        version,
        employ_number,
        warehouse_define_id)
      values
        (S_WAREHOUSE_ACCESS_USER.NEXTVAL,
        sysdate,
        '12345678',
        1,
        'trigger_warehouse_info触发器自动同步新增',
        0,
        '12345678',
        v_warehouse_id);
        count_warehouse_user := count_warehouse_user + 1;
    end if;
  end if;
  ---插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,count_warehouse_define,count_warehouse_user,sysdate,'同步成功;' ||:new.subinventory_code ,'trigger_warehouse_info:t_sys_erp_subinventory->t_warehouse_define/t_warehouse_access_user');
exception when others then
  exception_info := 'trigger_warehouse_info:'||:new.subinventory_code||' An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,count_warehouse_define,count_warehouse_user,sysdate,exception_info,'trigger_warehouse_info:t_sys_erp_subinventory->t_warehouse_define/t_warehouse_access_user');
end TRIGGER_WAREHOUSE_INFO;
/

