create view V_LIS_REPORT_QTY_PERSENT as
  SELECT
    /**库存物资占比统计表原始视图*/
    s."BUSSINESS_DATE",
    s."OU_ID",
    s."ORGANIZATION_ID",
    s."ITEM_CATEGORY_CODE",
    s."ITEM_CATEGORY_NAME",
    s."ITEM_ID",
    s."ITEM_CODE",
    s."ITEM_DESC",
    s."ITEM_UOM_CODE",
    s."ITEM_UOM_DESC",
    s."COLLECTACCOUNT",
    s."STARTACCOUNT",
    s."STARTQTY",
    s."ENDACCOUNT",
    s."ENDQTY",
    (o.organization_code
    || ' '
    || o.organization_name) orginfo
  FROM v_lis_report_qty_start_stop s
  LEFT JOIN t_sys_erp_organizations o
  ON s.organization_id=o.organization_id
/

