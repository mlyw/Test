create PROCEDURE proc_po_line_uid (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_po_line_uid is
select id, material_uid, spm_po_distribution_id, spm_po_line_location_id, spm_po_line_id, spm_po_header_id, created_date, import_date from i_spm_po_lineuid where import_date > start_time and import_date < end_time;
i_po_line_uid csr_i_po_line_uid%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_spm_po_lineuid where import_date > start_time and import_date < end_time;
  open csr_i_po_line_uid;
  fetch csr_i_po_line_uid into i_po_line_uid;
while (csr_i_po_line_uid%found) loop
  select count(*) into count_value from t_base_spm_pur_order_line_uid where SPM_PO_LINE_ID = i_po_line_uid.spm_po_distribution_id;
if(count_value = 1) then
    update t_base_spm_pur_order_line_uid
       set last_updated_date = sysdate,
           material_uid = i_po_line_uid.material_uid
     where spm_po_line_id = i_po_line_uid.spm_po_distribution_id;
 else 
 insert into t_base_spm_pur_order_line_uid
   (id, created_date, last_updated_date, status, version, material_uid, received_flag, spm_po_line_id)
 values
   (S_PUR_ORDER_LINE_UID.Nextval, sysdate, sysdate, 1, 0, i_po_line_uid.material_uid, 0, i_po_line_uid.spm_po_distribution_id);
end if;
fetch csr_i_po_line_uid into i_po_line_uid;
count_success:=count_success+1;
end loop;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_base_spm_pur_order_line_uid');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_base_spm_pur_order_line_uid');
close csr_i_po_line_uid;
commit;
end;
/

