create procedure PROC_AD_USER_SD as
total_value number(15);
count_value number(2);
count_disabled number(15);--user失效状态
count_disabled1 number(15);--ouuser失效状态
count_ouuser number(15); 
count_success number(15);
deptId number(15);
deptCode varchar2(100);
exception_info varchar2(3000);
cursor csr_ad_user is 
select SEQ_ID,U_ID,U_NAME,DEPT_NAME,INNER_MAIL,TITLE,OFFICE_PHONE,PHONE,MIS_ID,EMPLOYEE_NUMBER
       from T_AD_USER where seq_id in (866776);
ad_users csr_ad_user%rowtype;
begin

--处理新增、更新数据
count_success :=0;
open csr_ad_user ;
fetch csr_ad_user into ad_users;
while (csr_ad_user%found) loop
  BEGIN
       select d.id into deptId from t_lis_dept d where d.dept_name=ad_users.dept_name and d.status = 1;
  EXCEPTION
      WHEN NO_DATA_FOUND THEN
        deptId := NULL;
  END;  
   
  BEGIN   --查询dept_code
       select dt.dept_code into deptCode from t_lis_dept dt where dt.dept_name = ad_users.dept_name and dt.status =1 ;
  EXCEPTION
      WHEN NO_DATA_FOUND THEN
        deptCode := NULL;
  END; 
  insert into t_lis_user(                      --初始密码password MD5(ika,123)=7C837AC658FD72AB90C0C3E145E9953A
   employee_number,employee_name,employee_num_ext,org_code,org_name,office_tel,mobile_phone,email,user_id,dept_id,created_date,password,type,status,version,string_value1,created_user
  ) values(
    ad_users.employee_number,ad_users.u_name,ad_users.employee_number,deptCode,ad_users.dept_name,ad_users.office_phone,ad_users.phone,ad_users.inner_mail,ad_users.u_id,deptId,sysdate,'F146A144911EB0190985E68B7C126356',2,1,0,'sync from adUser','12345678'
  );
  --82
  insert into t_lis_ouuser o (id,employee_number,ou_employee_number,ou_dept_code,ou_id,ou_dept_id,status,version,created_user,created_date,string_value1
  ) values (
  LIS_ORDER_SEQ.NEXTVAL,ad_users.employee_number,'82_'||ad_users.employee_number,deptCode,82,deptId,1,0,'12345678',sysdate,'sync from adUser'
  );
  --102
  insert into t_lis_ouuser o (id,employee_number,ou_employee_number,ou_dept_code,ou_id,ou_dept_id,status,version,created_user,created_date,string_value1
  ) values (
  LIS_ORDER_SEQ.NEXTVAL,ad_users.employee_number,'102_'||ad_users.employee_number,deptCode,102,deptId,1,0,'12345678',sysdate,'sync from adUser'
  );
  --192
  insert into t_lis_ouuser o (id,employee_number,ou_employee_number,ou_dept_code,ou_id,ou_dept_id,status,version,created_user,created_date,string_value1
  ) values (
  LIS_ORDER_SEQ.NEXTVAL,ad_users.employee_number,'192_'||ad_users.employee_number,deptCode,192,deptId,1,0,'12345678',sysdate,'sync from adUser'
  );
fetch csr_ad_user into ad_users;
end loop;
close csr_ad_user;
commit;
exception when others then
  rollback;
  --count_num := count_success;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_AD_USER');
close csr_ad_user;
commit;
end;
/

