create FUNCTION "AVAILABLE_QTY"(v_item_code varchar2,
                                           v_item_type varchar2 --物料类型：1 物料 2物料组
                                           )
  return float as
  v_available_qty number(19, 5);

BEGIN
  if v_item_type = 1 then
      select sum(r.availableNumber)
        into v_available_qty
        from (select distinct (c.id) id,
                              round(nvl(c.onhand_quantity, 0) -
                                    (nvl(f.RESERVE_QUANTITY, 0) +
                                     nvl(asgn.asgn_quty, 0)),
                                    5) availableNumber
                FROM (select a.id, a.onhand_quantity
                        from T_WH_CURRENT_ONHAND_QUANTITY a
                        join t_warehouse_access_user d
                          on a.warehouse_define_id = d.warehouse_define_id
                        left join T_WAREHOUSE_DEFINE w
                          on a.warehouse_define_id = w.id
                         and w.is_storage like 'Y'
                         and w.MIS_OU_ID = '82'
                       where a.ONHAND_QUANTITY > 0
                         and a.ERP_TYPE = '2G'
                         and a.status = 1
                         and a.item_package_id is null
                         and a.item_code = v_item_code
                         and w.CATEGORY_ID =
                             (select twc.id
                                from T_WAREHOUSE_CATEGORY twc
                               where twc.CODE like '01')
                         and a.id not in
                             (select ql.onhand_id
                                from t_lis_recipient_quota_locking ql
                                join t_lis_recipient_quota_detail qd
                                  on ql.detail_id = qd.id)) c
                left join (select e.onhand_id,
                                 sum(nvl(e.RESERVE_QUANTITY, 0)) as RESERVE_QUANTITY
                            from T_SYS_ITEM_RESEREVE_INFO e
                           where sysdate < e.reserve_end_day
                             and e.status = 1
                           group by e.onhand_id) f
                  on c.id = f.onhand_id
                left join (select asgninfo.warehouse_Onhand_Id,
                                 nvl(sum(asgninfo.asgn_quty), 0) as asgn_quty
                            from T_OUT_NOTMK asgninfo
                           where asgninfo.asgn_ln_status = 3
                           group by asgninfo.warehouse_Onhand_Id
                          having min(asgninfo.IF_RESERVE) = 0) asgn
                  on c.id = asgn.warehouse_Onhand_Id) r;
    elsif v_item_type = 2 then
      select sum(r.availableNumber)
        into v_available_qty
        from (select distinct (c.id) id,
                              round(nvl(c.onhand_quantity, 0) -
                                    (nvl(f.RESERVE_QUANTITY, 0) +
                                     nvl(asgn.asgn_quty, 0)),
                                    5) availableNumber
                FROM (select a.id, a.onhand_quantity
                        from T_WH_CURRENT_ONHAND_QUANTITY a
                        join t_warehouse_access_user d
                          on a.warehouse_define_id = d.warehouse_define_id
                        left join T_WAREHOUSE_DEFINE w
                          on a.warehouse_define_id = w.id
                         and w.is_storage like 'Y'
                         and w.MIS_OU_ID = '82'
                       where a.ONHAND_QUANTITY > 0
                         and a.ERP_TYPE = '2G'
                         and a.status = 1
                         and a.item_package_id is null
                         and exists
                       (select 1
                                from t_lis_itemgroup_head igh,
                                     T_Lis_Itemgroup_Line igl
                               where igh.id = igl.item_group_headid
                                 and igl.item_id = a.item_id
                                 and igh.id = v_item_code)
                         and w.CATEGORY_ID =
                             (select twc.id
                                from T_WAREHOUSE_CATEGORY twc
                               where twc.CODE like '01')
                         and a.id not in
                             (select ql.onhand_id
                                from t_lis_recipient_quota_locking ql
                                join t_lis_recipient_quota_detail qd
                                  on ql.detail_id = qd.id)) c
                left join (select e.onhand_id,
                                 sum(nvl(e.RESERVE_QUANTITY, 0)) as RESERVE_QUANTITY
                            from T_SYS_ITEM_RESEREVE_INFO e
                           where sysdate < e.reserve_end_day
                             and e.status = 1
                           group by e.onhand_id) f
                  on c.id = f.onhand_id
                left join (select asgninfo.warehouse_Onhand_Id,
                                 nvl(sum(asgninfo.asgn_quty), 0) as asgn_quty
                            from T_OUT_NOTMK asgninfo
                           where asgninfo.asgn_ln_status = 3
                           group by asgninfo.warehouse_Onhand_Id
                          having min(asgninfo.IF_RESERVE) = 0) asgn
                  on c.id = asgn.warehouse_Onhand_Id) r;
  end if;
  RETURN nvl(v_available_qty, 0);
END;
/

