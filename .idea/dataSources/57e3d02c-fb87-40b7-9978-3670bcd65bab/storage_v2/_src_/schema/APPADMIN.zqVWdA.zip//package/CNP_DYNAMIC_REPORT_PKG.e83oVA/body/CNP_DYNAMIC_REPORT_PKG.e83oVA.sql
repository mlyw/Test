create package body cnp_dynamic_report_pkg is
  procedure proc_execute_cnpreport(item_codee in varchar2,warehouse_id in varchar2,diff in number,checkDate in varchar2, endDate in varchar2,dynamic_checking out cur_dynamic_checking,total out number)
as
  warehouseCode VARCHAR2(100);
  warehouseNames VARCHAR2(500);
  exception_info VARCHAR2(200);    -- error message text
begin    
   delete from T_CNP_REPORT_TEMP;
   delete from temp_dynamic_warehouse;
   delete from T_CNP_REPORT;
   delete from t_wh_onhand_quantity_temp;
   commit;
   select w.warehouse_define_code into warehouseCode from t_warehouse_define w where w.id = warehouse_id;
   select w.warehouse_define_code||'-'||w.warehouse_define_name into warehouseNames from t_warehouse_define w where w.id = warehouse_id;
 /*查询期初数量 
  -- insert into t_wh_onhand_quantity_temp (select * from t_wh_current_onhand_quantity);
   INSERT INTO T_WH_ONHAND_QUANTITY_TEMP (ONHAND_QUANTITY,ITEM_CODE,WAREHOUSE_DEFINE_ID)
   -- 出库 查询日期之前创建的现有量 C001 出去的  期初+ 
   select sum(mk.asgn_quty),l.item_code,1491 from t_out_ln l left join t_out_hd h on l.outhdinfo_id = h.id left join t_out_notmk mk  on l.id = mk.ord_ln_id
   where h.status =1 and l.status = 1 and mk.status = 1 and h.item_type_id = 2 and mk.asgn_time > to_timestamp(checkDate,'yyyy-MM-dd hh24:mi:ss') 
   and l.item_code = (case when nvl(item_codee, '*') = '*' then l.item_code else item_codee end)
   group by l.item_code
  UNION ALL
  --入库 查询日期之后入库到C001的 减掉 
    select sum(l.current_receive_quantity)*(-1) AS RECEIVE_QUANTITY,l.item_code AS ITEM_CODE ,1461
    from t_receiptorder_headerinfo h left join t_receiptorder_lineinfo l on l.receipt_order_id = H.ID 
    where h.is_cnp = 'Y' and h.status = 1 and l.status = 1 
    and h.receipt_date> to_timestamp(checkDate,'yyyy-MM-dd hh24:mi:ss') and l.item_code = (case when nvl(item_codee, '*') = '*' then l.item_code else item_codee end)
    group by l.item_code
   UNION ALL
   --报废卡退库 退到C999
    select sum(l.actual_qty) , i.item_code,2931 from t_refundwastecard_head h left join t_refundwastecard_line l on h.seq_id =l.head_id left join t_sys_erp_items i on i.seq_id = l.item_id where h.status = 1 and l.status = 1 and l.accounted_date >  to_timestamp(checkDate,'yyyy-MM-dd hh24:mi:ss')
    and i.item_code = (case when nvl(item_codee, '*') = '*' then i.item_code else item_codee end)
    group by i.item_code
;
commit;*/
  /*向临时表中插入（出库）数据*/  
  
 INSERT INTO T_CNP_REPORT_TEMP(ITEM_CODE,ITEM_DESC,RECEIVE_QUTY,UOM_DESC)
   SELECT LN.ITEM_CODE,max(LN.ITEM_DESC),NVL(SUM(LN.CURRENT_RECEIVE_QUANTITY),0),max(LN.UOM_DESC) FROM T_RECEIPTORDER_LINEINFO LN,T_RECEIPTORDER_HEADERINFO HD,T_BASE_SPM_PUR_ORDER_LINES SPL 
   WHERE LN.Accounting_Confrim_Import_Date BETWEEN to_date(checkDate,'yyyy-MM-dd hh24:mi:ss') and to_date(endDate,'yyyy-MM-dd hh24:mi:ss')
   AND LN.ITEM_CODE = (case when nvl(item_codee, '*') = '*' then LN.ITEM_CODE else item_codee end) 
   AND HD.ID = LN.RECEIPT_ORDER_ID AND SPL.SPM_PO_LINE_ID = LN.SPM_PO_LINE_ID AND SPL.INVENTORY_TYPE <> 'EXPENSE'
   AND HD.STATUS = 1 AND LN.STATUS = 1 AND SPL.STATUS = 1 AND LN.RECEIPT_ORDER_LINE_SID =2
   AND LN.WAREHOUSE_RECEIVE_ID = warehouse_id AND HD.IS_CNP = 'Y'   
   GROUP BY LN.ITEM_CODE;  
   
   --出库
   INSERT INTO T_CNP_REPORT_TEMP(ITEM_CODE,ITEM_DESC,OUT_ASGN_QUTY,UOM_DESC)
   SELECT MK.ITEM_CODE,max(L.ITEM_NAME),SUM(L.APPLY_QUTY),max(L.UNIT) FROM T_OUT_HD H,T_OUT_LN L,T_OUT_NOTMK MK
   WHERE  MK.ITEM_CODE = (case when nvl(item_codee, '*') = '*' then MK.ITEM_CODE else item_codee end)  AND l.outhdinfo_id = h.id
   AND MK.ASGN_TIME BETWEEN to_date(checkDate,'yyyy-MM-dd hh24:mi:ss') and to_date(endDate,'yyyy-MM-dd hh24:mi:ss') 
   AND L.SUBINVENTORY_CODE = warehouseCode
   AND MK.ord_ln_id = L.id AND H.ITEM_TYPE_ID = 2
   AND H.STATUS = 1 AND L.STATUS = 1 AND MK.STATUS = 1 
   AND L.ORD_LN_STATUS = 4 OR L.ORD_LN_STATUS = 6   
   GROUP BY MK.ITEM_CODE;
   
   INSERT INTO T_CNP_REPORT_TEMP(ITEM_CODE,ITEM_DESC,OUT_ACC_QUTY,UOM_DESC)
   SELECT MK.ITEM_CODE,max(L.ITEM_NAME),SUM(MK.Asgn_Quty),max(L.UNIT) FROM T_OUT_HD H,T_OUT_LN L,T_OUT_NOTMK MK
   WHERE  MK.ITEM_CODE = (case when nvl(item_codee, '*') = '*' then MK.ITEM_CODE else item_codee end)  AND l.outhdinfo_id = h.id
   AND MK.ACC_CFM_DATE BETWEEN to_date(checkDate,'yyyy-MM-dd hh24:mi:ss') and to_date(endDate,'yyyy-MM-dd hh24:mi:ss')
   AND L.SUBINVENTORY_CODE = warehouseCode
   AND MK.ord_ln_id = L.id AND H.ITEM_TYPE_ID = 2
   AND H.STATUS = 1 AND L.STATUS = 1 AND MK.STATUS = 1 
   AND L.ORD_LN_STATUS = 7 OR L.ORD_LN_STATUS = 6   
   GROUP BY MK.ITEM_CODE;
   --退库
   
   --报废卡
   INSERT INTO T_CNP_REPORT_TEMP(ITEM_CODE,ITEM_DESC,BAD_QUTY)
   SELECT SEI.ITEM_CODE,max(SEI.ITEM_NAME),NVL(SUM(RFL.ACTUAL_QTY),0) FROM T_REFUNDWASTECARD_HEAD RFH,T_REFUNDWASTECARD_LINE RFL ,T_SYS_ERP_ITEMS SEI
   WHERE RFH.SEQ_ID = RFL.HEAD_ID
   AND RFL.ACCOUNTED_DATE BETWEEN to_date(checkDate,'yyyy-MM-dd hh24:mi:ss') and to_date(endDate,'yyyy-MM-dd hh24:mi:ss')
   AND RFH.STATUS = 1 AND RFL.STATUS = 1 AND SEI.SEQ_ID = RFL.ITEM_ID
   AND SEI.ITEM_CODE =   (case when nvl(item_codee, '*') = '*' then SEI.ITEM_CODE else item_codee end)
   AND RFL.Receive_Wd_Id = warehouse_id
   AND RFL.ORDER_LINE_STATUS = 7
   GROUP BY SEI.ITEM_CODE;
    
   INSERT INTO T_CNP_REPORT(ITEM_CODE,ITEM_DESC,WAREHOUSE_ID,WAREHOUSE_NAME,RECEIVE_QUANTITY,OUT_ASSIGNEQTY ,OUT_ACCOUNTQTY,BACK_QUANTITY,BAD_Quantity,EXEC_DATE,UOM_DESC)
   SELECT TEMP.ITEM_CODE,max(TEMP.ITEM_DESC),warehouse_id,warehouseNames,NVL(SUM(TEMP.RECEIVE_QUTY),0),NVL(SUM(TEMP.OUT_ASGN_QUTY),0),NVL(SUM(TEMP.OUT_ACC_QUTY),0),NVL(SUM(TEMP.BACK_QUTY),0),NVL(SUM(TEMP.BAD_QUTY),0),
   TRUNC(SYSDATE),max(TEMP.UOM_DESC) FROM T_CNP_REPORT_TEMP TEMP 
  -- left join 
  -- (select sum(wq.onhand_quantity) as orgQuty ,wq.item_code as item_code from t_wh_onhand_quantity_temp wq where wq.item_code =(case when nvl(item_codee, '*') = '*' then wq.ITEM_CODE else item_codee end)
  -- and wq.warehouse_define_id = warehouse_id group by wq.item_code) org on org.item_code = temp.item_code
   GROUP BY TEMP.ITEM_CODE order by TEMP.ITEM_CODE;
    
/*   UPDATE T_CNP_REPORT CT
   SET (PRODUCT_CODE,PRODUCT_DESC,ONHAND_QUANTITY) = 
   (SELECT max(WOQ.PRODUCT_CODE) product_code,max(WOQ.PRODUCT_DESC) product_desc,sum(WOQ.ONHAND_QUANTITY) ONHAND_QUANTITY FROM T_WH_CURRENT_ONHAND_QUANTITY WOQ 
   WHERE   WOQ.ITEM_CODE = CT.ITEM_CODE AND WOQ.STATUS = 1 AND WOQ.WAREHOUSE_DEFINE_ID =CT.WAREHOUSE_ID  group by woq.item_code);
*/
--
   UPDATE T_CNP_REPORT CT
    SET (PRODUCT_CODE,PRODUCT_DESC,ONHAND_QUANTITY,AVAILABLE_QUANTITY,ORIGINAL_QUANTITY) = 
    (SELECT max(WOQ.PRODUCT_CODE) product_code,max(WOQ.PRODUCT_DESC) product_desc,sum(WOQ.ONHAND_QUANTITY) ONHAND_QUANTITY,SUM(WOQ.ONHAND_QUANTITY-nvl(f.RESERVE_QUANTITY,0)) AVAILABLE_QUANTITY ,(sum(WOQ.ONHAND_QUANTITY)+CT.OUT_ASSIGNEQTY+CT.OUT_ACCOUNTQTY-CT.RECEIVE_QUANTITY) ORIGINAL_QUANTITY
     FROM T_WH_CURRENT_ONHAND_QUANTITY WOQ
     left join (select e.onhand_id,sum(nvl(e.RESERVE_QUANTITY,0)) as RESERVE_QUANTITY
              from T_SYS_ITEM_RESEREVE_INFO e where sysdate < e.reserve_end_day and e.status = 1 
              group by e.onhand_id) f on WOQ.id=f.onhand_id
     WHERE WOQ.ITEM_CODE = CT.ITEM_CODE AND WOQ.STATUS = 1 AND WOQ.WAREHOUSE_DEFINE_ID =CT.WAREHOUSE_ID  group by woq.item_code) ;   
   COMMIT;  
    open dynamic_checking for select * from T_CNP_REPORT t order by t.item_code;
  --返回查询结果的总数
  select count(*) into total from T_CNP_REPORT;
  commit;
   --异常处理 
   EXCEPTION
   WHEN OTHERS THEN
     ROLLBACK;
     exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
     INSERT INTO I_ERP_LOGS(SEQ_ID,CREATE_DATE,Exceptions,TABLE_NAME) values (i_erp_logs_seq.nextval,sysdate,exception_info,'T_CNP_REPORT');
     COMMIT;
end;
end cnp_dynamic_report_pkg;
/

