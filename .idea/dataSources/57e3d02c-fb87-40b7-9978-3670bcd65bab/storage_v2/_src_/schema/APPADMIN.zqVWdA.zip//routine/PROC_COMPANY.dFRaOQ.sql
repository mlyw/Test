create PROCEDURE "PROC_COMPANY" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_company is
select seq_id, company_id, company_code, company_name, enable_flag, start_data_active, end_data_active, erp_type, import_date from i_erp_company
 where import_date > start_time and import_date < end_time order by erp_type desc;
i_company csr_i_company%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from I_ERP_COMPANY where import_date > start_time and import_date < end_time;
  open csr_i_company;
  fetch csr_i_company into i_company;
while (csr_i_company%found) loop
  select count(*) into count_value from T_SYS_ERP_COMPANY where ERP_COMPANY_ID = i_company.company_id and erp_type = i_company.erp_type;
  if(count_value = 1 and i_company.enable_flag = 'Y' and i_company.end_data_active is null) then
      update T_SYS_ERP_COMPANY t set t.last_updated_date = sysdate,
      t.erp_company_code = i_company.company_code,
      t.erp_company_name = i_company.company_name,
      t.erp_type = i_company.erp_type,
      t.start_date_active = i_company.start_data_active,
      t.end_date_active = i_company.end_data_active
      where t.erp_company_id = i_company.company_id
      and t.erp_type = i_company.erp_type;
   elsif(count_value = 1 and i_company.enable_flag = 'N') then
   update T_SYS_ERP_COMPANY t set t.last_updated_date = sysdate,
      t.erp_company_code = i_company.company_code,
      t.erp_company_name = i_company.company_name,
      t.erp_type = i_company.erp_type,
      t.start_date_active = i_company.start_data_active,
      t.end_date_active = i_company.end_data_active,
      t.status = 0
      where t.erp_company_id = i_company.company_id
      and t.erp_type = i_company.erp_type;
   elsif(count_value = 1 and i_company.enable_flag = 'Y' and i_company.end_data_active is not null) then
   update T_SYS_ERP_COMPANY t set t.last_updated_date = sysdate,
      t.erp_company_code = i_company.company_code,
      t.erp_company_name = i_company.company_name,
      t.erp_type = i_company.erp_type,
      t.start_date_active = i_company.start_data_active,
      t.end_date_active = i_company.end_data_active,
      t.status = 0
      where t.erp_company_id = i_company.company_id
      and t.erp_type = i_company.erp_type;
 elsif(count_value = 0 and i_company.end_data_active is null and i_company.enable_flag = 'Y') then
insert into t_sys_erp_company
  (erp_company_id, erp_company_code, erp_company_name, erp_type, start_date_active, end_date_active, validity_flag, created_date, last_updated_date, status, version, seq_id)
values
  (i_company.company_id, i_company.company_code, i_company.company_name, i_company.erp_type, i_company.start_data_active, i_company.end_data_active, i_company.enable_flag, sysdate, sysdate, 1, 0, i_company.seq_id);
end if;
fetch csr_i_company into i_company;
count_success := count_success + 1;
end loop;
close csr_i_company;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','T_SYS_ERP_COMPANY');
exception when others then
  rollback;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_ERP_COMPANY');
  commit;
end;
/

