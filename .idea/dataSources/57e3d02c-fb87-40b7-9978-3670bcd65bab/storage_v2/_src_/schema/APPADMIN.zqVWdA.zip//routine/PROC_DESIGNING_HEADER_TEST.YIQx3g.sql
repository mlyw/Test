create PROCEDURE proc_designing_header_test (start_time timestamp,end_time timestamp) as

total_value number(15);
count_success number(15);
exception_info varchar2(3000);
version_value number(19);
updateing_count NUMBER(19); -- updateing 状态数据计数

cursor csr_i_designing_header is
    select
    seq_id,
    design_id,
    project_code,
    mis_no,
    req_code,
    project_no,
    station_no,
    station_name,
    old_structure,
    new_structure,
    remove_device,
    add_cabinet,
    storage_space_code,
    storage_dept_code,
    use_dept_code,
    use_dept_name,
    device_admin,
    delivery_date,
    plan_delivery_date,
    station_contact_person,
    station_contact_phone,
    station_addr,
    design_dept,
    design_deptcontact_phone,
    construction_dept,
    const_contact_person,
    const_contact_phone,
    remark1,
    remark2,
    remark3,
    string_attr,
    long_attr,
    datetime_attr,
    double_attr,
    import_date,
    is_temporder,
    design_status,
    approved_time
  from I_EPM_DESIGNINGFORM_HEADER where import_date between start_time and  end_time;

i_designing_header csr_i_designing_header%rowtype;

begin
  count_success := 0;
  total_value:= 0;
  version_value:= 0;

  -- select count(SEQ_ID) into total_value from I_EPM_DESIGNINGFORM_HEADER where import_date between start_time and end_time;

  open csr_i_designing_header;

  fetch csr_i_designing_header into i_designing_header;

  while (csr_i_designing_header%found) LOOP
    
    -- 新增updateing状态，需要查询之前是否有updateing状态的数据，如果有则失效
    IF (i_designing_header.Design_Status = 'updateing') THEN
        SELECT COUNT(h.seq_id) INTO updateing_count FROM t_sys_epm_designingform_header h 
            WHERE h.design_id = i_designing_header.design_id AND h.req_code = i_designing_header.req_code
            AND h.project_no = i_designing_header.project_no AND h.design_status = 'updateing' AND h.status = 1;
    ELSE
        updateing_count := 0;
    END IF;
        
    IF (updateing_count > 0) THEN
        UPDATE t_sys_epm_designingform_header h
            SET h.status = 0
          WHERE h.design_id = i_designing_header.design_id AND h.req_code = i_designing_header.req_code
            AND h.project_no = i_designing_header.project_no AND h.design_status = 'updateing' AND h.status = 1;
    END IF;
    
    version_value := 1;

    insert into T_SYS_EPM_DESIGNINGFORM_HEADER
      (
        seq_id,
        design_id,
        project_code,
        mis_no,
        req_code,
        project_no,
        station_no,
        station_name,
        old_structure,
        new_structure,
        remove_device,
        add_cabinet,
        storage_space_code,
        storage_dept_code,
        use_dept_code,
        use_dept_name,
        device_admin,
        delivery_date,
        plan_delivery_date,
        station_contact_person,
        station_contact_phone,
        station_addr,
        design_dept,
        design_deptcontact_phone,
        construction_dept,
        const_contact_person,
        const_contact_phone,
        remark1,
        remark2,
        remark3,
        string_attr,
        long_attr,
        datetime_attr,
        double_attr,
        created_user,
        created_date,
        last_updated_user,
        last_updated_date,
        version,
        status,
        is_temporder,
        design_status,
        approved_time
      )
      values
      (
         SEQ_EPM_DESIGNINGFORM.nextval,
         i_designing_header.design_id,
         i_designing_header.project_code,
         i_designing_header.mis_no,
         i_designing_header.req_code,
         i_designing_header.project_no,
         i_designing_header.station_no,
         i_designing_header.station_name,
         i_designing_header.old_structure,
         i_designing_header.new_structure,
         i_designing_header.remove_device,
         i_designing_header.add_cabinet,
         i_designing_header.storage_space_code,
         i_designing_header.storage_dept_code,
         i_designing_header.use_dept_code,
         i_designing_header.use_dept_name,
         i_designing_header.device_admin,
         i_designing_header.delivery_date,
         i_designing_header.plan_delivery_date,
         i_designing_header.station_contact_person,
         i_designing_header.station_contact_phone,
         i_designing_header.station_addr,
         i_designing_header.design_dept,
         i_designing_header.design_deptcontact_phone,
         i_designing_header.construction_dept,
         i_designing_header.const_contact_person,
         i_designing_header.const_contact_phone,
         i_designing_header.remark1,
         i_designing_header.remark2,
         i_designing_header.remark3,
         i_designing_header.string_attr,
         i_designing_header.long_attr,
         i_designing_header.datetime_attr,
         i_designing_header.double_attr,
         '',
         sysdate,
         '',
         sysdate,
         version_value,
         1,
         i_designing_header.is_temporder,
         i_designing_header.design_status,
         i_designing_header.approved_time
      );


  fetch csr_i_designing_header into i_designing_header;
    count_success:=count_success+1;
  end loop;
close csr_i_designing_header;


--log
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,'同步成功','T_SYS_EPM_DESIGNINGFORM_HEADER');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_EPM_DESIGNINGFORM_HEADER');
commit;
end;
/

