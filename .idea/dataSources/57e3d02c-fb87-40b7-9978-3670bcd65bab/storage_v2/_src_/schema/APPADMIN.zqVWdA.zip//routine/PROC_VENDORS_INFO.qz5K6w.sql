create PROCEDURE "PROC_VENDORS_INFO" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
CURSOR CSR_I_VENDORS_INFO IS
  SELECT 
    VENDOR_ID, VENDOR_NUMBER, VENDOR_NAME, VENDOR_TYPE_LOOKUP_CODE, 
    ATTRIBUTE10, ATTRIBUTE11, ATTRIBUTE12, CREATION_DATE, CREATED_BY, 
    ENABLED_FLAG, LAST_UPDATE_DATE, START_DATE_ACTIVE, END_DATE_ACTIVE, ERP_TYPE, SEQ_ID 
 FROM I_ERP_VENDORS_INFO
 where create_date between start_time and end_time ;
i_VENDORS_INFO csr_i_VENDORS_INFO%rowtype;
begin
  COUNT_SUCCESS := 0;
  SELECT COUNT(seq_id) INTO TOTAL_VALUE 
  FROM I_ERP_VENDORS_INFO 
  where create_date between start_time and end_time;
  open csr_i_VENDORS_INFO;
  fetch csr_i_VENDORS_INFO into i_VENDORS_INFO;
while (csr_i_VENDORS_INFO%found) loop
  SELECT COUNT(*) INTO COUNT_VALUE 
  FROM T_SYS_ERP_VENDORS 
  WHERE VENDOR_ID = I_VENDORS_INFO.VENDOR_ID AND ERP_TYPE = I_VENDORS_INFO.ERP_TYPE;
  if(count_value = 1 and i_VENDORS_INFO.enabled_flag = 'Y' and i_VENDORS_INFO.end_date_active is null) then
      UPDATE T_SYS_ERP_VENDORS T 
      set t.last_updated_date = sysdate, version = version + 1,
      t.vendor_code = i_VENDORS_INFO.vendor_number,
      T.VENDOR_NAME = I_VENDORS_INFO.VENDOR_NAME,
      --t.erp_type = i_VENDORS_INFO.erp_type,
      t.vendor_type_lookup_code = i_VENDORS_INFO.vendor_type_lookup_code,
      t.attribute10 = i_VENDORS_INFO.attribute10,
      t.attribute11 = i_VENDORS_INFO.attribute11,
      t.attribute12 = i_VENDORS_INFO.attribute12,
      t.start_date_active = i_VENDORS_INFO.start_date_active,
      t.end_date_active = i_VENDORS_INFO.end_date_active
      WHERE T.VENDOR_ID = I_VENDORS_INFO.VENDOR_ID
      and T.ERP_TYPE = I_VENDORS_INFO.ERP_TYPE;
   elsif(count_value = 1 and i_VENDORS_INFO.enabled_flag = 'N') then
    UPDATE T_SYS_ERP_VENDORS T 
    set t.last_updated_date = sysdate, version = version + 1,
      t.vendor_code = i_VENDORS_INFO.vendor_number,
      T.VENDOR_NAME = I_VENDORS_INFO.VENDOR_NAME,
      --t.erp_type = i_VENDORS_INFO.erp_type,
      t.vendor_type_lookup_code = i_VENDORS_INFO.vendor_type_lookup_code,
      t.attribute10 = i_VENDORS_INFO.attribute10,
      t.attribute11 = i_VENDORS_INFO.attribute11,
      t.attribute12 = i_VENDORS_INFO.attribute12,
      t.start_date_active = i_VENDORS_INFO.start_date_active,
      t.end_date_active = i_VENDORS_INFO.end_date_active,
      t.status = 0
      WHERE T.VENDOR_ID = I_VENDORS_INFO.VENDOR_ID
      and T.ERP_TYPE = i_VENDORS_INFO.erp_type;
   elsif(count_value = 1 and i_VENDORS_INFO.enabled_flag = 'Y' and i_VENDORS_INFO.end_date_active is not null and i_VENDORS_INFO.end_date_active > sysdate) then
   UPDATE T_SYS_ERP_VENDORS T 
    set t.last_updated_date = sysdate, version = version + 1,
      t.vendor_code = i_VENDORS_INFO.vendor_number,
      T.VENDOR_NAME = I_VENDORS_INFO.VENDOR_NAME,
      --t.erp_type = i_VENDORS_INFO.erp_type,
      t.vendor_type_lookup_code = i_VENDORS_INFO.vendor_type_lookup_code,
      t.attribute10 = i_VENDORS_INFO.attribute10,
      t.attribute11 = i_VENDORS_INFO.attribute11,
      t.attribute12 = i_VENDORS_INFO.attribute12,
      t.start_date_active = i_VENDORS_INFO.start_date_active,
      t.end_date_active = i_VENDORS_INFO.end_date_active,
      t.status = 0
      WHERE T.VENDOR_ID = I_VENDORS_INFO.VENDOR_ID
      and T.ERP_TYPE = i_VENDORS_INFO.erp_type;
 elsif(count_value = 0 and i_VENDORS_INFO.enabled_flag = 'Y' and i_VENDORS_INFO.end_date_active is null) then
  INSERT INTO T_SYS_ERP_VENDORS
    (seq_id, vendor_id, created_date, last_updated_date, status, version, erp_type, vendor_code, vendor_name, vendor_type_lookup_code, attribute10, attribute11, attribute12, start_date_active, end_date_active)
  VALUES
    (i_VENDORS_INFO.Seq_Id , i_VENDORS_INFO.vendor_id, sysdate, sysdate, 1, 1, i_VENDORS_INFO.erp_type, i_VENDORS_INFO.vendor_number, i_VENDORS_INFO.vendor_name, i_VENDORS_INFO.vendor_type_lookup_code, i_VENDORS_INFO.attribute10, i_VENDORS_INFO.attribute11, i_VENDORS_INFO.attribute12, i_VENDORS_INFO.start_date_active, i_VENDORS_INFO.end_date_active);
end if;
fetch csr_i_VENDORS_INFO into i_VENDORS_INFO;
count_success:=count_success+1;
end loop;
close csr_i_VENDORS_INFO;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_sys_erp_vendors');
exception when others then
  rollback;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_erp_vendors');
  commit;
end;
/

