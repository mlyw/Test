create procedure PROC_BUDGET_PRIKEY(timestr varchar2) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_budget is 
select seq_id,PRI_KEY,COMPANY_CODE,PROJECT_NUM,BUDGET_DEPT_CODE,BUDGET_ACCOUNT,ACTIVITY_CODE,BRAND_CODE,ENABLED_FLAG,START_DATE,END_DATE from I_Budget_Info where Starttimestamp=timestr;
i_budget csr_i_budget%rowtype;
begin
  count_success := 0;
  select count(seq_id) into total_value from I_Budget_Info where Starttimestamp=timestr;
  open csr_i_budget;
  fetch csr_i_budget into i_budget;
  while(csr_i_budget%found) loop
     select count(*) into count_value 
     from T_Sys_Erp_Budget t
     where T.Segment3 =  i_budget.PROJECT_NUM
      and T.Segment2 =  i_budget.BUDGET_DEPT_CODE
      and T.Segment5 =  i_budget.BUDGET_ACCOUNT
      and T.Segment4 =  i_budget.ACTIVITY_CODE
      and T.Segment7 =  i_budget.BRAND_CODE
     ;
     if(count_value > 0) then
       update t_sys_erp_budget T set T.pri_key = i_budget.PRI_KEY
       where T.Segment3 =  i_budget.PROJECT_NUM
        and T.Segment2 =  i_budget.BUDGET_DEPT_CODE
        and T.Segment5 =  i_budget.BUDGET_ACCOUNT
        and T.Segment4 =  i_budget.ACTIVITY_CODE
        and T.Segment7 =  i_budget.BRAND_CODE  ;   
    end if;
    fetch csr_i_budget into i_budget;
  end loop;
  close csr_i_budget; 
  --删除接口表数据
end;
/

