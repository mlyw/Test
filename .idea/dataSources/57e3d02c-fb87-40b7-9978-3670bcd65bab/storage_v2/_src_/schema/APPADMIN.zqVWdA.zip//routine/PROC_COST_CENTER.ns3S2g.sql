create PROCEDURE "PROC_COST_CENTER" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_cost is
select cost_center_id, cost_center_code, cost_center_name, erp_type, start_date_active, end_data_active, create_date, seq_id from i_erp_cost_center_info where create_date > start_time and create_date < end_time order by erp_type desc;
i_cost csr_i_cost%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_erp_cost_center_info where create_date > start_time and create_date < end_time;
  open csr_i_cost;
  fetch csr_i_cost into i_cost;
while (csr_i_cost%found) loop
  select count(*) into count_value from T_SYS_ERP_COST_CENTER where COST_CENTER_ID = i_cost.cost_center_id and ERP_TYPE = i_cost.erp_type;
  if(count_value = 1 and i_cost.end_data_active is null) then
      update t_Sys_Erp_Cost_Center t set t.last_updated_date = sysdate,
      t.cost_center_code = i_cost.cost_center_code,
      t.cost_center_name = i_cost.cost_center_name,
      t.erp_type= i_cost.erp_type,
      t.start_date_active = i_cost.start_date_active,
      t.end_data_active = i_cost.end_data_active
      where t.cost_center_id = i_cost.cost_center_id;
   elsif(count_value = 1 and i_cost.end_data_active is not null) then
      update t_Sys_Erp_Cost_Center t set t.last_updated_date = sysdate,
      t.cost_center_code = i_cost.cost_center_code,
      t.cost_center_name = i_cost.cost_center_name,
      t.erp_type= i_cost.erp_type,
      t.start_date_active = i_cost.start_date_active,
      t.end_data_active = i_cost.end_data_active
      where t.cost_center_id = i_cost.cost_center_id;
 elsif(count_value = 0 and i_cost.end_data_active is null) then
  insert into t_sys_erp_cost_center
    (seq_id, cost_center_id, cost_center_code, cost_center_name, erp_type, start_date_active, end_data_active, created_date, last_updated_date, status)
  values
    (i_cost.seq_id, i_cost.cost_center_id, i_cost.cost_center_code, i_cost.cost_center_name, i_cost.erp_type, i_cost.start_date_active, i_cost.end_data_active, sysdate, sysdate, 1);
end if;
fetch csr_i_cost into i_cost;
count_success:=count_success+1;
end loop;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','T_SYS_ERP_COST_CENTER');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_ERP_COST_CENTER');
close csr_i_cost;
commit;
end;

/

