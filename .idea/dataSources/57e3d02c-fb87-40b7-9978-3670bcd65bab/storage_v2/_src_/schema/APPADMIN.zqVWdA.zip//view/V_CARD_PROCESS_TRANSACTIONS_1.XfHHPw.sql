create view V_CARD_PROCESS_TRANSACTIONS_1 as
  select trl.item_code 物料编码,
       null 来源子库存,
       twd.mis_subinventory_name 目的子库存,
       '1 CNP接收入库' 交易类型,
       to_char(trl.accounting_confrim_import_date, 'YYYY-MM-DD') 导入MIS日期,
       trl.current_receive_quantity 交易数量,
       trh.receipt_order_code 单号,
       trh.id 头ID,
       trl.receiptorderlineid 行ID
  from t_receiptorder_headerinfo trh,
       t_receiptorder_lineinfo   trl,
       t_warehouse_define        twd
 where trh.id = trl.receipt_order_id
   and trl.warehouse_receive_id = twd.id
   and twd.mis_subinventory_name like 'C%'
   and trh.status = 1
   and trl.status = 1
union
-- CNP出库
select distinct tol.item_code 物料编码,
                tol.subinventory_code 来源子库存,
                tol.to_subinventory_code 目的子库存,
                '3 CNP出库' 交易类型,
       to_char(tom.acc_cfm_imptomis_date, 'YYYY-MM-DD') 导入MIS日期,
                tol.asgn_quty 交易数量,
                toh.out_ord_code 单号,
                toh.id 头ID,
                tol.id 行ID
  from t_out_hd toh, t_out_ln tol, t_out_notmk tom
 where toh.id = tol.outhdinfo_id
   and tol.id = tom.outlninfo_id
   and tol.subinventory_code like 'C%'
   and toh.status = 1
   and tol.status = 1
   and tom.status = 1
   and tol.ord_ln_status = 7
union
-- SIM卡销售月结
select tsi.item_code 物料编码,
       twd.mis_subinventory_name 来源子库存,
       null 目的子库存,
       '5 SIM卡销售月结' 交易类型,
       to_char(tsh.transaction_processing_time, 'YYYY-MM-DD') 导入MIS日期,
       tsl.simcard_qty 交易数量,
       tsh.simcard_order_code 单号,
       tsh.id 头ID,
       tsl.id 行ID
  from t_lis_simcard_sales_month_head tsh,
       t_lis_simcard_sales_month_line tsl,
       t_warehouse_define             twd,
       t_sys_erp_items                tsi
 where tsh.id = tsl.head_id
   and tsl.wd_id = twd.id
   and tsl.item_id = tsi.seq_id
   and tsh.status = 1
   and tsl.status = 1
   and tsh.head_status = 4
   and tsl.line_status = 4
union
-- RM销售
select tls.item_code 物料编码,
       tls.subinventory_code 来源子库存,
       null 目的子库存,
       '6 RM销售' 交易类型,
       to_char(tls.transcation_date, 'YYYY-MM-DD') 导入MIS日期,
       tls.quantity 交易数量,
       tls.origin_filename 单号,
       tls.seq_id 头ID,
       tls.seq_id 行ID
  from t_lis_rm_sales tls
 where nvl(tls.flag, 'X') = 'Y'
   and tls.status = 1
union
-- 营业厅调拨
select tcl.item_code 物料编码,
       twd_from.mis_subinventory_name 来源子库存,
       twd_to.mis_subinventory_name 目的子库存,
       '8 营业厅调拨' 交易类型,
       to_char(tch.account_date, 'YYYY-MM-DD') 导入MIS日期,
       tcl.change_quty 交易数量,
       tch.wh_chg_ord_code 单号,
       tch.id 头ID,
       tcl.id 行ID
  from t_chg_hd_ln        tch,
       t_chg_ln           tcl,
       t_warehouse_define twd_from,
       t_warehouse_define twd_to
 where tch.id = tcl.chghdln_id
   and tcl.wh_id_trf_from = twd_from.id
   and tcl.wh_id_trf_into = twd_to.id
   and twd_from.mis_subinventory_name like 'C%'
   and tch.order_status = 50
   and tch.status = 1
   and tcl.status = 1
 order by 导入MIS日期, 交易类型, 物料编码, 来源子库存, 目的子库存
/

