create PROCEDURE "PROC_SP" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_sp is
select seq_id, spare_id, spare_code, spare_name, enable_flag, start_data_active, end_data_active, erp_type, import_date from i_erp_sp
 where import_date > start_time and import_date < end_time order by erp_type desc;
i_sp csr_i_sp%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from I_ERP_SP where import_date > start_time and import_date < end_time;
  open csr_i_sp;
  fetch csr_i_sp into i_sp;
while (csr_i_sp%found) loop
  select count(*) into count_value from T_SYS_ERP_SP where ERP_SP_ID = i_sp.spare_id and erp_type = i_sp.erp_type;
  if(count_value = 1 and i_sp.enable_flag = 'Y' and i_sp.end_data_active is null) then
      update T_SYS_ERP_SP t set t.last_updated_date = sysdate,
      t.erp_sp_code = i_sp.spare_code,
      t.erp_sp_name = i_sp.spare_name,
      t.erp_type = i_sp.erp_type,
      t.start_date_active = i_sp.start_data_active,
      t.end_date_active = i_sp.end_data_active
      where t.erp_sp_id = i_sp.spare_id
      and t.erp_type = i_sp.erp_type;
   elsif(count_value = 1 and i_sp.enable_flag = 'N') then
   update T_SYS_ERP_SP t set t.last_updated_date = sysdate,
      t.erp_sp_code = i_sp.spare_code,
      t.erp_sp_name = i_sp.spare_name,
      t.erp_type = i_sp.erp_type,
      t.start_date_active = i_sp.start_data_active,
      t.end_date_active = i_sp.end_data_active,
      t.status = 0
      where t.erp_sp_id = i_sp.spare_id
      and t.erp_type = i_sp.erp_type;
   elsif(count_value = 1 and i_sp.enable_flag = 'Y' and i_sp.end_data_active is not null) then
   update T_SYS_ERP_SP t set t.last_updated_date = sysdate,
      t.erp_sp_code = i_sp.spare_code,
      t.erp_sp_name = i_sp.spare_name,
      t.erp_type = i_sp.erp_type,
      t.start_date_active = i_sp.start_data_active,
      t.end_date_active = i_sp.end_data_active,
      t.status = 0
      where t.erp_sp_id = i_sp.spare_id
      and t.erp_type = i_sp.erp_type;
 elsif(count_value = 0 and i_sp.end_data_active is null and i_sp.enable_flag = 'Y') then
insert into t_sys_erp_sp
  (erp_sp_id, erp_sp_code, erp_sp_name, erp_type, start_date_active, end_date_active, validity_flag, created_date, last_updated_date, status, version, seq_id)
values
  (i_sp.spare_id, i_sp.spare_code, i_sp.spare_name, i_sp.erp_type, i_sp.start_data_active, i_sp.end_data_active, i_sp.enable_flag, sysdate, sysdate, 1, 0, i_sp.seq_id);   
end if;
fetch csr_i_sp into i_sp;
count_success := count_success + 1;
end loop;
close csr_i_sp;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','T_SYS_ERP_SP');
exception when others then
  rollback;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_ERP_SP');
  commit;
end;
/

