create PROCEDURE proc_spm_itemPurMapping_sync (start_time timestamp, end_time timestamp) as
  total_value number(15);
  count_value number(2);
  count_success number(15);
  exception_info varchar2(3000);
  --读取（start_time，end_time）之间的数据
cursor csr_i_spm_itemPurcataMapping is
  select seq_id,
         materialinfo_mapping_id,
         material_num,
         material_desc,
         purchase_catalog_code1,
         purchase_catalog_name1,
         purchase_catalog_code2,
         purchase_catalog_name2,
         purchase_catalog_code3,
         purchase_catalog_name3,
         purchase_catalog_code4,
         purchase_catalog_name4,
         purchase_catalog_code5,
         purchase_catalog_name5,
         material_catalog_code1,
         material_catalog_name1,
         material_catalog_code2,
         material_catalog_name2,
         material_catalog_code3,
         material_catalog_name3,
         old_material_num,
         old_material_desc,
         iseffective,
         attribute1,
         attribute2,
         attribute3,
         attribute4,
         attribute5,
         create_time,
         last_update_date
  from i_spm_item_purcata_mapping
  where create_time between start_time and end_time;

i_spm_itemPurcataMapping csr_i_spm_itemPurcataMapping%rowtype;
begin
  count_success := 0;
  select count(seq_id) into total_value 
  from i_spm_item_purcata_mapping 
  where create_time between start_time and end_time;
  open csr_i_spm_itemPurcataMapping;
  fetch csr_i_spm_itemPurcataMapping into i_spm_itemPurcataMapping;
  while (csr_i_spm_itemPurcataMapping%found) loop
    select count(materialinfo_mapping_id) into count_value 
    from t_sys_spm_item_purcata_mapping 
    where materialinfo_mapping_id = i_spm_itemPurcataMapping.materialinfo_mapping_id;
    if (count_value = 1) then
      update t_sys_spm_item_purcata_mapping syitp 
      set material_num=i_spm_itemPurcataMapping.material_num,
                                                      material_desc=i_spm_itemPurcataMapping.material_desc,
                                                      purchase_catalog_code1=i_spm_itemPurcataMapping.purchase_catalog_code1,
                                                      purchase_catalog_name1=i_spm_itemPurcataMapping.purchase_catalog_name1,
                                                      purchase_catalog_code2=i_spm_itemPurcataMapping.purchase_catalog_code2,
                                                      purchase_catalog_name2=i_spm_itemPurcataMapping.purchase_catalog_name2,
                                                      purchase_catalog_code3=i_spm_itemPurcataMapping.purchase_catalog_code3,
                                                      purchase_catalog_name3=i_spm_itemPurcataMapping.purchase_catalog_name3,
                                                      purchase_catalog_code4=i_spm_itemPurcataMapping.purchase_catalog_code4,
                                                      purchase_catalog_name4=i_spm_itemPurcataMapping.purchase_catalog_name4,
                                                      purchase_catalog_code5=i_spm_itemPurcataMapping.purchase_catalog_code5,
                                                      purchase_catalog_name5=i_spm_itemPurcataMapping.purchase_catalog_name5,
                                                      material_catalog_code1=i_spm_itemPurcataMapping.material_catalog_code1,
                                                      material_catalog_name1=i_spm_itemPurcataMapping.material_catalog_name1,
                                                      material_catalog_code2=i_spm_itemPurcataMapping.material_catalog_code2,
                                                      material_catalog_name2=i_spm_itemPurcataMapping.material_catalog_name2,
                                                      material_catalog_code3=i_spm_itemPurcataMapping.material_catalog_code3,
                                                      material_catalog_name3=i_spm_itemPurcataMapping.material_catalog_name3,
                                                      old_material_num=i_spm_itemPurcataMapping.old_material_num,
                                                      old_material_desc=i_spm_itemPurcataMapping.old_material_desc,
                                                      iseffective=i_spm_itemPurcataMapping.iseffective,
                                                      attribute1=i_spm_itemPurcataMapping.attribute1,
                                                      attribute2=i_spm_itemPurcataMapping.attribute2,
                                                      attribute3=i_spm_itemPurcataMapping.attribute3,
                                                      attribute4=i_spm_itemPurcataMapping.attribute4,
                                                      attribute5=i_spm_itemPurcataMapping.attribute5,
                                                      last_update_date=i_spm_itempurcatamapping.last_update_date,
                                                      last_updated_date=sysdate, version = version + 1
      where syitp.materialinfo_mapping_id=i_spm_itemPurcataMapping.materialinfo_mapping_id;
    else
      insert into t_sys_spm_item_purcata_mapping (materialinfo_mapping_id,
                                             material_num,
                                             material_desc,
                                             purchase_catalog_code1,
                                             purchase_catalog_name1,
                                             purchase_catalog_code2,
                                             purchase_catalog_name2,
                                             purchase_catalog_code3,
                                             purchase_catalog_name3,
                                             purchase_catalog_code4,
                                             purchase_catalog_name4,
                                             purchase_catalog_code5,
                                             purchase_catalog_name5,
                                             material_catalog_code1,
                                             material_catalog_name1,
                                             material_catalog_code2,
                                             material_catalog_name2,
                                             material_catalog_code3,
                                             material_catalog_name3,
                                             old_material_num,
                                             old_material_desc,
                                             iseffective,
                                             attribute1,
                                             attribute2,
                                             attribute3,
                                             attribute4,
                                             attribute5,
                                             last_update_date,
                                             created_date,
                                             last_updated_date,
                                             status,
                                             version)
      values(i_spm_itemPurcataMapping.materialinfo_mapping_id,
             i_spm_itemPurcataMapping.material_num,
             i_spm_itemPurcataMapping.material_desc,
             i_spm_itemPurcataMapping.purchase_catalog_code1,
             i_spm_itemPurcataMapping.purchase_catalog_name1,
             i_spm_itemPurcataMapping.purchase_catalog_code2,
             i_spm_itemPurcataMapping.purchase_catalog_name2,
             i_spm_itemPurcataMapping.purchase_catalog_code3,
             i_spm_itemPurcataMapping.purchase_catalog_name3,
             i_spm_itemPurcataMapping.purchase_catalog_code4,
             i_spm_itemPurcataMapping.purchase_catalog_name4,
             i_spm_itemPurcataMapping.purchase_catalog_code5,
             i_spm_itemPurcataMapping.purchase_catalog_name5,
             i_spm_itemPurcataMapping.material_catalog_code1,
             i_spm_itemPurcataMapping.material_catalog_name1,
             i_spm_itemPurcataMapping.material_catalog_code2,
             i_spm_itemPurcataMapping.material_catalog_name2,
             i_spm_itemPurcataMapping.material_catalog_code3,
             i_spm_itemPurcataMapping.material_catalog_name3,
             i_spm_itemPurcataMapping.old_material_num,
             i_spm_itemPurcataMapping.old_material_desc,
             i_spm_itemPurcataMapping.iseffective,
             i_spm_itemPurcataMapping.attribute1,
             i_spm_itemPurcataMapping.attribute2,
             i_spm_itemPurcataMapping.attribute3,
             i_spm_itemPurcataMapping.attribute4,
             i_spm_itemPurcataMapping.attribute5,
             i_spm_itemPurcataMapping.last_update_date,
             sysdate,sysdate,1,1);
    end if;
  fetch csr_i_spm_itempurcatamapping into i_spm_itempurcatamapping;
  count_success := count_success + 1;
  end loop;
  close csr_i_spm_itemPurcataMapping ;
  --插入日志
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value, total_value,sysdate,'同步成功','t_sys_spm_item_purcata_mapping');
  exception when others then
      exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
    insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_sys_spm_item_purcata_mapping');
  commit;
end;
/

