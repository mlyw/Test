create PROCEDURE proc_po_line_ygz (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
project_id_value number(19); 
count_project_value number(19);
item_seq_id number(19);
task_seq_id number(19);
product_seq_id number(19);
cursor csr_i_po_line is
select t.id, t.spm_po_line_id, t.spm_po_line_location_id, t.spm_po_header_id, t.mis_po_header_id, t.mis_po_line_id, t.mis_po_line_location_id, t.mis_po_distribution_id, t.organization_id, t.item_category_id, t.item_category_code, t.item_category_desc, t.item_id, t.item_code, t.item_desc, t.product_category_id, t.product_category_code, t.product_category_desc, t.product_id, t.product_code, t.product_desc, t.uom_code, t.uom_desc, t.unit_price_ex_tax, t.unit_price, t.tax_rate, t.quantity_ordered, t.project_code, t.task_id, t.expenditure_type_id, t.creation_date, t.last_updated_date, t.po_line_status, t.created_date, t.spm_po_distribution_id, t.impor_date, t.inventory_type, t.account_combination_id, t.account_combination_code, t.account_combination_desc, t.applicant_employee_id, t.applicant_employee_number, t.applicant_employee_name,h.erp_type from i_spm_po_line_l t,i_spm_po_header_l h where t.SPM_PO_HEADER_ID = h.SPM_PO_HEADER_ID and impor_date > start_time and impor_date < end_time;
i_po_line csr_i_po_line%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from i_spm_po_line_l where impor_date > start_time and impor_date < end_time;
  open csr_i_po_line;
  fetch csr_i_po_line into i_po_line;
while (csr_i_po_line%found) loop
  select count(*) into count_value from t_base_spm_pur_order_lines_l where spm_po_line_id = i_po_line.spm_po_distribution_id;
  select seq_id into item_seq_id from t_sys_erp_items t where t.item_code = i_po_line.item_code and t.organization_id = i_po_line.organization_id;
  if(i_po_line.task_id is null or i_po_line.task_id = 0) then
  task_seq_id := null;
  elsif(i_po_line.task_id is not null) then
  select seq_id into task_seq_id from t_sys_erp_tasks where task_id = i_po_line.task_id and erp_type = i_po_line.erp_type;
  end if;
--  if(i_po_line.product_id is null) then
--  product_seq_id := null;
--  elsif(i_po_line.product_id is not null) then
--  select seq_id into product_seq_id from t_sys_spm_products p where p.product_id = i_po_line.product_id and p.erp_type = i_po_line.erp_type;
--  end if;
  if(i_po_line.project_code is null) then
  project_id_value := null;
  elsif(i_po_line.project_code is not null) then
    select count(*) into count_project_value from t_sys_erp_projects p where p.project_code = i_po_line.project_code and p.erp_type = i_po_line.erp_type;
    if(count_project_value > 0 ) then
    select seq_id into project_id_value from t_sys_erp_projects p where p.project_code = i_po_line.project_code and p.erp_type = i_po_line.erp_type;
    elsif(count_project_value = 0) then
    project_id_value := null;
    end if;
  end if; 
  if(count_value = 1) then
     update t_base_spm_pur_order_lines_l
        set last_updated_date = sysdate,
            item_category_code = i_po_line.item_category_code,
            item_category_desc = i_po_line.item_category_desc,
            item_category_id = i_po_line.item_category_id,
            item_code = i_po_line.item_code,
            item_desc = i_po_line.item_desc,
            item_id = item_seq_id,
            mis_po_distribution_id = i_po_line.mis_po_distribution_id,
            mis_po_header_id = i_po_line.mis_po_header_id,
            mis_po_line_id = i_po_line.mis_po_line_id,
            mis_po_line_location_id = i_po_line.mis_po_line_location_id,
            organization_id = i_po_line.organization_id,
            poline_status = i_po_line.po_line_status,
            product_id = null,
            task_id = task_seq_id,
            project_id = project_id_value,
            uom_desc = i_po_line.uom_desc,
            spm_po_header_id = i_po_line.spm_po_header_id,
            uom_code = i_po_line.uom_code,
            product_unit_price_ex_tax = i_po_line.unit_price_ex_tax,
            product_unit_price = i_po_line.unit_price,
            product_tax_rate = i_po_line.tax_rate,
            spm_line_id = i_po_line.spm_po_line_id,
            spm_po_line_location_id = i_po_line.spm_po_line_location_id,
            inventory_type = i_po_line.inventory_type,
            account_combination_id = i_po_line.account_combination_id,
            account_combination_code = i_po_line.account_combination_code,
            account_combination_desc = i_po_line.account_combination_desc,
            applicant_employee_id = i_po_line.applicant_employee_id,
            applicant_employee_number = i_po_line.applicant_employee_number,
            applicant_employee_name = i_po_line.applicant_employee_name
      where spm_po_line_id = i_po_line.spm_po_distribution_id;
 else
insert into t_base_spm_pur_order_lines_l
  (spm_po_line_id, created_date, last_updated_date, status, version, item_category_code, item_category_desc, item_category_id, item_code, item_desc, item_id, mis_po_distribution_id, mis_po_header_id, mis_po_line_id, mis_po_line_location_id, organization_id, poline_status, product_id, quantity_ordered, quantity_receivable, quantity_received, quantity_returned, task_id, uom_desc, spm_po_header_id, uom_code, product_unit_price_ex_tax, product_unit_price, product_tax_rate, spm_line_id, spm_po_line_location_id, inventory_type, account_combination_id, account_combination_code, account_combination_desc, applicant_employee_id, applicant_employee_number, applicant_employee_name, project_id)
values
  (i_po_line.spm_po_distribution_id, sysdate, sysdate, 1, 0, i_po_line.item_category_code, i_po_line.item_category_desc, i_po_line.item_category_id, i_po_line.item_code, i_po_line.item_desc, item_seq_id, i_po_line.mis_po_distribution_id, i_po_line.mis_po_header_id, i_po_line.mis_po_line_id, i_po_line.mis_po_line_location_id, i_po_line.organization_id, i_po_line.po_line_status, null, i_po_line.quantity_ordered, i_po_line.quantity_ordered, 0, 0, task_seq_id, i_po_line.uom_desc, i_po_line.spm_po_header_id, i_po_line.uom_code, i_po_line.unit_price_ex_tax, i_po_line.unit_price, i_po_line.tax_rate, i_po_line.spm_po_line_id, i_po_line.spm_po_line_location_id, i_po_line.inventory_type, i_po_line.account_combination_id, i_po_line.account_combination_code, i_po_line.account_combination_desc, i_po_line.applicant_employee_id, i_po_line.applicant_employee_number, i_po_line.applicant_employee_name, project_id_value);
end if;
fetch csr_i_po_line into i_po_line;
count_success:=count_success+1;
end loop;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_base_spm_pur_order_lines_l');
exception when others then
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_base_spm_pur_order_lines_l');
close csr_i_po_line;
commit;
end;
/

