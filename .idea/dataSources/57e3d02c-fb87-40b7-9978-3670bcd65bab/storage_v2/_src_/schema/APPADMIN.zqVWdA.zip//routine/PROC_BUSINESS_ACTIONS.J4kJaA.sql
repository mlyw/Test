create PROCEDURE proc_business_actions (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_business is
select activity_id, activity_code, description, offset_flag, sell_flag, enabled_flag, start_date_active, end_date_active, create_date, seq_id from i_erp_business_actions where create_date > start_time and create_date < end_time ;
i_business csr_i_business%rowtype;
begin
  count_success := 0;
  select count(seq_id) into total_value from i_Erp_Business_Actions where create_date > start_time and create_date < end_time;
  open csr_i_business;
  fetch csr_i_business into i_business;
while (csr_i_business%found) loop
  select count(seq_id) into count_value from t_Sys_Erp_Business_Actions where BUSINESS_ACTION_ID = i_business.ACTIVITY_ID;
  if(count_value = 1 and i_business.enabled_flag = 'Y' and i_business.end_date_active is null) then
      update t_Sys_Erp_Business_Actions t set t.last_updated_date = sysdate,
      t.business_action_code = i_business.activity_code,
      t.business_action_name = i_business.description,
      t.end_date_active = i_business.end_date_active,
      t.start_date_active = i_business.start_date_active,
      t.sell_flag = i_business.sell_flag,
      t.offset_flag = i_business.offset_flag
      where t.business_action_id = i_business.activity_id;
   elsif(count_value = 1 and i_business.enabled_flag = 'N') then
   update t_Sys_Erp_Business_Actions t set t.last_updated_date = sysdate,
      t.business_action_code = i_business.activity_code,
      t.business_action_name = i_business.description,
      t.start_date_active = i_business.start_date_active,
      t.end_date_active = i_business.end_date_active,
      t.sell_flag = i_business.sell_flag,
      t.offset_flag = i_business.offset_flag,
      t.status = 0
      where t.business_action_id = i_business.activity_id;
   elsif(count_value = 1 and i_business.enabled_flag = 'Y' and i_business.end_date_active is not null) then
   update t_Sys_Erp_Business_Actions t set t.last_updated_date = sysdate,
      t.business_action_code = i_business.activity_code,
      t.business_action_name = i_business.description,
      t.start_date_active = i_business.start_date_active,
      t.end_date_active = i_business.end_date_active,
      t.sell_flag = i_business.sell_flag,
      t.offset_flag = i_business.offset_flag,
      t.status = 0
      where t.business_action_id = i_business.activity_id;
 else
   insert into t_sys_erp_business_actions
     (seq_id, business_action_id, created_date, last_updated_date, status, business_action_code, business_action_name, end_date_active, start_date_active, sell_flag, offset_flag, erp_type)
   values
     (i_business.seq_id, i_business.activity_id, sysdate, sysdate, 1, i_business.activity_code, i_business.description, i_business.end_date_active, i_business.start_date_active, i_business.sell_flag, i_business.offset_flag, '2G');
end if;
fetch csr_i_business into i_business;
count_success:=count_success+1;
end loop;
close csr_i_business;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','t_Sys_Erp_Business_Actions');
exception when others then
  rollback;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'t_Sys_Erp_Business_Actions');
  commit;
end;
/

