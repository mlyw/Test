create PROCEDURE PROC_ONHAND_DEAL_SYNC AS 
  v_quantity number(19,5);
  v_sum number(19,5);
  quantity number(19,5); 
  reserve_quantity number(19,5);
  available_quantity number(19,5);
  exception_info varchar2(255);
  --待处理的现有量游标
  CURSOR c_items IS SELECT Wh.Itemcode,Wh.Mipiccode,Wh.Warehousecode,Wh.Quantity 
    FROM Temp_Deal_Onhand WH
    where Wh.Itemcode='130100001';
  c_item c_items%rowtype;    
  E_EXECUTING_EXCEPTION exception;
  
  type r_onhand is record
  ( 
   onhand_id number,
   onhand_quantity number(19,5)
  );
  type r_c_onhand is ref cursor return r_onhand;
  c_onhand  r_c_onhand;
  v_onhand r_onhand;
BEGIN
  open c_items;
  fetch c_items into c_item;
  while (c_items%found) loop
    --当前待处理的现有量数
    v_quantity := c_item.quantity;
    
    --如果数量小于0,标识需要扣减
    if(v_quantity < 0) then 
  
      select sum(nvl(Wq.Onhand_Quantity,0)) into v_sum  from T_Wh_Current_Onhand_Quantity wq 
        where Wq.Status = 1 and Wq.Onhand_Quantity > 0
              and Wq.Item_Code = c_item.itemcode
              and Wq.Mis_Pic_Code = c_item.Mipiccode
              and Wq.Warehouse_Define_Id = (
                    select id from T_Warehouse_Define wd where Wd.Warehouse_Define_Code = c_item.Warehousecode and Wd.Status = 1
                  );
      
      v_quantity := abs(v_quantity);
      if(v_sum < v_quantity) then
        raise E_EXECUTING_EXCEPTION;
      end if;
      
      open c_onhand for 
      select wq.id onhand_id,Wq.Onhand_Quantity onhand_quantity from T_Wh_Current_Onhand_Quantity wq 
        where Wq.Status = 1 and Wq.Onhand_Quantity > 0
              and Wq.Item_Code = c_item.itemcode
              and Wq.Mis_Pic_Code = c_item.Mipiccode
              and Wq.Warehouse_Define_Id = (
                    select id from T_Warehouse_Define wd where Wd.Warehouse_Define_Code = c_item.Warehousecode and Wd.Status = 1
                  )
        order by Wq.Onhand_Quantity;
      fetch c_onhand into v_onhand;
      quantity := v_quantity;
      
      while (c_onhand%found) loop
        exit when quantity=0;
        reserve_quantity:=0;
        select nvl(sum(Info.Reserve_Quantity),0) into reserve_quantity from T_Sys_Item_Resereve_Info info where Info.Onhand_Id=v_onhand.onhand_id and Info.Status =1;
        
        
        available_quantity := v_onhand.onhand_quantity-reserve_quantity;
        
        
        if(available_quantity >= quantity) then
          update T_Wh_Current_Onhand_Quantity wq 
            set wq.Onhand_Quantity=wq.Onhand_Quantity-quantity ,Wq.String_Value1 = Wq.String_Value1|| '(17-9-10原:'|| Wq.Onhand_Quantity ||',扣:'||quantity||',余:'||(wq.Onhand_Quantity-quantity)||')' 
            where wq.id=v_onhand.onhand_id;
          quantity := 0;
        else
          update T_Wh_Current_Onhand_Quantity wq 
            set wq.Onhand_Quantity=wq.Onhand_Quantity-available_quantity 
             ,Wq.String_Value1 = Wq.String_Value1|| '(17-9-10原:'|| Wq.Onhand_Quantity ||',扣:'||available_quantity||',余:'||(wq.Onhand_Quantity-available_quantity )||')' 
            where wq.id=v_onhand.onhand_id;
          quantity := quantity-available_quantity;
        end if;
        fetch c_onhand into v_onhand;
      end loop;
     
      if(quantity > 0) then
        raise E_EXECUTING_EXCEPTION;
      end if;
       commit;
      close  c_onhand;
    elsif(v_quantity > 0) then
     Dbms_Output.Put_Line(v_quantity);
     Insert into T_Wh_Current_Onhand_Quantity(ID,CREATED_DATE,CREATED_USER,DATE_VALUE1,LAST_UPDATED_DATE,LAST_UPDATED_USER,NUMBER_VALUE1,STATUS,STRING_VALUE1,VERSION,CONSIGNED,ITEM_CATEGORY_CODE,ITEM_CATEGORY_DESC,ITEM_CATEGORY_ID,ITEM_CODE,ITEM_DESC,ITEM_ID,MIS_PIC_CODE,PRODUCT_CATEGORY_CODE,PRODUCT_CATEGORY_DESC,PRODUCT_CATEGORY_ID,PRODUCT_CODE,PRODUCT_DESC,PRODUCT_ID,PROJECT_ID,RECEIPT_PIC_CODE,TESTING_STATUS,UOM_CODE,UOM_DESC,WAREHOUSE_DEFINE_ID,PROJECT_NUMBER,PROJECT_NAME,PRODUCT_UNIT_PRICE_EX_TAX,PRODUCT_UNIT_PRICE,VENDOR_ID,LOCATOR_ID,LOCATOR_CODE,ERP_TYPE,PRODUCT_TAX_RATE,ONHAND_QUANTITY,EPM_TASK_CODE,EPM_TASK_NAME,IS_ITEM_PACKAGE,ITEM_PACKAGE_ID,IS_FITTINGS,PROJECT_NO,SUB_PROJECT_SEQ_ID,SUB_PROJECT_NO,SUB_PROJECT_PERSON,SUB_PROJECT_PERSON_NAME) 
     values (S_WH_CURRENT_ONHAND_QUANTITY.nextVal,
              sysdate,'82_12345678',sysdate,sysdate,'82_12345678',null,1,
              '2017-9-10手动执行C999加现有量',1,null,null,null,null,
              (select Its.Item_Code from T_Sys_Erp_Items its where its.status=1 and Its.Item_Code=c_item.itemcode and Its.Organization_Id=(
                select Org.Organization_Id from T_Sys_Erp_Organizations org where Org.Organization_Code='BJC'
              )),
              (select Its.Item_Name from T_Sys_Erp_Items its where its.status=1 and Its.Item_Code=c_item.itemcode and Its.Organization_Id=(
                select Org.Organization_Id from T_Sys_Erp_Organizations org where Org.Organization_Code='BJC'
              )), 
              (select Its.Seq_Id from T_Sys_Erp_Items its where its.status=1 and Its.Item_Code=c_item.itemcode and Its.Organization_Id=(
                select Org.Organization_Id from T_Sys_Erp_Organizations org where Org.Organization_Code='BJC'
              )),
              c_item.Mipiccode,null,null,null,null,null,null,null,null,null,
              (select Its.Uom_Code from T_Sys_Erp_Items its where its.status=1 and Its.Item_Code=c_item.itemcode and Its.Organization_Id=(
                select Org.Organization_Id from T_Sys_Erp_Organizations org where Org.Organization_Code='BJC'
              )),
              (select Its.Uom_Desc from T_Sys_Erp_Items its where its.status=1 and Its.Item_Code=c_item.itemcode and Its.Organization_Id=(
                select Org.Organization_Id from T_Sys_Erp_Organizations org where Org.Organization_Code='BJC'
              )),
              (select id from T_Warehouse_Define wd where Wd.Warehouse_Define_Code =c_item.Warehousecode and wd.status=1),null,null,null,null,null,null,null,'2G',null,
              c_item.Quantity,null,null,null,null,null,null,null,null,null,null);
        commit;
         Dbms_Output.Put_Line(v_quantity);
    end if;       
    fetch c_items into c_item;
   
  end loop;
  close c_items;
  commit;
  exception
  when E_EXECUTING_EXCEPTION  then
    rollback;
  when others then
    rollback;
END PROC_ONHAND_DEAL_SYNC;

/*
select Wq.Onhand_Quantity,Wq.Mis_Pic_Code,  wq.* from T_Wh_Current_Onhand_Quantity wq 
where Wq.Status =1 
and  Wq.Onhand_Quantity > 0
and Wq.Item_Code = '130100001'
and Wq.Warehouse_Define_Id =(
select id from T_Warehouse_Define wd where Wd.Warehouse_Define_Code ='C999' and wd.status=1
) and wq.id=186536;
SELECT Wh.Itemcode,Wh.Mipiccode,Wh.Warehousecode,Wh.Quantity ,
(
  select sum(Wq.Onhand_Quantity) from T_Wh_Current_Onhand_Quantity wq 
    join T_Warehouse_Define wd on wd.id=Wq.Warehouse_Define_Id 
where Wq.Status =1 
and  Wq.Onhand_Quantity > 0
and Wq.Item_Code = '130100001'
and Wd.Warehouse_Define_Code=Wh.Warehousecode and Wd.Status = 1
) onh
FROM Temp_Deal_Onhand WH
where Wh.Itemcode='130100004';
 SELECT Wh.Itemcode,Wh.Mipiccode,Wh.Warehousecode,Wh.Quantity 
    FROM Temp_Deal_Onhand WH
    where Wh.Itemcode='130100001';
    
select *from I_Erp_Logs  where Table_Name='Temp_Deal_Onhand' order by seq_id desc;
delete from Temp_Deal_Onhand 
where Itemcode='130100001' and Warehousecode <> 'C999';
 select *from Temp_Deal_Onhand;
select 
sum(
--Wq.String_Value1
substr(Wq.String_Value1, instr(Wq.String_Value1,'扣:')+2, instr(Wq.String_Value1,',余:')-instr(Wq.String_Value1,'扣:')+2-4) 
)
from T_Wh_Current_Onhand_Quantity wq 
where Wq.Item_Code = '130100001' and Wq.String_Value1 like '%原:%';

select sum(Wq.Onhand_Quantity)
from T_Wh_Current_Onhand_Quantity wq 
where Wq.Item_Code = '130100001' and Wq.Onhand_Quantity > 0 and Wq.Status =1;--1578080


select wq.id, Wq.Created_Date,Wq.String_Value1,Wq.Onhand_Quantity from T_Wh_Current_Onhand_Quantity wq 
where Wq.Item_Code = '130100001'
and Wq.Warehouse_Define_Id=(
select id from T_Warehouse_Define wd where Wd.Warehouse_Define_Code ='C999' and wd.status=1
)
order by wq.id desc;

*/

