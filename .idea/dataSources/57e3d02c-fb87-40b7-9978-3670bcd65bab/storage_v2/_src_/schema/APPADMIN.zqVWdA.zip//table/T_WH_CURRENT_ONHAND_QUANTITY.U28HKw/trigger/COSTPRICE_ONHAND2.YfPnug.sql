create trigger COSTPRICE_ONHAND2
  before update of PRODUCT_UNIT_PRICE
  on T_WH_CURRENT_ONHAND_QUANTITY
  for each row
  BEGIN
    :new.Cost_Unit_Price := :new.Product_Unit_Price;
END;
/

