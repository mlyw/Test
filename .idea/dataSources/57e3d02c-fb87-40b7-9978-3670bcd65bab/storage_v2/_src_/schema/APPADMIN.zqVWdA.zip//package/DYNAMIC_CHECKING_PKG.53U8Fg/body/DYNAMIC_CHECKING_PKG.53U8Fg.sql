create package body dynamic_checking_pkg is
   procedure proc_dynamic_checking(ouEmployeeNumber in varchar2,ouId in long,flag in varchar2,pagenum in number,pagesize in number,warehouse_id in varchar2,dynamic_checking out cur_dynamic_checking,total out number)
as
  v_date date;--定义一个统一的时间
  v_ErrorCode NUMBER;           -- error message code
  v_ErrorText VARCHAR2(200);    -- error message text
begin
  v_date := sysdate;
  delete from temp_table;
  delete from temp_dynamic_warehouse;
  delete from temp_dynamic_data;
  commit;
  /*迭代仓库向临时表中插数据*/
  insert into temp_dynamic_warehouse(col_warehouse_id)
  select t.id
    from t_warehouse_define t
    left join t_warehouse_category ware_cate
      on t.category_id = ware_cate.id
   where t.status = 1
     and ware_cate.code = '01'
     and ware_cate.status = 1
   start with t.id = warehouse_id
  connect by prior t.id = t.parent_warehouse_id;
  delete from temp_dynamic_warehouse where col_warehouse_id
  not in (
      select distinct (b.id) id
      from (select distinct twd.id, twd.parent_warehouse_id,twd.warehouse_define_code
      from t_warehouse_define twd,
      t_warehouse_category twc,
      t_warehouse_access twa,
      t_lis_user_role    tlr
      where twd.status = 1
      and twd.category_id = twc.id
      and twc.code = '01'
      and twd.id = twa.warehouse_define_id
      and twa.role_id = tlr.role_id
      and tlr.ou_employee_number = ouEmployeeNumber
      and twd.mis_ou_id = ouId
      and twd.mis_subinventoey_id is not null) a
      join t_warehouse_define b
      on (a.parent_warehouse_id = b.id or a.id = b.id) );
  /*向临时表中插入（出库）数据*/
  --（1）当天领用出库            hejin
  insert into temp_table(col_item_id,col_count,col_type,col_warehouse_id)
  select notmk.item_id,(case when sum(notmk.asgn_quty) is null then 0 else sum(notmk.asgn_quty) end),1,notmk.source_warehouse_id
  from t_out_ln outln, t_out_hd outhd,t_out_notmk notmk
  where outln.outhdinfo_id = outhd.id
  and notmk.ord_ln_id = outln.id
  and outln.status = 1
  and outhd.status = 1
  and notmk.status = 1
  and (outln.ord_ln_status = 5 or outln.ord_ln_status = 6 or outln.ord_ln_status = 7)
  and exists (select 1 from temp_dynamic_warehouse where notmk.source_warehouse_id = col_warehouse_id)
  and notmk.acpt_cfm_date between trunc(v_date) and v_date
  group by notmk.source_warehouse_id,notmk.item_id;

  --（2）调库（当天调出）         yangwei
  --需要判断的条件，行信息头id=行id、头信息状态=5（结束）、指定的调出仓库和物料、规定的时间内
  insert into temp_table(col_item_id,col_count,col_type,col_warehouse_id)
  select chglnout.item_id,(case when sum(chglnout.change_quty) is null then 0 else sum(chglnout.change_quty) end),1,chglnout.wh_id_trf_from
  from t_chg_hd_ln chghdout,t_chg_ln chglnout
  where chghdout.id=chglnout.chghdln_id
  and chghdout.status = 1
  and chglnout.status = 1
  and (chghdout.order_status='5' or chghdout.RECEIPT_DATE is not null)
  and exists (select 1 from temp_dynamic_warehouse where chglnout.wh_id_trf_from = col_warehouse_id)
  and chghdout.fact_created_date between trunc(v_date) and v_date
  group by chglnout.wh_id_trf_from,chglnout.item_id;

  --（3）退货         duanyang
  insert into temp_table(col_item_id,col_count,col_type,col_warehouse_id)
  select q.item_id, (case when sum(d.return_quantity) is null then 0 else sum(d.return_quantity) end),1,q.warehouse_define_id
  from t_returnorder_headerinfo h,
       t_returnorder_line_detail d,
       t_returnorder_lineinfo l,
       t_wh_current_onhand_quantity q
  where h.id=d.return_order_id
  and d.line_id=l.id and l.inventory_type <> 'EXPENSE'
  and h.status=1
  and d.status=1
  and d.onhand_id=q.id
  and h.order_status=4
  and exists (select 1 from temp_dynamic_warehouse where q.warehouse_define_id = col_warehouse_id)
  and l.return_confirm_date between trunc(v_date) and v_date
  group by q.warehouse_define_id,q.item_id;

  /*向临时表中插入（入库）数据*/
  --（1）当天退库                zhanglinlin
  insert into temp_table(col_item_id,col_count,col_type,col_warehouse_id)
  select bckln.itemid,(case when sum(bckln.backquantity) is null then 0 else sum(bckln.backquantity) end),2,bckln.warehousebacktoid
  from t_bck_hd bckhd,t_bck_ln bckln
  where bckln.bckhdinfo_id = bckhd.id
  and bckln.status = 1
  and bckhd.status = 1
  and (bckhd.orderstatus = 50 or bckhd.orderstatus = 60)
  and (bckln.line_status_id = 40 or bckln.line_status_id = 50 or bckln.line_status_id = 60)
  and exists (select 1 from temp_dynamic_warehouse where to_char(bckln.warehousebacktoid) = col_warehouse_id)
  and bckhd.warereceiver_date between trunc(v_date) and v_date
  group by bckln.warehousebacktoid,bckln.itemid;


  --（2）调库（当天调入）             yangwei
  --需要判断的条件，行信息头id=行id、头信息状态=5（结束）、指定的调入仓库和物料、规定的时间内
  insert into temp_table(col_item_id,col_count,col_type,col_warehouse_id)
  select chglnin.item_id,(case when sum(chglnin.change_quty) is null then 0 else sum(chglnin.change_quty) end),2,chglnin.wh_id_trf_into
  from t_chg_hd_ln chghdin,t_chg_ln chglnin
  where chghdin.id=chglnin.chghdln_id
  and chghdin.status = 1
  and chglnin.status = 1
  and (chghdin.order_status='5' or chghdin.RECEIPT_DATE is not null)
  and exists (select 1 from temp_dynamic_warehouse where chglnin.wh_id_trf_into = col_warehouse_id)
  and chghdin.fact_created_date between trunc(v_date) and v_date
  group by chglnin.wh_id_trf_into,chglnin.item_id;

  --（3）当天接收入库                 duanyang
  insert into temp_table(col_item_id,col_count,col_type,col_warehouse_id)
  select receln.item_id,(case when sum(receln.current_receive_quantity) is null then 0 else sum(receln.current_receive_quantity) end),2,receln.warehouse_receive_id
  from t_receiptorder_lineinfo receln,t_receiptorder_headerinfo recehd,t_base_spm_pur_order_lines l
  where recehd.id = receln.receipt_order_id and l.spm_po_line_id=receln.spm_po_line_id and l.inventory_type <> 'EXPENSE'
  and recehd.status = 1
  and receln.status = 1
  and receln.receipt_order_line_sid > 0
  and exists (select 1 from temp_dynamic_warehouse where receln.warehouse_receive_id = col_warehouse_id)
  and receln.receipt_confirm_date between trunc(v_date) and v_date
  group by receln.warehouse_receive_id,receln.item_id;

  /**把临时表中的数据行转列插入到持久化数据的表中*/
  insert into temp_dynamic_data
  (item_id, warehouse_define_id, in_quantity, out_quantity)
  select t1.col_item_id,
  t1.col_warehouse_id,
  sum(decode(t1.col_type, '2', t1.col_count,0)) as in_num,
  sum(decode(t1.col_type, '1', t1.col_count,0)) as out_num
  from TEMP_TABLE t1
  group by t1.col_warehouse_id,t1.col_item_id;

  update temp_dynamic_data dyc_data
     set (warehouse_define_name) =
         (select warehouse_define_code || '|' || warehouse_define_name
            from t_warehouse_define ware_de
           where ware_de.id = dyc_data.warehouse_define_id);
  update temp_dynamic_data dc_data
     set (item_code,
          item_desc,
          uom_desc,
          erp_type) =
          (select item_code,
                  item_name,
                  uom_code,
                  erp_type
              from t_sys_erp_items item
              where item.seq_id = dc_data.item_id);
  /**把持久化数据的数据和现有量表的数据通过item_id(新的ID：SEQ_ID)关联去修改持久化数据表中的数据*/
  update temp_dynamic_data dc_data
     set (product_code,
          product_desc,
          onhand_quantity) =
         (select max(onhand.product_code) product_code,
                 max(onhand.product_desc) product_desc,
                 sum(onhand.onhand_quantity) onhand_quantity
            from t_wh_current_onhand_quantity onhand
           where onhand.warehouse_define_id = dc_data.warehouse_define_id
             and onhand.item_id = dc_data.item_id
             and onhand.status = '1');
  --返回分页结果集
  if flag='query' then
    open dynamic_checking for select item_id,
                                     item_code,
                                     item_desc,
                                     product_code,
                                     product_desc,
                                     warehouse_define_id,
                                     warehouse_define_name,
                                     in_quantity,
                                     out_quantity,
                                     onhand_quantity,
                                     erp_type,
                                     uom_desc
                                from (select rownum rnum,
                                             item_id,
                                             item_code,
                                             item_desc,
                                             product_code,
                                             product_desc,
                                             warehouse_define_id,
                                             warehouse_define_name,
                                             in_quantity,
                                             out_quantity,
                                             onhand_quantity,
                                             erp_type,
                                             uom_desc
                                        from temp_dynamic_data order by warehouse_define_id,item_id)
                               where rnum <= pagenum*pagesize
                               and rnum > (pagenum-1)*pagesize;
  else
    open dynamic_checking for select item_id, item_code, item_desc, product_code, product_desc, warehouse_define_id, warehouse_define_name, in_quantity, out_quantity, onhand_quantity, erp_type, uom_desc from temp_dynamic_data order by warehouse_define_id,item_id;
  end if;

  --返回查询结果的总数
  select count(*) into total from temp_dynamic_data;
  commit;
  EXCEPTION
  WHEN others THEN
  rollback;
  total := -1;
  v_ErrorCode := SQLCODE;
  v_ErrorText := SUBSTR(SQLERRM, 1, 200);
  insert into I_ERP_LOGS (SEQ_ID,create_date,exceptions) values (I_ERP_LOGS_seq.nextval,sysdate,'proc_dynamic_checking:异常信息[code]:'||v_ErrorCode||',[message]:'||v_ErrorText);
  commit;
end proc_dynamic_checking;
end dynamic_checking_pkg;
/

