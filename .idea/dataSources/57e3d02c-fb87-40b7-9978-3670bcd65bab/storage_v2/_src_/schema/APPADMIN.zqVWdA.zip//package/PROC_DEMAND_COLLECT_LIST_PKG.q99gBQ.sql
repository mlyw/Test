create package proc_demand_collect_list_pkg is
   type cur_proc_demand_collect_list is ref cursor;
   procedure proc_demand_collect_list(erpTypeVO in varchar2,pageno in number,pagesize in number,taskcode in varchar2,taskfounder in varchar2,supplymode in varchar2,materialcode in varchar2,materialdesc in varchar2,flag in varchar2,
       temp_list out cur_proc_demand_collect_list,total out number);
end proc_demand_collect_list_pkg;
/

