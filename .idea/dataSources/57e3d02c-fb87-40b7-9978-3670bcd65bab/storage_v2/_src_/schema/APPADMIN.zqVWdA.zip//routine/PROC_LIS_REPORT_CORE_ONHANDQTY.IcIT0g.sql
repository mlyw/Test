create PROCEDURE proc_lis_report_core_onhandqty
AS
  exception_info VARCHAR2(3000);
BEGIN
  ----写入期初数据
  INSERT INTO T_LIS_REPORT_CORE_ONHANDQTY
  SELECT sysdate computedate,
    TO_CHAR(sysdate,'yyyyMM') bussinessdate,
    '',
    1,
    q.item_code,
    q.item_desc item_name,
    q.item_id,
    q.uom_code,
    q.uom_desc,
    i.concatenated_segments,
    i.category_description,
    q.warehouse_define_id,
    w.mis_ou_id ou_id,
    q.erp_type,
    w.mis_io_id organization_id,
    SUM(NVL(q.onhand_quantity,0)) onhandQuantity,
    SUM(NVL(q.onhand_quantity,0)*NVL(q.Cost_Unit_Price,0)) onhandAccount,
    1,
    NULL
  FROM t_wh_current_onhand_quantity q,
    mv_warehouse_define w,
    t_sys_erp_items i
  WHERE q.status              =1
  AND w.status                =1
  AND i.status                =1
  AND q.warehouse_define_id   =w.id
  AND q.item_id               =i.seq_id
  AND NVL(q.onhand_quantity,0)>0
  GROUP BY w.mis_ou_id,
    w.mis_io_id,
    q.warehouse_define_id,
    i.concatenated_segments,
    i.category_description,
    q.item_id,
    q.item_code,
    q.item_desc,
    q.uom_code,
    q.uom_desc,
    q.erp_type;
  COMMIT;
  ----写入期末数据
  INSERT INTO T_LIS_REPORT_CORE_ONHANDQTY
  SELECT sysdate computedate,
    TO_CHAR((sysdate-1),'yyyyMM') bussinessdate,
    '',
    1,
    q.item_code,
    q.item_desc item_name,
    q.item_id,
    q.uom_code,
    q.uom_desc,
    i.concatenated_segments,
    i.category_description,
    q.warehouse_define_id,
    w.mis_ou_id ou_id,
    q.erp_type,
    w.mis_io_id organization_id,
    SUM(NVL(q.onhand_quantity,0)) onhandQuantity,
    SUM(NVL(q.onhand_quantity,0)*NVL(q.Cost_Unit_Price,0)) onhandAccount,
    2,
    NULL
  FROM t_wh_current_onhand_quantity q,
    mv_warehouse_define w,
    t_sys_erp_items i
  WHERE q.status              =1
  AND w.status                =1
  AND i.status                =1
  AND q.warehouse_define_id   =w.id
  AND q.item_id               =i.seq_id
  AND NVL(q.onhand_quantity,0)>0
  GROUP BY w.mis_ou_id,
    w.mis_io_id,
    q.warehouse_define_id,
    i.concatenated_segments,
    i.category_description,
    q.item_id,
    q.item_code,
    q.item_desc,
    q.uom_code,
    q.uom_desc,
    q.erp_type;
  COMMIT;
  ---写入期初期末的现有量快照
  insert into t_lis_core_onhandqty_all
    (id, created_date, created_user, date_value1, last_updated_date, last_updated_user, number_value1, status, string_value1, version, consigned, item_category_code, item_category_desc, item_category_id, item_code, item_desc, item_id, mis_pic_code, product_category_code, product_category_desc, product_category_id, product_code, product_desc, product_id, project_id, receipt_pic_code, testing_status, uom_code, uom_desc, warehouse_define_id, project_number, project_name, product_unit_price_ex_tax, product_unit_price, vendor_id, locator_id, locator_code, erp_type, product_tax_rate, onhand_quantity, epm_task_code, epm_task_name, is_item_package, item_package_id, is_fittings, project_no, sub_project_seq_id, sub_project_no, sub_project_person, sub_project_person_name,Cost_Unit_Price, bulid_date) 
  select id, created_date, created_user, date_value1, last_updated_date, last_updated_user, number_value1, status, string_value1, version, consigned, item_category_code, item_category_desc, item_category_id, item_code, item_desc, item_id, mis_pic_code, product_category_code, product_category_desc, product_category_id, product_code, product_desc, product_id, project_id, receipt_pic_code, testing_status, uom_code, uom_desc, warehouse_define_id, project_number, project_name, product_unit_price_ex_tax, product_unit_price, vendor_id, locator_id, locator_code, erp_type, product_tax_rate, onhand_quantity, epm_task_code, epm_task_name, is_item_package, item_package_id, is_fittings, project_no, sub_project_seq_id, sub_project_no, sub_project_person, sub_project_person_name,Cost_Unit_Price,sysdate from t_wh_current_onhand_quantity;
  commit;
  --插入日志
  INSERT
  INTO i_erp_logs VALUES
    (
      i_erp_logs_seq.nextval,
      0,
      0,
      sysdate,
      '期初期末执行成功',
      'T_LIS_REPORT_CORE_ONHANDQTY'
    );
EXCEPTION
WHEN OTHERS THEN
  exception_info := 'ERR: An error occurred with info:'||TO_CHAR(SQLCODE)||' '||sqlerrm;
  INSERT
  INTO i_erp_logs VALUES
    (
      i_erp_logs_seq.nextval,
      0,0,
      sysdate,
      exception_info,
      'T_LIS_REPORT_CORE_ONHANDQTY'
    );
  COMMIT;
END proc_lis_report_core_onhandqty;
/

