create trigger WH_QUANTITY_DATE_VALUE1
  before insert or update
  on T_WH_CURRENT_ONHAND_QUANTITY
  for each row
  BEGIN
     :new.date_value1 := to_TIMESTAMP(to_char(:new.created_date,'yyyy-mm-dd'),'yyyy-mm-dd');
END;
/

