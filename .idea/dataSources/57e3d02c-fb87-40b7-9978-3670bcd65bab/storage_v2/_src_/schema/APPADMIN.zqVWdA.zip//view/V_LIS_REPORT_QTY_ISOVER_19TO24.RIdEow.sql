create view V_LIS_REPORT_QTY_ISOVER_19TO24 as
  SELECT
    /**以物料及单位为维度的19-24个月呆滞物资的呆滞金额视图*/
    rca.ou_id,
    rca.organization_id,
    rca.warehouse_define_id,
    rca.item_category_code,
    rca.item_category_name,
    rca.item_id,
    rca.item_code,
    rca.item_desc,
    rca.item_uom_code,
    rca.item_uom_desc,
    SUM(rca.item_account) over_19to24_account
  FROM t_lis_report_core_ageinfo rca
  WHERE rca.age_19to24       =1
  GROUP BY rca.ou_id,
    rca.organization_id,
    rca.organization_code,
    rca.organization_name,
    rca.warehouse_define_id,
    rca.warehouse_define_code,
    rca.warehouse_define_desc,
    rca.item_category_code,
    rca.item_category_name,
    rca.item_id,
    rca.item_code,
    rca.item_desc,
    rca.item_uom_code,
    rca.item_uom_desc
/

