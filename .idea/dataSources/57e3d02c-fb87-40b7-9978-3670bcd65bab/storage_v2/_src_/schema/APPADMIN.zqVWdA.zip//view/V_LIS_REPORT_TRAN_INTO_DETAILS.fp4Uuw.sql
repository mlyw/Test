create view V_LIS_REPORT_TRAN_INTO_DETAILS as
  SELECT receivetmp.accounting_confirm_date import_date,
    receivetmp.id order_id,
    receivetmp.item_code,
    receivetmp.item_id,
    receivetmp.item_desc,
    receivetmp.uom_code,
    receivetmp.uom_desc,
    receivetmp.warehouse_receive_id,
    receivetmp.order_type,
    receivetmp.ordercomtent,
    NVL(receivetmp.current_receive_quantity,0) current_receive_quantity,
    (NVL(receivetmp.product_unit_price,0)*NVL(receivetmp.current_receive_quantity,0)) current_receive_account,
    s.project_code,
    ac.employee_name liaozhang_name,
    re.employee_name shiwu_name,
    NULL company,
    NULL hall
  FROM
    (SELECT rh.id,
      rl.item_id,
      rl.item_code,
      rl.item_desc,
      rl.uom_code,
      rl.uom_desc,
      rl.warehouse_receive_id,
      '接收入库' order_type,
      rl.project_id,
      rl.accounting_confirm_by_uid,---料帐人
      rl.receipt_confirm_by_uid,   ---实物管理员
      'MIS采购订单号:'
      || sh.mis_po_number
      || '接收入库' ordercomtent,
      rl.accounting_confirm_date,
      NVL(rl.product_unit_price,0) product_unit_price,
      NVL(rl.current_receive_quantity,0) current_receive_quantity
    FROM t_receiptorder_headerinfo rh,
      t_base_spm_pur_order_headers sh,
      t_receiptorder_lineinfo rl
    WHERE rl.status                                     =1
    AND rl.status                                       =1
    AND rh.order_status                                 =5
    AND rl.receipt_order_line_sid                       =2
    AND rl.receipt_order_id                             =rh.id
    AND rh.po_id                                        =sh.spm_po_header_id
    AND TO_CHAR(rl.accounting_confirm_date,'yyyy-MM-dd')>'2016-12-31'
    ) receivetmp
  LEFT JOIN t_sys_erp_projects s
  ON receivetmp.project_id=s.seq_id
  LEFT JOIN MV_T_LIS_OUUSER ac
  ON receivetmp.accounting_confirm_by_uid=ac.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER re
  ON receivetmp.receipt_confirm_by_uid=re.ou_employee_number
  UNION ALL
  ----rm销售数据
  SELECT rs.transcation_date import_date,
    rs.seq_id order_id,
    rs.item_code,
    rs.item_id,
    i.item_name item_desc,
    i.uom_code,
    i.uom_desc,
    d.id warehouse_receive_id,
    '有价卡销售回退' order_type,
    'RM系统导入有价卡销售回退' ordercomtent,
    NVL(ABS(NVL(rs.quantity,0)),0) current_receive_quantity,
    0*NVL(ABS(NVL(rs.quantity,0)),0) current_receive_account,
    NULL project_code,
    NULL liaozhang_name,------料帐人
    NULL shiwu_name,    ------实物管理员
    d.hall_dept_name company,
    (d.warehouse_define_code
    ||' '
    ||d.warehouse_define_name) hall
  FROM t_lis_rm_sales rs
  LEFT JOIN t_sys_erp_items i
  ON rs.item_id=i.seq_id
  LEFT JOIN MV_sys_shm_hall d
  ON rs.subinventory_code                      =d.warehouse_define_code
  WHERE NVL(rs.quantity,0)                     <0
  AND TO_CHAR(rs.transcation_date,'yyyy-MM-dd')>'2016-12-31'
  AND NVL(rs.flag,'')                          ='Y'
  UNION ALL
  ----SIM卡销售月结-回退数
  SELECT tmp.transaction_processing_time import_date,
    tmp.id order_id,
    i.item_code,
    tmp.item_id,
    i.item_name item_desc,
    i.uom_code,
    i.uom_desc,
    tmp.wd_id warehouse_receive_id,
    tmp.order_type order_type,
    tmp.order_type ordercomtent,
    tmp.simcard_qty current_receive_quantity,
    0*NVL(tmp.simcard_qty,0) current_receive_account,
    NULL project_code,
    l.employee_name liaozhang_name,
    s.employee_name shiwu_name,
    d.hall_dept_name company,
    (d.warehouse_define_code
    ||' '
    ||d.warehouse_define_name) hall
  FROM
    (SELECT sl.item_id,
      sl.wd_id,
      ABS(sl.simcard_qty) simcard_qty,
      sh.transaction_processing_time,
      sh.id,
      'SIM卡销售回退' order_type,
      sh.created_user shiwu,
      sl.last_updated_user liaozhang
    FROM T_Lis_Simcard_Sales_Month_Head sh,
      T_Lis_Simcard_Sales_Month_Line sl
    WHERE sl.status                                         =1
    AND sh.status                                           =1
    AND sl.head_id                                          =sh.id
    AND sh.head_status                                      =4
    AND sl.line_status                                      =4
    AND TO_CHAR(sh.transaction_processing_time,'yyyy-MM-dd')>'2016-12-31'
    AND NVL(sl.simcard_qty,0)                               <0
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN MV_sys_shm_hall d
  ON tmp.wd_id=d.id
  LEFT JOIN MV_T_LIS_OUUSER l
  ON tmp.liaozhang=l.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER s
  ON tmp.shiwu=s.ou_employee_number
  UNION ALL
  ----工程退库/工程杂收
  SELECT tmp.acc_cfm_date import_date,
    tmp.id order_id,
    tmp.item_code,
    tmp.itemid item_id,
    tmp.item_name item_desc,
    i.uom_code,
    tmp.unit uom_desc,
    tmp.warehousebacktoid warehouse_receive_id,
    tmp.order_type order_type,
    tmp.back_order_desc ordercomtent,
    tmp.acpt_cfm_quty current_receive_quantity,
    NVL(tmp.prouintprice,0)*NVL(tmp.acpt_cfm_quty,0) current_receive_account,
    p.project_code project_code,
    l.employee_name liaozhang_name,
    s.employee_name shiwu_name,
    NULL company,
    NULL hall
  FROM
    (SELECT bl.item_name,
      bl.itemid,
      bl.item_code,
      bl.unit,
      bl.warehousebacktoid,
      bl.acpt_cfm_quty,
      bl.prouintprice,
      bl.acc_cfm_date,
      bh.id,
      CASE
        WHEN bh.backtypeid=5
        THEN '杂收'
        ELSE '退库'
      END AS order_type,
      bl.acccfm_by_userid liaozhang,
      bl.acpt_cfm_byid shiwu,
      bh.projectid,
      bh.back_order_desc
    FROM t_bck_hd bh,
      t_bck_ln bl
    WHERE bh.status                          =1
    AND bl.status                            =1
    AND bh.orderstatus                       =60
    AND bh.backtypeid                       IN (1,5)
    AND bl.backorderid                       =bh.id
    AND TO_CHAR(bl.acc_cfm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.itemid=i.seq_id
  LEFT JOIN t_sys_erp_projects p
  ON tmp.projectid=p.seq_id
  LEFT JOIN MV_T_LIS_OUUSER l
  ON tmp.liaozhang=l.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER s
  ON tmp.shiwu=s.ou_employee_number
  UNION ALL
  ---综合调增/综合退库
  SELECT tmp.acc_cfm_date import_date,
    tmp.id order_id,
    tmp.item_code,
    tmp.itemid item_id,
    tmp.item_name item_desc,
    i.uom_code,
    tmp.unit uom_desc,
    tmp.warehousebacktoid warehouse_receive_id,
    tmp.order_type order_type,
    tmp.back_order_desc ordercomtent,
    tmp.backquantity current_receive_quantity,
    NVL(tmp.prouintprice,0)*NVL(tmp.backquantity,0) current_receive_account,
    p.project_code project_code,
    l.employee_name liaozhang_name,
    s.employee_name shiwu_name,
    NULL company,
    NULL hall
  FROM
    (SELECT bl.item_name,
      bl.itemid,
      bl.item_code,
      bl.unit,
      bl.warehousebacktoid,
      bl.backquantity,
      bl.prouintprice,
      bl.acc_cfm_date,
      bh.id,
      CASE
        WHEN bh.backtypeid=86
        THEN '杂收'
        ELSE '退库'
      END AS order_type,
      bl.acccfm_by_userid liaozhang,
      bl.acpt_cfm_byid shiwu,
      bh.projectid,
      bh.back_order_desc
    FROM t_bck_hd bh,
      t_bck_ln bl
    WHERE bh.status                          =1
    AND bl.status                            =1
    AND bh.orderstatus                       =60
    AND bh.backtypeid                       IN (84,86)
    AND bl.backorderid                       =bh.id
    AND TO_CHAR(bl.acc_cfm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.itemid=i.seq_id
  LEFT JOIN t_sys_erp_projects p
  ON tmp.projectid=p.seq_id
  LEFT JOIN MV_T_LIS_OUUSER l
  ON tmp.liaozhang=l.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER s
  ON tmp.shiwu=s.ou_employee_number
  UNION ALL
  ---调拨-调入方
  ----工程物资调拨
  SELECT tmp.account_date import_date,
    tmp.id order_id,
    tmp.item_code,
    tmp.item_id,
    tmp.item_desc ,
    tmp.uom_code,
    tmp.uom_desc,
    tmp.wh_id_trf_into warehouse_receive_id,
    tmp.order_type order_type,
    tmp.wh_chg_desc ordercomtent,
    tmp.change_quty current_receive_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.change_quty,0) current_receive_account,
    p.project_code,
    l.employee_name liaozhang_name,
    s.employee_name shiwu_name,
    d.hall_dept_name company,
    (d.warehouse_define_code
    ||' '
    ||d.warehouse_define_name) hall
  FROM
    (SELECT hl.item_id,
      hl.item_code,
      hl.item_desc,
      hl.uom_desc,
      hl.uom_code,
      hl.wh_id_trf_into,
      NVL(hl.product_unit_price,0) product_unit_price,
      hl.change_quty,
      hd.account_date,
      hd.id,
      hl.prj_id_trf_into,
      '调拨' order_type,
      hd.wh_chg_desc,
      hl.acc_cfm_byuser_id liaozhang,
      hd.ware_receipt_user shiwu
    FROM t_chg_hd_ln hd,
      t_chg_ln hl
    WHERE hd.status                          =1
    AND hl.status                            =1
    AND hd.order_status                     IN (5,50)
    AND hl.chghdln_id                        =hd.id
    AND TO_CHAR(hd.account_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN MV_sys_shm_hall d
  ON tmp.wh_id_trf_into=d.id
  LEFT JOIN t_sys_erp_projects p
  ON tmp.prj_id_trf_into=p.seq_id
  LEFT JOIN MV_T_LIS_OUUSER l
  ON tmp.liaozhang=l.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER s
  ON tmp.shiwu=s.ou_employee_number
  UNION ALL
  ---报废卡退库 c999是接收入库
  SELECT tmp.accounted_date import_date,
    tmp.seq_id order_id,
    i.item_code,
    tmp.item_id,
    i.item_name item_desc,
    i.uom_code,
    i.uom_desc,
    tmp.receive_wd_id warehouse_receive_id,
    tmp.order_type order_type,
    tmp.order_desc ordercomtent,
    tmp.actual_qty current_receive_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.actual_qty,0) current_receive_account,
    NULL project_code,
    l.employee_name liaozhang_name,
    s.employee_name shiwu_name,
    NULL company,
    NULL hall
  FROM
    (SELECT rwl.item_id,
      rwl.receive_wd_id,
      0 product_unit_price,
      rwl.actual_qty,
      rwl.accounted_date,
      rwh.order_desc,
      rwh.seq_id,
      '报废卡退库' order_type,
      rwl.receive_confirm_user,
      rwl.accounted_user
    FROM t_refundwastecard_head rwh,
      t_refundwastecard_line rwl
    WHERE rwh.status                            =1
    AND rwl.status                              =1
    AND rwh.order_status                        =7
    AND rwl.order_line_status                   =7
    AND TO_CHAR(rwl.accounted_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN MV_T_LIS_OUUSER l
  ON tmp.accounted_user=l.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER s
  ON tmp.receive_confirm_user=s.ou_employee_number
  UNION ALL
  -----cnp出库时从C001出到具体的营业厅 具体营业厅的数据当做营业厅的入库数据??营业厅条件放哪方，人员
  SELECT tmp.acc_cfm_date import_date,
    tmp.id order_id,
    tmp.item_code,
    tmp.item_id,
    i.item_name item_desc,
    i.uom_code,
    i.uom_desc,
    d.id warehouse_receive_id,
    tmp.order_type,
    NULL ordercomtent,
    tmp.Acpt_Cfm_Quty current_receive_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.Acpt_Cfm_Quty,0) current_receive_account,
    NULL project_code,
    l.employee_name liaozhang_name,
    s.employee_name shiwu_name,
    d.hall_dept_name company,
    (d.warehouse_define_code
    ||' '
    ||d.warehouse_define_name) hall
  FROM
    (SELECT m.item_id,
      m.item_code,
      l.to_subinventory_code,
      m.product_unit_price,
      m.Acpt_Cfm_Quty,
      m.acc_cfm_date,
      h.id,
      '大库调入' order_type， m.acc_cfm_byuser_id,
      m.acpt_cfm_byuser_id
    FROM t_out_hd h,
      t_out_ln l,
      t_out_notmk m
    WHERE h.status                          =1
    AND l.status                            =1
    AND m.status                            =1
    AND h.ord_status                        =6
    AND l.ord_ln_status                     =7
    AND m.asgn_ln_status                    =1
    AND m.outlninfo_id                      =l.id
    AND l.outhdinfo_id                      =h.id
    AND l.to_subinventory_code             IS NOT NULL
    AND TO_CHAR(m.acc_cfm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN MV_sys_shm_hall d
  ON tmp.to_subinventory_code=d.warehouse_define_code
  LEFT JOIN MV_T_LIS_OUUSER l
  ON tmp.acc_cfm_byuser_id=l.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER s
  ON tmp.acpt_cfm_byuser_id=s.ou_employee_number
/

