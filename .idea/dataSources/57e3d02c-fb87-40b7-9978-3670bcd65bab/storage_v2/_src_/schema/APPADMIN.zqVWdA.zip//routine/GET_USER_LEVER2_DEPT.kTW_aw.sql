create function get_user_lever2_dept(v_ouEmployeeNumber varchar2)
return number is deptId number(16);
begin
    --查询员工的二级部门
    select id into deptId  from t_lis_dept where status=1 and Parent_Id=251
    start with id=(select ou.ou_dept_id from t_lis_ouuser ou where ou.ou_employee_number=v_ouEmployeeNumber and ou.status=1)
    connect by prior parent_id=id;
   
    --返回员工的二级部门
    return deptId;
end;
/

