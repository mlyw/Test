create PROCEDURE PROC_IF_QUOTA_ENOUGH (deptId      in number,
                                                 itemType    in varchar2,
                                                 itemId      in number,
                                                 quantity    in number,
                                                 careatDate  in date,
                                                 ifPic       in number,
                                                 flag        out number,
                                                 errorInfo   out varchar2,
                                                 result_info out sys_refcursor) as
  v_record_count        number(19);
  v_total_quantity      number(19, 5);
  v_item_code           varchar2(30);
  v_temp_quantity       number(19, 5);
  v_total_in_qunaity    number(19, 5);
  v_quota_control_type  number(5);
  v_temp_quota_total    number(19, 5);
  v_quota_start_date    date;
  v_quota_end_date      date;
  v_quota_temp_quantity number(19, 5);
  type r_quota_info is ref cursor return temp_quota_if_enough%rowtype;
  c_all_quota_info r_quota_info;
  v_all_quota_info c_all_quota_info%rowtype;
  E_QUANTITY_NOT_ENOUGH exception;
begin
 delete from TEMP_quota_if_enough;
  v_temp_quantity := quantity;
  if ifPic = 1 then
     
    insert into TEMP_quota_if_enough
      (detail_id, Quantity, Quota_Type)
      select d.id,
             d.available_quantity - nvl((select sum(qr.quota_quantity)  from t_lis_recipient_quota_reserve qr where qr.status=1 and qr.quota_detail_id=d.id), 0),
             h.quota_type
        from t_lis_recipient_quota_line l
        join t_lis_recipient_quota_header h
          on l.header_id = h.id
         and h.order_status = 2 and h.quota_type='batch_type'
        join t_lis_delivery_notice_line dl
          on dl.id = l.delivery_notice_line_id
         and dl.item_id = itemId
        join t_lis_recipient_quota_detail d
          on l.id = d.line_id
         and d.dept_id = get_user_lever2_dept_by_id(deptId)--修改为申领人的二级部门
       where l.status = 1
         and h.status = 1
         and dl.status = 1
         and dl.item_type_code = lower(itemType)
         and d.status = 1;
    -- 按批次查询配额时，有效期不做限制，yangwl 2015/5/28
    --    and h.start_date <= careatDate
    --    and h.end_date >=  careatDate;
 end if;
 
  if ifPic = 1 then  --按批次不需要有效期限制
    insert into TEMP_quota_if_enough
    (detail_id, Quantity, Quota_Type)
    SELECT d.ID,
           d.available_quantity - nvl((select sum(qr.quota_quantity)  from t_lis_recipient_quota_reserve qr where qr.status=1 and qr.quota_detail_id=d.id), 0),
           h.quota_type
      from t_lis_recipient_quota_detail d
      join t_lis_recipient_quota_header h
        on d.header_id = h.id and h.quota_type='batch_type' --区分按批次
       and h.order_status = 2
      join t_lis_recipient_quota_line l
        on d.line_id = l.id
       and l.item_type = lower(itemType)
       and l.item_dimension = 'item_code'
       and l.item_dimension_id = itemId
     where d.status = 1
       and h.status = 1
       and l.status = 1
       AND d.dept_id = get_user_lever2_dept_by_id(deptId)--修改为申领人的二级部门
 union all
    select d.id,
           d.available_quantity - nvl((select sum(qr.quota_quantity)  from t_lis_recipient_quota_reserve qr where qr.status=1 and qr.quota_detail_id=d.id), 0),
           h.quota_type
      from t_lis_recipient_quota_detail d
      join t_lis_recipient_quota_header h
        on d.header_id = h.id and h.quota_type='batch_type'
      join t_lis_recipient_quota_line l
        on d.line_id = l.id
       and l.item_type = lower(itemType)
       and l.item_dimension = 'item_group'
      join t_lis_itemgroup_head gh
        on l.item_dimension_id = gh.id
       and exists (select 1
              from t_lis_itemgroup_line gl
             where gl.item_group_headid = gh.id
               and gl.status = 1
               and gl.item_id = itemId)
     where d.status = 1
       and h.status = 1
       and l.status = 1
       and d.dept_id = get_user_lever2_dept_by_id(deptId);--修改为申领人的二级部门
  else --按总量需要有效期限制
      insert into TEMP_quota_if_enough
    (detail_id, Quantity, Quota_Type)
    SELECT d.ID,
           d.available_quantity - nvl((select sum(qr.quota_quantity)  from t_lis_recipient_quota_reserve qr where qr.status=1 and qr.quota_detail_id=d.id), 0),
           h.quota_type
      from t_lis_recipient_quota_detail d
      join t_lis_recipient_quota_header h
        on d.header_id = h.id and h.quota_type='total_type'--区分按总量
       and h.order_status = 2
      join t_lis_recipient_quota_line l
        on d.line_id = l.id
       and l.item_type = lower(itemType)
       and l.item_dimension = 'item_code'
       and l.item_dimension_id = itemId
     where d.status = 1
       and h.status = 1
       and l.status = 1
       AND d.dept_id = get_user_lever2_dept_by_id(deptId)--修改为申领人的二级部门
       and careatDate between h.start_date and h.end_date
 union all
    select d.id,
           d.available_quantity - nvl((select sum(qr.quota_quantity)  from t_lis_recipient_quota_reserve qr where qr.status=1 and qr.quota_detail_id=d.id), 0),
           h.quota_type
      from t_lis_recipient_quota_detail d
      join t_lis_recipient_quota_header h
        on d.header_id = h.id and h.quota_type='total_type'
      join t_lis_recipient_quota_line l
        on d.line_id = l.id
       and l.item_type = lower(itemType)
       and l.item_dimension = 'item_group'
      join t_lis_itemgroup_head gh
        on l.item_dimension_id = gh.id
       and exists (select 1
              from t_lis_itemgroup_line gl
             where gl.item_group_headid = gh.id
               and gl.status = 1
               and gl.item_id = itemId)
     where d.status = 1
       and h.status = 1
       and l.status = 1
       and d.dept_id = get_user_lever2_dept_by_id(deptId)--修改为申领人的二级部门
       and careatDate between h.start_date and h.end_date;
  end if;
  select count(*) into v_record_count from temp_quota_if_enough;

  if v_record_count = 0 then
    flag := 0; --该物料没有配额
  else
    flag := 1;
  end if;
  if v_record_count > 0 then
    select item.item_code into v_item_code from t_sys_erp_items item where item.seq_id = itemId and item.status = 1;
    select count(*) into v_record_count from temp_quota_if_enough tq where tq.quota_type = 'batch_type';
    if ifPic = 1 and v_record_count >0 then
      select sum(tq.quantity) into v_total_quantity from temp_quota_if_enough tq where tq.quota_type = 'batch_type'
       group by tq.quota_type;
        
      if v_total_quantity < v_temp_quantity then
        errorInfo := v_item_code || '配额已不足,申请数量为:' || quantity || '可用配额为:' ||v_total_quantity||'请按照配额领用,如果需要超配额领用,请联系相关调度员!';
        raise E_QUANTITY_NOT_ENOUGH;
      end if;
      if v_total_quantity >= v_temp_quantity then
        open c_all_quota_info for
          select tq.detail_id, tq.quantity, tq.quota_type, tq.if_use from temp_quota_if_enough tq where tq.quota_type = 'batch_type'
           order by quantity desc;
        loop
          fetch c_all_quota_info into v_all_quota_info;
          exit when c_all_quota_info%notfound;
          exit when v_temp_quantity = 0;
          if v_all_quota_info.quantity >= v_temp_quantity then
            update temp_quota_if_enough utq set utq.if_use = 1 where utq.detail_id = v_all_quota_info.detail_id;
            v_temp_quantity := 0;
          else
            update temp_quota_if_enough utq set utq.if_use = 1 where utq.detail_id = v_all_quota_info.detail_id;
            v_temp_quantity := v_temp_quantity - v_all_quota_info.quantity;
          end if;
        end loop;
      end if;
    else
      select tq.detail_id, tq.quantity, tq.quota_type, if_use into v_all_quota_info from temp_quota_if_enough tq
       where tq.quota_type = 'total_type';
       
      --查出这个配额的控制方式和有效期
      select ql.quota_control_type,qh.start_date,qh.end_date,nvl(ql.available_quantiy,0)
        into v_quota_control_type, v_quota_start_date,v_quota_end_date,v_temp_quota_total--4497
        from t_lis_recipient_quota_detail qd
        join t_lis_recipient_quota_line ql
          on qd.line_id = ql.id
        join t_lis_recipient_quota_header qh
          on qd.header_id = qh.id
       where qd.id = v_all_quota_info.detail_id
         and qd.status = 1
         and ql.status = 1
         and qh.status = 1;
        
      if v_quota_control_type = 2 then
     
        --如果是按 入库数量*可用配额/可用配额总量 的方式控制的话 要计算在有效期内的入库数量
        select sum(line.current_receive_quantity) into v_total_in_qunaity--2167
          from t_receiptorder_lineinfo line
          join t_receiptorder_headerinfo head
            on head.id = line.receipt_order_id
           and head.is_straight = 0
           and head.order_status = 5
           and head.status = 1
         where line.status = 1
           and line.item_id = itemId
           and line.accounting_confrim_import_date >= v_quota_start_date
           and line.accounting_confrim_import_date <= v_quota_end_date;
        if v_total_in_qunaity >= v_temp_quota_total then
          --如果大于可用配额总量
          if v_all_quota_info.quantity < v_temp_quantity then
            errorInfo := v_item_code || '配额已不足,申请数量为:' || quantity ||'可用配额为:' || v_all_quota_info.quantity||'请按照配额领用,如果需要超配额领用,请联系相关调度员!';
            raise E_QUANTITY_NOT_ENOUGH;
          end if;
          if v_all_quota_info.quantity >= v_temp_quantity then update temp_quota_if_enough utq set utq.if_use = 1 where utq.detail_id = v_all_quota_info.detail_id;
            v_temp_quantity := 0;
          end if;
          end if;
          
         if v_total_in_qunaity < v_temp_quota_total then
          v_quota_temp_quantity := trunc(v_total_in_qunaity *v_all_quota_info.quantity /v_temp_quota_total,5);
          if v_quota_temp_quantity < v_temp_quantity then
            errorInfo := v_item_code || '配额已不足,申请数量为:' || quantity ||'可用配额为:' || v_quota_temp_quantity||'请按照配额领用,如果需要超配额领用,请联系相关调度员!';
            raise E_QUANTITY_NOT_ENOUGH;
          elsif v_quota_temp_quantity >= v_temp_quantity then
            update temp_quota_if_enough utq set utq.if_use = 1 where utq.detail_id = v_all_quota_info.detail_id;
            v_temp_quantity := 0;
          end if;
        end if;
    
    end if;
    if v_quota_control_type = 1 then
      if v_all_quota_info.quantity < v_temp_quantity then
            errorInfo := v_item_code || '配额已不足,申请数量为:' || quantity ||'可用配额为:' || v_all_quota_info.quantity ||'请按照配额领用,如果需要超配额领用,请联系相关调度员!';
            raise E_QUANTITY_NOT_ENOUGH;
          end if;
          if v_all_quota_info.quantity >= v_temp_quantity then update temp_quota_if_enough utq set utq.if_use = 1 where utq.detail_id = v_all_quota_info.detail_id;
          v_temp_quantity := 0;
          end if;
      end if;
  end if;
end if;
if flag=1 and v_temp_quantity <> 0 then
  raise E_QUANTITY_NOT_ENOUGH;
  end if;
  if flag =1 then
open result_info for select tq.detail_id, tq.quantity, tq.quota_type, tq.if_use from temp_quota_if_enough tq where tq.if_use = 1;
end if;
exception
when E_QUANTITY_NOT_ENOUGH then flag := -1; when others then 
  errorInfo :=SQLCODE||'---'||SQLERRM;
  flag := -10;
end;
/

