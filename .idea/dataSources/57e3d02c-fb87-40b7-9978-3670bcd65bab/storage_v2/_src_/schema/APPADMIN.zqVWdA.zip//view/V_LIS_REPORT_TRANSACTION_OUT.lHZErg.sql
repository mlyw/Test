create view V_LIS_REPORT_TRANSACTION_OUT as
  SELECT i.item_code,
    i.item_name item_desc,
    tmp.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.sub_wd_id warehouse_out_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    tmp.product_unit_price,
    tmp.actual_qty current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.actual_qty,0) current_out_account,
    tmp.accounted_date import_date,
    tmp.seq_id order_id,
    tmp.order_code order_code,
    tmp.order_type,
    a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM
    (SELECT rl.item_id,
      rl.sub_wd_id,
      0 product_unit_price,
      rl.actual_qty,
      rl.accounted_date,
      rh.seq_id,
      rh.order_code,
      '报废卡退库' order_type
    FROM t_refundwastecard_head rh,
      t_refundwastecard_line rl
    WHERE rh.status                            =1
    AND rl.status                              =1
    AND rh.order_status                        =7
    AND rl.order_line_status                   =7
    AND TO_CHAR(rl.accounted_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.sub_wd_id=d.id
  LEFT JOIN t_warehouse_define_area a
  ON tmp.sub_wd_id=a.warehouse_id
  UNION ALL
  ----rm销售数据 营业厅销售出去的数据
  SELECT i.item_code,
    i.item_name item_desc,
    rs.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    d.id warehouse_out_id ,
    rs.subinventory_code warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    0 product_unit_price,
    NVL(rs.quantity,0) current_out_quantity,
    0*NVL(rs.quantity,0) current_out_account,
    rs.transcation_date,
    rs.seq_id order_id,
    rs.origin_filename order_code,
    '有价卡销售' order_type,
    a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM t_lis_rm_sales rs
  LEFT JOIN t_sys_erp_items i
  ON rs.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON rs.subinventory_code =d.warehouse_define_code
  LEFT JOIN t_warehouse_define_area a
  ON rs.subinventory_code                      =a.warehouse_code
  WHERE NVL(rs.quantity,0)                     >0
  AND TO_CHAR(rs.transcation_date,'yyyy-MM-dd')>'2016-12-31'
  AND NVL(rs.flag,'')                          ='Y'
  UNION ALL
  ----SIM卡销售月结-销售数量
  SELECT i.item_code,
    i.item_name item_desc,
    tmp.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.wd_id warehouse_out_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    0 product_unit_price,
    tmp.simcard_qty current_out_quantity,
    0*NVL(tmp.simcard_qty,0) current_out_account,
    tmp.transaction_processing_time import_date， tmp.id order_id,
    tmp.simcard_order_code order_code,
    tmp.order_type,
    a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM
    (SELECT sl.item_id,
      sl.wd_id,
      sl.simcard_qty simcard_qty,
      sh.transaction_processing_time,
      sh.id,
      sh.simcard_order_code,
      'SIM卡销售' order_type
    FROM T_Lis_Simcard_Sales_Month_Head sh,
      T_Lis_Simcard_Sales_Month_Line sl
    WHERE sl.status                                         =1
    AND sh.status                                           =1
    AND sl.head_id                                          =sh.id
    AND sh.head_status                                      =4
    AND sl.line_status                                      =4
    AND TO_CHAR(sh.transaction_processing_time,'yyyy-MM-dd')>'2016-12-31'
    AND NVL(sl.simcard_qty,0)                               >0
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.wd_id=d.id
  LEFT JOIN t_warehouse_define_area a
  ON tmp.wd_id=a.warehouse_id
  UNION ALL
  ---调拨-调出方
  SELECT tmp.item_code,
    tmp.item_desc,
    tmp.item_id,
    tmp.uom_code,
    tmp.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.wh_id_trf_from warehouse_out_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    tmp.product_unit_price,
    tmp.change_quty current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.change_quty,0) current_out_account,
    tmp.account_date import_date,
    tmp.id order_id,
    tmp.wh_chg_ord_code order_code,
    tmp.order_type order_type,
    a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM
    (SELECT hl.item_code,
      hl.item_id,
      hl.uom_desc,
      hl.uom_code,
      hl.item_desc,
      hl.wh_id_trf_from,
      NVL(hl.product_unit_price,0) product_unit_price,
      hl.change_quty,
      hd.account_date,
      hd.id,
      hd.wh_chg_ord_code,
      '调拨' order_type
    FROM t_chg_hd_ln hd,
      t_chg_ln hl
    WHERE hd.status                          =1
    AND hl.status                            =1
    AND hd.order_status                     IN (5,50)
    AND hl.chghdln_id                        =hd.id
    AND TO_CHAR(hd.account_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.wh_id_trf_from=d.id
  LEFT JOIN t_warehouse_define_area a
  ON tmp.wh_id_trf_from=a.warehouse_id
  UNION ALL
  ---工程及cnp出库,杂发
  SELECT tmp.item_code,
    i.item_name item_desc,
    tmp.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.warehouseid warehouse_out_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    tmp.product_unit_price,
    tmp.Acpt_Cfm_Quty current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.Acpt_Cfm_Quty,0) current_out_account,
    tmp.acc_cfm_date import_date,
    tmp.id order_id,
    tmp.out_ord_code order_code,
    tmp.order_type， a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM
    (SELECT om.item_id,
      om.item_code,
      om.warehouseid,
      om.product_unit_price,
      om.Acpt_Cfm_Quty,
      om.acc_cfm_date,
      oh.id,
      oh.out_ord_code,
      CASE
        WHEN oh.item_type_id=5
        THEN '杂发'
        ELSE '出库'
      END AS order_type
    FROM t_out_hd oh,
      t_out_ln ol,
      t_out_notmk om
    WHERE oh.status                          =1
    AND ol.status                            =1
    AND om.status                            =1
    AND ol.Outhdinfo_Id                      =oh.id
    AND om.Outlninfo_Id                      =ol.id
    AND oh.item_type_id                     IN (1,5,2)
    AND oh.ord_status                        in (6,9)
    AND om.asgn_ln_status                    =1
    AND ol.ord_ln_status                     in (2, 7)
    AND TO_CHAR(om.acc_cfm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.warehouseid=d.id
  LEFT JOIN t_warehouse_define_area a
  ON tmp.warehouseid=a.warehouse_id
  UNION ALL
  ----综合出库
  SELECT tmp.item_code,
    i.item_name item_desc,
    tmp.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.warehouseid warehouse_out_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    tmp.product_unit_price,
    tmp.Asgn_Quty current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.Asgn_Quty,0) current_out_account,
    tmp.acc_cfm_date import_date， tmp.id order_id,
    tmp.out_ord_code,
    tmp.order_type,
    a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM
    (SELECT om.item_id,
      om.item_code,
      om.warehouseid,
      om.product_unit_price,
      om.Asgn_Quty,
      om.acc_cfm_date,
      oh.id,
      oh.out_ord_code,
      CASE
        WHEN oh.item_type_id=86
        THEN '杂发'
        ELSE '出库'
      END AS order_type
    FROM t_out_hd oh,
      t_out_ln ol,
      t_out_notmk om
    WHERE oh.status                          =1
    AND ol.status                            =1
    AND om.status                            =1
    AND ol.Outhdinfo_Id                      =oh.id
    AND om.Outlninfo_Id                      =ol.id
    AND oh.item_type_id                     IN (84,86)
    AND oh.ord_status                        =6
    AND om.asgn_ln_status                    =1
    AND ol.ord_ln_status                     =7
    AND TO_CHAR(om.acc_cfm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.warehouseid=d.id
  LEFT JOIN t_warehouse_define_area a
  ON tmp.warehouseid=a.warehouse_id
  UNION ALL
  ---退货单据
  SELECT i.item_code,
    i.item_name item_desc,
    tmp.item_id,
    i.uom_code,
    i.uom_desc,
    i.concatenated_segments,
    i.category_description,
    tmp.warehouse_define_id warehouse_out_id,
    d.warehouse_define_code,
    d.warehouse_define_name,
    d.mis_ou_id,
    d.mis_ou_name,
    d.mis_io_id,
    d.mis_io_code,
    d.mis_io_name,
    tmp.product_unit_price,
    tmp.return_quantity current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.return_quantity,0) current_out_account,
    tmp.accounting_confirm_import_date import_date,
    tmp.id order_id,
    tmp.return_order_code order_code,
    tmp.order_type,
    a.occupy_area
    ||'/'
    ||a.areainfo occupy_areainfo
  FROM
    (SELECT trh.id,
      trh.return_order_code,
      trl.return_quantity,
      trl.item_id,
      trl.warehouse_define_id,
      trl.product_unit_price,
      trl.accounting_confirm_import_date,
      '退货' order_type
    FROM t_returnorder_headerinfo trh,
      t_returnorder_lineinfo trl
    WHERE trl.return_order_id                                   =trh.id
    AND trh.status                                              =1
    AND trl.status                                              =1
    AND trh.order_status                                        =4
    AND TO_CHAR(trl.accounting_confirm_import_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_warehouse_define d
  ON tmp.warehouse_define_id=d.id
  LEFT JOIN t_warehouse_define_area a
  ON tmp.warehouse_define_id=a.warehouse_id
/

