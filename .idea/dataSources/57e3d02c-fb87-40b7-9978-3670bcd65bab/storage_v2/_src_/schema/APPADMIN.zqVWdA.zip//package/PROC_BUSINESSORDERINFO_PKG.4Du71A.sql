create PACKAGE PROC_BUSINESSORDERINFO_PKG is
   type cursor_header_list is ref cursor;--header cursor
   type cursor_line_list is ref cursor;--line cursor

   --查询头信息
   PROCEDURE PROC_BUSINESSORDERINFO_HEADERS(startdate date,enddate date,temp_headerlist out cursor_header_list);
   --查询行信息
   PROCEDURE PROC_BUSINESSORDERINFO_LINES(startdate date,enddate date,orderid in number,ordertype in varchar2,ordernum varchar2,temp_linelist out cursor_line_list);
end PROC_BUSINESSORDERINFO_PKG;
/

