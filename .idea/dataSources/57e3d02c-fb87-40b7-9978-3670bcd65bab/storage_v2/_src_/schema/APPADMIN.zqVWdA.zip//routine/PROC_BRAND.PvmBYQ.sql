create PROCEDURE "PROC_BRAND" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_brand is
select brand_id, brand_code, brand_name, enable_flag, start_data_active, end_data_active, erp_type, import_date, seq_id, create_date from i_erp_brand where create_date > start_time and create_date < end_time order by erp_type desc;
i_brand csr_i_brand%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from I_ERP_BRAND where create_date > start_time and create_date < end_time;
  open csr_i_brand;
  fetch csr_i_brand into i_brand;
while (csr_i_brand%found) loop
  select count(*) into count_value from T_SYS_ERP_BRAND where BRAND_ID = i_brand.brand_id and erp_type = i_brand.erp_type;
  if(count_value = 1 and i_brand.enable_flag = 'Y' and i_brand.end_data_active is null) then
      update T_SYS_ERP_BRAND t set t.last_updated_date = sysdate,
      t.brand_code = i_brand.brand_code,
      t.brand_name = i_brand.brand_name,
      t.erp_type = i_brand.erp_type,
      t.start_data_active = i_brand.start_data_active,
      t.end_data_active = i_brand.end_data_active
      where t.brand_id = i_brand.brand_id;
   elsif(count_value = 1 and i_brand.enable_flag = 'N') then
   update t_Sys_Erp_Brand t set t.last_updated_date = sysdate,
      t.brand_code = i_brand.brand_code,
      t.brand_name = i_brand.brand_name,
      t.erp_type = i_brand.erp_type,
      t.start_data_active = i_brand.start_data_active,
      t.end_data_active = i_brand.end_data_active,
      t.status = 0
      where t.brand_id = i_brand.brand_id;
   elsif(count_value = 1 and i_brand.enable_flag = 'Y' and i_brand.end_data_active is not null) then
   update t_Sys_Erp_Brand t set t.last_updated_date = sysdate,
      t.brand_code = i_brand.brand_code,
      t.brand_name = i_brand.brand_name,
      t.erp_type = i_brand.erp_type,
      t.start_data_active = i_brand.start_data_active,
      t.end_data_active = i_brand.end_data_active,
      t.status = 0
      where t.brand_id = i_brand.brand_id;
 elsif(count_value = 0 and i_brand.end_data_active is null and i_brand.enable_flag = 'Y') then
   insert into t_sys_erp_brand
     (seq_id, brand_id, created_date, last_updated_date, status, brand_code, brand_name, erp_type, start_data_active, end_data_active)
   values
     (i_brand.seq_id, i_brand.brand_id, sysdate, sysdate, 1, i_brand.brand_code, i_brand.brand_name, i_brand.erp_type, i_brand.start_data_active, i_brand.end_data_active);
end if;
fetch csr_i_brand into i_brand;
count_success:=count_success+1;
end loop;
close csr_i_brand;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','T_SYS_ERP_BRAND');
exception when others then
  rollback;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_ERP_BRAND');
  commit;
end;
/

