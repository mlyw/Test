create PROCEDURE "PROC_IC" (start_time timestamp,end_time timestamp) as
total_value number(15);
count_value number(2);
count_success number(15);
exception_info varchar2(3000);
cursor csr_i_ic is
select seq_id, internal_company_id, internal_company_code, internal_company_name, enable_flag, start_data_active, end_data_active, erp_type, import_date from i_erp_ic
 where import_date > start_time and import_date < end_time order by erp_type desc;
i_ic csr_i_ic%rowtype;
begin
  count_success := 0;
  select count(*) into total_value from I_ERP_IC where import_date > start_time and import_date < end_time;
  open csr_i_ic;
  fetch csr_i_ic into i_ic;
while (csr_i_ic%found) loop
  select count(*) into count_value from T_SYS_ERP_IC where ERP_IC_ID = i_ic.internal_company_id and erp_type = i_ic.erp_type;
  if(count_value = 1 and i_ic.enable_flag = 'Y' and i_ic.end_data_active is null) then
      update T_SYS_ERP_IC t set t.last_updated_date = sysdate,
      t.erp_ic_code = i_ic.internal_company_code,
      t.erp_ic_name = i_ic.internal_company_name,
      t.erp_type = i_ic.erp_type,
      t.start_date_active = i_ic.start_data_active,
      t.end_date_active = i_ic.end_data_active
      where t.erp_ic_id = i_ic.internal_company_id
      and t.erp_type = i_ic.erp_type;
   elsif(count_value = 1 and i_ic.enable_flag = 'N') then
   update T_SYS_ERP_IC t set t.last_updated_date = sysdate,
      t.erp_ic_code = i_ic.internal_company_code,
      t.erp_ic_name = i_ic.internal_company_name,
      t.erp_type = i_ic.erp_type,
      t.start_date_active = i_ic.start_data_active,
      t.end_date_active = i_ic.end_data_active,
      t.status = 0
      where t.erp_ic_id = i_ic.internal_company_id
      and t.erp_type = i_ic.erp_type;
   elsif(count_value = 1 and i_ic.enable_flag = 'Y' and i_ic.end_data_active is not null) then
   update T_SYS_ERP_IC t set t.last_updated_date = sysdate,
      t.erp_ic_code = i_ic.internal_company_code,
      t.erp_ic_name = i_ic.internal_company_name,
      t.erp_type = i_ic.erp_type,
      t.start_date_active = i_ic.start_data_active,
      t.end_date_active = i_ic.end_data_active,
      t.status = 0
      where t.erp_ic_id = i_ic.internal_company_id
      and t.erp_type = i_ic.erp_type;
 elsif(count_value = 0 and i_ic.end_data_active is null and i_ic.enable_flag = 'Y') then
insert into t_sys_erp_ic
  (erp_ic_id, erp_ic_code, erp_ic_name, erp_type, start_date_active, end_date_active, validity_flag, created_date, last_updated_date, status, version, seq_id)
values
  (i_ic.internal_company_id, i_ic.internal_company_code, i_ic.internal_company_name, i_ic.erp_type, i_ic.start_data_active, i_ic.end_data_active, i_ic.enable_flag, sysdate, sysdate, 1, 0, i_ic.seq_id);
end if;
fetch csr_i_ic into i_ic;
count_success := count_success + 1;
end loop;
close csr_i_ic;
commit;
--插入日志
insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,total_value,sysdate,'同步成功','T_SYS_ERP_IC');
exception when others then
  rollback;
  exception_info := 'ERR: An error occurred with info:'||to_char(sqlcode)||' '||sqlerrm;
  insert into i_erp_logs values (i_erp_logs_seq.nextval,total_value,count_success,sysdate,exception_info,'T_SYS_ERP_IC');
  commit;
end;
/

