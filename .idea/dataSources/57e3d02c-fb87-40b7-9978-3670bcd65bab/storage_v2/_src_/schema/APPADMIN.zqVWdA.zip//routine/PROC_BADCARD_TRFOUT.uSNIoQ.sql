create PROCEDURE PROC_BADCARD_TRFOUT(
   V_BADCARD_TRFOUT_ID IN NUMBER,
   V_ITEM_CODE IN VARCHAR2, 
   V_MIS_PIC_CODE IN VARCHAR2, 
   V_QUANTITY IN NUMBER,
   V_SRC_SUBINVENTORY_CODE IN VARCHAR2, 
   V_TO_SUBINVENTORY_CODE IN VARCHAR2) AS
   
   QUANTITY_VO NUMBER(19,5);-- 用来接收传值和赋值计算应用 wjr
   CURRENT_ONHAND_QTY NUMBER(19,5);--当前循环实时现有量
   UPDATE_COUNT NUMBER(10);
   COUNT_VALUE NUMBER(10);
   WHCURRENT_ONHAND_QTY_ID NUMBER(19);
   --SRC_SUBWAREHOUSEID NUMBER(19);
   TO_SUBWAREHOUSEID NUMBER(19);
   TOTAL_QTY NUMBER(19, 5);
   ORG_CODE  varchar2(64);
   reverse_count        NUMBER(19);  --冻结条数
   reverse_qty          NUMBER(19, 5);--冻结现有量数量
   CURSOR LIS_WH_ONHAND_QTY IS  --定义LIS WH_CURRENT_ONHAND_QTY的游标 wjr
   SELECT WH.ID, WH.VERSION, WH.ONHAND_QUANTITY 
   FROM T_WH_CURRENT_ONHAND_QUANTITY WH 
   INNER JOIN T_WAREHOUSE_DEFINE WD ON WH.WAREHOUSE_DEFINE_ID=WD.ID
   WHERE WH.ITEM_CODE = V_ITEM_CODE -- 物料编码
         AND WH.MIS_PIC_CODE = V_MIS_PIC_CODE -- mis批次号
         and wh.onhand_quantity > 0
         and wh.status = 1
         and exists (
         select 1 from T_SYS_ERP_SUBINVENTORY sub
         INNER JOIN T_SYS_ERP_ORGANIZATIONS ORG ON ORG.ORGANIZATION_ID = SUB.ORGANIZATIONS_ID
         where  sub.status = 1 and sub.SUBINVENTORY_CODE = V_SRC_SUBINVENTORY_CODE and org.organization_code = (select organization_code from T_SYS_ERP_ORGANIZATIONS t where ORGANIZATION_ID=SUB.ORGANIZATIONS_ID)
         and sub.SUBINVENTORY_ID = wd.MIS_SUBINVENTOEY_ID
                 )
   order by wh.created_date;
   whonhand_qty lis_wh_onhand_qty%rowtype;-- 将游标的每一条数据赋值给whonhand_qty
BEGIN
   quantity_vo := V_QUANTITY;-- 赋值
   select o.organization_code into ORG_CODE from T_SYS_ERP_SUBINVENTORY s,T_SYS_ERP_ORGANIZATIONS o where 
   s.ORGANIZATIONS_ID = o.ORGANIZATION_ID and S.Subinventory_Code=V_SRC_SUBINVENTORY_CODE;
   if quantity_vo >= 0 then --当数量大于0 就执行保存操作
     select count(wd.id) into COUNT_VALUE 
     from t_sys_erp_subinventory sub 
     INNER JOIN t_warehouse_define wd on sub.subinventory_id = wd.mis_subinventoey_id 
    where sub.subinventory_code = V_SRC_SUBINVENTORY_CODE
            and sub.status=1
            and wd.status=1
            and sub.organizations_id in (
                    select org.organization_id  from T_SYS_ERP_ORGANIZATIONS org  
                    where org.status=1 and org.organization_code= ORG_CODE
                );
      if 1 = COUNT_VALUE then
      select wd.id into TO_SUBWAREHOUSEID 
      from t_sys_erp_subinventory sub 
      INNER JOIN t_warehouse_define wd on sub.subinventory_id=wd.mis_subinventoey_id 
            where sub.subinventory_code= V_SRC_SUBINVENTORY_CODE 
            and sub.status=1
            and wd.status=1
            and sub.organizations_id in (
                    select org.organization_id  
                    from T_SYS_ERP_ORGANIZATIONS org  
                    where org.status=1 and org.organization_code = ORG_CODE
            ); 
            
          select S_WH_CURRENT_ONHAND_QUANTITY.NEXTVAL into WHCURRENT_ONHAND_QTY_ID from dual;
          -- 生成现有量
          INSERT INTO T_WH_CURRENT_ONHAND_QUANTITY (ID,ITEM_CODE,ITEM_DESC,ITEM_ID, MIS_PIC_CODE,
                  ONHAND_QUANTITY, STRING_VALUE1, UOM_CODE, UOM_DESC, WAREHOUSE_DEFINE_ID, ERP_TYPE, STATUS, 
                  "VERSION", CREATED_DATE, CREATED_USER, LAST_UPDATED_DATE, LAST_UPDATED_USER)
            SELECT WHCURRENT_ONHAND_QTY_ID, BCITEM.ITEM_CODE, BCITEM.ITEM_NAME, BCITEM.SEQ_ID, 
            BCITEM.MIS_PIC_CODE, BCITEM.QTY, BCITEM.STR_VAL1,BCITEM.UOM_CODE, BCITEM.UOM_DESC,
            BCITEM.TO_SUBWAREHOUSEID, BCITEM.ERP_TYPE,
            1, 1, systimestamp,'12345678',systimestamp,'12345678'
          FROM (SELECT BC.ITEM_CODE,
                       ITEM1.ITEM_NAME,
                       ITEM1.SEQ_ID,
                       V_MIS_PIC_CODE AS MIS_PIC_CODE,
                       BC.QUANTITY AS QTY,
                       BC.ITEM_TYPE || ' ' || BC.ITEM_CODE AS STR_VAL1,
                       ITEM1.UOM_CODE, ITEM1.UOM_DESC,
                       TO_SUBWAREHOUSEID as "TO_SUBWAREHOUSEID",
                       OUORG.ERP_TYPE
                 FROM T_LIS_BADCARD_TROUT BC
                 INNER JOIN T_SYS_ERP_ITEMS ITEM1 ON ITEM1.ITEM_CODE = BC.ITEM_CODE 
                 AND BC.seq_id = V_BADCARD_TRFOUT_ID 
                 left join (
                       SELECT OU.ERP_TYPE,
                              ORG.ORGANIZATION_CODE,
                              org.organization_id
                       from T_SYS_ERP_OU ou
                       inner join T_SYS_ERP_ORGANIZATIONS org
                       ON ORG.OU_ID = OU.OU_ID
                       AND ORG.ORGANIZATION_CODE = ORG_CODE
                 ) OUORG ON OUORG.ORGANIZATION_ID = ITEM1.ORGANIZATION_ID
                 WHERE ITEM1.STATUS = 1 AND ITEM1.SEQ_ID IS NOT NULL
                 ) bcitem; 
                 
          -- 生成现有量操作明细       
          INSERT INTO T_LIS_BADCARD_TROUT_REL
                  (SEQ_ID, BADCARD_OUT_ID, WH_ONHANDQTY_ID, STATUS, VERSION, CREATED_DATE, LAST_UPDATED_DATE,
                  ORIGIN_QUANTITY, QUANTITY)
                 VALUES
                  (SEQ_LIS_BADCARD_TRFOUT.NEXTVAL, V_BADCARD_TRFOUT_ID, WHCURRENT_ONHAND_QTY_ID, 1, 1, 
                  SYSDATE, SYSDATE, 0, QUANTITY_VO);
          -- 更新标识位为 Y        
          update  T_LIS_BADCARD_TROUT 
          set flag = 'Y',Created_Date=Sysdate 
          where seq_id = V_BADCARD_TRFOUT_ID;
          
          commit;
       end if;
   else 
      total_qty := 0;
       select SUM(nvl(QTY.ONHAND_QUANTITY, 0)) into total_qty from T_WH_CURRENT_ONHAND_QUANTITY QTY
 WHERE  QTY.STATUS = 1 AND QTY.ONHAND_QUANTITY > 0
 and QTY.ITEM_CODE = V_ITEM_CODE and QTY.MIS_PIC_CODE = V_MIS_PIC_CODE 
 and exists (
  select 1 from T_WAREHOUSE_DEFINE WD , T_SYS_ERP_SUBINVENTORY INV, T_SYS_ERP_ORGANIZATIONS ORG
  where WD.STATUS = 1 and INV.STATUS = 1
  AND INV.SUBINVENTORY_ID = WD.MIS_SUBINVENTOEY_ID AND ORG.ORGANIZATION_ID = INV.ORGANIZATIONS_ID
  and INV.SUBINVENTORY_CODE = V_SRC_SUBINVENTORY_CODE and ORG.ORGANIZATION_CODE = ORG_CODE
  AND WD.ID = QTY.WAREHOUSE_DEFINE_ID );
             
    IF TOTAL_QTY + V_QUANTITY >= 0 THEN
     
     /* 
    SELECT WD.ID INTO TO_SUBWAREHOUSEID
    FROM T_SYS_ERP_SUBINVENTORY SUB 
    INNER JOIN T_WAREHOUSE_DEFINE WD ON SUB.SUBINVENTORY_ID=WD.MIS_SUBINVENTOEY_ID
            where sub.subinventory_code= V_TO_SUBINVENTORY_CODE
            and sub.status=1
            and wd.status=1
            and sub.organizations_id in (
                    SELECT ORG.ORGANIZATION_ID  FROM T_SYS_ERP_ORGANIZATIONS ORG  
                    where org.status=1 and org.organization_code='BJC'
            );
    
     -- 增加报废子库现有量
    SELECT S_WH_CURRENT_ONHAND_QUANTITY.NEXTVAL INTO WHCURRENT_ONHAND_QTY_ID FROM DUAL;
    
    INSERT INTO T_WH_CURRENT_ONHAND_QUANTITY (ID,ITEM_CODE,ITEM_DESC,ITEM_ID, MIS_PIC_CODE,
                  ONHAND_QUANTITY, STRING_VALUE1, UOM_CODE, UOM_DESC, WAREHOUSE_DEFINE_ID, ERP_TYPE, STATUS, 
                  "VERSION", CREATED_DATE, CREATED_USER, LAST_UPDATED_DATE, LAST_UPDATED_USER)
            SELECT WHCURRENT_ONHAND_QTY_ID, BCITEM.ITEM_CODE, BCITEM.ITEM_NAME, BCITEM.SEQ_ID, 
            BCITEM.MIS_PIC_CODE, BCITEM.QTY, BCITEM.STR_VAL1,BCITEM.UOM_CODE, BCITEM.UOM_DESC,
            BCITEM.TO_SUBWAREHOUSEID, BCITEM.ERP_TYPE,
            1, 1, systimestamp,'12345678',systimestamp,'12345678'
          FROM (SELECT BC.ITEM_CODE,
                       ITEM1.ITEM_NAME,
                       ITEM1.SEQ_ID,
                       V_MIS_PIC_CODE AS MIS_PIC_CODE,
                       -1 * BC.QUANTITY AS QTY,
                       BC.ITEM_TYPE || ' ' || BC.ITEM_CODE ||  ', 手动处理坏卡转到C999的现有量，日期：2015-08-24.' AS STR_VAL1,
                       ITEM1.UOM_CODE, ITEM1.UOM_DESC,
                       TO_SUBWAREHOUSEID as "TO_SUBWAREHOUSEID",
                       OUORG.ERP_TYPE
                 FROM T_LIS_BADCARD_TROUT BC
                 INNER JOIN T_SYS_ERP_ITEMS ITEM1 ON ITEM1.ITEM_CODE = BC.ITEM_CODE 
                 AND BC.seq_id = V_BADCARD_TRFOUT_ID 
                 left join (
                       SELECT OU.ERP_TYPE,
                              ORG.ORGANIZATION_CODE,
                              org.organization_id
                       from T_SYS_ERP_OU ou
                       inner join T_SYS_ERP_ORGANIZATIONS org
                       ON ORG.OU_ID = OU.OU_ID
                       AND ORG.ORGANIZATION_CODE = 'BJC'
                 ) OUORG ON OUORG.ORGANIZATION_ID = ITEM1.ORGANIZATION_ID
                 WHERE ITEM1.STATUS = 1 AND ITEM1.SEQ_ID IS NOT NULL
                 ) bcitem;  
      */
    
           for whonhand_qty in lis_wh_onhand_qty  loop
        UPDATE_COUNT := 0;
        --LIS现有量 currentOnHandQty
        SELECT WH.ONHAND_QUANTITY INTO CURRENT_ONHAND_QTY  from T_WH_CURRENT_ONHAND_QUANTITY wh where wh.id=whonhand_qty.id;
        reverse_qty := 0;
        reverse_count :=0;
         --冻结
          select count(*) into reverse_count from t_sys_item_resereve_info info where info.status = 1 and info.onhand_id = whonhand_qty.id and (info.reserve_end_day - info.reserve_start_day) < 31;
          if(reverse_count > 0) then
            select sum(info.reserve_quantity) into reverse_qty from t_sys_item_resereve_info info where info.status = 1 and info.onhand_id = whonhand_qty.id;
          end if;
          --如果本条现有量减去冻结<=0，则循环下一个现有量,否则 扣减
          if(CURRENT_ONHAND_QTY  - reverse_qty <= 0) then 
            update T_LIS_BADCARD_TROUT BC set BC.flag = 'N', bc.string_value1='扣减失败,原因: 存在冻结数据.' where BC.seq_id = V_BADCARD_TRFOUT_ID; --更新rm sales此条数据为标记成功
            commit;
          else 
          
             if (CURRENT_ONHAND_QTY - reverse_qty + quantity_vo = 0 ) then -- (1) 判断如果等于0 ,结束此循环 ,更新三张表的关系
               UPDATE T_WH_CURRENT_ONHAND_QUANTITY WH 
               SET WH.ONHAND_QUANTITY = CURRENT_ONHAND_QTY + QUANTITY_VO,
               wh.version=nvl(wh.version,0)+1,wh.last_updated_date=sysdate  --更新LIS 物料现有量
               where wh.id = whonhand_qty.id and wh.version=whonhand_qty.version;
               UPDATE_COUNT := sql%rowcount; -- 更新了现有量条数
               IF(UPDATE_COUNT > 0) THEN
                 UPDATE T_LIS_BADCARD_TROUT BC 
                 SET BC.FLAG = 'Y' ,Created_Date=Sysdate                  
                 WHERE BC.SEQ_ID = V_BADCARD_TRFOUT_ID;
                 -- 增加处理关系
                 INSERT INTO T_LIS_BADCARD_TROUT_REL
                  (SEQ_ID, BADCARD_OUT_ID, WH_ONHANDQTY_ID, STATUS, VERSION, CREATED_DATE, LAST_UPDATED_DATE,
                  ORIGIN_QUANTITY, QUANTITY)
                 VALUES
                  (SEQ_LIS_BADCARD_TRFOUT.NEXTVAL, V_BADCARD_TRFOUT_ID, WHONHAND_QTY.ID,1,1,SYSDATE,SYSDATE, 
                  CURRENT_ONHAND_QTY, QUANTITY_VO);
                commit;
                 exit;
               end if;
           elsif (CURRENT_ONHAND_QTY - reverse_qty + quantity_vo > 0) then -- (2) 判断如果等于>0 ,结束此循环 ,更新三张表的关系
             UPDATE T_WH_CURRENT_ONHAND_QUANTITY WH 
             SET WH.ONHAND_QUANTITY = CURRENT_ONHAND_QTY + QUANTITY_VO,
             wh.version=nvl(wh.version,1)+1,wh.last_updated_date=sysdate  --更新LIS 物料现有量
             where wh.id = whonhand_qty.id and wh.version=whonhand_qty.version;
             UPDATE_COUNT := sql%rowcount;
             IF(UPDATE_COUNT > 0) THEN
               UPDATE T_LIS_BADCARD_TROUT BC 
               SET BC.FLAG = 'Y',Created_Date=Sysdate 
               WHERE BC.SEQ_ID = V_BADCARD_TRFOUT_ID;
               INSERT INTO T_LIS_BADCARD_TROUT_REL
                  (SEQ_ID, BADCARD_OUT_ID, WH_ONHANDQTY_ID, STATUS, VERSION, CREATED_DATE, LAST_UPDATED_DATE,
                  ORIGIN_QUANTITY, QUANTITY)
                 VALUES
                  (SEQ_LIS_BADCARD_TRFOUT.NEXTVAL, V_BADCARD_TRFOUT_ID, WHONHAND_QTY.ID,1,1,SYSDATE,SYSDATE, 
                  CURRENT_ONHAND_QTY, QUANTITY_VO);
               commit;
               exit;
             end if;
           elsif (CURRENT_ONHAND_QTY - reverse_qty + quantity_vo < 0 ) then -- (3) 判断如果等于 < 0 ,继续循环 ,更新三张表的关系
             UPDATE T_WH_CURRENT_ONHAND_QUANTITY WH 
             SET WH.ONHAND_QUANTITY = 0+reverse_qty, 
             WH.VERSION=NVL(WH.VERSION,1) + 1, 
             wh.last_updated_date=sysdate  --更新LIS 物料现有量
             where wh.id = whonhand_qty.id and wh.version=whonhand_qty.version;
             UPDATE_COUNT := sql%rowcount;
             if(UPDATE_COUNT > 0) then
               INSERT INTO T_LIS_BADCARD_TROUT_REL
                  (SEQ_ID, BADCARD_OUT_ID, WH_ONHANDQTY_ID, STATUS, VERSION, CREATED_DATE, LAST_UPDATED_DATE,
                  ORIGIN_QUANTITY, QUANTITY)
                 VALUES
                  (SEQ_LIS_BADCARD_TRFOUT.NEXTVAL, V_BADCARD_TRFOUT_ID, WHONHAND_QTY.ID, 1, 1, SYSDATE, SYSDATE, 
                  CURRENT_ONHAND_QTY, QUANTITY_VO);
                  
               UPDATE T_LIS_BADCARD_TROUT BC 
               SET BC.FLAG = 'Y',Created_Date=Sysdate 
               where bc.seq_id = V_BADCARD_TRFOUT_ID; --更新rm sales此条数据为标记成功
               QUANTITY_VO := CURRENT_ONHAND_QTY  - reverse_qty + quantity_vo;
               commit;
             end if;
           end if;
          end if;
       end loop;
      else 
      update T_LIS_BADCARD_TROUT BC set BC.flag = 'N',bc.string_value1 = '扣减失败,原因:现有量不足.' where BC.seq_id = V_BADCARD_TRFOUT_ID; --更新rm sales此条数据为标记成功 
      commit;
    END IF;
  end if;
  --open temp_list for select * from T_LIS_BADCARD_TROUT_TMP bc where bc.seq_id = BADCARD_TRFOUT_ID and rm.flag = 'Y';
 END PROC_BADCARD_TRFOUT;
/

