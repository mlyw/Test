create view V_LIS_REPORT_ITEM_TURN_RATE as
  SELECT
   /**以ou/库存/子库/物料分类/物料为维度的期初、期末、当前库存、统计周期内的出入库、
   呆滞物资数据原始表视图（由于需要动态传参数，视图仅供sql实例参考，不能用于实际视图查询，需要在此基础上进行各种group by 分组统计）*/
    reslutdata.ou_id,
    reslutdata.organization_id,
    reslutdata.orginfo,
    reslutdata.warehouse_define_id,
    reslutdata.warehouseinfo,
    reslutdata.item_category_code,
    reslutdata.item_category_name,
    reslutdata.item_id,
    reslutdata.item_code,
    reslutdata.item_desc,
    reslutdata.item_uom_code,
    reslutdata.item_uom_desc,
    SUM(reslutdata.startaccount) startaccount,
    SUM(reslutdata.endaccount) endaccount,
    SUM(reslutdata.out_onhand_account) out_onhand_account,
    SUM(reslutdata.out_onhand_quantity) out_onhand_quantity,
    SUM(reslutdata.receive_onhand_account) receive_onhand_account,
    SUM(reslutdata.receive_onhand_quantity) receive_onhand_quantity,
    SUM(reslutdata.item_account) item_account,
    SUM(reslutdata.item_quantity) item_quantity,
    SUM(reslutdata.isoveraccount) isoveraccount
  FROM
    (SELECT rss.ou_id,
      rss.organization_id,
      (dd.mis_io_code
      ||' '
      ||dd.mis_io_name) orginfo,
      rss.warehouse_define_id,
      (dd.warehouse_define_code
      ||' '
      ||dd.warehouse_define_name) warehouseinfo,
      rss.item_category_code,
      rss.item_category_name,
      rss.item_id,
      rss.item_code,
      rss.item_desc,
      rss.item_uom_code,
      rss.item_uom_desc,
      SUM(rss.startaccount) startaccount,
      SUM(rss.endaccount) endaccount,
      0 out_onhand_account,
      0 out_onhand_quantity,
      0 receive_onhand_account,
      0 receive_onhand_quantity,
      0 item_account,
      0 item_quantity,
      0 isoveraccount
    FROM v_lis_report_start_stop rss
    LEFT JOIN t_warehouse_define dd
    ON rss.warehouse_define_id=dd.id
    WHERE ((rss.bussiness_date='201702'
    AND rss.endaccount        =0
    AND rss.endqty            =0)
    OR (rss.bussiness_date    ='201708'
    AND rss.startaccount      =0
    AND rss.startqty          =0))
    AND 1                     =1
    GROUP BY rss.ou_id,
      rss.organization_id,
      dd.mis_io_code,
      dd.mis_io_name,
      rss.warehouse_define_id,
      dd.warehouse_define_code,
      dd.warehouse_define_name,
      rss.item_category_code,
      rss.item_category_name,
      rss.item_id,
      rss.item_code,
      rss.item_desc,
      rss.item_uom_code,
      rss.item_uom_desc
    UNION ALL
    ----统计周期内出入库金额及数量
    SELECT rct.ou_id,
      rct.organization_id,
      (rct.organization_code
      ||' '
      ||rct.organization_name) orginfo,
      rct.warehouse_define_id,
      (rct.warehouse_define_code
      ||' '
      ||rct.warehouse_define_desc) warehouseinfo,
      rct.item_category_code,
      rct.item_category_name,
      rct.item_id,
      rct.item_code,
      rct.item_desc,
      rct.item_uom_code,
      rct.item_uom_desc,
      0 startaccount,
      0 endaccount,
      SUM(rct.out_onhand_account) out_onhand_account,
      SUM(rct.out_onhand_quantity) out_onhand_quantity,
      SUM(rct.receive_onhand_account) receive_onhand_account,
      SUM(rct.receive_onhand_quantity) receive_onhand_quantity,
      0 item_account,
      0 item_quantity,
      0 isoveraccount
    FROM t_lis_report_core_transaction rct
    WHERE TO_CHAR(rct.bussiness_date,'yyyyMMdd')>='201702'
    AND TO_CHAR(rct.bussiness_date,'yyyyMMdd')  <='201708'
    AND 1                                        =1
    GROUP BY rct.ou_id,
      rct.organization_id,
      rct.organization_code,
      rct.organization_name,
      rct.warehouse_define_id,
      rct.warehouse_define_code,
      rct.warehouse_define_desc,
      rct.item_category_code,
      rct.item_category_name,
      rct.item_id,
      rct.item_code,
      rct.item_desc,
      rct.item_uom_code,
      rct.item_uom_desc
    UNION ALL
    ----当前库存金额及数量
    SELECT rqi.mis_ou_id ou_id,
      rqi.mis_io_id organization_id,
      (rqi.mis_io_code
      ||' '
      ||rqi.mis_io_name) orginfo,
      rqi.warehouse_define_id,
      (rqi.warehouse_define_code
      ||' '
      ||rqi.warehouse_define_name) warehouseinfo,
      rqi.concatenated_segments item_category_code,
      rqi.category_description item_category_name,
      rqi.item_id,
      rqi.item_code,
      rqi.item_desc,
      rqi.uom_code item_uom_code,
      rqi.uom_desc item_uom_desc,
      0 startaccount,
      0 endaccount,
      0 out_onhand_account,
      0 out_onhand_quantity,
      0 receive_onhand_account,
      0 receive_onhand_quantity,
      SUM(rqi.item_account) item_account,
      SUM(rqi.item_quantity) item_quantity,
      0 isoveraccount
    FROM v_lis_report_qty_item_now rqi
    GROUP BY rqi.mis_ou_id,
      rqi.mis_io_id,
      rqi.mis_io_code,
      rqi.mis_io_name,
      rqi.warehouse_define_id,
      rqi.warehouse_define_code,
      rqi.warehouse_define_name,
      rqi.concatenated_segments,
      rqi.category_description,
      rqi.item_id,
      rqi.item_code,
      rqi.item_desc,
      rqi.uom_code,
      rqi.uom_desc
    UNION ALL
    ----呆滞物资金额及数量
    SELECT rca.ou_id,
      rca.organization_id,
      (rca.organization_code
      ||' '
      ||rca.organization_name) orginfo,
      rca.warehouse_define_id,
      (rca.warehouse_define_code
      ||' '
      ||rca.warehouse_define_desc) warehouseinfo,
      rca.item_category_code,
      rca.item_category_name,
      rca.item_id,
      rca.item_code,
      rca.item_desc,
      rca.item_uom_code,
      rca.item_uom_desc,
      0 startaccount,
      0 endaccount,
      0 out_onhand_account,
      0 out_onhand_quantity,
      0 receive_onhand_account,
      0 receive_onhand_quantity,
      0 item_account,
      0 item_quantity,
      SUM(rca.item_account) isoveraccount
    FROM t_lis_report_core_ageinfo rca
    WHERE rca.isover=1
    GROUP BY rca.ou_id,
      rca.organization_id,
      rca.organization_code,
      rca.organization_name,
      rca.warehouse_define_id,
      rca.warehouse_define_code,
      rca.warehouse_define_desc,
      rca.item_category_code,
      rca.item_category_name,
      rca.item_id,
      rca.item_code,
      rca.item_desc,
      rca.item_uom_code,
      rca.item_uom_desc
    ) reslutdata
  GROUP BY reslutdata.ou_id,
    reslutdata.organization_id,
    reslutdata.orginfo,
    reslutdata.warehouse_define_id,
    reslutdata.warehouseinfo,
    reslutdata.item_category_code,
    reslutdata.item_category_name,
    reslutdata.item_id,
    reslutdata.item_code,
    reslutdata.item_desc,
    reslutdata.item_uom_code,
    reslutdata.item_uom_desc
/

