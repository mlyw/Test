create view V_CARD_PROCESS_TRANSACTIONS as
  select t.item_code 物料编码,
       twd.mis_subinventory_name 子库存,
       '0 期初' 交易类型,
       to_char(t.created_date, 'YYYY-MM-DD') 交易日期,
       null 导入MIS日期,
       t.onhand_quantity 交易数量,
       '0 期初' 单号,
       t.mis_pic_code MIS批次号,
       t.id 头ID,
       t.id 行ID
  from t_wh_onhand_quantity_init_0703 t, t_warehouse_define twd
 where t.warehouse_define_id = twd.id
   and twd.mis_subinventory_name like 'C%'
   -- and twd.mis_subinventory_name <> 'C990'
union
-- CNP接收，接收仓库现有量+
select trl.item_code 物料编码,
       twd.mis_subinventory_name 子库存,
       '1 CNP接收入库' 交易类型,
       to_char(trl.receipt_confirm_date, 'YYYY-MM-DD') 交易日期,
       to_char(trl.accounting_confrim_import_date, 'YYYY-MM-DD') 导入MIS日期,
       trl.current_receive_quantity 交易数量,
       trh.receipt_order_code 单号,
       trl.mis_pic_code MIS批次号,
       trh.id 头ID,
       trl.receiptorderlineid 行ID
  from t_receiptorder_headerinfo trh,
       t_receiptorder_lineinfo   trl,
       t_warehouse_define        twd
 where trh.id = trl.receipt_order_id
   and trl.warehouse_receive_id = twd.id
   and twd.mis_subinventory_name like 'C%'
   and trh.status = 1
   and trl.status = 1
   and trh.order_status = 5 -- ?已完成
union
-- CNP出库，发出仓库现有量-
select tol.item_code 物料编码,
       tol.subinventory_code 子库存,
       '3 CNP出库-发出' 交易类型,
       to_char(tom.trf_out_cfm_date, 'YYYY-MM-DD') 交易日期,
       to_char(tom.acc_cfm_imptomis_date, 'YYYY-MM-DD') 导入MIS日期,
       0 - tom.asgn_quty 交易数量,
       toh.out_ord_code 单号,
       tom.mis_pic_code MIS批次号,
       toh.id 头ID,
       tom.id 行ID
  from t_out_hd toh, t_out_ln tol, t_out_notmk tom
 where toh.id = tol.outhdinfo_id
   and tol.id = tom.outlninfo_id
   and tol.subinventory_code like 'C%'
   and toh.status = 1
   and tol.status = 1
   and tom.status = 1
   and tol.ord_ln_status >= 4 --CNP出库在发出确认后修改现有量，状态变为4在途
union
-- CNP出库，接收仓库现有量+
select tol.item_code 物料编码,
       tol.to_subinventory_code 子库存,
       '4 CNP出库-收入' 交易类型,
       to_char(tom.trf_out_cfm_date, 'YYYY-MM-DD') 交易日期,
       to_char(tom.acc_cfm_imptomis_date, 'YYYY-MM-DD') 导入MIS日期,
       tom.asgn_quty 交易数量,
       toh.out_ord_code 单号,
       tom.mis_pic_code MIS批次号,
       toh.id 头ID,
       tom.id 行ID
  from t_out_hd toh, t_out_ln tol, t_out_notmk tom
 where toh.id = tol.outhdinfo_id
   and tol.id = tom.outlninfo_id
   and tol.to_subinventory_code like 'C%'
   and toh.status = 1
   and tol.status = 1
   and tom.status = 1
   and tol.ord_ln_status >= 4 --CNP出库在发出确认后修改现有量，状态变为4在途
   -- and tol.to_subinventory_code <> 'C990'
union
-- SIM卡销售月结，销售仓库现有量-
select tsi.item_code 物料编码,
       twd.mis_subinventory_name 子库存,
       '5 SIM卡销售月结' 交易类型,
       to_char(tsl.trade_date, 'YYYY-MM-DD') 交易日期,
       to_char(tsh.transaction_processing_time, 'YYYY-MM-DD') 导入MIS日期,
       0 - tsl.simcard_qty 交易数量,
       tsh.simcard_order_code 单号,
       tsl.line_pic MIS批次号,
       tsh.id 头ID,
       tsl.id 行ID
  from t_lis_simcard_sales_month_head tsh,
       t_lis_simcard_sales_month_line tsl,
       t_warehouse_define             twd,
       t_sys_erp_items                tsi
 where tsh.id = tsl.head_id
   and tsl.wd_id = twd.id
   and tsl.item_id = tsi.seq_id
   and tsh.status = 1
   and tsl.status = 1
   and tsh.head_status = 4
   and tsl.line_status = 4
union
-- RM销售，按照RM传来的数据进行增减
select tls.item_code 物料编码,
       tls.subinventory_code 子库存,
       '6 RM销售' 交易类型,
       to_char(tls.transcation_date, 'YYYY-MM-DD') 交易日期,
       to_char(tls.transcation_date, 'YYYY-MM-DD') 导入MIS日期,
       tls.quantity 交易数量,
       tls.origin_filename 单号,
       tls.erp_order_batch MIS批次号,
       tls.seq_id 头ID,
       tls.seq_id 行ID
  from t_lis_rm_sales tls
 where nvl(tls.flag, 'X') = 'Y'
   and tls.status = 1
union
-- 坏卡报废，发出仓库现有量-
select t.item_code 物料编码,
       t.src_subinventory 子库存,
       '7 坏卡报废手工处理' 交易类型,
       to_char(t.created_date, 'YYYY-MM-DD') 交易日期,
       null 导入MIS日期,
       t.quantity 交易数量,
       null 单号,
       'S1000000000' MIS批次号,
       t.seq_id 头ID,
       t.seq_id 行ID
  from t_lis_badcard_trout t
 where nvl(t.flag,'X') =  'Y'
   and t.src_subinventory not like '？？？%'
union
-- 坏卡报废，接收仓库现有量+
select t.item_code 物料编码,
       t.to_subinventory 子库存,
       '7 坏卡报废手工处理' 交易类型,
       to_char(t.created_date, 'YYYY-MM-DD') 交易日期,
       null 导入MIS日期,
       t.quantity 交易数量,
       null 单号,
       'S1000000000' MIS批次号,
       t.seq_id 头ID,
       t.seq_id 行ID
  from t_lis_badcard_trout t
 where nvl(t.flag,'X') =  'Y'
   and t.src_subinventory = 'C999'
union
-- 营业厅调拨，发出仓库现有量-
select tcl.item_code 物料编码,
       twd_from.mis_subinventory_name 子库存,
       '8 营业厅调拨' 交易类型,
       to_char(tch.account_date, 'YYYY-MM-DD') 交易日期,
       to_char(tch.account_date, 'YYYY-MM-DD') 导入MIS日期,
       0 - tcl.change_quty 交易数量,
       tch.wh_chg_ord_code 单号,
       tcl.mis_pic_code MIS批次号,
       tch.id 头ID,
       tcl.id 行ID
  from t_chg_hd_ln tch, t_chg_ln tcl, t_warehouse_define twd_from, t_warehouse_define twd_to
 where tch.id = tcl.chghdln_id
 and tcl.wh_id_trf_from = twd_from.id
 and tcl.wh_id_trf_into = twd_to.id
 and twd_from.mis_subinventory_name like 'C%'
 and tch.order_status = 50
 and tch.status = 1
 and tcl.status = 1
union
-- 营业厅调拨，接收仓库现有量+
select tcl.item_code 物料编码,
       twd_to.mis_subinventory_name 子库存,
       '8 营业厅调拨' 交易类型,
       to_char(tch.account_date, 'YYYY-MM-DD') 交易日期,
       to_char(tch.account_date, 'YYYY-MM-DD') 导入MIS日期,
       tcl.change_quty 交易数量,
       tch.wh_chg_ord_code 单号,
       tcl.mis_pic_code MIS批次号,
       tch.id 头ID,
       tcl.id 行ID
  from t_chg_hd_ln tch, t_chg_ln tcl, t_warehouse_define twd_from, t_warehouse_define twd_to
 where tch.id = tcl.chghdln_id
 and tcl.wh_id_trf_from = twd_from.id
 and tcl.wh_id_trf_into = twd_to.id
 and twd_from.mis_subinventory_name like 'C%'
 and tch.order_status = 50
 and tch.status = 1
 and tcl.status = 1
union
-- 坏卡报废，发出仓库现有量-
select tsi.item_code 物料编码,
       twd.warehouse_define_code 子库存,
       '9 坏卡报废系统处理' 交易类型,
       to_char(trl.receive_confirm_date, 'YYYY-MM-DD') 交易日期,
       to_char(trl.accounted_date, 'YYYY-MM-DD') 导入MIS日期,
       0 - nvl(trl.actual_qty, 0) 交易数量,
       trh.order_code 单号,
       trl.mis_pic_num MIS批次号,
       trh.seq_id 头ID,
       trl.seq_id 行ID
  from t_refundwastecard_head trh,
       t_refundwastecard_line trl,
       t_sys_erp_items        tsi,
       t_warehouse_define     twd
 where trh.seq_id = trl.head_id
   and trl.item_id = tsi.seq_id
   and trl.sub_wd_id = twd.id
   and trh.status = 1
   and trl.status = 1
   and trh.order_status = 7
   and trl.order_line_status = 7
union
-- 坏卡报废，接收仓库现有量+
select tsi.item_code 物料编码,
       twd.warehouse_define_code 子库存,
       '9 坏卡报废系统处理' 交易类型,
       to_char(trl.receive_confirm_date, 'YYYY-MM-DD') 交易日期,
       to_char(trl.accounted_date, 'YYYY-MM-DD') 导入MIS日期,
       nvl(trl.actual_qty, 0) 交易数量,
       trh.order_code 单号,
       trl.mis_pic_num MIS批次号,
       trh.seq_id 头ID,
       trl.seq_id 行ID
  from t_refundwastecard_head trh,
       t_refundwastecard_line trl,
       t_sys_erp_items        tsi,
       t_warehouse_define     twd
 where trh.seq_id = trl.head_id
   and trl.item_id = tsi.seq_id
   and trl.receive_wd_id = twd.id
   and trh.status = 1
   and trl.status = 1
   and trh.order_status = 7
   and trl.order_line_status = 7
order by 物料编码, 子库存, 导入MIS日期, 交易类型
/

