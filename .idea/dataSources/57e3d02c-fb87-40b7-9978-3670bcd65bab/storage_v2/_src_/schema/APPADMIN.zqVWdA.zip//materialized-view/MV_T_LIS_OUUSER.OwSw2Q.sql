create materialized view MV_T_LIS_OUUSER
refresh force on demand
  as
    SELECT
  /**每6小时运行一次:START WITH SYSDATE NEXT SYSDATE + 21600/86400*/
  tmp.*,
    d.dept_name,
    sysdate builddate,
    CASE
      WHEN (instr(d.dept_name, '/') > 0)
      THEN SUBSTR(d.dept_name,0,(INSTR(d.dept_name,'/',1,1)-1))
      ELSE d.dept_name
    END AS company
  FROM
    (SELECT o.ou_employee_number,
      u.employee_name,
      u.dept_id
    FROM t_lis_ouuser o,
      t_lis_user u
    WHERE o.employee_number=u.employee_number
    ) tmp
  LEFT JOIN t_lis_dept d
  ON tmp.dept_id=d.id
  AND d.status  =1

/

