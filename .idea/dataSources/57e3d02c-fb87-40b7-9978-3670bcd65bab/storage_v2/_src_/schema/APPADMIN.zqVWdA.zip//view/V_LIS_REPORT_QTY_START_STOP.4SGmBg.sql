create view V_LIS_REPORT_QTY_START_STOP as
  SELECT
    /**以ou/库存/物料分类/物料为维度的期初期末以及年度集采现有量视图*/
    tmp.bussiness_date,
    tmp.ou_id,
    tmp.organization_id,
    tmp.item_category_code,
    tmp.item_category_name,
    tmp.item_id,
    tmp.item_code,
    tmp.item_desc,
    tmp.item_uom_code,
    tmp.item_uom_desc,
    tmp.startaccount,
    tmp.startqty,
    tmp.endaccount,
    tmp.endqty,
    NVL(tmp1.collectaccount,0) collectaccount
  FROM
    (SELECT lrc.bussiness_date,
      lrc.ou_id,
      lrc.organization_id,
      lrc.item_category_code,
      lrc.item_category_name,
      lrc.item_id,
      lrc.item_code,
      lrc.item_desc,
      lrc.item_uom_code,
      lrc.item_uom_desc,
      SUM(lrc.onhand_quantity_account) startaccount,
      SUM(lrc.onhand_quantity) startqty,
      0 endaccount,
      0 endqty
    FROM t_lis_report_core_onhandqty lrc,
      t_wh_current_onhand_quantity t,
      t_receiptorder_lineinfo rl
    WHERE lrc.data_type        =1
    AND lrc.item_id            =t.item_id
    AND lrc.item_desc          =t.item_desc
    AND lrc.item_code          =t.item_code
    AND lrc.item_uom_code      =t.uom_code
    AND lrc.item_uom_desc      =t.uom_desc
    AND lrc.warehouse_define_id=t.warehouse_define_id
    AND t.receipt_pic_code     =rl.receipt_pic_code
    AND t.receipt_pic_code    IS NOT NULL
    AND lrc.bussiness_date     =TO_CHAR(rl.accounting_confirm_date,'yyyyMM')
    GROUP BY lrc.bussiness_date,
      lrc.ou_id,
      lrc.organization_id,
      lrc.item_category_code,
      lrc.item_category_name,
      lrc.item_id,
      lrc.item_code,
      lrc.item_desc,
      lrc.item_uom_code,
      lrc.item_uom_desc
    UNION ALL
    ---期末金额
    SELECT lrc.bussiness_date,
      lrc.ou_id,
      lrc.organization_id,
      lrc.item_category_code,
      lrc.item_category_name,
      lrc.item_id,
      lrc.item_code,
      lrc.item_desc,
      lrc.item_uom_code,
      lrc.item_uom_desc,
      0 startaccount,
      0 startqty,
      SUM(lrc.onhand_quantity_account) endaccount,
      SUM(lrc.onhand_quantity) endqty
    FROM t_lis_report_core_onhandqty lrc,
      t_wh_current_onhand_quantity t,
      t_receiptorder_lineinfo rl
    WHERE lrc.data_type        =2
    AND lrc.item_id            =t.item_id
    AND lrc.item_desc          =t.item_desc
    AND lrc.item_code          =t.item_code
    AND lrc.item_uom_code      =t.uom_code
    AND lrc.item_uom_desc      =t.uom_desc
    AND lrc.warehouse_define_id=t.warehouse_define_id
    AND t.receipt_pic_code     =rl.receipt_pic_code
    AND t.receipt_pic_code    IS NOT NULL
    AND lrc.bussiness_date     =TO_CHAR(rl.accounting_confirm_date,'yyyyMM')
    GROUP BY lrc.bussiness_date,
      lrc.ou_id,
      lrc.organization_id,
      lrc.item_category_code,
      lrc.item_category_name,
      lrc.item_id,
      lrc.item_code,
      lrc.item_desc,
      lrc.item_uom_code,
      lrc.item_uom_desc
    UNION ALL
    ---计算库存物资占比使用的当前月的期末金额
    SELECT TO_CHAR(sysdate,'yyyyMM') bussinessdate,
      w.mis_ou_id ou_id,
      w.mis_io_id organization_id,
      i.concatenated_segments item_category_code,
      i.category_description item_category_name,
      q.item_id,
      q.item_code,
      q.item_desc,
      q.uom_code item_uom_code,
      q.uom_desc item_uom_desc,
      0 startaccount,
      0 startqty,
      SUM(NVL(q.onhand_quantity,0)*NVL(q.cost_unit_price,0)) endaccount,
      SUM(NVL(q.onhand_quantity,0)) endqty
    FROM t_wh_current_onhand_quantity q,
      mv_warehouse_define w,
      t_sys_erp_items i,
      t_receiptorder_lineinfo rl
    WHERE q.status               =1
    AND w.status                 =1
    AND i.status                 =1
    AND TO_CHAR(sysdate,'yyyyMM')=TO_CHAR(rl.accounting_confirm_date,'yyyyMM')
    AND q.warehouse_define_id    =w.id
    AND q.item_id                =i.seq_id
    AND NVL(q.onhand_quantity,0) >0
    AND q.receipt_pic_code       =rl.receipt_pic_code
    AND q.receipt_pic_code      IS NOT NULL
    GROUP BY w.mis_ou_id,
      w.mis_io_id,
      i.concatenated_segments,
      i.category_description,
      q.item_id,
      q.item_code,
      q.item_desc,
      q.uom_code,
      q.uom_desc
    ) tmp
  LEFT JOIN
    (
    ---截止到当天的年度集采金额
    SELECT rqo.po_ou_id,
      rqo.pol_organization_id,
      rqo.concatenated_segments,
      rqo.category_description,
      rqo.item_id,
      rqo.po_item_code,
      rqo.po_item_desc,
      rqo.po_uom_code,
      rqo.po_uom_desc,
      SUM(NVL(rqo.collectaccount,0)) collectaccount
    FROM v_lis_report_qty_order rqo
    WHERE rqo.bussiness_date>'201612'
    GROUP BY rqo.po_ou_id,
      rqo.pol_organization_id,
      rqo.concatenated_segments,
      rqo.category_description,
      rqo.item_id,
      rqo.po_item_code,
      rqo.po_item_desc,
      rqo.po_uom_code,
      rqo.po_uom_desc
    ) tmp1
  ON tmp.ou_id              =tmp1.po_ou_id
  AND tmp.organization_id   =tmp1.pol_organization_id
  AND tmp.item_category_code=tmp1.concatenated_segments
  AND tmp.item_category_name=tmp1.category_description
  AND tmp.item_id           =tmp1.item_id
  AND tmp.item_code         =tmp1.po_item_code
  AND tmp.item_desc         =tmp1.po_item_desc
  AND tmp.item_uom_code     =tmp1.po_uom_code
  AND tmp.item_uom_desc     =tmp1.po_uom_desc
/

