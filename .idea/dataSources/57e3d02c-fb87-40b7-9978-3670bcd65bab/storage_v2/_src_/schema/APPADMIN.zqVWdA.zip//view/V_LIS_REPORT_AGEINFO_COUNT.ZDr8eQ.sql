create view V_LIS_REPORT_AGEINFO_COUNT as
  SELECT
    /**库龄统计报表原始数据查询视图*/
    t."CREATE_DATE",
    t."BUSSINESS_DATE",
    t."STRING_VALUE1",
    t."STATUS",
    t."VERSION",
    t."ITEM_CODE",
    t."ITEM_DESC",
    t."ITEM_ID",
    t."ITEM_UOM_CODE",
    t."ITEM_UOM_DESC",
    t."ITEM_CATEGORY_CODE",
    t."ITEM_CATEGORY_NAME",
    t."WAREHOUSE_DEFINE_ID",
    t."WAREHOUSE_DEFINE_CODE",
    t."WAREHOUSE_DEFINE_DESC",
    t."OU_ID",
    t."OU_NAME",
    t."ORGANIZATION_CODE",
    t."ORGANIZATION_NAME",
    t."ORGANIZATION_ID",
    t."RECEIPT_PIC_CODE",
    t."ITEM_RECEIVE_DATE",
    t."ITEM_COUNT",
    t."ITEM_ACCOUNT",
    t."ISOVER",
    t."ITEM_AGE",
    t."AGE_7TO9",
    t."AGE_10TO12",
    t."AGE_13TO18",
    t."AGE_19TO24",
    t."AGE_25MORE",
    t."PRODUCT_UNIT_PRICE",
    t."MIS_PIC_CODE",
    t."VENDOR_ID",
    t."LOCATOR_CODE",
    t."LOCATOR_ID",
    t."PROJECT_ID",
    t."PROJECT_NAME",
    t."PROJECT_NUMBER",
    t."VENDOR_NAME",
    tmp.MIS_PO_NUMBER PO_NUMBER ,
    tmp.spm_po_desc po_desc
  FROM T_LIS_REPORT_CORE_AGEINFO t
  LEFT JOIN
    (SELECT B.MIS_PO_NUMBER,
      b.spm_po_desc,
      l.receipt_pic_code
    FROM t_receiptorder_headerinfo h,
      t_receiptorder_lineinfo l,
      t_base_spm_pur_order_headers b
    WHERE l.receipt_order_id =h.id
    AND h.po_id              =b.spm_po_header_id
    ) tmp
  ON t.receipt_pic_code=tmp.receipt_pic_code
/

