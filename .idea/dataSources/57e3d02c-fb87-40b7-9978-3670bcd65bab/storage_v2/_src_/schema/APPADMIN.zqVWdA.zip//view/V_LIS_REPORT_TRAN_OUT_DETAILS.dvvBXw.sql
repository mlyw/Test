create view V_LIS_REPORT_TRAN_OUT_DETAILS as
  SELECT tmp.accounted_date import_date,
    tmp.seq_id order_id,
    i.item_code,
    tmp.item_id,
    i.item_name item_desc,
    i.uom_code,
    i.uom_desc,
    tmp.sub_wd_id warehouse_out_id,
    tmp.order_type,
    tmp.order_desc ordercomtent,
    tmp.actual_qty current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.actual_qty,0) current_out_account,
    NULL project_code,
    l.employee_name liaozhang_name,
    s.employee_name shiwu_name,
    d.hall_dept_name company,
    (d.warehouse_define_code
    ||' '
    ||d.warehouse_define_name) hall
  FROM
    (SELECT rl.item_id,
      rl.sub_wd_id,
      0 product_unit_price,
      rl.actual_qty,
      rl.accounted_date,
      rh.seq_id,
      '报废卡退库' order_type,
      rl.receive_confirm_user,
      rl.accounted_user,
      rh.order_desc
    FROM t_refundwastecard_head rh,
      t_refundwastecard_line rl
    WHERE rh.status                            =1
    AND rl.status                              =1
    AND rh.order_status                        =7
    AND rl.order_line_status                   =7
    AND TO_CHAR(rl.accounted_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN MV_sys_shm_hall d
  ON tmp.sub_wd_id=d.id
  LEFT JOIN MV_T_LIS_OUUSER l
  ON tmp.accounted_user=l.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER s
  ON tmp.receive_confirm_user=s.ou_employee_number
  UNION ALL
  ----rm销售数据 营业厅销售出去的数据
  SELECT rs.transcation_date import_date,
    rs.seq_id order_id,
    rs.item_code,
    rs.item_id,
    i.item_name item_desc,
    i.uom_code,
    i.uom_desc,
    d.id warehouse_out_id ,
    '有价卡销售' order_type,
    'RM系统导入有价卡销售' ordercomtent,
    NVL(rs.quantity,0) current_out_quantity,
    0*NVL(rs.quantity,0) current_out_account,
    NULL project_code,
    NULL liaozhang_name,------料帐人
    NULL shiwu_name,    ------实物管理员
    d.hall_dept_name company,
    (d.warehouse_define_code
    ||' '
    ||d.warehouse_define_name) hall
  FROM t_lis_rm_sales rs
  LEFT JOIN t_sys_erp_items i
  ON rs.item_id=i.seq_id
  LEFT JOIN MV_sys_shm_hall d
  ON rs.subinventory_code                      =d.warehouse_define_code
  WHERE NVL(rs.quantity,0)                     >0
  AND TO_CHAR(rs.transcation_date,'yyyy-MM-dd')>'2016-12-31'
  AND NVL(rs.flag,'')                          ='Y'
  UNION ALL
  ----SIM卡销售月结-销售数量
  SELECT tmp.transaction_processing_time import_date,
    tmp.id order_id,
    i.item_code,
    tmp.item_id,
    i.item_name item_desc,
    i.uom_code,
    i.uom_desc,
    tmp.wd_id warehouse_out_id,
    tmp.order_type,
    tmp.order_type ordercomtent,
    tmp.simcard_qty current_out_quantity,
    0*NVL(tmp.simcard_qty,0) current_out_account,
    NULL project_code,
    l.employee_name liaozhang_name,
    s.employee_name shiwu_name,
    d.hall_dept_name company,
    (d.warehouse_define_code
    ||' '
    ||d.warehouse_define_name) hall
  FROM
    (SELECT sl.item_id,
      sl.wd_id,
      sl.simcard_qty simcard_qty,
      sh.transaction_processing_time,
      sh.id,
      'SIM卡销售' order_type,
      sh.created_user shiwu,
      sl.last_updated_user liaozhang
    FROM T_Lis_Simcard_Sales_Month_Head sh,
      T_Lis_Simcard_Sales_Month_Line sl
    WHERE sl.status                                         =1
    AND sh.status                                           =1
    AND sl.head_id                                          =sh.id
    AND sh.head_status                                      =4
    AND sl.line_status                                      =4
    AND TO_CHAR(sh.transaction_processing_time,'yyyy-MM-dd')>'2016-12-31'
    AND NVL(sl.simcard_qty,0)                               >0
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN MV_sys_shm_hall d
  ON tmp.wd_id=d.id
  LEFT JOIN MV_T_LIS_OUUSER l
  ON tmp.liaozhang=l.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER s
  ON tmp.shiwu=s.ou_employee_number
  UNION ALL
  ---调拨-调出方
  SELECT tmp.account_date import_date,
    tmp.id order_id,
    tmp.item_code,
    tmp.item_id,
    tmp.item_desc,
    tmp.uom_code,
    tmp.uom_desc,
    tmp.wh_id_trf_from warehouse_out_id,
    tmp.order_type order_type,
    tmp.wh_chg_desc ordercomtent,
    tmp.change_quty current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.change_quty,0) current_out_account,
    p.project_code,
    l.employee_name liaozhang_name,
    s.employee_name shiwu_name,
    d.hall_dept_name company,
    (d.warehouse_define_code
    ||' '
    ||d.warehouse_define_name) hall
  FROM
    (SELECT hl.item_id,
      hl.item_code,
      hl.uom_desc,
      hl.uom_code,
      hl.item_desc,
      hl.wh_id_trf_from,
      NVL(hl.product_unit_price,0) product_unit_price,
      hl.change_quty,
      hd.account_date,
      hd.id,
      '调拨' order_type,
      hd.wh_chg_desc,
      hl.acc_cfm_byuser_id liaozhang,
      hd.ware_receipt_user shiwu,
      hl.prj_id_trf_from
    FROM t_chg_hd_ln hd,
      t_chg_ln hl
    WHERE hd.status                          =1
    AND hl.status                            =1
    AND hd.order_status                     IN (5,50)
    AND hl.chghdln_id                        =hd.id
    AND TO_CHAR(hd.account_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN MV_sys_shm_hall d
  ON tmp.wh_id_trf_from=d.id
  LEFT JOIN t_sys_erp_projects p
  ON tmp.prj_id_trf_from=p.seq_id
  LEFT JOIN MV_T_LIS_OUUSER l
  ON tmp.liaozhang=l.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER s
  ON tmp.shiwu=s.ou_employee_number
  UNION ALL
  ---工程及cnp出库,杂发
  SELECT tmp.acc_cfm_date import_date,
    tmp.id order_id,
    tmp.item_code,
    tmp.item_id,
    i.item_name item_desc,
    i.uom_code,
    i.uom_desc,
    tmp.warehouseid warehouse_out_id,
    tmp.order_type,
    tmp.ord_desc ordercomtent,
    tmp.Acpt_Cfm_Quty current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.Acpt_Cfm_Quty,0) current_out_account,
    p.project_code project_code,
    l.employee_name liaozhang_name,
    s.employee_name shiwu_name,
    d.hall_dept_name company,
    (d.warehouse_define_code
    ||' '
    ||d.warehouse_define_name) hall
  FROM
    (SELECT om.item_id,
      om.item_code,
      om.warehouseid,
      om.product_unit_price,
      om.Acpt_Cfm_Quty,
      om.acc_cfm_date,
      oh.id,
      CASE
        WHEN oh.item_type_id=5
        THEN '杂发'
        ELSE '出库'
      END AS order_type,
      oh.ord_desc,
      oh.project_id,
      om.acc_cfm_byuser_id,
      om.acpt_cfm_byuser_id
    FROM t_out_hd oh,
      t_out_ln ol,
      t_out_notmk om
    WHERE oh.status                          =1
    AND ol.status                            =1
    AND om.status                            =1
    AND ol.Outhdinfo_Id                      =oh.id
    AND om.Outlninfo_Id                      =ol.id
    AND oh.item_type_id                     IN (1,5,2)
    AND oh.ord_status                        =6
    AND om.asgn_ln_status                    =1
    AND ol.ord_ln_status                     =7
    AND TO_CHAR(om.acc_cfm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN MV_sys_shm_hall d
  ON tmp.warehouseid=d.id
  LEFT JOIN t_sys_erp_projects p
  ON tmp.project_id=p.seq_id
  LEFT JOIN MV_T_LIS_OUUSER l
  ON tmp.acc_cfm_byuser_id=l.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER s
  ON tmp.acpt_cfm_byuser_id=s.ou_employee_number
  UNION ALL
  ----综合出库
  SELECT tmp.acc_cfm_date import_date,
    tmp.id order_id,
    tmp.item_code,
    tmp.item_id,
    i.item_name item_desc,
    i.uom_code,
    i.uom_desc,
    tmp.warehouseid warehouse_out_id,
    tmp.order_type,
    tmp.ord_desc ordercomtent,
    tmp.Asgn_Quty current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.Asgn_Quty,0) current_out_account,
    p.project_code project_code,
    l.employee_name liaozhang_name,
    s.employee_name shiwu_name,
    d.hall_dept_name company,
    (d.warehouse_define_code
    ||' '
    ||d.warehouse_define_name) hall
  FROM
    (SELECT om.item_id,
      om.item_code,
      om.warehouseid,
      om.product_unit_price,
      om.Asgn_Quty,
      om.acc_cfm_date,
      oh.id,
      oh.out_ord_code,
      CASE
        WHEN oh.item_type_id=86
        THEN '杂发'
        ELSE '出库'
      END AS order_type,
      oh.ord_desc,
      oh.project_id,
      om.acc_cfm_byuser_id,
      om.acpt_cfm_byuser_id
    FROM t_out_hd oh,
      t_out_ln ol,
      t_out_notmk om
    WHERE oh.status                          =1
    AND ol.status                            =1
    AND om.status                            =1
    AND ol.Outhdinfo_Id                      =oh.id
    AND om.Outlninfo_Id                      =ol.id
    AND oh.item_type_id                     IN (84,86)
    AND oh.ord_status                        =6
    AND om.asgn_ln_status                    =1
    AND ol.ord_ln_status                     =7
    AND TO_CHAR(om.acc_cfm_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN MV_sys_shm_hall d
  ON tmp.warehouseid=d.id
  LEFT JOIN t_sys_erp_projects p
  ON tmp.project_id=p.seq_id
  LEFT JOIN MV_T_LIS_OUUSER l
  ON tmp.acc_cfm_byuser_id=l.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER s
  ON tmp.acpt_cfm_byuser_id=s.ou_employee_number
  UNION ALL
  ---退货单据 普通退货 不需要分公司信息
  SELECT tmp.accounting_confirm_import_date import_date,
    tmp.id order_id,
    i.item_code,
    tmp.item_id,
    i.item_name item_desc,
    i.uom_code,
    i.uom_desc,
    tmp.warehouse_define_id warehouse_out_id,
    tmp.order_type,
    tmp.return_desc ordercomtent,
    tmp.return_quantity current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.return_quantity,0) current_out_account,
    p.project_code project_code,
    l.employee_name liaozhang_name,
    s.employee_name shiwu_name,
    NULL company,
    NULL hall
  FROM
    (SELECT trh.id,
      trl.return_quantity,
      trl.item_id,
      trl.warehouse_define_id,
      trl.product_unit_price,
      trl.accounting_confirm_import_date,
      '退货' order_type,
      trl.project_id,
      trh.return_desc,
      trl.accounting_confirm_by_uid,
      trl.return_confirm_by_uid
    FROM t_returnorder_headerinfo trh,
      t_returnorder_lineinfo trl
    WHERE trl.return_order_id=trh.id
    AND trh.status           =1
    AND trl.status           =1
    AND trh.order_status     =4
    AND trh.return_order_code NOT LIKE '%ZHTH%'
    AND TO_CHAR(trl.accounting_confirm_import_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_sys_erp_projects p
  ON tmp.project_id=p.seq_id
  LEFT JOIN MV_T_LIS_OUUSER l
  ON tmp.accounting_confirm_by_uid=l.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER s
  ON tmp.return_confirm_by_uid=s.ou_employee_number
  UNION ALL
  ---退货单据 综合退货 需要按照创建人得到分公司
  SELECT tmp.accounting_confirm_import_date import_date,
    tmp.id order_id,
    i.item_code,
    tmp.item_id,
    i.item_name item_desc,
    i.uom_code,
    i.uom_desc,
    tmp.warehouse_define_id warehouse_out_id,
    tmp.order_type,
    tmp.return_desc ordercomtent,
    tmp.return_quantity current_out_quantity,
    NVL(tmp.product_unit_price,0)*NVL(tmp.return_quantity,0) current_out_account,
    p.project_code project_code,
    l.employee_name liaozhang_name,
    s.employee_name shiwu_name,
    f.company company,
    NULL hall
  FROM
    (SELECT trh.id,
      trl.return_quantity,
      trl.item_id,
      trl.warehouse_define_id,
      trl.product_unit_price,
      trl.accounting_confirm_import_date,
      '退货' order_type,
      trl.project_id,
      trh.return_desc,
      trl.accounting_confirm_by_uid,
      trl.return_confirm_by_uid,
      trh.order_created_by_uid
    FROM t_returnorder_headerinfo trh,
      t_returnorder_lineinfo trl
    WHERE trl.return_order_id=trh.id
    AND trh.status           =1
    AND trl.status           =1
    AND trh.order_status     =4
    AND trh.return_order_code LIKE '%ZHTH%'
    AND TO_CHAR(trl.accounting_confirm_import_date,'yyyy-MM-dd')>'2016-12-31'
    ) tmp
  LEFT JOIN t_sys_erp_items i
  ON tmp.item_id=i.seq_id
  LEFT JOIN t_sys_erp_projects p
  ON tmp.project_id=p.seq_id
  LEFT JOIN MV_T_LIS_OUUSER l
  ON tmp.accounting_confirm_by_uid=l.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER s
  ON tmp.return_confirm_by_uid=s.ou_employee_number
  LEFT JOIN MV_T_LIS_OUUSER f
  ON tmp.order_created_by_uid=f.ou_employee_number
/

